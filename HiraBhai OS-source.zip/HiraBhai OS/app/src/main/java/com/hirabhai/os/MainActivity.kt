package com.hirabhai.os

import android.app.Activity
import android.app.ActivityManager
import android.app.admin.DevicePolicyManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.view.View
import android.webkit.*
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
 private var lastYoutubeLaunch = 0L
 private var fileChooserCallback: ValueCallback<Array<Uri>>? = null
 private val channelUrl = "https://youtube.com/@thehirabhai"

 private fun openYoutubeChannel() {
  val now = android.os.SystemClock.elapsedRealtime()
  if (now - lastYoutubeLaunch < 2000L) return
  lastYoutubeLaunch = now
  try {
   startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(channelUrl)).setPackage("com.google.android.youtube"))
  } catch (_: Exception) {
   try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(channelUrl))) } catch (_: Exception) { }
  }
 }

 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  window.statusBarColor = Color.rgb(4, 8, 12)
  window.navigationBarColor = Color.rgb(4, 8, 12)
  window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv() or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
  val web = WebView(this)
  web.setBackgroundColor(Color.rgb(4, 8, 12))
  web.settings.javaScriptEnabled = true
  web.settings.domStorageEnabled = true
  web.addJavascriptInterface(object {
   @JavascriptInterface fun openYoutube() { runOnUiThread { openYoutubeChannel() } }
   @JavascriptInterface fun openSettings() { runOnUiThread { try { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)) } catch (_: Exception) { } } }
   @JavascriptInterface fun getSystemInfo(): String {
    val result = JSONObject()
    try {
     val battery = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
     val level = battery?.getIntExtra("level", -1) ?: -1
     val scale = battery?.getIntExtra("scale", -1) ?: -1
     if (level >= 0 && scale > 0) {
      result.put("battery", (level * 100 / scale).coerceIn(0, 100))
      val status = battery?.getIntExtra("status", -1) ?: -1
      result.put("charging", status == android.os.BatteryManager.BATTERY_STATUS_CHARGING || status == android.os.BatteryManager.BATTERY_STATUS_FULL)
     } else result.put("battery", JSONObject.NULL)
    } catch (_: Exception) { result.put("battery", JSONObject.NULL) }
    result.put("device", listOf(android.os.Build.MANUFACTURER, android.os.Build.MODEL).joinToString(" ").trim())
    result.put("android", android.os.Build.VERSION.RELEASE ?: "")
    try {
     val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
     val network = cm.activeNetwork
     result.put("network", if (network != null && cm.getNetworkCapabilities(network) != null) "Connected" else "Offline")
    } catch (_: Exception) { result.put("network", "Unavailable") }
    return result.toString()
   }
   @JavascriptInterface fun getInstalledApps(): String {
    val apps = JSONArray()
    try {
     val launchIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
     val resolved = packageManager.queryIntentActivities(launchIntent, 0)
     val seen = HashSet<String>()
     for (item in resolved) {
      val info = item.activityInfo?.applicationInfo ?: continue
      if (info.packageName == packageName || !seen.add(info.packageName)) continue
      val app = JSONObject()
      app.put("name", packageManager.getApplicationLabel(info).toString())
      app.put("package", info.packageName)
      app.put("category", if (info.category == ApplicationInfo.CATEGORY_GAME) "Games" else "Apps")
      try {
       val icon = packageManager.getApplicationIcon(info)
       val bitmap = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888)
       val canvas = Canvas(bitmap)
       icon.setBounds(0, 0, canvas.width, canvas.height)
       icon.draw(canvas)
       val bytes = java.io.ByteArrayOutputStream().also { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }.toByteArray()
       app.put("icon", "data:image/png;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP))
       bitmap.recycle()
      } catch (_: Exception) { }
      apps.put(app)
     }
    } catch (_: Exception) { }
    return apps.toString()
   }
   @JavascriptInterface fun launchApp(appPackage: String) {
    runOnUiThread {
     try {
      val launch = packageManager.getLaunchIntentForPackage(appPackage) ?: return@runOnUiThread
      startActivity(launch)
     } catch (_: Exception) { }
    }
   }
   @JavascriptInterface fun getSecurityStatus(): String {
    val result = JSONObject()
    val policy = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
    val deviceOwner = try { policy.isDeviceOwnerApp(packageName) } catch (_: Exception) { false }
    val profileOwner = try { policy.isProfileOwnerApp(packageName) } catch (_: Exception) { false }
    val lockTask = try {
     (getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).lockTaskModeState != ActivityManager.LOCK_TASK_MODE_NONE
    } catch (_: Exception) { false }
    result.put("deviceOwner", deviceOwner)
    result.put("profileOwner", profileOwner)
    result.put("management", deviceOwner || profileOwner)
    result.put("kiosk", lockTask)
    return result.toString()
   }
  }, "Hira")
  web.webChromeClient = object : WebChromeClient() {
   override fun onShowFileChooser(view: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?): Boolean {
    fileChooserCallback?.onReceiveValue(null)
    fileChooserCallback = callback
    return try {
     startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE), 41)
     true
    } catch (_: Exception) { fileChooserCallback = null; false }
   }
  }
  web.webViewClient = object : WebViewClient() {
   override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
    val url = request?.url?.toString() ?: return false
    if (url.startsWith("https://youtube.com")) {
     try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) { }
     return true
    }
    return false
   }
  }
  setContentView(web)
  web.loadUrl("file:///android_asset/index.html")
 }

 @Deprecated("Handled by the visible web screen first")
 override fun onBackPressed() {
  val web = findViewById<WebView>(android.R.id.content)
  if (web == null) { super.onBackPressed(); return }
  web.evaluateJavascript("window.handleAndroidBack ? window.handleAndroidBack() : false") { handled ->
   if (handled != "true") super.onBackPressed()
  }
 }

 @Deprecated("Handled for the wallpaper picker")
 override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
  super.onActivityResult(requestCode, resultCode, data)
  if (requestCode == 41) {
   val result = if (resultCode == RESULT_OK && data?.data != null) arrayOf(data.data!!) else null
   fileChooserCallback?.onReceiveValue(result)
   fileChooserCallback = null
  }
 }
}
