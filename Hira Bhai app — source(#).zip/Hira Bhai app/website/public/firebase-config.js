// Firebase web REST configuration. This API key is a public project identifier, not a secret.
// Firestore/Storage rules enforce authorization; restrict the key to required Firebase APIs.
window.HIRA_FIREBASE_CONFIG = {
  apiKey: "AIzaSyC43mwOKPEAZlMWNLMDd4leP3_nEEmzpdA",
  projectId: "hira-bhai",
  storageBucket: "hira-bhai.firebasestorage.app"
};
