# AI creator website builder and hosting setup

The Android editor saves a creator-owned site document at `creatorWebsites/{username}`. Unpublished documents are owner-only; published documents can be fetched by their exact username. The hosted page reads only `publicProfiles/{username}`, that published website document, and public videos belonging to the creator.

## Enable AI generation and publish websites

1. In Google AI Studio, create a Gemini API key. In Firebase Console, switch the project to the **Blaze** plan and link billing before deploying Cloud Functions. Cloud Functions deployment requires Blaze; set budget alerts.
2. From the project root, sign in to Firebase CLI and store the Gemini key as a server secret for project `hira-bhai`:

   ```sh
   firebase login
   firebase functions:secrets:set GEMINI_API_KEY --project hira-bhai
   ```

   Paste the key only into the CLI prompt; never add it to Android source, website files, or Git. Then deploy the generation endpoint:

   ```sh
   firebase deploy --project hira-bhai --only functions:generateWebsite
   ```

   The endpoint requires a signed-in Firebase user and limits generation to five requests per minute per user. Gemini 2.5 Flash currently has a free API tier; paid text input/output is metered by tokens (pricing can change). Check the current [Gemini API pricing](https://ai.google.dev/gemini-api/docs/pricing). On the free tier, Google may use submitted prompts to improve its products; check the current privacy terms before enabling it for users.

3. `website/public/firebase-config.js` is filled with the existing Firebase project's public API key, project ID, and bucket. The API key is not a secret and is already present in the Android Firebase config; restrict it to the needed Firebase APIs. Firestore and Storage Rules enforce access.
4. Deploy Firestore rules, Hosting and the function from the project root:

   ```sh
   firebase use <same-project-id>
   firebase deploy --project hira-bhai --only firestore:rules,hosting,functions:generateWebsite
   ```

4. A published creator URL has the format `https://<project-id>.web.app/creator/<username>`. Publish the website in the Android builder only after Hosting and the rules are deployed.

Firebase assigns the `.web.app` domain. A custom domain is optional and must be connected and verified in Firebase Hosting; DNS changes are required at the domain provider. Saving a “Published website” makes its Firestore content public; it does not deploy Hosting. Share the URL only after configuring the Web app and successfully deploying Hosting and the rules. No custom domain or website hosting is silently provisioned by the Android app.

The public page displays generated HTML/CSS/JavaScript in a sandboxed iframe. The preview disables file access, external network requests, forms, parent navigation and storage. Generated websites therefore cannot load remote images, fonts, APIs or third-party scripts unless a future review deliberately adds those capabilities.

The builder stores small website images inline in the website Firestore document (maximum three section images, plus a logo and a site profile picture). Creator videos remain in Firebase Storage and are listed only when their video metadata has `visibility == public`. Firestore rules are included in the project but still need deployment to the Firebase Console project.
