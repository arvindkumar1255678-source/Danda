# Hira Bhai admin and moderation setup

## Access model

The Admin Panel uses the Firebase Authentication custom claim `platformAdmin: true`. The Android profile document is never used to grant admin access. The app checks the refreshed claim for navigation, and every `adminModeration` request independently verifies the signed ID token with Firebase Admin SDK. Reports, moderation records, and audit entries cannot be read or written directly by app clients.

Grant the initial admin claim only from a trusted operator workstation or Cloud Shell with Application Default Credentials and the Firebase Admin SDK available in `functions`:

```sh
cd functions
GOOGLE_CLOUD_PROJECT=hira-bhai HB_CONFIRM_ADMIN_UID=<verified-auth-uid> node grant-platform-admin.js <verified-auth-uid>
```

The script preserves other custom claims and revokes refresh tokens, so the admin must sign in again. Do not create a public endpoint to grant admin claims. To revoke access, use a trusted Admin SDK tool to remove `platformAdmin` from that user's custom claims and revoke refresh tokens.

## Deploy backend and rules

Deploy the report/admin endpoints, Firestore rules/indexes, and Storage rules to the intended Firebase project:

```sh
firebase deploy --only functions:submitContentReport,functions:adminModeration,firestore:rules,firestore:indexes,storage --project hira-bhai
```

Firebase Cloud Functions deployment requires the Blaze billing plan. Review Cloud Functions, Firestore, and Storage usage and configure billing alerts before production rollout.

## Moderation behavior

- Authenticated users submit one report per target; duplicate reports from the same account return the prior report state.
- Moderators can review video, user, and comment reports; remove video metadata and Storage assets; remove reported comments; suspend/restore accounts; dismiss reports; and view server-written audit history.
- Suspension disables Firebase Authentication, revokes refresh tokens, and writes a server-only status that Firestore and Storage rules check. Restoring the account re-enables Authentication and clears the rule-level suspension state.
- `/profiles` document counts are used for creators, and Firebase Authentication user records are counted for total users.
- No client-editable `isAdmin`/role profile field or administrator secret is shipped in the APK.
