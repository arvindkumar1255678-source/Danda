package com.hirabhai.platform

import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.Manifest
import android.content.Intent
import android.graphics.Color
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.graphics.LinearGradient
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.media.MediaExtractor
import android.media.MediaCodec
import android.media.MediaFormat
import android.media.AudioFormat
import android.os.ParcelFileDescriptor
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.RecognitionListener
import android.speech.RecognitionPart
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.TextureView
import android.view.Surface
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.*
import android.util.Patterns
import android.util.Log
import android.content.pm.ActivityInfo
import androidx.media3.common.MediaItem
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.common.MediaMetadata
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.common.util.concurrent.ListenableFuture
import android.content.ComponentName
import androidx.media3.common.util.UnstableApi
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Composition
import androidx.media3.transformer.ProgressHolder
import androidx.media3.effect.Crop
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.Contrast
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.RgbAdjustment
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.ListenerRegistration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.RectF
import android.graphics.SurfaceTexture
import android.media.MediaRecorder
import android.util.Base64
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.UUID
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import android.content.ClipboardManager
import android.content.ClipData
import android.content.ContentValues
import android.view.WindowManager
import android.webkit.WebView
import android.webkit.WebSettings
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.content.pm.PackageManager
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.google.firebase.Firebase
import com.google.firebase.ai.Chat
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Content
import com.google.firebase.ai.type.GenerativeBackend
import com.google.firebase.ai.type.PublicPreviewAPI
import com.google.firebase.ai.type.AspectRatio
import com.google.firebase.ai.type.ImagePart
import com.google.firebase.ai.type.ResponseModality
import com.google.firebase.ai.type.generationConfig
import com.google.firebase.ai.type.imageConfig
import com.google.firebase.ai.type.content
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.tasks.await
import org.json.JSONObject
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity(), com.razorpay.PaymentResultWithDataListener {
    private val bg = Color.rgb(0, 45, 41)
    private val mint = Color.rgb(35, 164, 143)
    private val primaryText = Color.WHITE
    private val secondaryText = Color.rgb(196, 216, 213)
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private var selected = "Home"
    private var displayedSelected = "Home"
    private var displayedTitle = "Home"
    private var restoringScreen = false
    private data class ScreenSnapshot(
        val root: LinearLayout,
        val content: LinearLayout,
        val scroll: ScrollView?,
        val bottomBar: View?,
        val refresh: SwipeRefreshLayout?,
        val selected: String,
        val title: String,
        val needsStatusInset: Boolean,
        val usesContentStatusInset: Boolean,
        val currentVideoId: String?,
        val activeHistoryVideoId: String?
    )
    private val screenHistory = ArrayDeque<ScreenSnapshot>()
    private data class HomeFeedPageState(
        var cursor: com.google.firebase.firestore.DocumentSnapshot? = null,
        val loadedIds: MutableSet<String> = mutableSetOf(),
        var hasMore: Boolean = true,
        var loading: Boolean = false,
        var generation: Int = 0,
        var footer: View? = null
    )
    private val homeFeedPages = mutableMapOf<String, HomeFeedPageState>()
    private var pendingDonationCreatorId: String? = null
    private var pendingDonationOrderId: String? = null

    private var selectedPhoto: Uri? = null
    private var currentProfile = hashMapOf<String, Any>()
    private var subscriptionTestRecordsView: TextView? = null
    private var selectedVideoUri: Uri? = null
    private var selectedVideoThumbnailUri: Uri? = null
    private var videoThumbnail: Bitmap? = null
    private var selectedVideoDurationMs = 0L
    private var returnToVideoUploadAfterProfileSave = false
    private var pendingVideoTitle = ""
    private var pendingVideoDescription = ""
    private var pendingVideoVisibility = "public"
    private var pendingVideoIsShort = false
    private var pendingVideoHashtags = ""
    private val homeSearchHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var homeSearchRunnable: Runnable? = null
    private var homeSearchSerial = 0
    private val homeAiConversation = mutableListOf<Pair<String, String>>()
    private var homeSearchOverlay: View? = null
    private var homeSearchFeed: View? = null
    private var homeSearchHeader: View? = null
    private var homeSearchChrome: View? = null
    private var homeSearchPageActive = false
    private var homeSearchChromeCollapsed = false
    private var homeInlineWebView: android.webkit.WebView? = null
    private var homeWebFullscreenView: View? = null
    private var homeWebFullscreenContainer: ViewGroup? = null
    private var homeWebFullscreenCallback: android.webkit.WebChromeClient.CustomViewCallback? = null
    private var homeWebPreviousOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    private var homeInlineBrowserContainer: View? = null
    private var homeInlineBrowserToolbar: View? = null
    private var homeInlineFullPage = false
    private var homeInlineResultsContainer: View? = null
    private var homeInlineBrowserTitle: TextView? = null
    private var savedHomePagesContainer: LinearLayout? = null
    private var movieCatalogCache: List<Pair<String, Map<String, Any>>>? = null
    private var videoPlayer: ExoPlayer? = null
    private var shortsPlayer: ExoPlayer? = null
    private var shortsScroll: ScrollView? = null
    private var shortsPages = mutableListOf<Triple<String, Map<String, Any>, PlayerView>>()
    private var activeShortIndex = -1
    private var shortFeedFullscreen = false
    private var musicController: MediaController? = null
    private var musicControllerFuture: ListenableFuture<MediaController>? = null
    private var musicListenerAttached = false
    private var musicMiniTitle: TextView? = null
    private var musicMiniPlay: TextView? = null
    private var musicMiniContainer: View? = null
    private var musicQueue: List<Map<String, Any>> = emptyList()
    private var musicQueueIndex = 0
    private var musicShuffleEnabled = false
    private var advancingAudioQueue = false
    private var lastAudioPlayNotifiedId: String? = null
    private var musicPlayerProgress: SeekBar? = null
    private var musicPlayerTime: TextView? = null
    private var musicPlayerTitle: TextView? = null
    private var musicPlayerArtist: TextView? = null
    private var musicPlayerCover: ImageView? = null
    private var musicProgressRunnable: Runnable? = null
    private var selectedAudioUri: Uri? = null
    private var selectedAudioCoverUri: Uri? = null
    private var pendingAudioTitle = ""
    private var pendingAudioArtist = ""
    private var pendingAudioDescription = ""
    private var pendingAudioVisibility = "public"
    private var currentAudioScreen = false
    private val playbackProgressHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var playbackProgressRunnable: Runnable? = null
    private var videoPlayerView: PlayerView? = null
    private var videoPlayerFrame: FrameLayout? = null
    private var mainScroll: ScrollView? = null
    private var bottomBar: View? = null
    private var videoFullscreen = false
    private var currentVideoId: String? = null
    private var activeHistoryVideoId: String? = null
    private var playlistQueue: List<String> = emptyList()
    private var playlistQueueIndex = -1
    private var homeRefreshLayout: SwipeRefreshLayout? = null
    private var statusBarInset = 0
    private var systemNavigationInset = 0
    private var rootNeedsStatusInset = false
    private var contentUsesStatusInset = true
    private val screenFirestoreListeners = mutableListOf<ListenerRegistration>()
    private val publicPhotoCache = mutableMapOf<String, String?>()
    private val aiScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var aiJob: Job? = null
    private var aiThreadId: String? = null
    private var aiMessages = mutableListOf<AiChatMessage>()
    private var aiList: LinearLayout? = null
    private var aiStatus: TextView? = null
    private var aiInput: EditText? = null
    private var aiSend: TextView? = null
    private var aiLoadingText: TextView? = null
    private var generatedAiImage: Bitmap? = null
    private var imageGeneratorPreview: ImageView? = null
    private var imageGeneratorStatus: TextView? = null
    private var imageGeneratorProgress: ProgressBar? = null
    private var imageGeneratorPrompt: EditText? = null
    private var pendingImageSave: Bitmap? = null
    private var contentStudioPrompt: EditText? = null
    private var contentStudioResult: TextView? = null
    private var contentStudioProgress: ProgressBar? = null
    private var contentStudioTask = "Video titles"
    private var aiVideoReferenceUri: Uri? = null
    private var aiVideoProgress: ProgressBar? = null
    private var aiVideoStatus: TextView? = null
    private var aiVideoPrompt: EditText? = null
    private var aiVideoPreview: VideoView? = null
    private var generatedAiVideoFile: File? = null
    private var videoEditSource: Uri? = null
    private var uploadCameraDialog: Dialog? = null
    private var uploadCameraDevice: CameraDevice? = null
    private var uploadCameraSession: CameraCaptureSession? = null
    private var uploadCameraTexture: TextureView? = null
    private var uploadCameraId: String? = null
    private var uploadPreviewSize: android.util.Size? = null
    private var uploadRecordSize: android.util.Size? = null
    private var uploadSensorOrientation = 90
    private var uploadRecorder: MediaRecorder? = null
    private var uploadRecording = false
    private var uploadWantRecord = false
    private var keepLiveRecording = false
    private var uploadRecordFile: File? = null
    private var liveActionButton: TextView? = null
    private var videoEditMusic: Uri? = null
    private var videoEditMusicIsNarration = false
    private var videoEditThumbnail: Uri? = null
    private var videoEditProgress: ProgressBar? = null
    private var videoEditStatus: TextView? = null
    private var videoEditPreview: VideoView? = null
    private var editedVideoFile: File? = null
    private var studioSelectedEffect = 0
    private var studioMuteOriginalAudio = false
    private var studioTextPosition = 0
    private var studioPreviewTime: SeekBar? = null
    private var studioPreviewDuration: TextView? = null
    private var activeTransformer: Transformer? = null
    private val exportProgressHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var exportProgressRunnable: Runnable? = null
    private var websiteOwnerProfile: Map<String, Any> = emptyMap()
    private var websiteSections = mutableListOf<MutableMap<String, Any>>()
    private var websiteBuilderName: EditText? = null
    private var websiteBuilderDescription: EditText? = null
    private var websiteBuilderStatus: TextView? = null
    private var websiteAiPrompt: EditText? = null
    private var websiteHtmlEditor: EditText? = null
    private var websiteCssEditor: EditText? = null
    private var websiteJsEditor: EditText? = null
    private var websiteProjectId: String? = null
    private var websiteSectionsBox: LinearLayout? = null
    private var websiteTemplate = "portfolio"
    private var websitePalette = "ocean"
    private var websiteFont = "system"
    private var websiteLogoData: String? = null
    private var websitePhotoData: String? = null
    private var websitePublished = false
    private var websitePublishSwitch: Switch? = null
    private var websiteUsername: String? = null
    private var websiteCreatorId: String? = null
    private var websitePublishedAt: Any? = null
    private var websiteImagePurpose = "section"
    private var websitePendingImageTitle = ""
    private var appBuilderPrompt: EditText? = null
    private var appBuilderName: EditText? = null
    private var appBuilderPackage: EditText? = null
    private var appBuilderSource: EditText? = null
    private var appBuilderStatus: TextView? = null
    private var appBuilderProgress: ProgressBar? = null
    private var appBuilderProjectId: String? = null
    private var appBuilderTemplate = "counter"
    private var appBuilderTheme = "teal"
    private var appBuilderPreview = JSONObject()
    private var pendingApkDownloadUrl: String? = null
    private var voiceTts: TextToSpeech? = null
    private var voiceTtsReady = false
    private var voiceLanguageOptions = mutableListOf<Pair<String, Locale>>()
    private var voiceChoices = mutableListOf<android.speech.tts.Voice?>()
    private var voiceLanguageSpinner: Spinner? = null
    private var voiceStyleSpinner: Spinner? = null
    private var voiceTextInput: EditText? = null
    private var voiceRate: SeekBar? = null
    private var voiceProgress: ProgressBar? = null
    private var voiceStatus: TextView? = null
    private var voicePlaybackButton: TextView? = null
    private var voicePreviewPlayer: MediaPlayer? = null
    private var generatedVoiceFile: File? = null
    private var pendingNarrationUri: Uri? = null
    private var pendingAudioExportFile: File? = null
    private var subtitleVideoUri: Uri? = null
    private var subtitleVideoDurationMs = 0L
    private var subtitleLanguage = "en-US"
    private var subtitleCues = mutableListOf<CaptionCue>()
    private var subtitleRows: LinearLayout? = null
    private var subtitleProgress: ProgressBar? = null
    private var subtitleStatus: TextView? = null
    private var subtitleRecognizer: SpeechRecognizer? = null
    private var subtitleAudioPipe: Array<ParcelFileDescriptor>? = null
    private var subtitleDecodeThread: Thread? = null
    private var pendingSubtitleSave: File? = null
    private var pendingUploadCaptionsSrt: String? = null
    private var pendingUploadCaptionLanguage = "en-US"
    private var attachCaptionsToCurrentUpload = false
    private var videoCaptionOverlay: TextView? = null
    private var videoCaptionToggle: CheckBox? = null
    private var activeVideoCaptions = emptyList<CaptionCue>()
    private var captionLanguageOptions = mutableListOf<Pair<String, String>>()
    private var captionTicker: Runnable? = null

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); window.statusBarColor=bg; window.navigationBarColor=Color.WHITE; window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR; if (!openCreatorWebsiteRoute(intent) && !openCreatorRoute(intent) && !openVideoRoute(intent) && !openCommunityPostRoute(intent)) showHome() }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); setIntent(intent); if (!openCreatorWebsiteRoute(intent) && !openCreatorRoute(intent) && !openVideoRoute(intent) && !openCommunityPostRoute(intent)) showHome() }

    override fun onBackPressed() {
        if (uploadCameraDialog?.isShowing == true) { uploadCameraDialog?.dismiss(); return }
        if (homeWebFullscreenView != null) { exitHomeWebFullscreen(); return }
        if (::root.isInitialized && ViewCompat.getRootWindowInsets(root)?.isVisible(WindowInsetsCompat.Type.ime()) == true) {
            hideSearchKeyboard()
            return
        }
        if (homeSearchPageActive && homeSearchChromeCollapsed) { setHomeSearchChromeCollapsed(false); return }
        if (homeInlineBrowserContainer?.visibility == View.VISIBLE) {
            val web = homeInlineWebView
            if (web?.canGoBack() == true) web.goBack() else closeHomeInlineBrowser()
            return
        }
        if (homeSearchPageActive) { hideHomeSearchPage(); return }
        if (shortFeedFullscreen) { showHome(); return }
        if (videoFullscreen) { exitVideoFullscreen(); return }
        if (restorePreviousScreen()) return
        if (currentVideoId != null) { playlistQueue = emptyList(); playlistQueueIndex = -1; currentVideoId = null; showHome(); return }
        super.onBackPressed()
    }

    private fun restorePreviousScreen(): Boolean {
        val previous = screenHistory.removeLastOrNull() ?: return false
        screenFirestoreListeners.forEach { runCatching { it.remove() } }
        screenFirestoreListeners.clear()
        aiJob?.cancel(); aiJob = null
        releaseShortsPlayer(); releaseVideoPlayer(); stopSubtitleRecognition()
        selected = previous.selected
        displayedSelected = previous.selected
        displayedTitle = previous.title
        currentVideoId = previous.currentVideoId
        activeHistoryVideoId = previous.activeHistoryVideoId
        rootNeedsStatusInset = previous.needsStatusInset
        contentUsesStatusInset = previous.usesContentStatusInset
        root = previous.root
        content = previous.content
        mainScroll = previous.scroll
        bottomBar = previous.bottomBar
        homeRefreshLayout = previous.refresh
        window.statusBarColor = Color.rgb(0, 45, 41)
        window.navigationBarColor = Color.rgb(0, 45, 41)
        window.decorView.systemUiVisibility = 0
        restoringScreen = true
        setContentView(root)
        ViewCompat.requestApplyInsets(root)
        restoringScreen = false
        return true
    }

    override fun onDestroy() {
        stopUploadCameraPreview(); releaseVideoPlayer(); aiScope.cancel()
        stopSubtitleRecognition()
        releaseVoicePreview(); voiceTts?.stop(); voiceTts?.shutdown(); voiceTts = null
        musicProgressRunnable?.let { playbackProgressHandler.removeCallbacks(it) }
        musicControllerFuture?.let { MediaController.releaseFuture(it) }
        musicControllerFuture = null; musicController = null
        super.onDestroy()
    }

    private data class CaptionCue(var startMs: Long, var endMs: Long, var text: String)

    override fun onPause() {
        videoPlayer?.let { player -> currentVideoId?.let { savePlaybackProgress(it, player) }; player.pause() }
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        renderSavedHomePages()
    }

    @Deprecated("Runtime permission result callback")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 70) {
            val cameraGranted = grantResults.getOrNull(permissions.indexOf(Manifest.permission.CAMERA)) == PackageManager.PERMISSION_GRANTED
            if (cameraGranted) showUploadOptions()
            else info("Camera permission needed", "Allow camera access so the live camera can stay on behind the upload box.")
        } else if (requestCode == 71 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            beginLiveCapture()
        } else if (requestCode == 96 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            pendingApkDownloadUrl?.let { startApkDownload(it) }; pendingApkDownloadUrl = null
        } else if (requestCode == 2032 && grantResults.firstOrNull() != PackageManager.PERMISSION_GRANTED) {
            info("Notifications are off", "Tasks remain saved, but Android will not show reminder alerts until notification permission is allowed in system settings.")
        }
        HiraDownloads.handlePermissionResult(this, requestCode, grantResults)
    }

    private fun openCreatorRoute(intent: Intent?): Boolean {
        val uri = intent?.data ?: return false
        if (uri.scheme != "hirabhai") return false
        val parts = uri.pathSegments
        if (parts.size != 2 || parts[0] != "u") return false
        loadPublicCreator(parts[1].removePrefix("@").lowercase(), null)
        return true
    }

    private fun openCreatorWebsiteRoute(intent: Intent?): Boolean {
        val uri = intent?.data ?: return false
        if (uri.scheme != "hirabhai") return false
        val parts = uri.pathSegments
        if (parts.size != 2 || parts[0] != "site") return false
        loadCreatorWebsite(parts[1].lowercase())
        return true
    }

    private fun openVideoRoute(intent: Intent?): Boolean {
        val uri = intent?.data ?: return false
        if (uri.scheme != "hirabhai") return false
        val parts = uri.pathSegments
        if (parts.size != 2 || parts[0] != "v") return false
        openVideoById(parts[1])
        return true
    }

    private fun openCommunityPostRoute(intent: Intent?): Boolean {
        val uri = intent?.data ?: return false
        if (uri.scheme != "hirabhai") return false
        val parts = uri.pathSegments
        if (parts.size != 2 || parts[0] != "p") return false
        showCommunityPost(parts[1])
        return true
    }

    private fun base(title: String = "Hira Bhai", pullToRefresh: Boolean = false, natureBackground: Boolean = false) {
        if (::root.isInitialized && ::content.isInitialized && !restoringScreen) {
            screenHistory.addLast(ScreenSnapshot(root, content, mainScroll, bottomBar, homeRefreshLayout,
                displayedSelected, displayedTitle, rootNeedsStatusInset, contentUsesStatusInset, currentVideoId, activeHistoryVideoId))
            while (screenHistory.size > 12) screenHistory.removeFirst()
        }
        displayedSelected = selected
        displayedTitle = if (title == "Hira Bhai") selected else title
        aiJob?.cancel(); aiJob = null
        currentAudioScreen = false
        shortFeedFullscreen = false
        musicProgressRunnable?.let { playbackProgressHandler.removeCallbacks(it) }; musicProgressRunnable = null
        releaseShortsPlayer()
        releaseVideoPlayer()
        stopSubtitleRecognition()
        screenFirestoreListeners.forEach { it.remove() }
        screenFirestoreListeners.clear()
        homeSearchOverlay = null
        homeSearchFeed = null
        homeSearchHeader = null
        homeSearchChrome = null
        homeSearchPageActive = false
        homeSearchChromeCollapsed = false
        homeInlineBrowserContainer = null
        homeInlineBrowserToolbar = null
        homeInlineFullPage = false
        homeInlineResultsContainer = null
        homeInlineBrowserTitle = null
        homeInlineWebView?.apply { stopLoading(); (parent as? ViewGroup)?.removeView(this); destroy() }
        homeInlineWebView = null
        homeRefreshLayout = null
        rootNeedsStatusInset = false
        contentUsesStatusInset = true
        root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; background = if (natureBackground) NatureBackdropDrawable() else round(bg, 0) }
        window.statusBarColor = Color.rgb(0, 45, 41)
        window.navigationBarColor = Color.rgb(0, 45, 41)
        window.decorView.systemUiVisibility = 0
        val scroll=ScrollView(this).apply { isFillViewport=true; clipToPadding=false }
        mainScroll = scroll
        content=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(20),dp(14),dp(20),dp(20)) }
        scroll.addView(content)
        root.setOnApplyWindowInsetsListener { view, insets ->
            statusBarInset = insets.systemWindowInsetTop
            systemNavigationInset = insets.systemWindowInsetBottom
            content.setPadding(dp(20), if (contentUsesStatusInset) dp(14) + statusBarInset else dp(8), dp(20), dp(20))
            view.setPadding(0, if (homeWebFullscreenView != null) 0 else if (rootNeedsStatusInset) statusBarInset else 0, 0, if (videoFullscreen || shortFeedFullscreen || homeWebFullscreenView != null) 0 else systemNavigationInset)
            insets
        }
        if (pullToRefresh) {
            val refresh = SwipeRefreshLayout(this).apply {
                setColorSchemeColors(mint)
                setProgressBackgroundColorSchemeColor(Color.WHITE)
                addView(scroll, ViewGroup.LayoutParams(-1, -1))
            }
            homeRefreshLayout = refresh
            root.addView(refresh, LinearLayout.LayoutParams(-1, 0, 1f))
        } else root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
    }

    private fun showHome() {
        if (currentVideoId != null) { playlistQueue = emptyList(); playlistQueueIndex = -1 }
        selected="Home"; base(pullToRefresh = true, natureBackground = true)
        val header=LinearLayout(this).apply { gravity=Gravity.CENTER_VERTICAL; orientation=LinearLayout.HORIZONTAL }
        val logo=ImageView(this).apply { setImageResource(R.drawable.hira_bhai_logo); scaleType=ImageView.ScaleType.CENTER_CROP; contentDescription="Hira Bhai multicolor circular logo"; layoutParams=LinearLayout.LayoutParams(dp(42),dp(42)) }
        val name=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER_VERTICAL; setPadding(dp(8),0,0,0); addView(label("Hira Bhai",16,Color.WHITE,true)) }
        val searchBox = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = glass(0x35ffffff, 24); setPadding(dp(10), 0, dp(5), 0)
            layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f).apply { leftMargin = dp(8); rightMargin = dp(5) }
        }
        val searchInput = EditText(this).apply {
            hint = "Search anything"; textSize = 14f; gravity = Gravity.CENTER_VERTICAL
            setTextColor(Color.WHITE); setHintTextColor(0xffe0f1fa.toInt()); setSingleLine(true)
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            background = null; contentDescription = "Search Hira Bhai videos and the web"
            setPadding(0, 0, 0, 0)
        }
        val clearSearch = TextView(this).apply {
            text = "×"; textSize = 21f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            contentDescription = "Clear home search"; visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(dp(28), -1); isClickable = true; isFocusable = true
        }
        val homeSearchButton = TextView(this).apply {
            text = "⌕"; textSize = 20f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            contentDescription = "Search from Home"; layoutParams = LinearLayout.LayoutParams(dp(30), -1)
            isClickable = true; isFocusable = true
        }
        searchBox.addView(searchInput, LinearLayout.LayoutParams(0, -1, 1f)); searchBox.addView(clearSearch); searchBox.addView(homeSearchButton)
        val bell = TextView(this).apply {
            text = "🔔"; textSize = 19f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); background = glass(0x44ffffff, 100)
            contentDescription = "Notifications"; layoutParams = LinearLayout.LayoutParams(dp(38), dp(38))
            isClickable = true; isFocusable = true; setOnClickListener { showNotifications() }
            attachUnreadBadge(this)
        }
        val browserShortcut = TextView(this).apply {
            text = "🌐"; textSize = 17f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = glass(0x44ffffff, 100); contentDescription = "Open Hira Bhai Browser"
            layoutParams = LinearLayout.LayoutParams(dp(38), dp(38)).apply { rightMargin = dp(4) }
            isClickable = true; isFocusable = true
            setOnClickListener { startActivity(Intent(this@MainActivity, InAppBrowserActivity::class.java)) }
        }
        val avatar=TextView(this).apply { text=FirebaseBackend.auth?.currentUser?.email?.take(1)?.uppercase() ?: "HB"; textSize=14f; gravity=Gravity.CENTER; setTextColor(Color.WHITE); background=round(0xff315573.toInt(),100); layoutParams=LinearLayout.LayoutParams(dp(38),dp(38)).apply { gravity=Gravity.CENTER_VERTICAL; leftMargin=dp(5) }; setOnClickListener { showAccount() } }
        header.addView(logo); header.addView(name,LinearLayout.LayoutParams(-2,-2)); header.addView(searchBox); header.addView(browserShortcut); header.addView(bell); header.addView(avatar)
        // Keep only the brand, search, account and notifications fixed above the feed.
        rootNeedsStatusInset = true
        contentUsesStatusInset = false
        root.setPadding(0, statusBarInset, 0, systemNavigationInset)
        content.setPadding(dp(20), dp(8), dp(20), dp(20))
        val refreshContainer = homeRefreshLayout
        refreshContainer?.let { root.removeView(it) }
        header.setPadding(dp(14), dp(7), dp(14), dp(2))
        root.addView(header, LinearLayout.LayoutParams(-1, -2))
        val homeSearchPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = glass(0x46ffffff, 18)
            setPadding(dp(12), dp(8), dp(12), dp(10)); visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f).apply { leftMargin = dp(14); rightMargin = dp(14); topMargin = dp(5); bottomMargin = dp(5) }
        }
        val homeSearchStatus = label("Hira Bhai Search · web, images, videos and apps", 12, 0xffe5f3fa.toInt(), false)
        val homeSearchProgress = ProgressBar(this).apply { isIndeterminate = true; visibility = View.GONE }
        val searchChrome = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        var homeSearchMode = "All"
        val homeSearchResults = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val homeSearchModes = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val homeSearchModeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("All", "Web", "Videos", "Images", "News", "Apps", "AI Answer").forEach { mode ->
            val chip = TextView(this).apply {
                text = mode; textSize = 11f; setTextColor(Color.WHITE); background = glass(0x35ffffff, 100)
                setPadding(dp(11), dp(7), dp(11), dp(7)); isClickable = true; isFocusable = true
                setOnClickListener {
                    closeHomeInlineBrowser()
                    homeInlineResultsContainer?.visibility = View.VISIBLE
                    homeSearchMode = mode
                    (getSystemService(INPUT_METHOD_SERVICE) as? android.view.inputmethod.InputMethodManager)
                        ?.hideSoftInputFromWindow(searchInput.windowToken, 0)
                    if (searchInput.text.isNotBlank()) performHomeUniversalSearch(searchInput.text.toString(), homeSearchStatus, homeSearchProgress, homeSearchResults, homeSearchMode)
                }
            }
            homeSearchModeRow.addView(chip, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) })
        }
        homeSearchModes.addView(homeSearchModeRow)
        searchChrome.addView(homeSearchStatus)
        searchChrome.addView(homeSearchProgress, LinearLayout.LayoutParams(dp(26), dp(26)).apply { gravity = Gravity.CENTER; topMargin = dp(5) })
        searchChrome.addView(homeSearchModes, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(7) })
        val engineHeading = label("Search engines · open results inside Hira Bhai", 12, 0xffe5f3fa.toInt(), false)
        searchChrome.addView(engineHeading, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        val engineScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val engineRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Google", "Bing", "DuckDuckGo", "Brave").forEach { engine ->
            val engineChip = TextView(this).apply {
                text = engine; textSize = 11f; setTextColor(Color.WHITE); background = glass(0x35ffffff, 100)
                setPadding(dp(11), dp(7), dp(11), dp(7)); isClickable = true; isFocusable = true
                setOnClickListener {
                    val term = searchInput.text.toString().trim()
                    if (term.isNotEmpty()) {
                        saveRecentSearch(term)
                        showHomeSearchPage()
                        (getSystemService(INPUT_METHOD_SERVICE) as? android.view.inputmethod.InputMethodManager)
                            ?.hideSoftInputFromWindow(searchInput.windowToken, 0)
                        val encoded = Uri.encode(term)
                        val url = when (engine) {
                            "Google" -> "https://www.google.com/search?q=$encoded"
                            "Bing" -> "https://www.bing.com/search?q=$encoded"
                            "DuckDuckGo" -> "https://duckduckgo.com/?q=$encoded"
                            else -> "https://search.brave.com/search?q=$encoded"
                        }
                        openHomeInlineBrowser(url, engine)
                    }
                }
            }
            engineRow.addView(engineChip, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) })
        }
        engineScroll.addView(engineRow)
        searchChrome.addView(engineScroll, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5) })
        homeSearchPanel.addView(searchChrome, LinearLayout.LayoutParams(-1, -2))
        val homeSearchResultScroll = ScrollView(this).apply {
            isFillViewport = false; isVerticalScrollBarEnabled = false
            addView(homeSearchResults, ViewGroup.LayoutParams(-1, -2))
        }
        homeSearchPanel.addView(homeSearchResultScroll, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(4) })
        val inlineBrowser = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE
            background = glass(0x35ffffff, 16); setPadding(dp(7), dp(7), dp(7), dp(7))
        }
        val inlineBrowserToolbar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val backToResults = TextView(this).apply {
            text = "‹ Results"; textSize = 13f; setTextColor(Color.WHITE); setPadding(dp(7), dp(5), dp(10), dp(5))
            isClickable = true; isFocusable = true; setOnClickListener { closeHomeInlineBrowser() }
        }
        val inlineBrowserTitle = label("Hira Bhai Browser", 13, Color.WHITE, true)
        inlineBrowserToolbar.addView(backToResults)
        inlineBrowserToolbar.addView(inlineBrowserTitle, LinearLayout.LayoutParams(0, -2, 1f))
        fun browserAction(symbol: String, description: String, action: () -> Unit) = TextView(this).apply {
            text = symbol; textSize = 17f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            contentDescription = description; setOnClickListener { action() }
        }
        inlineBrowserToolbar.addView(browserAction("+", "Add page to Home") { saveHomeInlinePage() }, LinearLayout.LayoutParams(dp(27), dp(38)))
        inlineBrowserToolbar.addView(browserAction("↓", "Downloads") { showHomeDownloads() }, LinearLayout.LayoutParams(dp(27), dp(38)))
        inlineBrowserToolbar.addView(browserAction("◷", "History") { showHomeBrowserHistory() }, LinearLayout.LayoutParams(dp(27), dp(38)))
        val browserMenu = TextView(this).apply {
            text = "⋮"; textSize = 21f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            contentDescription = "Browser actions"; setPadding(dp(8), 0, dp(5), 0)
            setOnClickListener { showHomeInlineBrowserMenu(this) }
        }
        inlineBrowserToolbar.addView(browserMenu, LinearLayout.LayoutParams(dp(28), dp(38)))
        inlineBrowser.addView(inlineBrowserToolbar)
        homeInlineBrowserToolbar = inlineBrowserToolbar
        homeInlineBrowserTitle = inlineBrowserTitle
        val inlineWeb = android.webkit.WebView(this).apply {
            settings.javaScriptEnabled = true; settings.domStorageEnabled = true; settings.allowFileAccess = false
            settings.allowContentAccess = false
            if (android.os.Build.VERSION.SDK_INT >= 26) settings.safeBrowsingEnabled = true
            setBackgroundColor(Color.TRANSPARENT)
            webViewClient = object : android.webkit.WebViewClient() {
                override fun shouldOverrideUrlLoading(view: android.webkit.WebView, request: android.webkit.WebResourceRequest): Boolean =
                    request.url.scheme !in setOf("http", "https")
            }
            setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
                HiraDownloads.enqueue(this@MainActivity, url, userAgent, contentDisposition, mimeType, this.url)
            }
            HiraDownloads.enableLongPressDownloads(this@MainActivity, this)
            webChromeClient = object : android.webkit.WebChromeClient() {
                override fun onReceivedTitle(view: android.webkit.WebView, title: String?) {
                    InterestHistory.recordPage(this@MainActivity, title.orEmpty(), view.url.orEmpty())
                }
                override fun onShowCustomView(view: View, callback: android.webkit.WebChromeClient.CustomViewCallback) {
                    if (homeWebFullscreenView != null) { callback.onCustomViewHidden(); return }
                    homeWebFullscreenView = view
                    homeWebFullscreenCallback = callback
                    homeWebPreviousOrientation = requestedOrientation
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    val fullscreen = FrameLayout(this@MainActivity).apply {
                        setBackgroundColor(Color.BLACK)
                        addView(view, FrameLayout.LayoutParams(-1, -1))
                    }
                    homeWebFullscreenContainer = fullscreen
                    (window.decorView as ViewGroup).addView(fullscreen, ViewGroup.LayoutParams(-1, -1))
                    window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    root.requestApplyInsets()
                }
                override fun onHideCustomView() { exitHomeWebFullscreen() }
            }
        }
        inlineBrowser.addView(inlineWeb, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(5) })
        homeSearchPanel.addView(inlineBrowser, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(6) })
        homeInlineWebView = inlineWeb
        homeInlineBrowserContainer = inlineBrowser
        homeInlineResultsContainer = homeSearchResultScroll
        root.addView(homeSearchPanel, LinearLayout.LayoutParams(-1, 0, 1f))
        homeSearchOverlay = homeSearchPanel
        homeSearchFeed = refreshContainer
        homeSearchHeader = header
        homeSearchChrome = searchChrome
        var previousResultScrollY = 0
        homeSearchResultScroll.setOnScrollChangeListener { _, _, scrollY, _, _ ->
            if (scrollY > previousResultScrollY + dp(4)) {
                hideSearchKeyboard()
                setHomeSearchChromeCollapsed(true)
            } else if (scrollY < previousResultScrollY - dp(4) || scrollY == 0) {
                setHomeSearchChromeCollapsed(false)
            }
            previousResultScrollY = scrollY
        }
        var previousWebScrollY = 0
        inlineWeb.setOnScrollChangeListener { _, _, scrollY, _, _ ->
            if (scrollY > previousWebScrollY + dp(4)) {
                hideSearchKeyboard()
                setHomeSearchChromeCollapsed(true)
            } else if (scrollY < previousWebScrollY - dp(4) || scrollY == 0) {
                setHomeSearchChromeCollapsed(false)
            }
            previousWebScrollY = scrollY
        }
        if (refreshContainer != null) root.addView(refreshContainer, LinearLayout.LayoutParams(-1, 0, 1f))
        fun clearHomeSearch(restoreFocus: Boolean = false) {
            homeSearchRunnable?.let(homeSearchHandler::removeCallbacks); homeSearchRunnable = null
            homeSearchSerial++
            searchInput.text.clear(); clearSearch.visibility = View.GONE
            hideHomeSearchPage(); homeSearchProgress.visibility = View.GONE
            homeSearchResults.removeAllViews(); homeSearchStatus.text = "Hira Bhai Search · web, images, videos and apps"
            if (restoreFocus) {
                searchInput.requestFocus()
                (getSystemService(INPUT_METHOD_SERVICE) as? android.view.inputmethod.InputMethodManager)
                    ?.showSoftInput(searchInput, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
            }
        }
        clearSearch.setOnClickListener { clearHomeSearch(true) }
        homeSearchButton.setOnClickListener {
            val term = searchInput.text.toString().trim()
            if (term.isNotEmpty()) {
                showHomeSearchPage()
                (getSystemService(INPUT_METHOD_SERVICE) as? android.view.inputmethod.InputMethodManager)
                    ?.hideSoftInputFromWindow(searchInput.windowToken, 0)
                performHomeUniversalSearch(term, homeSearchStatus, homeSearchProgress, homeSearchResults, homeSearchMode)
            }
        }
        searchInput.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                closeHomeInlineBrowser()
                val term = s?.toString()?.trim().orEmpty()
                clearSearch.visibility = if (term.isEmpty()) View.GONE else View.VISIBLE
                if (term.isEmpty()) { clearHomeSearch(); return }
                showHomeSearchPage()
                homeSearchResults.removeAllViews(); homeSearchProgress.visibility = View.GONE
                homeSearchStatus.text = "Suggestions · English or हिन्दी"
                val recent = getRecentSearches().take(3)
                val suggestion = TextView(this@MainActivity).apply { text = "⌕  Search ‘$term’ with Hira Bhai Search"; textSize = 13f; setTextColor(Color.WHITE); setPadding(dp(5), dp(6), dp(5), dp(6)); isClickable = true; isFocusable = true; setOnClickListener { performHomeUniversalSearch(term, homeSearchStatus, homeSearchProgress, homeSearchResults, homeSearchMode) } }
                homeSearchResults.addView(suggestion)
                recent.forEach { recentTerm ->
                    val item = TextView(this@MainActivity).apply { text = "◷  $recentTerm"; textSize = 12f; setTextColor(0xffe5f3fa.toInt()); setPadding(dp(5), dp(5), dp(5), dp(5)); isClickable = true; setOnClickListener { searchInput.setText(recentTerm); searchInput.setSelection(searchInput.text.length) } }
                    homeSearchResults.addView(item)
                }
                homeSearchRunnable?.let(homeSearchHandler::removeCallbacks)
                if (homeSearchMode != "AI Answer") {
                    val runnable = Runnable { performHomeUniversalSearch(term, homeSearchStatus, homeSearchProgress, homeSearchResults, homeSearchMode) }
                    homeSearchRunnable = runnable; homeSearchHandler.postDelayed(runnable, 750)
                }
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        searchInput.setOnEditorActionListener { _, _, _ ->
            val term = searchInput.text.toString().trim()
            if (term.isNotEmpty()) {
                (getSystemService(INPUT_METHOD_SERVICE) as? android.view.inputmethod.InputMethodManager)
                    ?.hideSoftInputFromWindow(searchInput.windowToken, 0)
                performHomeUniversalSearch(term, homeSearchStatus, homeSearchProgress, homeSearchResults, homeSearchMode)
            }
            true
        }
        val feed = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val feedHeading = label("For you · personalized", 21, Color.WHITE, true).apply { setPadding(0, dp(21), 0, dp(12)) }
        var feedMode = "For you"
        rowChips(listOf("For you", "Trending", "Recent", "Popular", "Music", "Learning", "Nature", "AI Builder")) { mode ->
            if (mode == "AI Builder") {
                showAiAppBuilder()
                return@rowChips
            }
            feedMode = mode
            feedHeading.text = when (mode) {
                "Music" -> "Music from creators"
                "For you" -> "For you · personalized"
                "Recent" -> "Recently uploaded"
                else -> "$mode videos"
            }
            if (mode == "Music") loadPublicAudioFeed(feed, "") else loadPublicVideoFeed(feed, homeRefreshLayout, mode, reset = true)
        }
        homeSection("Featured for you")
        val feature=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; background=glass(0x43ffffff,26); setPadding(dp(13),dp(13),dp(13),dp(15)) }
        val art=FrameLayout(this).apply { background=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(0xff57bde7.toInt(),0xff0877b5.toInt(),0xff0f4966.toInt())).apply { cornerRadius=dp(20).toFloat() }; layoutParams=LinearLayout.LayoutParams(-1,dp(190)); clipToOutline = true }
        art.addView(MountainArtView(this), FrameLayout.LayoutParams(-1,-1))
        val nature=TextView(this).apply { text="✦\n\n  YOUR STORY\n  STARTS HERE"; textSize=24f; typeface=Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE); gravity=Gravity.CENTER; letterSpacing=.04f }
        art.addView(nature,FrameLayout.LayoutParams(-1,-1)); val play=TextView(this).apply { text="▶"; textSize=18f; gravity=Gravity.CENTER; setTextColor(Color.WHITE); background=round(0xcc1b3448.toInt(),100); layoutParams=FrameLayout.LayoutParams(dp(48),dp(48),Gravity.CENTER) }; art.addView(play)
        feature.addView(art); feature.addView(label("Upload your first creator video",19,Color.WHITE,true).apply { setPadding(dp(2),dp(13),dp(2),dp(4)) }); feature.addView(label("Share a real video with the Hira Bhai community",13,0xffe3f4fb.toInt(),false).apply { setPadding(dp(2),0,dp(2),0) }); feature.setOnClickListener { chooseVideoUpload() }; content.addView(feature)
        homeSection("Create apps with AI")
        content.addView(TextView(this).apply {
            text = "Open Hira Bhai AI App Builder"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = glass(0x43ffffff, 26)
            setPadding(dp(16), dp(20), dp(16), dp(20))
            isClickable = true
            isFocusable = true
            setOnClickListener { showAiAppBuilder() }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2) })
        addSavedHomePagesSection(content)
        content.addView(feedHeading)
        content.addView(label("For you uses your private watch history, likes, subscriptions, and themes from searches and pages opened in Hira Bhai. Public videos only; creators are mixed to reduce repeats.", 12, 0xffe4f4fb.toInt(), false).apply { setPadding(0, 0, 0, dp(8)) })
        content.addView(feed)
        homeRefreshLayout?.setOnRefreshListener { if (feedMode == "Music") loadPublicAudioFeed(feed, "") else loadPublicVideoFeed(feed, homeRefreshLayout, feedMode, reset = true) }
        loadPublicVideoFeed(feed, homeRefreshLayout, feedMode, reset = true)
        addBottom()
    }

    private fun addYoutubeMoviesSection() {
        homeSection("YouTube Movies")
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = glass(0x43ffffff, 22)
            setPadding(dp(13), dp(13), dp(13), dp(14))
        }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val logo = TextView(this).apply {
            text = "▶"; textSize = 15f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = round(0xffff0033.toInt(), 8); layoutParams = LinearLayout.LayoutParams(dp(35), dp(25)).apply { rightMargin = dp(8) }
            contentDescription = "YouTube logo"
        }
        brand.addView(logo); brand.addView(label("YouTube", 18, Color.WHITE, true))
        card.addView(brand)
        card.addView(label("Search YouTube trailers and publicly available movies. Playback opens YouTube; age, region, Premium and rights restrictions are controlled by YouTube and the channel.", 12, 0xffe5f3fa.toInt(), false).apply { setPadding(0, dp(8), 0, dp(10)) })
        val query = EditText(this).apply {
            hint = "Search YouTube movies"; isSingleLine = true; imeOptions = EditorInfo.IME_ACTION_SEARCH
            filters = arrayOf(android.text.InputFilter.LengthFilter(120))
            setPadding(dp(12), dp(9), dp(12), dp(9)); background = round(Color.WHITE, 12)
        }
        card.addView(query)
        val searchButton = TextView(this).apply {
            text = "Search YouTube"; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setTextColor(Color.WHITE); background = round(0xffe62117.toInt(), 12); setPadding(dp(14), dp(11), dp(14), dp(11))
            isClickable = true; isFocusable = true
        }
        card.addView(searchButton, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        val resultStatus = label("Choose a category or search. Only public videos marked as embeddable by YouTube are listed.", 12, 0xffe5f3fa.toInt(), false).apply { setPadding(0, dp(9), 0, dp(6)) }
        card.addView(resultStatus)
        val results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        card.addView(results)
        fun doSearch(term: String) {
            query.setText(term)
            searchYoutubeMovies(term, resultStatus, results)
        }
        searchButton.setOnClickListener { doSearch(query.text.toString()) }
        query.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) { doSearch(query.text.toString()); true } else false
        }
        val categoryScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val categoryRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(
            "Bollywood" to "Bollywood official movie trailer",
            "Hollywood" to "Hollywood official movie trailer",
            "Gujarati Movies" to "Gujarati full movie official",
            "Hindi Movies" to "Hindi full movie official",
            "South Indian Movies" to "South Indian official movie trailer",
            "Full Movies" to "official full movie"
        ).forEach { (labelText, term) ->
            val chip = TextView(this).apply {
                text = labelText; textSize = 12f; setTextColor(Color.WHITE); background = glass(0x35ffffff, 100)
                setPadding(dp(12), dp(8), dp(12), dp(8)); isClickable = true; isFocusable = true
                setOnClickListener { doSearch(term) }
            }
            categoryRow.addView(chip, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(7) })
        }
        categoryScroll.addView(categoryRow)
        card.addView(categoryScroll, 2, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(9); bottomMargin = dp(2) })
        content.addView(card)
    }

    private fun addSavedHomePagesSection(parent: LinearLayout) {
        homeSection("Saved to Home")
        val rows = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        savedHomePagesContainer = rows
        parent.addView(rows)
        renderSavedHomePages()
    }

    private fun renderSavedHomePages() {
        val rows = savedHomePagesContainer ?: return
        rows.removeAllViews()
        val pages = InterestHistory.savedHomePages(this)
        if (pages.isEmpty()) {
            rows.addView(label("Save any page from Hira Bhai Browser and it will appear here.", 12, 0xffe5f3fa.toInt(), false).apply { setPadding(0, 0, 0, dp(8)) })
            return
        }
        pages.take(12).forEach { page ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = glass(0x3affffff, 16); setPadding(dp(8), dp(8), dp(8), dp(8))
                isClickable = true; isFocusable = true; setOnClickListener { openInAppBrowser(page.url) }
            }
            page.previewPath?.let { path ->
                val bitmap = android.graphics.BitmapFactory.decodeFile(path)
                if (bitmap != null) {
                    card.addView(ImageView(this).apply {
                        setImageBitmap(bitmap); scaleType = ImageView.ScaleType.CENTER_CROP
                        contentDescription = "Preview of ${page.title}"; clipToOutline = true
                        background = round(0xff294b60.toInt(), 10)
                    }, LinearLayout.LayoutParams(-1, dp(156)))
                }
            }
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(3), dp(5), 0, 0) }
            val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            labels.addView(label(page.title, 14, Color.WHITE, true).apply { maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END })
            labels.addView(label(Uri.parse(page.url).host.orEmpty(), 11, 0xffcde6f0.toInt(), false).apply { setPadding(0, dp(3), 0, 0); maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE })
            row.addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
            val remove = TextView(this).apply {
                text = "×"; textSize = 20f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
                contentDescription = "Remove saved page"; setPadding(dp(10), 0, dp(8), 0)
                setOnClickListener { InterestHistory.removeHomePage(this@MainActivity, page.url); renderSavedHomePages() }
            }
            row.addView(remove, LinearLayout.LayoutParams(-2, dp(38)))
            card.addView(row)
            rows.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
    }

    private fun addPersonalizedWebSection(parent: LinearLayout, currentQuery: String) {
        val section = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = glass(0x42ffffff, 20)
            setPadding(dp(13), dp(12), dp(13), dp(13))
        }
        val heading = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        heading.addView(label("Picked for your interests", 17, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        val refresh = TextView(this).apply {
            text = "Refresh"; textSize = 11f; setTextColor(Color.WHITE); background = glass(0x35ffffff, 50)
            setPadding(dp(9), dp(6), dp(9), dp(6)); isClickable = true; isFocusable = true
        }
        val clear = TextView(this).apply {
            text = "Clear"; textSize = 11f; setTextColor(Color.WHITE); background = glass(0x35ffffff, 50)
            setPadding(dp(9), dp(6), dp(9), dp(6)); isClickable = true; isFocusable = true
        }
        heading.addView(refresh, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(5) })
        heading.addView(clear)
        section.addView(heading)
        section.addView(label("Based on searches and pages opened inside Hira Bhai. Activity history stays on this device; matching topics are sent to Hira Bhai Search for live results.", 12, 0xffe5f3fa.toInt(), false).apply { setPadding(0, dp(5), 0, dp(8)) })
        val status = label("Finding topics you may like…", 12, 0xffe5f3fa.toInt(), false)
        val progress = ProgressBar(this).apply { isIndeterminate = true }
        val results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val browserFallback = TextView(this).apply {
            text = "Open these topics in Hira Bhai Browser"; textSize = 13f; gravity = Gravity.CENTER
            setTextColor(Color.WHITE); background = glass(0x5539bda5, 14); setPadding(dp(10), dp(9), dp(10), dp(9))
            isClickable = true; isFocusable = true; visibility = View.GONE
        }
        section.addView(status)
        section.addView(progress, LinearLayout.LayoutParams(dp(24), dp(24)).apply { topMargin = dp(6) })
        section.addView(results)
        section.addView(browserFallback, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        parent.addView(section, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })
        val stopWords = setOf("the", "and", "for", "with", "from", "this", "that", "what", "how", "why", "are", "was", "you", "your", "about", "into", "best", "new", "latest", "search", "है", "और", "का", "की", "के", "में", "से", "को", "क्या", "कैसे", "पर")
        fun topicsFor(queryHint: String): List<String> {
            val scores = linkedMapOf<String, Double>()
            getRecentSearches().take(8).forEachIndexed { index, query ->
                recommendationTokens(query).filterNot { it in stopWords }.forEach { token -> scores[token] = (scores[token] ?: 0.0) + 4.0 / (index + 1) }
            }
            InterestHistory.recentPageTitles(this).take(20).forEachIndexed { index, title ->
                recommendationTokens(title).filterNot { it in stopWords }.forEach { token -> scores[token] = (scores[token] ?: 0.0) + 2.0 / (index + 1) }
            }
            recommendationTokens(queryHint).filterNot { it in stopWords }.forEach { token -> scores[token] = (scores[token] ?: 0.0) + 6.0 }
            return scores.entries.sortedByDescending { it.value }.take(3).map { it.key }
        }
        fun loadTopics(topics: List<String>) {
            results.removeAllViews()
            if (topics.isEmpty()) {
                progress.visibility = View.GONE
                status.text = "Search a topic above or open a webpage inside Hira Bhai to get recommendations."
                return
            }
            val query = topics.joinToString(" ")
            browserFallback.visibility = View.GONE
            status.text = "Exploring: ${topics.joinToString(" · ")}"
            progress.visibility = View.VISIBLE
            val user = FirebaseBackend.auth?.currentUser
            val projectId = try { com.google.firebase.FirebaseApp.getInstance().options.projectId } catch (_: Exception) { null }
            if (user == null || projectId.isNullOrBlank()) {
                progress.visibility = View.GONE
                status.text = "Sign in to load live web pages for: ${topics.joinToString(" · ")}."
                return
            }
            aiScope.launch {
                try {
                    val token = user.getIdToken(false).await().token ?: throw IllegalStateException("Could not verify your sign-in")
                    val payload = withContext(Dispatchers.IO) { postInternetSearch(projectId, token, query, "web", 0) }
                    val items = payload.optJSONArray("items") ?: JSONArray()
                    runOnUiThread {
                        if (isFinishing || isDestroyed) return@runOnUiThread
                        progress.visibility = View.GONE
                        results.removeAllViews()
                        if (items.length() == 0) {
                            status.text = "No live pages matched these topics. Check your search provider and try Refresh."
                            browserFallback.visibility = View.VISIBLE
                            return@runOnUiThread
                        }
                        val ranked = (0 until items.length()).mapNotNull { items.optJSONObject(it) }
                            .sortedByDescending { item ->
                                val text = "${item.optString("title")} ${item.optString("description")}".lowercase(Locale.ROOT)
                                topics.sumOf { topic -> if (text.contains(topic.lowercase(Locale.ROOT))) 3 else 0 }
                            }
                        status.text = "${ranked.size} web pages matched your recent interests"
                        ranked.take(6).forEach { addInternetSearchResult(results, it) }
                    }
                } catch (error: Exception) {
                    runOnUiThread {
                        progress.visibility = View.GONE
                        status.text = "Live recommendations failed: ${error.message ?: "Check sign-in and Search configuration, then Refresh."}"
                        browserFallback.visibility = View.VISIBLE
                    }
                }
            }
        }
        browserFallback.setOnClickListener {
            val topicQuery = topicsFor(currentQuery).joinToString(" ")
            if (topicQuery.isNotBlank()) {
                showHomeSearchPage()
                openHomeInlineBrowser("https://www.google.com/search?q=${Uri.encode(topicQuery)}", "Hira Bhai Search")
            }
        }
        refresh.setOnClickListener { loadTopics(topicsFor(currentQuery)) }
        clear.setOnClickListener {
            InterestHistory.clear(this)
            getSharedPreferences("hira_search_history", MODE_PRIVATE).edit().remove("recent").apply()
            loadTopics(topicsFor(currentQuery))
        }
        loadTopics(topicsFor(currentQuery))
    }

    private fun addMoviesLibrarySection() {
        homeSection("Movies · 100-title library")
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = glass(0x43ffffff, 22)
            setPadding(dp(13), dp(13), dp(13), dp(14))
        }
        card.addView(label("A home for verified public-domain and licensed films. Movie listings come from the Hira Bhai movie catalog.", 12, 0xffe5f3fa.toInt(), false))
        val query = EditText(this).apply {
            hint = "Search movies"; isSingleLine = true; setTextColor(Color.WHITE); setHintTextColor(0xffd8eaf2.toInt())
            background = glass(0x35ffffff, 12); setPadding(dp(11), dp(8), dp(11), dp(8))
        }
        card.addView(query, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(9) })
        val categoryScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val categoryRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        var category = "All"
        val status = label("Loading movie catalog…", 12, 0xffe5f3fa.toInt(), false).apply { setPadding(0, dp(9), 0, dp(6)) }
        val progress = ProgressBar(this).apply { isIndeterminate = true; visibility = View.VISIBLE }
        val results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun refresh() = loadHomeMovies(query.text.toString(), category, status, progress, results)
        listOf("All", "Bollywood", "Hollywood", "Gujarati", "Hindi", "Other").forEach { name ->
            val chip = TextView(this).apply {
                text = name; textSize = 11f; setTextColor(Color.WHITE); background = glass(0x35ffffff, 100)
                setPadding(dp(10), dp(7), dp(10), dp(7)); isClickable = true; isFocusable = true
                setOnClickListener { category = name; refresh() }
            }
            categoryRow.addView(chip, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) })
        }
        categoryScroll.addView(categoryRow)
        card.addView(categoryScroll, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        card.addView(status)
        card.addView(progress, LinearLayout.LayoutParams(dp(24), dp(24)))
        card.addView(results)
        val admin = label("⚙  Manage movie catalog", 13, 0xffa9d8ef.toInt(), true).apply {
            setPadding(0, dp(10), 0, 0); isClickable = true; isFocusable = true
            setOnClickListener { showMovieAdmin() }
        }
        FirebaseBackend.auth?.currentUser?.getIdToken(false)?.addOnSuccessListener { token ->
            if (token.claims["platformAdmin"] == true && card.isAttachedToWindow) card.addView(admin)
        }
        val movieFilterHandler = android.os.Handler(android.os.Looper.getMainLooper())
        var movieFilterRunnable: Runnable? = null
        query.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                movieFilterRunnable?.let(movieFilterHandler::removeCallbacks)
                val next = Runnable { refresh() }
                movieFilterRunnable = next
                movieFilterHandler.postDelayed(next, 250)
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        content.addView(card)
        refresh()
    }

    private fun loadHomeMovies(query: String, category: String, status: TextView, progress: ProgressBar, results: LinearLayout) {
        fun render(movies: List<Pair<String, Map<String, Any>>>) {
            progress.visibility = View.GONE
            val term = query.trim().lowercase()
            val filtered = movies.filter { (_, data) ->
                (category == "All" || data["category"] == category) &&
                    (term.isBlank() || listOf("title", "category", "language", "genre", "year").any { field -> data[field].toString().lowercase().contains(term) })
            }
            results.removeAllViews()
            status.text = if (filtered.isEmpty()) "No verified movie entries yet. A platform admin can add licensed or public-domain titles." else "${filtered.size} movie${if (filtered.size == 1) "" else "s"} · up to 100 entries"
            filtered.forEach { (id, data) -> addMovieCatalogCard(results, id, data) }
        }
        movieCatalogCache?.let { render(it); return }
        val db = FirebaseBackend.db
        if (db == null) { progress.visibility = View.GONE; status.text = "Movie catalog is unavailable until Firestore is configured."; return }
        progress.visibility = View.VISIBLE; status.text = "Loading verified movie entries…"
        db.collection("movies").whereEqualTo("visibility", "published").limit(100).get()
            .addOnSuccessListener { snapshot ->
                movieCatalogCache = snapshot.documents.mapNotNull { doc -> doc.data?.let { doc.id to it } }
                render(movieCatalogCache.orEmpty())
            }
            .addOnFailureListener { error ->
                progress.visibility = View.GONE; status.text = "Movie catalog failed to load: ${friendlyError(error)}"
                Log.e("HiraBhaiMovies", "Published movie catalog read failed", error)
            }
    }

    private fun addMovieCatalogCard(parent: LinearLayout, movieId: String, movie: Map<String, Any>) {
        val title = movie["title"] as? String ?: "Movie"
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = glass(0x35ffffff, 14); setPadding(dp(8), dp(8), dp(8), dp(8))
            isClickable = true; isFocusable = true; setOnClickListener { showMovieDetails(movieId, movie) }
        }
        val poster = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP; background = round(0xffdce8ed.toInt(), 8); clipToOutline = true
            layoutParams = LinearLayout.LayoutParams(dp(64), dp(88)).apply { rightMargin = dp(10) }
            contentDescription = "$title poster"
        }
        row.addView(poster)
        val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        labels.addView(label(title, 14, Color.WHITE, true).apply { maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END })
        labels.addView(label("${movie["category"] ?: "Other"} · ${movie["language"] ?: "Language not set"}", 11, 0xffe5f3fa.toInt(), false).apply { setPadding(0, dp(4), 0, dp(2)) })
        labels.addView(label("${movie["genre"] ?: "Genre not set"} · ${movie["year"] ?: "Year n/a"}", 11, 0xffe5f3fa.toInt(), false))
        labels.addView(label("Verified: ${movie["licenseType"] ?: "unconfirmed"}", 10, 0xffa9d8ef.toInt(), false).apply { setPadding(0, dp(4), 0, 0) })
        row.addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
        parent.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(7) })
        val posterUrl = movie["posterUrl"] as? String ?: return
        if (Uri.parse(posterUrl).scheme == "https") aiScope.launch {
            try {
                val bitmap = withContext(Dispatchers.IO) {
                    (URL(posterUrl).openConnection().apply { connectTimeout = 7000; readTimeout = 7000 }).getInputStream().use { BitmapFactory.decodeStream(it) }
                }
                if (bitmap != null) runOnUiThread { if (poster.isAttachedToWindow) poster.setImageBitmap(bitmap) }
            } catch (error: Exception) { Log.w("HiraBhaiMovies", "Could not load movie poster", error) }
        }
    }

    private fun showMovieDetails(movieId: String, movie: Map<String, Any>) {
        base(); heading(movie["title"] as? String ?: "Movie", "${movie["category"] ?: "Other"} · ${movie["language"] ?: "Language not set"} · ${movie["year"] ?: "Year n/a"}")
        val posterUrl = movie["posterUrl"] as? String
        if (!posterUrl.isNullOrBlank() && posterUrl.startsWith("https://")) {
            val poster = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER; contentDescription = "Movie poster" }
            content.addView(poster, LinearLayout.LayoutParams(-1, dp(240)).apply { bottomMargin = dp(12) })
            aiScope.launch {
                try {
                    val bitmap = withContext(Dispatchers.IO) { URL(posterUrl).openConnection().apply { connectTimeout = 7000; readTimeout = 7000 }.getInputStream().use { BitmapFactory.decodeStream(it) } }
                    if (bitmap != null) runOnUiThread { if (poster.isAttachedToWindow) poster.setImageBitmap(bitmap) }
                } catch (error: Exception) { Log.w("HiraBhaiMovies", "Could not load movie detail poster", error) }
            }
        }
        val description = movie["description"] as? String ?: ""
        content.addView(label("${movie["genre"] ?: "Genre not set"} · ${movie["licenseType"] ?: "license status not set"}", 13, secondaryText, true))
        if (description.isNotBlank()) content.addView(label(description, 14, primaryText, false).apply { setPadding(0, dp(12), 0, dp(12)) })
        content.addView(label("Playback opens the source URL supplied by the catalog admin. Hira Bhai does not download or re-upload movie media.", 12, secondaryText, false))
        button("▶  Watch from official source") { openCatalogMovieLink(movie["playbackUrl"] as? String) }
        (movie["trailerUrl"] as? String)?.takeIf { it.startsWith("https://") }?.let { url -> button("▶  Official trailer") { openCatalogMovieLink(url) } }
        val user = FirebaseBackend.auth?.currentUser
        user?.getIdToken(false)?.addOnSuccessListener { token ->
            if (token.claims["platformAdmin"] == true && ::content.isInitialized) button("Edit movie") { showMovieEditor(movieId, movie) }
        }
        addBottom()
    }

    private fun openCatalogMovieLink(url: String?) {
        if (url.isNullOrBlank() || Uri.parse(url).scheme != "https") { info("Unavailable", "This movie has no valid official playback link."); return }
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        catch (_: Exception) { info("Link unavailable", "The official movie source could not be opened.") }
    }

    private fun showMovieAdmin() {
        val user = FirebaseBackend.auth?.currentUser
        val db = FirebaseBackend.db
        if (user == null || db == null) { info("Admin sign-in required", "Sign in with a platform administrator account to manage the movie catalog."); return }
        user.getIdToken(true).addOnSuccessListener { token ->
            if (token.claims["platformAdmin"] != true) { info("Not authorized", "Only a platform administrator can manage movie listings."); return@addOnSuccessListener }
            base(); heading("Movie catalog", "Manage up to 100 licensed, public-domain, or official YouTube listings")
            button("＋  Add movie") { showMovieEditor(null, null) }
            val status = label("Loading catalog…", 13, secondaryText, false)
            val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            content.addView(status); content.addView(list)
            db.collection("movies").limit(101).get().addOnSuccessListener { snapshot ->
                status.text = "${snapshot.size()} of 100 entries"
                snapshot.documents.take(100).forEach { doc ->
                    val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                    row.addView(label(doc.getString("title") ?: doc.id, 14, primaryText, true), LinearLayout.LayoutParams(0, -2, 1f))
                    row.addView(buttonView("Edit") { showMovieEditor(doc.id, doc.data ?: emptyMap()) }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(5) })
                    row.addView(buttonView("Delete") {
                        AlertDialog.Builder(this).setTitle("Delete movie?").setMessage(doc.getString("title") ?: "").setNegativeButton("Cancel", null)
                            .setPositiveButton("Delete") { _, _ -> doc.reference.delete().addOnSuccessListener { movieCatalogCache = null; showMovieAdmin() }.addOnFailureListener { error -> info("Delete failed", friendlyError(error)) } }.show()
                    }, LinearLayout.LayoutParams(-2, -2))
                    list.addView(row)
                }
            }.addOnFailureListener { error -> status.text = "Could not load movie catalog: ${friendlyError(error)}" }
            addBottom()
        }.addOnFailureListener { info("Not authorized", "Could not verify platform administrator access.") }
    }

    private fun showMovieEditor(movieId: String?, movie: Map<String, Any>?) {
        val user = FirebaseBackend.auth?.currentUser ?: return info("Sign in required", "Sign in as a platform administrator to save movie listings.")
        val db = FirebaseBackend.db ?: return info("Unavailable", "Firestore is not configured.")
        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(8), dp(18), dp(8)) }
        fun field(hint: String, existing: String = "") = EditText(this).apply {
            this.hint = hint; setText(existing); setTextColor(primaryText); setHintTextColor(secondaryText)
            setSingleLine(hint != "Description"); if (hint == "Description") minLines = 3
            background = round(Color.WHITE, 10); setPadding(dp(10), dp(8), dp(10), dp(8))
            form.addView(this, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
        }
        val title = field("Movie title", movie?.get("title") as? String ?: "")
        val category = Spinner(this).apply {
            adapter = android.widget.ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Bollywood", "Hollywood", "Gujarati", "Hindi", "Other"))
            setSelection((movie?.get("category") as? String)?.let { listOf("Bollywood", "Hollywood", "Gujarati", "Hindi", "Other").indexOf(it) }?.coerceAtLeast(0) ?: 0)
        }; form.addView(category)
        val language = field("Language", movie?.get("language") as? String ?: "")
        val genre = field("Genre", movie?.get("genre") as? String ?: "")
        val year = field("Year", movie?.get("year")?.toString() ?: "").apply { inputType = android.text.InputType.TYPE_CLASS_NUMBER }
        val poster = field("HTTPS poster URL", movie?.get("posterUrl") as? String ?: "")
        val description = field("Description", movie?.get("description") as? String ?: "")
        val playback = field("Official HTTPS playback URL", movie?.get("playbackUrl") as? String ?: "")
        val trailer = field("Official HTTPS trailer URL (optional)", movie?.get("trailerUrl") as? String ?: "")
        val source = field("HTTPS license/source evidence URL", movie?.get("sourceUrl") as? String ?: "")
        val licenseOptions = listOf("public_domain", "licensed", "official_youtube")
        val license = Spinner(this).apply {
            adapter = android.widget.ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, licenseOptions)
            setSelection(licenseOptions.indexOf(movie?.get("licenseType") as? String).coerceAtLeast(0))
        }; form.addView(license)
        val scroll = ScrollView(this).apply { addView(form) }
        val dialog = AlertDialog.Builder(this).setTitle(if (movieId == null) "Add movie" else "Edit movie").setView(scroll)
            .setNegativeButton("Cancel", null).setPositiveButton("Save", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val name = title.text.toString().trim(); val lang = language.text.toString().trim(); val style = genre.text.toString().trim()
                val filmYear = year.text.toString().toIntOrNull()
                val posterUrl = poster.text.toString().trim(); val playUrl = playback.text.toString().trim(); val sourceUrl = source.text.toString().trim()
                val trailerUrl = trailer.text.toString().trim()
                val licenseType = license.selectedItem.toString()
                fun isYouTubeLink(value: String): Boolean = Uri.parse(value).host in setOf("youtube.com", "www.youtube.com", "m.youtube.com", "youtu.be")
                if (name.isBlank() || lang.isBlank() || style.isBlank() || filmYear == null || filmYear !in 1888..2100 || !posterUrl.startsWith("https://") || !playUrl.startsWith("https://") || !sourceUrl.startsWith("https://") || (licenseType == "official_youtube" && !isYouTubeLink(playUrl)) || (trailerUrl.isNotBlank() && !isYouTubeLink(trailerUrl))) {
                    info("Check movie details", "Enter a title, language, genre, year, HTTPS poster, official HTTPS playback link, and HTTPS license/source evidence."); return@setOnClickListener
                }
                user.getIdToken(true).addOnSuccessListener { token ->
                    if (token.claims["platformAdmin"] != true) { info("Not authorized", "Only a platform administrator can save movie listings."); return@addOnSuccessListener }
                    val ref = movieId?.let { db.collection("movies").document(it) } ?: db.collection("movies").document()
                    val data = hashMapOf<String, Any>(
                        "movieId" to ref.id, "title" to name, "category" to category.selectedItem.toString(),
                        "language" to lang, "genre" to style, "year" to filmYear, "posterUrl" to posterUrl,
                        "description" to description.text.toString().trim().take(4000), "playbackUrl" to playUrl,
                        "trailerUrl" to trailerUrl, "licenseType" to licenseType,
                        "sourceUrl" to sourceUrl, "visibility" to "published", "updatedAt" to FieldValue.serverTimestamp()
                    )
                    if (movieId == null) {
                        db.collection("movies").limit(100).get().addOnSuccessListener { snapshot ->
                            if (snapshot.size() >= 100) { info("Catalog full", "The movie catalog supports up to 100 entries."); return@addOnSuccessListener }
                            data["createdAt"] = FieldValue.serverTimestamp()
                            ref.set(data).addOnSuccessListener { movieCatalogCache = null; dialog.dismiss(); showMovieAdmin() }.addOnFailureListener { error -> info("Save failed", friendlyError(error)) }
                        }.addOnFailureListener { error -> info("Save failed", friendlyError(error)) }
                    } else {
                        ref.update(data as Map<String, Any>).addOnSuccessListener { movieCatalogCache = null; dialog.dismiss(); showMovieAdmin() }.addOnFailureListener { error -> info("Save failed", friendlyError(error)) }
                    }
                }.addOnFailureListener { info("Not authorized", "Could not verify platform administrator access.") }
            }
        }
        dialog.show()
    }

    private fun searchYoutubeMovies(query: String, status: TextView, results: LinearLayout, progress: ProgressBar? = null) {
        val term = query.trim()
        if (term.isEmpty()) { status.text = "Enter a movie, language, or trailer to search YouTube."; progress?.visibility = View.GONE; return }
        if (term.length > 120) { status.text = "Keep the search under 120 characters."; progress?.visibility = View.GONE; return }
        val projectId = try { com.google.firebase.FirebaseApp.getInstance().options.projectId } catch (_: Exception) { null }
        if (projectId.isNullOrBlank()) { status.text = "YouTube discovery is unavailable until the Firebase project is configured."; progress?.visibility = View.GONE; return }
        results.removeAllViews()
        status.text = "Searching YouTube…"
        aiScope.launch {
            try {
                val response = withContext(Dispatchers.IO) { postYoutubeFunction(projectId, term) }
                val items = response.optJSONArray("items") ?: JSONArray()
                runOnUiThread {
                    progress?.visibility = View.GONE
                    results.removeAllViews()
                    if (items.length() == 0) status.text = "No public, embedding-enabled videos matched this search in India."
                    else {
                        status.text = "YouTube results · ${items.length()} videos"
                        for (index in 0 until items.length()) {
                            val item = items.optJSONObject(index) ?: continue
                            addYoutubeMovieCard(results, item)
                        }
                    }
                }
            } catch (error: Exception) {
                runOnUiThread { progress?.visibility = View.GONE; status.text = "YouTube search failed: ${error.message ?: friendlyError(error)}" }
            }
        }
    }

    private fun performHomeUniversalSearch(
        query: String,
        status: TextView,
        progress: ProgressBar,
        results: LinearLayout,
        mode: String = "All"
    ) {
        val term = query.trim()
        if (term.length < 2) {
            status.text = "Type at least two characters to search."
            progress.visibility = View.GONE
            return
        }
        closeHomeInlineBrowser()
        showHomeSearchPage()
        homeSearchRunnable?.let(homeSearchHandler::removeCallbacks)
        homeSearchSerial++
        val searchGeneration = homeSearchSerial
        saveRecentSearch(term)
        results.removeAllViews()
        progress.visibility = View.GONE
        status.text = "Hira Bhai Search · $mode"

        fun pane(title: String): Triple<TextView, ProgressBar, LinearLayout> {
            results.addView(label(title, 15, Color.WHITE, true).apply { setPadding(0, dp(10), 0, dp(3)) })
            val paneStatus = label("Searching…", 12, 0xffe5f3fa.toInt(), false)
            val paneProgress = ProgressBar(this).apply { isIndeterminate = true; visibility = View.VISIBLE }
            val paneResults = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            results.addView(paneStatus)
            results.addView(paneProgress, LinearLayout.LayoutParams(dp(22), dp(22)).apply { topMargin = dp(3) })
            results.addView(paneResults)
            return Triple(paneStatus, paneProgress, paneResults)
        }

        if (mode == "AI Answer") {
            performAiSearch(term, status, progress, results, followUp = false, generation = searchGeneration)
            return
        }
        val includeAll = mode == "All"
        if (includeAll || mode == "Videos") {
            val (s, p, r) = pane("Hira Bhai videos")
            runVideoSearch(term, s, p, r)
        }
        if (includeAll || mode == "Web") {
            val (s, p, r) = pane("Web results")
            searchInternet(term, "web", s, p, r, generation = searchGeneration)
        }
        if (mode == "Images") {
            val (s, p, r) = pane("Images")
            searchInternet(term, "images", s, p, r, generation = searchGeneration)
        }
        if (mode == "Videos") {
            val (s, p, r) = pane("Internet videos")
            searchInternet(term, "videos", s, p, r, generation = searchGeneration)
        }
        if (mode == "News") {
            val (s, p, r) = pane("News")
            searchInternet(term, "news", s, p, r, generation = searchGeneration)
        }
        if (mode == "Apps") {
            val (s, p, r) = pane("Google Play apps")
            searchInternet(term, "apps", s, p, r, generation = searchGeneration)
        }
    }

    private fun performAiSearch(
        question: String,
        status: TextView,
        progress: ProgressBar,
        results: LinearLayout,
        followUp: Boolean,
        generation: Int
    ) {
        val prompt = question.trim()
        if (prompt.length < 2) { status.text = "Ask a question using at least two characters."; return }
        if (!followUp) homeAiConversation.clear()
        val user = FirebaseBackend.auth?.currentUser
        val projectId = try { com.google.firebase.FirebaseApp.getInstance().options.projectId } catch (_: Exception) { null }
        if (user == null) { status.text = "Sign in to use Hira Bhai AI Search."; progress.visibility = View.GONE; return }
        if (projectId.isNullOrBlank()) { status.text = "Hira Bhai AI Search is not connected to a Firebase project."; progress.visibility = View.GONE; return }

        status.text = "AI Search · searching the web and preparing an answer…"
        progress.visibility = View.VISIBLE
        aiScope.launch {
            try {
                val token = user.getIdToken(false).await().token ?: throw IllegalStateException("Could not verify your sign-in")
                val history = JSONArray()
                homeAiConversation.takeLast(6).forEach { (asked, answered) ->
                    history.put(JSONObject().put("role", "user").put("text", asked))
                    history.put(JSONObject().put("role", "model").put("text", answered))
                }
                val payload = withContext(Dispatchers.IO) { postAiSearch(projectId, token, prompt, history) }
                val answer = payload.optString("answer").trim()
                if (answer.isBlank()) throw IllegalStateException("The AI service returned an empty answer.")
                runOnUiThread {
                    if (generation != homeSearchSerial) return@runOnUiThread
                    progress.visibility = View.GONE
                    homeAiConversation.add(prompt to answer)
                    renderAiSearchAnswer(prompt, answer, payload.optJSONArray("sources") ?: JSONArray(), payload.optJSONArray("relatedQuestions") ?: JSONArray(), status, progress, results, generation)
                }
            } catch (error: Exception) {
                runOnUiThread {
                    if (generation != homeSearchSerial) return@runOnUiThread
                    progress.visibility = View.GONE
                    status.text = error.message?.takeIf { it.isNotBlank() }?.let { "AI Search failed: $it" }
                        ?: "AI Search failed. Check Firebase and Gemini/Brave provider configuration."
                }
            }
        }
    }

    private fun renderAiSearchAnswer(
        question: String,
        answer: String,
        sources: JSONArray,
        related: JSONArray,
        status: TextView,
        progress: ProgressBar,
        results: LinearLayout,
        generation: Int
    ) {
        results.removeAllViews()
        status.text = "AI-generated answer · web sources shown separately"
        results.addView(label("Your question", 12, 0xffd7edf4.toInt(), true).apply { setPadding(0, dp(8), 0, dp(3)) })
        results.addView(label(question, 14, Color.WHITE, true).apply { setPadding(0, 0, 0, dp(8)) })
        val answerCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = glass(0x38ffffff, 15)
            setPadding(dp(12), dp(11), dp(12), dp(11))
        }
        answerCard.addView(label("AI answer · generated, not independently verified", 11, 0xffe2f2f7.toInt(), true))
        answerCard.addView(label(answer, 14, Color.WHITE, false).apply { setPadding(0, dp(7), 0, 0) })
        results.addView(answerCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        fun action(title: String, onClick: () -> Unit) = TextView(this).apply {
            text = title; textSize = 12f; setTextColor(Color.WHITE); background = glass(0x35ffffff, 100)
            setPadding(dp(11), dp(7), dp(11), dp(7)); isClickable = true; isFocusable = true
            setOnClickListener { onClick() }
        }
        actions.addView(action("Copy answer") {
            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Hira Bhai AI answer", answer))
            android.widget.Toast.makeText(this, "Answer copied", android.widget.Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) })
        actions.addView(action("Share") {
            val shareText = "$answer\n\nSources:\n" + (0 until sources.length()).mapNotNull { sources.optJSONObject(it)?.let { item -> "${item.optString("title")} — ${item.optString("url")}" } }.joinToString("\n")
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, shareText), "Share AI answer"))
        }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) })
        actions.addView(action("Clear conversation") {
            homeAiConversation.clear(); results.removeAllViews()
            status.text = "Conversation cleared · ask a new question."
            progress.visibility = View.GONE
        })
        results.addView(actions, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })

        if (sources.length() > 0) {
            results.addView(label("Web sources · search results, not endorsements", 14, Color.WHITE, true).apply { setPadding(0, dp(6), 0, dp(5)) })
            for (index in 0 until sources.length()) {
                val source = sources.optJSONObject(index) ?: continue
                val url = source.optString("url")
                val card = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL; background = glass(0x35ffffff, 13)
                    setPadding(dp(10), dp(9), dp(10), dp(9)); isClickable = true; isFocusable = true
                    setOnClickListener { if (url.startsWith("https://")) openInAppBrowser(url) }
                }
                card.addView(label("[${index + 1}] ${source.optString("title")}", 13, Color.WHITE, true))
                card.addView(label(source.optString("description"), 12, 0xffe5f3fa.toInt(), false).apply { setPadding(0, dp(3), 0, dp(3)) })
                card.addView(label(source.optString("source", Uri.parse(url).host.orEmpty()), 11, 0xffb7e3ef.toInt(), false))
                results.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })
            }
        } else {
            results.addView(label("No live web sources were returned for this answer.", 12, 0xffffe0b2.toInt(), false).apply { setPadding(0, dp(4), 0, dp(8)) })
        }

        if (related.length() > 0) {
            results.addView(label("Related questions", 14, Color.WHITE, true).apply { setPadding(0, dp(7), 0, dp(4)) })
            for (index in 0 until related.length()) {
                val suggestion = related.optString(index).trim()
                if (suggestion.isBlank()) continue
                results.addView(action("↪  $suggestion") {
                    performAiSearch(suggestion, status, progress, results, followUp = true, generation = generation)
                }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(5) })
            }
        }

        results.addView(label("Ask a follow-up", 14, Color.WHITE, true).apply { setPadding(0, dp(9), 0, dp(4)) })
        val followRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val followInput = EditText(this).apply {
            hint = "Ask another question…"; textSize = 14f; setTextColor(Color.WHITE); setHintTextColor(0xffd7eaf3.toInt())
            background = glass(0x35ffffff, 14); setPadding(dp(10), dp(8), dp(10), dp(8)); setSingleLine(true)
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEND
        }
        val ask = action("Ask") {
            val nextQuestion = followInput.text.toString().trim()
            if (nextQuestion.isNotBlank()) {
                val imm = getSystemService(INPUT_METHOD_SERVICE) as? android.view.inputmethod.InputMethodManager
                imm?.hideSoftInputFromWindow(followInput.windowToken, 0)
                performAiSearch(nextQuestion, status, progress, results, followUp = true, generation = generation)
            }
        }
        followInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_SEND) { ask.performClick(); true } else false
        }
        followRow.addView(followInput, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(7) })
        followRow.addView(ask)
        results.addView(followRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
    }

    private fun postAiSearch(projectId: String, token: String, question: String, history: JSONArray): JSONObject {
        val connection = (URL("https://us-central1-$projectId.cloudfunctions.net/aiSearch").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 15000; readTimeout = 50000; doOutput = true
            setRequestProperty("Content-Type", "application/json"); setRequestProperty("Authorization", "Bearer $token")
        }
        try {
            connection.outputStream.use { it.write(JSONObject().put("question", question).put("history", history).toString().toByteArray()) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            val body = try { JSONObject(text) } catch (_: Exception) { throw IllegalStateException("AI Search service returned an unreadable response (HTTP $code).") }
            if (code !in 200..299) throw IllegalStateException(body.optString("error", "AI Search failed (HTTP $code)."))
            return body
        } finally { connection.disconnect() }
    }

    private fun searchInternet(
        query: String,
        type: String,
        status: TextView,
        progress: ProgressBar,
        results: LinearLayout,
        page: Int = 0,
        append: Boolean = false,
        generation: Int = homeSearchSerial
    ) {
        if (!append) results.removeAllViews()
        for (index in results.childCount - 1 downTo 0) {
            if (results.getChildAt(index).tag == "hira_search_more") results.removeViewAt(index)
        }
        val user = FirebaseBackend.auth?.currentUser
        val projectId = try { com.google.firebase.FirebaseApp.getInstance().options.projectId } catch (_: Exception) { null }
        if (user == null) {
            progress.visibility = View.GONE
            status.text = "Sign in to search the public internet from Hira Bhai."
            return
        }
        if (projectId.isNullOrBlank()) {
            progress.visibility = View.GONE
            status.text = "Hira Bhai Search is not connected to a Firebase project."
            return
        }
        aiScope.launch {
            try {
                val token = user.getIdToken(false).await().token ?: throw IllegalStateException("Could not verify your sign-in")
                val payload = withContext(Dispatchers.IO) { postInternetSearch(projectId, token, query, type, page) }
                val items = payload.optJSONArray("items") ?: JSONArray()
                runOnUiThread {
                    if (generation != homeSearchSerial) return@runOnUiThread
                    progress.visibility = View.GONE
                    if (items.length() == 0) {
                        status.text = if (page == 0) "No $type results found. Try another search." else "No more results are available."
                        return@runOnUiThread
                    }
                    if (type == "images") {
                        fun appendImagePage(start: Int) {
                            val end = minOf(start + 20, items.length())
                            status.text = "Images ${start + 1}–$end · Hira Bhai Search"
                            for (index in start until end) items.optJSONObject(index)?.let { addInternetSearchResult(results, it) }
                            if (end < items.length()) {
                                val more = TextView(this@MainActivity).apply {
                                    tag = "hira_search_more"; text = "Show more images"; textSize = 13f
                                    gravity = Gravity.CENTER; setTextColor(Color.WHITE); background = glass(0x38ffffff, 13)
                                    setPadding(dp(12), dp(10), dp(12), dp(10)); isClickable = true; isFocusable = true
                                    setOnClickListener {
                                        results.removeView(this)
                                        appendImagePage(end)
                                    }
                                }
                                results.addView(more, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
                            }
                        }
                        appendImagePage(0)
                    } else {
                        status.text = "${page * 10 + 1}–${page * 10 + items.length()} · Hira Bhai Search"
                        for (index in 0 until items.length()) items.optJSONObject(index)?.let { addInternetSearchResult(results, it) }
                        if (payload.optBoolean("hasMore")) {
                            val more = TextView(this@MainActivity).apply {
                                tag = "hira_search_more"; text = "Load more results"; textSize = 13f
                                gravity = Gravity.CENTER; setTextColor(Color.WHITE); background = glass(0x38ffffff, 13)
                                setPadding(dp(12), dp(10), dp(12), dp(10)); isClickable = true; isFocusable = true
                                setOnClickListener {
                                    isEnabled = false
                                    searchInternet(query, type, status, progress, results, page + 1, true, generation)
                                }
                            }
                            results.addView(more, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
                        }
                    }
                }
            } catch (error: Exception) {
                runOnUiThread {
                    if (generation != homeSearchSerial) return@runOnUiThread
                    progress.visibility = View.GONE
                    status.text = error.message?.takeIf { it.isNotBlank() }
                        ?.let { "Hira Bhai Search failed: $it" }
                        ?: "Hira Bhai Search failed. Check the provider setup and try again."
                }
            }
        }
    }

    private fun postInternetSearch(projectId: String, token: String, query: String, type: String, page: Int): JSONObject {
        val connection = (URL("https://us-central1-$projectId.cloudfunctions.net/universalSearch").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 12000; readTimeout = 18000; doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Authorization", "Bearer $token")
        }
        try {
            connection.outputStream.use {
                it.write(JSONObject().put("query", query).put("type", type).put("page", page).toString().toByteArray())
            }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            val body = try { JSONObject(text) } catch (_: Exception) {
                throw IllegalStateException("Hira Bhai Search service returned an unreadable response (HTTP $code). Try one of the built-in search engines below.")
            }
            if (code !in 200..299) throw IllegalStateException(body.optString("error", "Internet search failed (HTTP $code)."))
            return body
        } finally {
            connection.disconnect()
        }
    }

    private fun addInternetSearchResult(parent: LinearLayout, item: JSONObject) {
        val url = item.optString("url")
        val title = item.optString("title", "Search result")
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = glass(0x38ffffff, 13)
            setPadding(dp(10), dp(9), dp(10), dp(9)); isClickable = true; isFocusable = true
            setOnClickListener {
                val uri = Uri.parse(url)
                if (uri.scheme == "https" || uri.scheme == "http") openInAppBrowser(url)
                else info("Link unavailable", "This search result does not have a web address.")
            }
        }
        card.addView(label(title, 14, Color.WHITE, true).apply { maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END })
        val thumbnailUrl = item.optString("thumbnailUrl")
        if (thumbnailUrl.startsWith("https://")) {
            val thumbnail = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; contentDescription = "$title image" }
            card.addView(thumbnail, LinearLayout.LayoutParams(-1, dp(140)).apply { topMargin = dp(6); bottomMargin = dp(5) })
            aiScope.launch {
                try {
                    val bitmap = withContext(Dispatchers.IO) { URL(thumbnailUrl).openConnection().apply { connectTimeout = 7000; readTimeout = 7000 }.getInputStream().use { BitmapFactory.decodeStream(it) } }
                    if (bitmap != null) runOnUiThread { if (thumbnail.isAttachedToWindow) thumbnail.setImageBitmap(bitmap) }
                } catch (error: Exception) { Log.w("HiraBhaiSearch", "Could not load search image", error) }
            }
        }
        val description = item.optString("description")
        if (description.isNotBlank()) card.addView(label(description, 12, 0xffe5f3fa.toInt(), false).apply { setPadding(0, dp(4), 0, dp(3)); maxLines = 3; ellipsize = android.text.TextUtils.TruncateAt.END })
        card.addView(label(url, 10, 0xffa9d8ef.toInt(), false).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE })
        parent.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
    }

    private fun openInAppBrowser(url: String) {
        try {
            if (selected == "Home" && homeInlineWebView != null) {
                showHomeSearchPage()
                openHomeInlineBrowser(url, "Hira Bhai Browser")
                return
            }
            startActivity(Intent(this, InAppBrowserActivity::class.java)
                .putExtra(InAppBrowserActivity.EXTRA_URL, url))
        } catch (_: Exception) {
            info("Link unavailable", "This result could not be opened in Hira Bhai.")
        }
    }

    private fun openHomeInlineBrowser(url: String, title: String) {
        val uri = Uri.parse(url)
        if (uri.scheme !in setOf("http", "https") || uri.host.isNullOrBlank()) return
        homeInlineFullPage = true
        setHomeSearchChromeCollapsed(false)
        homeSearchHeader?.visibility = View.GONE
        homeSearchChrome?.visibility = View.GONE
        homeInlineBrowserToolbar?.visibility = View.VISIBLE
        (homeSearchOverlay as? LinearLayout)?.apply {
            background = null
            setPadding(0, 0, 0, 0)
        }
        (homeInlineBrowserContainer as? LinearLayout)?.apply {
            background = null
            setPadding(0, 0, 0, 0)
        }
        homeInlineResultsContainer?.visibility = View.GONE
        homeInlineBrowserContainer?.visibility = View.VISIBLE
        homeInlineBrowserTitle?.text = title
        homeInlineWebView?.loadUrl(uri.toString())
    }

    private fun showHomeInlineBrowserMenu(anchor: View) {
        android.widget.PopupMenu(this, anchor).apply {
            menu.add("Add page to Home feed")
            menu.add("Download current video")
            menu.add("History")
            menu.add("Downloads")
            setOnMenuItemClickListener { item ->
                val web = homeInlineWebView
                when (item.title.toString()) {
                    "Add page to Home feed" -> {
                        saveHomeInlinePage()
                    }
                    "Download current video" -> downloadHomeInlineVideo()
                    "History" -> showHomeBrowserHistory()
                    "Downloads" -> showHomeDownloads()
                }
                true
            }
            show()
        }
    }

    private fun saveHomeInlinePage() {
        val web = homeInlineWebView
        val url = web?.url
        if (url != null && url.startsWith("http")) {
            val preview = InterestHistory.capturePreview(this, web, url)
            InterestHistory.saveToHome(this, web.title.orEmpty(), url, preview)
            renderSavedHomePages()
            info("Added to Home", "This page is saved in the Hira Bhai Home feed.")
        } else info("Page not ready", "Open a webpage first.")
    }

    private fun downloadHomeInlineVideo() {
        val web = homeInlineWebView ?: return
        HiraDownloads.downloadCurrentDirectVideo(this, web)
    }

    private fun showHomeBrowserHistory() {
        val pages = InterestHistory.recentPages(this)
        if (pages.isEmpty()) {
            AlertDialog.Builder(this).setTitle("Hira Bhai History").setMessage("No pages in browser history yet.").setPositiveButton("OK", null).show()
            return
        }
        AlertDialog.Builder(this).setTitle("Hira Bhai History")
            .setItems(pages.map { "${it.title}\n${Uri.parse(it.url).host.orEmpty()}" }.toTypedArray()) { _, index ->
                showHomeSearchPage(); openHomeInlineBrowser(pages[index].url, pages[index].title)
            }
            .setNeutralButton("Clear history") { _, _ -> InterestHistory.clear(this); showHomeBrowserHistory() }
            .setNegativeButton("Close", null).show()
    }

    private fun showHomeDownloads() {
        val entries = HiraDownloads.entries(this)
        if (entries.isEmpty()) {
            AlertDialog.Builder(this).setTitle("Downloads").setMessage("No downloads yet. Downloadable website files appear here.").setPositiveButton("OK", null).show()
            return
        }
        AlertDialog.Builder(this).setTitle("Hira Bhai Downloads")
            .setItems(entries.map { "${it.title}\n${HiraDownloads.status(this, it.id)}" }.toTypedArray()) { _, index ->
                HiraDownloads.open(this, entries[index].id, entries[index].mime)
            }
            .setNegativeButton("Close", null).show()
    }

    private fun showHomeSearchPage() {
        homeSearchPageActive = true
        setHomeSearchChromeCollapsed(false)
        homeSearchOverlay?.visibility = View.VISIBLE
        homeSearchFeed?.visibility = View.GONE
        bottomBar?.visibility = View.GONE
        musicMiniContainer?.visibility = View.GONE
    }

    private fun hideHomeSearchPage() {
        setHomeSearchChromeCollapsed(false)
        homeSearchPageActive = false
        homeSearchOverlay?.visibility = View.GONE
        homeSearchFeed?.visibility = View.VISIBLE
        bottomBar?.visibility = View.VISIBLE
        musicMiniContainer?.visibility = View.VISIBLE
        closeHomeInlineBrowser()
    }

    private fun closeHomeInlineBrowser() {
        homeInlineFullPage = false
        setHomeSearchChromeCollapsed(false)
        homeInlineBrowserContainer?.visibility = View.GONE
        homeInlineResultsContainer?.visibility = View.VISIBLE
        (homeSearchOverlay as? LinearLayout)?.apply {
            background = glass(0x46ffffff, 18)
            setPadding(dp(12), dp(8), dp(12), dp(10))
        }
        (homeInlineBrowserContainer as? LinearLayout)?.apply {
            background = glass(0x35ffffff, 16)
            setPadding(dp(7), dp(7), dp(7), dp(7))
        }
        homeInlineBrowserToolbar?.visibility = View.VISIBLE
        homeSearchHeader?.visibility = View.VISIBLE
        homeSearchChrome?.visibility = View.VISIBLE
    }

    private fun setHomeSearchChromeCollapsed(collapsed: Boolean) {
        if (homeInlineFullPage) return
        if (collapsed && !homeSearchPageActive) return
        homeSearchChromeCollapsed = collapsed
        val visibility = if (collapsed) View.GONE else View.VISIBLE
        homeSearchHeader?.visibility = visibility
        homeSearchChrome?.visibility = visibility
        homeInlineBrowserToolbar?.visibility = visibility
    }

    private fun hideSearchKeyboard() {
        if (!::root.isInitialized) return
        (getSystemService(INPUT_METHOD_SERVICE) as? android.view.inputmethod.InputMethodManager)
            ?.hideSoftInputFromWindow(root.windowToken, 0)
    }

    private fun addYoutubeMovieCard(parent: LinearLayout, item: JSONObject) {
        val videoId = item.optString("videoId")
        if (!Regex("^[A-Za-z0-9_-]{11}$").matches(videoId)) return
        val title = item.optString("title", "YouTube video")
        val channel = item.optString("channelName", "YouTube channel")
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; background = round(Color.WHITE, 14)
            setPadding(dp(8), dp(8), dp(10), dp(8)); isClickable = true; isFocusable = true
            setOnClickListener { openYoutubeVideo(videoId) }
        }
        val thumbnail = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP; background = round(0xffdce8ed.toInt(), 9); clipToOutline = true
            layoutParams = LinearLayout.LayoutParams(dp(126), dp(76)).apply { rightMargin = dp(10) }
            contentDescription = "YouTube thumbnail: $title"
        }
        row.addView(thumbnail)
        val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        labels.addView(label(title, 14, primaryText, true).apply { maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END })
        labels.addView(label(channel, 12, secondaryText, false).apply { setPadding(0, dp(4), 0, dp(3)); maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END })
        labels.addView(label("▶  Watch on YouTube", 11, 0xffe62117.toInt(), true))
        row.addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
        parent.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(7) })
        val thumbnailUrl = item.optString("thumbnailUrl")
        val uri = Uri.parse(thumbnailUrl)
        if (uri.scheme == "https" && (uri.host == "i.ytimg.com" || uri.host?.endsWith(".ytimg.com") == true)) {
            aiScope.launch {
                try {
                    val bitmap = withContext(Dispatchers.IO) {
                        val connection = java.net.URL(thumbnailUrl).openConnection().apply { connectTimeout = 8000; readTimeout = 8000 }
                        connection.getInputStream().use { BitmapFactory.decodeStream(it) }
                    }
                    if (bitmap != null) runOnUiThread { if (thumbnail.isAttachedToWindow) thumbnail.setImageBitmap(bitmap) }
                } catch (error: Exception) { Log.w("HiraBhaiYouTube", "Could not load YouTube thumbnail", error) }
            }
        }
    }

    private fun openYoutubeVideo(videoId: String) {
        openInAppBrowser("https://www.youtube.com/watch?v=$videoId")
    }

    private fun exitHomeWebFullscreen() {
        val view = homeWebFullscreenView ?: return
        homeWebFullscreenContainer?.let { (it.parent as? ViewGroup)?.removeView(it) }
        homeWebFullscreenView = null
        homeWebFullscreenContainer = null
        homeWebFullscreenCallback?.onCustomViewHidden()
        homeWebFullscreenCallback = null
        requestedOrientation = homeWebPreviousOrientation
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        root.requestApplyInsets()
    }

    private fun postYoutubeFunction(projectId: String, query: String): JSONObject {
        val connection = (URL("https://us-central1-$projectId.cloudfunctions.net/youtubeMoviesSearch").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 15000; readTimeout = 30000; doOutput = true
            setRequestProperty("Content-Type", "application/json")
        }
        connection.outputStream.use { it.write(JSONObject().put("query", query).toString().toByteArray()) }
        val code = connection.responseCode
        val body = (if (code in 200..299) connection.inputStream else connection.errorStream).bufferedReader().use { it.readText() }
        connection.disconnect()
        val result = JSONObject(body)
        if (code !in 200..299) throw IllegalStateException(result.optString("error", "YouTube search failed ($code)"))
        return result
    }

    private fun loadPublicVideoFeed(feed: LinearLayout, refresh: SwipeRefreshLayout?, mode: String = "For you", reset: Boolean = false) {
        val state = homeFeedPages.getOrPut(mode) { HomeFeedPageState() }
        if (reset) {
            state.generation++
            state.cursor = null
            state.loadedIds.clear()
            state.hasMore = true
            state.loading = false
            state.footer = null
            feed.removeAllViews()
        } else {
            if (state.loading || !state.hasMore) return
            state.footer?.let(feed::removeView)
            state.footer = null
            if (state.cursor == null && state.loadedIds.isNotEmpty()) return
        }
        val generation = state.generation
        state.loading = true
        val db = FirebaseBackend.db ?: run {
            state.loading = false
            if (reset) feed.removeAllViews()
            feed.addView(label("Video feed is unavailable until Firestore is configured.", 14, 0xffe4f4fb.toInt(), false))
            refresh?.isRefreshing = false
            return
        }
        val loading = if (reset) {
            val box = LinearLayout(this).apply {
                gravity = Gravity.CENTER; orientation = LinearLayout.VERTICAL
                setPadding(0, dp(18), 0, dp(18))
                addView(ProgressBar(this@MainActivity).apply { isIndeterminate = true }, LinearLayout.LayoutParams(dp(32), dp(32)))
            }
            box.addView(label("Loading public videos…", 14, 0xffe4f4fb.toInt(), false).apply { setPadding(0, dp(8), 0, 0) })
            feed.addView(box)
            box
        } else {
            val row = label("Loading more videos…", 13, 0xffe4f4fb.toInt(), false).apply { gravity = Gravity.CENTER; setPadding(0, dp(16), 0, dp(16)) }
            feed.addView(row)
            row
        }
        var query: com.google.firebase.firestore.Query = db.collection("videos").whereEqualTo("visibility", "public")
            .orderBy("createdAt", com.google.firebase.firestore.Query.Direction.DESCENDING).limit(40)
        state.cursor?.let { query = query.startAfter(it) }
        query.get().addOnSuccessListener { snapshot ->
            if (state.generation != generation) return@addOnSuccessListener
            state.loading = false
            feed.removeView(loading)
            state.cursor = snapshot.documents.lastOrNull() ?: state.cursor
            state.hasMore = snapshot.size() == 40
            val page = snapshot.documents.filter { it.id !in state.loadedIds && it.getString("visibility") == "public" && it.getBoolean("isShort") != true }
            state.loadedIds.addAll(snapshot.documents.map { it.id })
            if (page.isEmpty()) {
                if (state.loadedIds.isEmpty()) feed.addView(label("No public videos yet. Be the first to upload one.", 14, 0xffe4f4fb.toInt(), false).apply { setPadding(0, dp(6), 0, dp(12)) })
                finishHomeFeedPage(feed, refresh, mode, state, generation)
            } else rankAndRenderRecommendations(db, feed, page, mode, isCurrent = { state.generation == generation }) {
                finishHomeFeedPage(feed, refresh, mode, state, generation)
            }
        }.addOnFailureListener { error ->
            if (state.generation != generation) return@addOnFailureListener
            state.loading = false
            feed.removeView(loading)
            val projectId = try { com.google.firebase.FirebaseApp.getInstance().options.projectId ?: "unknown" } catch (_: Exception) { "unavailable" }
            val denied = error is com.google.firebase.firestore.FirebaseFirestoreException && error.code == com.google.firebase.firestore.FirebaseFirestoreException.Code.PERMISSION_DENIED
            val message = if (denied) "Public videos are blocked by Firestore Rules in project $projectId. Publish the corrected /videos rule for visibility = public, then refresh." else "Could not load videos: ${friendlyError(error)}"
            feed.addView(label(message, 14, 0xffe4f4fb.toInt(), false).apply { setPadding(0, dp(8), 0, dp(8)) })
            if (state.cursor != null || state.loadedIds.isNotEmpty()) feed.addView(buttonView("Retry loading videos") { loadPublicVideoFeed(feed, refresh, mode, reset = false) })
            refresh?.isRefreshing = false
            Log.e("HiraBhaiVideo", "Read failed: project=$projectId path=/videos where visibility=public", error)
        }
    }

    private fun finishHomeFeedPage(feed: LinearLayout, refresh: SwipeRefreshLayout?, mode: String, state: HomeFeedPageState, generation: Int) {
        if (state.generation != generation) return
        state.footer?.let(feed::removeView)
        state.footer = null
        if (state.hasMore) {
            state.footer = buttonView("Load more videos") { loadPublicVideoFeed(feed, refresh, mode, reset = false) }
            feed.addView(state.footer, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8); bottomMargin = dp(14) })
        } else if (state.loadedIds.isNotEmpty()) {
            state.footer = label("You’re all caught up", 12, 0xffe4f4fb.toInt(), false).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(16)) }
            feed.addView(state.footer)
        }
        refresh?.isRefreshing = false
    }

    private fun rankAndRenderRecommendations(
        db: com.google.firebase.firestore.FirebaseFirestore,
        feed: LinearLayout,
        videos: List<com.google.firebase.firestore.DocumentSnapshot>,
        mode: String,
        isCurrent: () -> Boolean,
        done: () -> Unit
    ) {
        val uid = FirebaseBackend.auth?.currentUser?.uid
        // User-private signals are read only when the owner has enabled personalized recommendations.
        fun rank(
            history: List<com.google.firebase.firestore.DocumentSnapshot>,
            subscriptions: Set<String>,
            preferences: List<com.google.firebase.firestore.DocumentSnapshot>,
            personalized: Boolean
        ) {
            if (!isCurrent()) return
            val historyIds = history.map { it.id }.toSet()
            val likedIds = history.filter { it.getBoolean("liked") == true }.map { it.id }.toSet()
            val weightedTopics = history.take(30).flatMap { item ->
                val title = item.getString("title") ?: return@flatMap emptyList()
                val openWeight = ((item.getLong("openCount") ?: 1L) - 1L).coerceIn(0L, 2L).toInt()
                val duration = item.getLong("durationMs") ?: 0L
                val completionWeight = if (duration > 0L && (item.getLong("positionMs") ?: 0L) * 100 / duration >= 60L) 2 else 0
                val multiplier = (1 + openWeight + completionWeight + if (item.getBoolean("liked") == true) 3 else 0).coerceAtMost(7)
                List(multiplier) { recommendationTokens(title) }.flatten()
            }
            val localSearchTopics = if (personalized) getRecentSearches().take(8).flatMapIndexed { index, query ->
                List(8 - index) { recommendationTokens(query) }.flatten()
            } else emptyList()
            val localPageTopics = if (personalized) InterestHistory.recentPageTitles(this).take(20).flatMapIndexed { index, title ->
                List((4 - index / 5).coerceAtLeast(1)) { recommendationTokens(title) }.flatten()
            } else emptyList()
            val interestTokens = (weightedTopics + localSearchTopics + localPageTopics).groupingBy { it }.eachCount()
            val notInterested = preferences.filter { it.getString("kind") == "not_interested_video" }.mapNotNull { it.getString("videoId") }.toSet()
            val mutedCreators = preferences.filter { it.getString("kind") == "muted_creator" }.mapNotNull { it.getString("creatorId") }.toSet()
            val visibleVideos = videos.filter { it.id !in notInterested && (it.getString("creatorId") ?: "") !in mutedCreators }
            val unseen = visibleVideos.filter { !personalized || it.id !in historyIds }
            val candidates = unseen.ifEmpty { visibleVideos }
            val finishWithStats: (Map<String, Long>) -> Unit = finish@{ likes ->
                if (!isCurrent()) return@finish
                val now = System.currentTimeMillis()
                val ranked = candidates.map { doc ->
                    val data = doc.data ?: emptyMap()
                    val title = (data["title"] as? String).orEmpty()
                    val description = (data["description"] as? String).orEmpty()
                    val creatorId = data["creatorId"] as? String ?: ""
                    val tokens = recommendationTokens("$title $description ${(data["tags"] as? List<*>)?.joinToString(" ").orEmpty()} ${(data["category"] as? String).orEmpty()}")
                    val affinity = tokens.sumOf { (interestTokens[it] ?: 0).coerceAtMost(4) }
                    val categoryMatch = mode in listOf("Music", "Learning", "Nature") && tokens.any { it in recommendationTokens(mode) }
                    val publishedAt = doc.getTimestamp("createdAt")?.toDate()?.time ?: 0L
                    val ageHours = ((now - publishedAt).coerceAtLeast(0L) / 3_600_000.0)
                    val recency = (72.0 - ageHours).coerceAtLeast(0.0) / 12.0
                    val likeCount = likes[doc.id] ?: 0L
                    val score = when (mode) {
                        "Trending" -> likeCount * 3.0 + recency
                        "Popular" -> likeCount + recency * 0.05
                        "Recent" -> publishedAt.toDouble()
                        "Music", "Learning", "Nature" -> (if (categoryMatch) 100.0 else 0.0) + affinity * 3 + recency
                        else -> if (personalized) affinity * 4.0 + (if (creatorId in subscriptions) 12.0 else 0.0) + recency - (if (doc.id in likedIds) 12.0 else 0.0) else likeCount * 3.0 + recency
                    }
                    Triple(doc, score, creatorId)
                }.filter { mode !in listOf("Music", "Learning", "Nature") || it.second >= 100.0 }
                    .sortedWith(compareByDescending<Triple<com.google.firebase.firestore.DocumentSnapshot, Double, String>> { it.second }
                        .thenByDescending { it.first.getTimestamp("createdAt")?.toDate()?.time ?: 0L })
                val diversified = mutableListOf<com.google.firebase.firestore.DocumentSnapshot>()
                val creatorCounts = mutableMapOf<String, Int>()
                ranked.forEach { item -> if ((creatorCounts[item.third] ?: 0) < 2) { diversified.add(item.first); creatorCounts[item.third] = (creatorCounts[item.third] ?: 0) + 1 } }
                if (diversified.isEmpty()) feed.addView(label(if (mode == "For you" && uid == null) "Sign in and watch or like videos to personalize your feed." else "No matching public videos yet.", 14, 0xffe4f4fb.toInt(), false))
                else {
                    if (mode == "For you" && personalized) renderRecommendedCreators(feed, diversified)
                    diversified.take(30).forEach { doc -> addHomeVideoCard(feed, doc.id, doc.data ?: emptyMap(), showRecommendationControls = mode == "For you") }
                }
                if (mode == "Recent") feed.addView(label("Sorted by upload date. Only public videos are included.", 12, 0xffe4f4fb.toInt(), false).apply { setPadding(0, dp(4), 0, dp(8)) })
                if (mode == "Trending" || mode == "Popular") feed.addView(label("Ranked from real like counts and upload dates. Hira Bhai does not currently track public view counts.", 12, 0xffe4f4fb.toInt(), false).apply { setPadding(0, dp(4), 0, dp(8)) })
                done()
            }
            if (mode !in listOf("Trending", "Popular") && !(mode == "For you" && !personalized)) { finishWithStats(emptyMap()); return }
            val allLikes = mutableMapOf<String, Long>()
            fun readLikeChunk(offset: Int) {
                val ids = candidates.drop(offset).take(30).map { it.id }
                if (ids.isEmpty()) { finishWithStats(allLikes); return }
                db.collection("videoStats").whereIn("videoId", ids).get()
                    .addOnSuccessListener { snap ->
                        snap.documents.forEach { allLikes[it.getString("videoId").orEmpty()] = (it.getLong("likeCount") ?: 0L).coerceAtLeast(0L) }
                        readLikeChunk(offset + ids.size)
                    }
                    .addOnFailureListener { error ->
                        Log.w("HiraBhaiRecommendations", "Could not read public like aggregate chunk", error)
                        readLikeChunk(offset + ids.size)
                    }
            }
            readLikeChunk(0)
        }
        fun loadPrivateSignals() {
            if (uid == null) { rank(emptyList(), emptySet(), emptyList(), false); return }
            val preferencesTask = db.collection("userActivity").document(uid).collection("recommendationPreferences").limit(500).get()
            if (mode != "For you") {
                preferencesTask.addOnSuccessListener { rank(emptyList(), emptySet(), it.documents, false) }
                    .addOnFailureListener { rank(emptyList(), emptySet(), emptyList(), false) }
                return
            }
            db.collection("userSettings").document(uid).get().addOnSuccessListener { settings ->
                if (!isCurrent()) return@addOnSuccessListener
                if (settings.getBoolean("recommendationsEnabled") == false) {
                    preferencesTask.addOnSuccessListener { rank(emptyList(), emptySet(), it.documents, false) }
                        .addOnFailureListener { rank(emptyList(), emptySet(), emptyList(), false) }
                    return@addOnSuccessListener
                }
                val historyTask = db.collection("userActivity").document(uid).collection("watchHistory")
                    .orderBy("lastWatchedAt", com.google.firebase.firestore.Query.Direction.DESCENDING).limit(100).get()
                val subscriptionsTask = db.collection("subscriptions").document(uid).collection("creators").limit(200).get()
                historyTask.addOnSuccessListener { history ->
                    subscriptionsTask.addOnSuccessListener { subscriptions ->
                        preferencesTask.addOnSuccessListener { preferences -> rank(history.documents, subscriptions.documents.mapNotNull { it.getString("creatorId") }.toSet(), preferences.documents, true) }
                            .addOnFailureListener { rank(history.documents, subscriptions.documents.mapNotNull { it.getString("creatorId") }.toSet(), emptyList(), true) }
                    }.addOnFailureListener { rank(history.documents, emptySet(), emptyList(), true) }
                }.addOnFailureListener { error ->
                    Log.w("HiraBhaiRecommendations", "Private watch history unavailable", error)
                    rank(emptyList(), emptySet(), emptyList(), false)
                }
            }.addOnFailureListener { error ->
                Log.w("HiraBhaiRecommendations", "Recommendation privacy setting unavailable; private signals will not be read", error)
                preferencesTask.addOnSuccessListener { rank(emptyList(), emptySet(), it.documents, false) }
                    .addOnFailureListener { rank(emptyList(), emptySet(), emptyList(), false) }
            }
        }
        loadPrivateSignals()
    }

    private fun recommendationTokens(text: String): Set<String> =
        text.lowercase(Locale.ROOT).split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length >= 3 }.toSet()

    private fun renderRecommendedCreators(feed: LinearLayout, videos: List<com.google.firebase.firestore.DocumentSnapshot>) {
        if (feed.findViewWithTag<View>("recommended_creator_row") != null) return
        val creators = videos.mapNotNull { doc ->
            val data = doc.data ?: return@mapNotNull null
            val id = data["creatorId"] as? String ?: return@mapNotNull null
            val username = data["creatorUsername"] as? String ?: return@mapNotNull null
            Triple(id, data["creatorName"] as? String ?: username, username)
        }.distinctBy { it.first }.take(8)
        if (creators.isEmpty()) return
        val section = LinearLayout(this).apply {
            tag = "recommended_creator_row"
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(2), 0, dp(10))
        }
        section.addView(label("Creators you may like", 17, Color.WHITE, true).apply { setPadding(0, dp(4), 0, dp(8)) })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        creators.forEach { (_, name, username) ->
            val creator = TextView(this).apply {
                text = "◉\n$name\n@$username"
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                background = glass(0x43ffffff, 18)
                setPadding(dp(12), dp(11), dp(12), dp(11))
                maxWidth = dp(155)
                maxLines = 3
                ellipsize = android.text.TextUtils.TruncateAt.END
                isClickable = true
                isFocusable = true
                setOnClickListener { loadPublicCreator(username, null) }
            }
            row.addView(creator, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(8) })
        }
        section.addView(android.widget.HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) })
        feed.addView(section)
    }

    private fun saveRecommendationFeedback(kind: String, videoId: String, creatorId: String?, onSaved: () -> Unit) {
        val user = FirebaseBackend.auth?.currentUser ?: run { info("Sign in required", "Sign in to manage your personalized video recommendations."); return }
        val db = FirebaseBackend.db ?: run { info("Recommendations unavailable", "Firestore is not configured."); return }
        val preferenceId = if (kind == "not_interested_video") "v_$videoId" else "c_${java.security.MessageDigest.getInstance("SHA-256").digest((creatorId ?: "").toByteArray()).joinToString("") { "%02x".format(it) }}"
        val values = mutableMapOf<String, Any>("kind" to kind, "updatedAt" to FieldValue.serverTimestamp())
        if (kind == "not_interested_video") values["videoId"] = videoId
        if (!creatorId.isNullOrBlank()) values["creatorId"] = creatorId
        db.collection("userActivity").document(user.uid).collection("recommendationPreferences").document(preferenceId)
            .set(values)
            .addOnSuccessListener { onSaved() }
            .addOnFailureListener { error -> info("Preference not saved", friendlyError(error)); Log.w("HiraBhaiRecommendations", "Private feedback write failed", error) }
    }

    private fun resetRecommendationFeedback() {
        val user = FirebaseBackend.auth?.currentUser ?: run { showAuth(false); return }
        val db = FirebaseBackend.db ?: return info("Recommendations unavailable", "Firestore is not configured.")
        val ref = db.collection("userActivity").document(user.uid).collection("recommendationPreferences")
        ref.get().addOnSuccessListener { snapshot ->
            if (snapshot.isEmpty) { info("Preferences reset", "There are no recommendation feedback preferences to clear."); return@addOnSuccessListener }
            val batches = snapshot.documents.chunked(450)
            var remaining = batches.size
            batches.forEach { docs ->
                val batch = db.batch()
                docs.forEach { batch.delete(it.reference) }
                batch.commit().addOnSuccessListener {
                    remaining--
                    if (remaining == 0) {
                        homeFeedPages.clear()
                        info("Preferences reset", "Not Interested and creator exclusions were cleared. Your watch history and subscriptions were not changed.")
                    }
                }.addOnFailureListener { info("Could not reset preferences", friendlyError(it)) }
            }
        }.addOnFailureListener { info("Could not reset preferences", friendlyError(it)) }
    }

    private fun loadRelatedVideos(parent: LinearLayout, currentVideoId: String, currentVideo: Map<String, Any>) {
        parent.addView(label("Related videos", 20, primaryText, true).apply { setPadding(0, dp(20), 0, dp(12)) })
        val status = label("Finding public videos with similar titles, topics, and categories…", 13, secondaryText, false)
        parent.addView(status)
        val db = FirebaseBackend.db ?: run { status.text = "Related videos need a configured Firestore connection."; return }
        val sourceTokens = recommendationTokens("${currentVideo["title"] ?: ""} ${currentVideo["description"] ?: ""} ${(currentVideo["tags"] as? List<*>)?.joinToString(" ").orEmpty()} ${currentVideo["category"] ?: ""}")
        val sourceCategory = (currentVideo["category"] as? String).orEmpty().lowercase(Locale.ROOT)
        db.collection("videos").whereEqualTo("visibility", "public")
            .orderBy("createdAt", com.google.firebase.firestore.Query.Direction.DESCENDING).limit(60).get()
            .addOnSuccessListener { snapshot ->
                val candidates = snapshot.documents.filter { it.id != currentVideoId && it.getString("visibility") == "public" && it.getBoolean("isShort") != true }
                val user = FirebaseBackend.auth?.currentUser
                val preferencesTask = user?.let {
                    db.collection("userActivity").document(it.uid).collection("recommendationPreferences").limit(500).get()
                }
                fun render(preferences: List<com.google.firebase.firestore.DocumentSnapshot>) {
                    if (parent.indexOfChild(status) < 0) return
                    val hiddenVideos = preferences.filter { it.getString("kind") == "not_interested_video" }.mapNotNull { it.getString("videoId") }.toSet()
                    val hiddenCreators = preferences.filter { it.getString("kind") == "muted_creator" }.mapNotNull { it.getString("creatorId") }.toSet()
                    val ranked = candidates.asSequence().filter { doc ->
                        doc.id !in hiddenVideos && (doc.getString("creatorId") ?: "") !in hiddenCreators
                    }.map { doc ->
                        val data = doc.data ?: emptyMap()
                        val tokens = recommendationTokens("${data["title"] ?: ""} ${data["description"] ?: ""} ${(data["tags"] as? List<*>)?.joinToString(" ").orEmpty()} ${data["category"] ?: ""}")
                        val overlap = sourceTokens.intersect(tokens).size
                        val categoryMatch = sourceCategory.isNotBlank() && sourceCategory == (data["category"] as? String).orEmpty().lowercase(Locale.ROOT)
                        Triple(doc, overlap * 2.0 + if (categoryMatch) 5.0 else 0.0, doc.getString("creatorId").orEmpty())
                    }.filter { it.second > 0.0 }
                        .sortedByDescending { it.second }
                        .toList()
                    val diverse = mutableListOf<com.google.firebase.firestore.DocumentSnapshot>()
                    val creators = mutableMapOf<String, Int>()
                    ranked.forEach { item ->
                        if ((creators[item.third] ?: 0) < 2) {
                            diverse.add(item.first)
                            creators[item.third] = (creators[item.third] ?: 0) + 1
                        }
                    }
                    if (diverse.isEmpty()) {
                        status.text = "No related public videos found yet. New public videos appear here when their metadata matches."
                    } else {
                        parent.removeView(status)
                        renderRecommendedCreators(parent, diverse)
                        diverse.take(8).forEach { doc -> addHomeVideoCard(parent, doc.id, doc.data ?: emptyMap()) }
                    }
                }
                preferencesTask?.addOnSuccessListener { render(it.documents) }
                    ?.addOnFailureListener { error ->
                        Log.w("HiraBhaiRecommendations", "Related-video preferences unavailable", error)
                        render(emptyList())
                    } ?: render(emptyList())
            }
            .addOnFailureListener { status.text = "Could not load related videos: ${friendlyError(it)}" }
    }

    private fun recordVideoOpened(videoId: String, video: Map<String, Any>) {
        val user = FirebaseBackend.auth?.currentUser ?: return
        val db = FirebaseBackend.db ?: return
        val ref = db.collection("userActivity").document(user.uid).collection("watchHistory").document(videoId)
        db.runTransaction { tx ->
            val current = tx.get(ref)
            val count = (current.getLong("openCount") ?: 0L).coerceAtMost(100000L)
            val payload = mapOf(
                "videoId" to videoId,
                "title" to ((video["title"] as? String)?.take(120) ?: "Video"),
                "creatorId" to ((video["creatorId"] as? String).orEmpty()),
                "creatorName" to ((video["creatorName"] as? String)?.take(120) ?: "Creator"),
                "creatorUsername" to ((video["creatorUsername"] as? String)?.take(32) ?: "creator"),
                "thumbnailStoragePath" to ((video["thumbnailStoragePath"] as? String).orEmpty()),
                "lastWatchedAt" to FieldValue.serverTimestamp(),
                "openCount" to (count + 1L),
                "liked" to (current.getBoolean("liked") ?: false),
                "positionMs" to (current.getLong("positionMs") ?: 0L),
                "durationMs" to ((video["durationMs"] as? Number)?.toLong() ?: current.getLong("durationMs") ?: 0L)
            )
            tx.set(ref, payload)
        }.addOnFailureListener { Log.w("HiraBhaiRecommendations", "Private watch history write failed", it) }
    }

    private fun savePlaybackProgress(videoId: String, player: ExoPlayer) {
        if (activeHistoryVideoId != videoId) return
        val user = FirebaseBackend.auth?.currentUser ?: return
        val db = FirebaseBackend.db ?: return
        val duration = player.duration.takeIf { it > 0L } ?: 0L
        val position = player.currentPosition.coerceAtLeast(0L).let { if (duration > 0L) it.coerceAtMost(duration) else it }
        val ref = db.collection("userActivity").document(user.uid).collection("watchHistory").document(videoId)
        ref.set(mapOf(
            "videoId" to videoId,
            "positionMs" to position,
            "durationMs" to duration,
            "lastWatchedAt" to FieldValue.serverTimestamp()
        ), SetOptions.merge()).addOnFailureListener { Log.w("HiraBhaiHistory", "Playback position save failed", it) }
    }

    private fun schedulePlaybackProgress(videoId: String, player: ExoPlayer) {
        playbackProgressRunnable?.let { playbackProgressHandler.removeCallbacks(it) }
        val runnable = object : Runnable {
            override fun run() {
                if (videoPlayer !== player || currentVideoId != videoId || !player.isPlaying) return
                savePlaybackProgress(videoId, player)
                playbackProgressHandler.postDelayed(this, 15_000L)
            }
        }
        playbackProgressRunnable = runnable
        playbackProgressHandler.postDelayed(runnable, 15_000L)
    }

    private fun stopPlaybackProgress(save: Boolean = true) {
        playbackProgressRunnable?.let { playbackProgressHandler.removeCallbacks(it) }
        playbackProgressRunnable = null
        val id = currentVideoId
        val player = videoPlayer
        if (save && id != null && player != null) savePlaybackProgress(id, player)
    }

    private fun setRecommendationLike(videoId: String, liked: Boolean) {
        val user = FirebaseBackend.auth?.currentUser ?: return
        val db = FirebaseBackend.db ?: return
        val ref = db.collection("userActivity").document(user.uid).collection("watchHistory").document(videoId)
        ref.set(mapOf("videoId" to videoId, "liked" to liked, "updatedAt" to FieldValue.serverTimestamp()), SetOptions.merge())
            .addOnFailureListener { Log.w("HiraBhaiRecommendations", "Private recommendation preference update failed", it) }
    }

    private fun clearRecommendationHistory(onComplete: (() -> Unit)? = null) {
        val user = FirebaseBackend.auth?.currentUser ?: run { showAuth(false); return }
        val db = FirebaseBackend.db ?: return info("History unavailable", "Firestore is not configured.")
        val ref = db.collection("userActivity").document(user.uid).collection("watchHistory")
        ref.get().addOnSuccessListener { snapshot ->
            val batches = snapshot.documents.chunked(450)
            if (batches.isEmpty()) { info("Watch history cleared", "Your private watch history is already empty."); onComplete?.invoke(); return@addOnSuccessListener }
            var remaining = batches.size
            batches.forEach { docs ->
                val batch = db.batch(); docs.forEach { batch.delete(it.reference) }
                batch.commit().addOnSuccessListener { if (--remaining == 0) { info("Watch history cleared", "Your private watch history was deleted."); onComplete?.invoke() } }
                    .addOnFailureListener { info("Could not clear history", friendlyError(it)) }
            }
        }.addOnFailureListener { info("Could not clear history", friendlyError(it)) }
    }

    private fun showWatchHistory() {
        val user = FirebaseBackend.auth?.currentUser ?: run { showAuth(false); return }
        selected = "Library"; base(); heading("Watch history", "Private to your Hira Bhai account")
        button("Clear watch history") {
            AlertDialog.Builder(this).setTitle("Clear watch history?")
                .setMessage("This permanently removes your recent videos and saved playback positions.")
                .setNegativeButton("Cancel", null).setPositiveButton("Clear") { _, _ -> clearRecommendationHistory { showWatchHistory() } }.show()
        }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(list)
        val ref = FirebaseBackend.db?.collection("userActivity")?.document(user.uid)?.collection("watchHistory")
            ?: run { list.addView(label("Watch history is unavailable until Firestore is configured.", 14, secondaryText, false)); addBottom(); return }
        list.addView(label("Loading recent videos…", 13, secondaryText, false))
        ref.orderBy("lastWatchedAt", com.google.firebase.firestore.Query.Direction.DESCENDING).limit(100).get()
            .addOnSuccessListener { snapshot ->
                list.removeAllViews()
                if (snapshot.isEmpty) list.addView(label("Videos you watch will appear here.", 14, secondaryText, false))
                snapshot.documents.forEach { doc ->
                    val position = doc.getLong("positionMs") ?: 0L
                    val duration = doc.getLong("durationMs") ?: 0L
                    val progressText = if (position > 0L) "Resume · ${formatDuration(position)}${if (duration > 0L) " / ${formatDuration(duration)}" else ""}" else "Watch again"
                    addSavedVideoRow(list, doc.id, doc.getString("title") ?: "Video", doc.getString("creatorName") ?: doc.getString("creatorUsername") ?: "Creator", doc.getString("thumbnailStoragePath").orEmpty(), progressText,
                        onOpen = { openVideoById(doc.id) },
                        onRemove = { doc.reference.delete().addOnSuccessListener { showWatchHistory() }.addOnFailureListener { info("History item not removed", friendlyError(it)) } })
                }
            }
            .addOnFailureListener { list.removeAllViews(); list.addView(label("Could not load watch history: ${friendlyError(it)}", 13, secondaryText, false)) }
        addBottom()
    }

    private fun showWatchLater() {
        val user = FirebaseBackend.auth?.currentUser ?: run { showAuth(false); return }
        selected = "Library"; base(); heading("Watch Later", "Your private saved videos")
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(list)
        val ref = FirebaseBackend.db?.collection("userActivity")?.document(user.uid)?.collection("watchLater")
            ?: run { list.addView(label("Watch Later is unavailable until Firestore is configured.", 14, secondaryText, false)); addBottom(); return }
        list.addView(label("Loading saved videos…", 13, secondaryText, false))
        ref.orderBy("savedAt", com.google.firebase.firestore.Query.Direction.DESCENDING).limit(200).get()
            .addOnSuccessListener { snapshot ->
                list.removeAllViews()
                if (snapshot.isEmpty) list.addView(label("Save a video with ＋ Watch Later and it will appear here.", 14, secondaryText, false))
                snapshot.documents.forEach { doc ->
                    addSavedVideoRow(list, doc.id, doc.getString("title") ?: "Video", doc.getString("creatorName") ?: doc.getString("creatorUsername") ?: "Creator", doc.getString("thumbnailStoragePath").orEmpty(), "Saved for later",
                        onOpen = { openVideoById(doc.id) },
                        onRemove = { doc.reference.delete().addOnSuccessListener { showWatchLater() }.addOnFailureListener { info("Could not remove saved video", friendlyError(it)) } })
                }
            }
            .addOnFailureListener { list.removeAllViews(); list.addView(label("Could not load Watch Later: ${friendlyError(it)}", 13, secondaryText, false)) }
        addBottom()
    }

    private fun addSavedVideoRow(
        parent: LinearLayout, videoId: String, title: String, creator: String, thumbnailPath: String,
        subtitle: String, onOpen: () -> Unit, onRemove: () -> Unit
    ) {
        val card = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; background = round(Color.WHITE, 15); setPadding(dp(9), dp(9), dp(9), dp(9)) }
        val thumbnail = ImageView(this).apply { setImageResource(android.R.drawable.ic_media_play); scaleType = ImageView.ScaleType.CENTER_CROP; background = round(0xffdce8ed.toInt(), 10); clipToOutline = true; layoutParams = LinearLayout.LayoutParams(dp(94), dp(68)).apply { rightMargin = dp(9) }; isClickable = true; setOnClickListener { onOpen() } }
        card.addView(thumbnail)
        val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; isClickable = true; setOnClickListener { onOpen() } }
        details.addView(label(title, 14, primaryText, true).apply { maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END })
        details.addView(label(creator, 12, secondaryText, false).apply { setPadding(0, dp(3), 0, 0); maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END })
        details.addView(label(subtitle, 11, mint, true).apply { setPadding(0, dp(4), 0, 0) })
        card.addView(details, LinearLayout.LayoutParams(0, -2, 1f))
        val remove = TextView(this).apply { text = "×"; textSize = 22f; setTextColor(0xffa6404c.toInt()); gravity = Gravity.CENTER; contentDescription = "Remove $title"; setPadding(dp(8), dp(8), dp(4), dp(8)); setOnClickListener { onRemove() } }
        card.addView(remove)
        parent.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        if (thumbnailPath.isNotBlank()) loadVideoThumbnail(thumbnailPath, thumbnail)
    }

    private fun addVideoToWatchLater(videoId: String, video: Map<String, Any>) {
        val user = FirebaseBackend.auth?.currentUser ?: run { showAuth(false); return }
        val db = FirebaseBackend.db ?: run { info("Watch Later unavailable", "Firestore is not configured."); return }
        val ref = db.collection("userActivity").document(user.uid).collection("watchLater").document(videoId)
        db.runTransaction { tx ->
            if (tx.get(ref).exists()) false
            else {
                tx.set(ref, mapOf(
                    "videoId" to videoId,
                    "title" to ((video["title"] as? String)?.take(120) ?: "Video"),
                    "creatorId" to ((video["creatorId"] as? String).orEmpty()),
                    "creatorName" to ((video["creatorName"] as? String)?.take(120) ?: "Creator"),
                    "creatorUsername" to ((video["creatorUsername"] as? String)?.take(32) ?: "creator"),
                    "thumbnailStoragePath" to ((video["thumbnailStoragePath"] as? String).orEmpty()),
                    "savedAt" to FieldValue.serverTimestamp()
                ))
                true
            }
        }.addOnSuccessListener { added -> info(if (added) "Saved to Watch Later" else "Already saved", if (added) "Find this video in your Library." else "This video is already on your Watch Later list.") }
            .addOnFailureListener { info("Could not save video", friendlyError(it)) }
    }

    private fun showPlaylists() {
        val user = FirebaseBackend.auth?.currentUser ?: run { showAuth(false); return }
        selected = "Playlists"; base(); heading("Playlists", "Your private and public video collections")
        action("＋ Create playlist", "Choose a name, description, and privacy") { createPlaylistDialog() }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(list)
        val ref = FirebaseBackend.db?.collection("userPlaylists")?.document(user.uid)?.collection("playlists")
            ?: run { list.addView(label("Playlists are unavailable until Firestore is configured.", 14, secondaryText, false)); addBottom(); return }
        list.addView(label("Loading playlists…", 13, secondaryText, false))
        ref.orderBy("updatedAt", com.google.firebase.firestore.Query.Direction.DESCENDING).limit(100).get()
            .addOnSuccessListener { snapshot ->
                list.removeAllViews()
                if (snapshot.isEmpty) list.addView(label("Create a playlist and add videos from any video card.", 14, secondaryText, false))
                snapshot.documents.forEach { doc ->
                    val privacy = if (doc.getString("visibility") == "public") "Public" else "Private"
                    val tile = LinearLayout(this).apply {
                        orientation = LinearLayout.VERTICAL; background = round(Color.WHITE, 16); setPadding(dp(15), dp(13), dp(15), dp(13))
                        isClickable = true; isFocusable = true; setOnClickListener { showMyPlaylist(doc.id) }
                    }
                    tile.addView(label(doc.getString("name") ?: "Playlist", 16, primaryText, true))
                    tile.addView(label("$privacy · ${doc.getLong("videoCount") ?: 0L} videos", 12, secondaryText, false).apply { setPadding(0, dp(4), 0, 0) })
                    val description = doc.getString("description").orEmpty()
                    if (description.isNotBlank()) tile.addView(label(description, 12, secondaryText, false).apply { setPadding(0, dp(5), 0, 0); maxLines = 2 })
                    list.addView(tile, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
                }
            }
            .addOnFailureListener { list.removeAllViews(); list.addView(label("Could not load playlists: ${friendlyError(it)}", 13, secondaryText, false)) }
        addBottom()
    }

    private fun createPlaylistDialog() {
        val user = FirebaseBackend.auth?.currentUser ?: run { showAuth(false); return }
        val db = FirebaseBackend.db ?: run { info("Playlist unavailable", "Firestore is not configured."); return }
        db.collection("profiles").document(user.uid).get().addOnSuccessListener { profile ->
            val creatorId = profile.getString("creatorId").orEmpty()
            val username = profile.getString("username").orEmpty()
            val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
            val name = field("Playlist name", android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES).apply { filters = arrayOf(android.text.InputFilter.LengthFilter(60)) }
            val description = field("Description (optional)", android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE).apply { minLines = 2; maxLines = 4; filters = arrayOf(android.text.InputFilter.LengthFilter(500)) }
            form.addView(name); form.addView(description)
            form.addView(label("Who can see this playlist?", 13, secondaryText, true).apply { setPadding(0, dp(10), 0, dp(4)) })
            val visibility = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
            val privateOption = RadioButton(this).apply { id = View.generateViewId(); text = "Private · only you" }
            val hasCreatorProfile = creatorId.isNotBlank() && username.isNotBlank()
            val publicOption = RadioButton(this).apply { id = View.generateViewId(); text = if (hasCreatorProfile) "Public · shown on your creator profile" else "Public · create a creator profile first"; isEnabled = hasCreatorProfile }
            visibility.addView(privateOption); visibility.addView(publicOption); visibility.check(privateOption.id); form.addView(visibility)
            val dialog = AlertDialog.Builder(this).setTitle("Create playlist").setView(form).setNegativeButton("Cancel", null).setPositiveButton("Create", null).create()
            dialog.setOnShowListener {
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                    val title = name.text.toString().trim(); val desc = description.text.toString().trim()
                    if (title.isBlank()) { name.error = "Enter a playlist name"; return@setOnClickListener }
                    val playlistId = UUID.randomUUID().toString()
                    val mode = if (visibility.checkedRadioButtonId == publicOption.id) "public" else "private"
                    val now = FieldValue.serverTimestamp()
                    val data = mapOf("playlistId" to playlistId, "creatorId" to creatorId, "creatorUsername" to username, "name" to title, "description" to desc, "visibility" to mode, "videoCount" to 0, "createdAt" to now, "updatedAt" to now)
                    val privateRef = db.collection("userPlaylists").document(user.uid).collection("playlists").document(playlistId)
                    val batch = db.batch(); batch.set(privateRef, data)
                    if (mode == "public") batch.set(db.collection("publicPlaylists").document(playlistId), data)
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled = false
                    batch.commit().addOnSuccessListener { dialog.dismiss(); showPlaylists() }
                        .addOnFailureListener { dialog.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled = true; info("Playlist not created", friendlyError(it)) }
                }
            }
            dialog.show()
        }.addOnFailureListener { info("Playlist unavailable", friendlyError(it)) }
    }

    private fun choosePlaylistForVideo(videoId: String, video: Map<String, Any>) {
        val user = FirebaseBackend.auth?.currentUser ?: run { showAuth(false); return }
        val db = FirebaseBackend.db ?: run { info("Playlist unavailable", "Firestore is not configured."); return }
        db.collection("userPlaylists").document(user.uid).collection("playlists").orderBy("updatedAt", com.google.firebase.firestore.Query.Direction.DESCENDING).limit(100).get()
            .addOnSuccessListener { snapshot ->
                val playlists = snapshot.documents
                if (playlists.isEmpty()) { AlertDialog.Builder(this).setTitle("No playlists yet").setMessage("Create a playlist before saving a video to it.").setNegativeButton("Cancel", null).setPositiveButton("Create playlist") { _, _ -> createPlaylistDialog() }.show(); return@addOnSuccessListener }
                AlertDialog.Builder(this).setTitle("Add to playlist").setItems(playlists.map { "${it.getString("name") ?: "Playlist"} · ${if (it.getString("visibility") == "public") "Public" else "Private"}" }.toTypedArray()) { _, which ->
                    addVideoToPlaylist(user.uid, playlists[which].id, videoId, video)
                }.setNegativeButton("Cancel", null).show()
            }.addOnFailureListener { info("Could not load playlists", friendlyError(it)) }
    }

    private fun addVideoToPlaylist(uid: String, playlistId: String, videoId: String, video: Map<String, Any>) {
        val db = FirebaseBackend.db ?: return
        val playlist = db.collection("userPlaylists").document(uid).collection("playlists").document(playlistId)
        val item = playlist.collection("items").document(videoId)
        val publicPlaylist = db.collection("publicPlaylists").document(playlistId)
        val publicItem = publicPlaylist.collection("items").document(videoId)
        db.runTransaction { tx ->
            val parent = tx.get(playlist)
            if (!parent.exists()) throw IllegalStateException("Playlist no longer exists.")
            val currentItem = tx.get(item)
            if (currentItem.exists()) return@runTransaction false
            val isPublic = parent.getString("visibility") == "public"
            val publicSnapshot = if (isPublic) tx.get(publicPlaylist) else null
            if (isPublic && publicSnapshot?.exists() != true) throw IllegalStateException("Public playlist is not available.")
            val count = (parent.getLong("videoCount") ?: 0L).toInt()
            if (count >= 200) throw IllegalStateException("A playlist can hold up to 200 videos.")
            val entry = mapOf("videoId" to videoId, "position" to count, "addedAt" to FieldValue.serverTimestamp())
            tx.set(item, entry)
            val patch = mapOf("videoCount" to count + 1, "updatedAt" to FieldValue.serverTimestamp())
            tx.update(playlist, patch)
            if (isPublic) {
                tx.set(publicItem, entry); tx.update(publicPlaylist, patch)
            }
            true
        }.addOnSuccessListener { added ->
            if (added) info("Added to playlist", "${video["title"] ?: "Video"} was added.") else info("Already in playlist", "This video is already saved in that playlist.")
        }.addOnFailureListener { info("Could not add video", friendlyError(it)) }
    }

    private fun showMyPlaylist(playlistId: String) {
        val user = FirebaseBackend.auth?.currentUser ?: run { showAuth(false); return }
        val db = FirebaseBackend.db ?: return info("Playlist unavailable", "Firestore is not configured.")
        db.collection("userPlaylists").document(user.uid).collection("playlists").document(playlistId).get()
            .addOnSuccessListener { doc -> if (doc.exists()) showPlaylistContents(playlistId, doc.data ?: emptyMap(), true) else info("Playlist unavailable", "This playlist was removed.") }
            .addOnFailureListener { info("Playlist unavailable", friendlyError(it)) }
    }

    private fun showPublicPlaylist(playlistId: String) {
        val db = FirebaseBackend.db ?: return info("Playlist unavailable", "Firestore is not configured.")
        db.collection("publicPlaylists").document(playlistId).get()
            .addOnSuccessListener { doc ->
                if (doc.exists() && doc.getString("visibility") == "public") showPlaylistContents(playlistId, doc.data ?: emptyMap(), false)
                else info("Playlist unavailable", "This public playlist is no longer available.")
            }.addOnFailureListener { info("Playlist unavailable", friendlyError(it)) }
    }

    private fun showPlaylistContents(playlistId: String, metadata: Map<String, Any>, owner: Boolean) {
        val user = FirebaseBackend.auth?.currentUser
        if (owner && user == null) { showAuth(false); return }
        selected = "Playlists"; base()
        val title = metadata["name"] as? String ?: "Playlist"
        val description = metadata["description"] as? String ?: ""
        val visibility = metadata["visibility"] as? String ?: "public"
        heading(title, "${if (visibility == "public") "Public" else "Private"} playlist · ${metadata["creatorUsername"] ?: "creator"}")
        if (description.isNotBlank()) content.addView(label(description, 14, secondaryText, false).apply { setPadding(0, 0, 0, dp(12)) })
        if (owner) content.addView(label("Playlist privacy is fixed when created. Only public videos can be added to public playlists; private playlists can also hold videos you can access.", 12, secondaryText, false).apply { setPadding(0, 0, 0, dp(8)) })
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(list)
        val db = FirebaseBackend.db ?: run { addBottom(); return }
        val items = if (owner) db.collection("userPlaylists").document(user!!.uid).collection("playlists").document(playlistId).collection("items")
            else db.collection("publicPlaylists").document(playlistId).collection("items")
        list.addView(label("Loading playlist videos…", 13, secondaryText, false))
        items.orderBy("position", com.google.firebase.firestore.Query.Direction.ASCENDING).limit(200).get()
            .addOnSuccessListener { snapshot ->
                list.removeAllViews()
                val itemDocs = snapshot.documents
                val videoIds = itemDocs.map { it.id }
                if (videoIds.isEmpty()) list.addView(label("This playlist is empty. Add videos from their Watch Later / Playlist controls.", 14, secondaryText, false))
                else {
                    val play = TextView(this).apply {
                        text = "▶  Play playlist"; textSize = 15f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
                        setTextColor(Color.WHITE); background = round(mint, 14); setPadding(dp(12), dp(12), dp(12), dp(12))
                        setOnClickListener { startPlaylistPlayback(videoIds) }
                    }
                    list.addView(play, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
                    if (snapshot.size() >= 200) list.addView(label("Showing the first 200 videos. Reorder is available for loaded items.", 12, secondaryText, false))
                    itemDocs.forEachIndexed { index, item ->
                        addPlaylistVideoRow(list, playlistId, metadata, owner, item, index, itemDocs)
                    }
                }
            }
            .addOnFailureListener { list.removeAllViews(); list.addView(label("Could not load playlist: ${friendlyError(it)}", 13, secondaryText, false)) }
        addBottom()
    }

    private fun addPlaylistVideoRow(
        parent: LinearLayout, playlistId: String, metadata: Map<String, Any>, owner: Boolean,
        item: com.google.firebase.firestore.DocumentSnapshot, index: Int,
        allItems: List<com.google.firebase.firestore.DocumentSnapshot>
    ) {
        val db = FirebaseBackend.db ?: return
        val videoId = item.id
        db.collection("videos").document(videoId).get().addOnSuccessListener { videoDoc ->
            if (!videoDoc.exists()) return@addOnSuccessListener
            val video = videoDoc.data ?: emptyMap()
            val title = videoDoc.getString("title") ?: "Video"
            val creator = videoDoc.getString("creatorName") ?: videoDoc.getString("creatorUsername") ?: "Creator"
            val card = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; background = round(Color.WHITE, 14); setPadding(dp(8), dp(8), dp(8), dp(8)) }
            val thumbnail = ImageView(this).apply { setImageResource(android.R.drawable.ic_media_play); scaleType = ImageView.ScaleType.CENTER_CROP; background = round(0xffdce8ed.toInt(), 9); clipToOutline = true; layoutParams = LinearLayout.LayoutParams(dp(96), dp(70)).apply { rightMargin = dp(9) }; setOnClickListener { openVideoById(videoId, video) } }
            card.addView(thumbnail)
            val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; isClickable = true; setOnClickListener { openVideoById(videoId, video) } }
            details.addView(label("${index + 1}. $title", 14, primaryText, true).apply { maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END })
            details.addView(label(creator, 12, secondaryText, false).apply { setPadding(0, dp(4), 0, 0) })
            card.addView(details, LinearLayout.LayoutParams(0, -2, 1f))
            if (owner) {
                val menu = TextView(this).apply {
                    text = "⋮"; textSize = 22f; gravity = Gravity.CENTER; setTextColor(primaryText); setPadding(dp(8), dp(8), dp(6), dp(8))
                    setOnClickListener {
                        val options = mutableListOf<String>(); val actions = mutableListOf<() -> Unit>()
                        if (index > 0) { options.add("Move up"); actions.add { movePlaylistVideo(playlistId, metadata, item, allItems[index - 1]) } }
                        if (index < allItems.lastIndex) { options.add("Move down"); actions.add { movePlaylistVideo(playlistId, metadata, item, allItems[index + 1]) } }
                        options.add("Remove from playlist"); actions.add { removePlaylistVideo(playlistId, metadata, videoId) }
                        AlertDialog.Builder(this@MainActivity).setTitle(title).setItems(options.toTypedArray()) { _, which -> actions[which]() }.show()
                    }
                }
                card.addView(menu)
            }
            parent.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
            (video["thumbnailStoragePath"] as? String)?.let { loadVideoThumbnail(it, thumbnail) }
        }.addOnFailureListener { Log.w("HiraBhaiPlaylist", "Could not read playlist video $videoId", it) }
    }

    private fun movePlaylistVideo(playlistId: String, metadata: Map<String, Any>, first: com.google.firebase.firestore.DocumentSnapshot, second: com.google.firebase.firestore.DocumentSnapshot) {
        val uid = FirebaseBackend.auth?.currentUser?.uid ?: run { showAuth(false); return }
        val db = FirebaseBackend.db ?: return
        val firstPosition = first.getLong("position") ?: 0L; val secondPosition = second.getLong("position") ?: 0L
        val privateItems = db.collection("userPlaylists").document(uid).collection("playlists").document(playlistId).collection("items")
        val batch = db.batch()
        batch.update(privateItems.document(first.id), "position", secondPosition)
        batch.update(privateItems.document(second.id), "position", firstPosition)
        if (metadata["visibility"] == "public") {
            val publicItems = db.collection("publicPlaylists").document(playlistId).collection("items")
            batch.update(publicItems.document(first.id), "position", secondPosition)
            batch.update(publicItems.document(second.id), "position", firstPosition)
        }
        batch.commit().addOnSuccessListener { showMyPlaylist(playlistId) }.addOnFailureListener { info("Could not reorder playlist", friendlyError(it)) }
    }

    private fun removePlaylistVideo(playlistId: String, metadata: Map<String, Any>, videoId: String) {
        val uid = FirebaseBackend.auth?.currentUser?.uid ?: run { showAuth(false); return }
        val db = FirebaseBackend.db ?: return
        val playlist = db.collection("userPlaylists").document(uid).collection("playlists").document(playlistId)
        val privateItems = playlist.collection("items")
        val publicPlaylist = db.collection("publicPlaylists").document(playlistId)
        privateItems.orderBy("position", com.google.firebase.firestore.Query.Direction.ASCENDING).limit(200).get()
            .addOnSuccessListener { snapshot ->
                if (snapshot.documents.none { it.id == videoId }) { showMyPlaylist(playlistId); return@addOnSuccessListener }
                val kept = snapshot.documents.filterNot { it.id == videoId }
                val patch = mapOf("videoCount" to kept.size, "updatedAt" to FieldValue.serverTimestamp())
                val batch = db.batch()
                batch.delete(privateItems.document(videoId))
                kept.forEachIndexed { index, doc -> if ((doc.getLong("position") ?: -1L) != index.toLong()) batch.update(doc.reference, "position", index) }
                batch.update(playlist, patch)
                if (metadata["visibility"] == "public") {
                    val publicItems = publicPlaylist.collection("items")
                    batch.delete(publicItems.document(videoId))
                    kept.forEachIndexed { index, doc -> if ((doc.getLong("position") ?: -1L) != index.toLong()) batch.update(publicItems.document(doc.id), "position", index) }
                    batch.update(publicPlaylist, patch)
                }
                batch.commit().addOnSuccessListener { showMyPlaylist(playlistId) }
                    .addOnFailureListener { info("Could not remove video", friendlyError(it)) }
            }
            .addOnFailureListener { info("Could not load playlist videos", friendlyError(it)) }
    }

    private fun addHomeVideoCard(parent: LinearLayout, videoId: String, video: Map<String, Any>, showRecommendationControls: Boolean = false) {
        val username = video["creatorUsername"] as? String
        val creatorId = video["creatorId"] as? String
        val title = video["title"] as? String ?: "Untitled video"
        val creator = video["creatorName"] as? String ?: username ?: "Creator"
        val duration = (video["durationMs"] as? Number)?.toLong() ?: 0L
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = glass(0x48ffffff, 20)
            setPadding(dp(10), dp(10), dp(10), dp(12)); isClickable = true; isFocusable = true
            setOnClickListener { openVideoById(videoId, video) }
        }
        val preview = FrameLayout(this).apply {
            background = round(0xffdce8ed.toInt(), 16); clipToOutline = true
            layoutParams = LinearLayout.LayoutParams(-1, dp(205))
        }
        val thumb = ImageView(this).apply {
            setImageResource(android.R.drawable.ic_media_play); scaleType = ImageView.ScaleType.CENTER_CROP
            layoutParams = FrameLayout.LayoutParams(-1, -1)
            contentDescription = "$title thumbnail"
        }
        preview.addView(thumb)
        val durationBadge = label(formatDuration(duration), 11, Color.WHITE, true).apply {
            setPadding(dp(7), dp(4), dp(7), dp(4)); background = round(0xcc102b3b.toInt(), 7)
        }
        preview.addView(durationBadge, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END).apply { rightMargin = dp(8); bottomMargin = dp(8) })
        card.addView(preview)
        card.addView(label(title, 17, Color.WHITE, true).apply { setPadding(dp(2), dp(11), dp(2), dp(4)) })
        val creatorLink = label("$creator${username?.let { "  ·  @$it" } ?: ""}", 13, 0xffe0eff7.toInt(), false).apply {
            isClickable = username != null; isFocusable = username != null
            if (username != null) setOnClickListener { loadPublicCreator(username, null) }
        }
        card.addView(creatorLink)
        if (username != null && creatorId != null) addSearchSubscriptionButton(card, username, creatorId)
        addVideoLibraryButtons(card, videoId, video)
        if (showRecommendationControls) {
            val controls = LinearLayout(this).apply { gravity = Gravity.END }
            val more = TextView(this).apply {
                text = "⋮  Recommendation options"
                textSize = 12f
                setTextColor(secondaryText)
                setPadding(dp(10), dp(8), dp(10), dp(8))
                isClickable = true
                isFocusable = true
                setOnClickListener { anchor ->
                    val menu = android.widget.PopupMenu(this@MainActivity, anchor)
                    menu.menu.add("Not interested")
                    if (!creatorId.isNullOrBlank()) menu.menu.add("Don’t recommend this creator")
                    menu.setOnMenuItemClickListener { item ->
                        val kind = if (item.title.toString() == "Not interested") "not_interested_video" else "muted_creator"
                        saveRecommendationFeedback(kind, videoId, creatorId) {
                            parent.removeView(card)
                            info("Recommendation updated", if (kind == "not_interested_video") "We’ll show you fewer videos like this." else "We’ll hide recommendations from this creator.")
                        }
                        true
                    }
                    menu.show()
                }
            }
            controls.addView(more)
            card.addView(controls)
        }
        if (FirebaseBackend.auth?.currentUser?.uid != video["ownerUid"]) {
            val report = TextView(this).apply {
                text = "⚑  Report video"; textSize = 12f; setTextColor(if (selected == "Home") 0xffe3f4fb.toInt() else secondaryText)
                setPadding(dp(4), dp(8), dp(4), dp(2)); isClickable = true; isFocusable = true
                setOnClickListener { showReportDialog("video", videoId) }
            }
            card.addView(report)
        }
        parent.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        (video["thumbnailStoragePath"] as? String)?.let { loadVideoThumbnail(it, thumb) }
    }

    private fun addVideoLibraryButtons(parent: LinearLayout, videoId: String, video: Map<String, Any>) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        fun smallButton(title: String, onClick: () -> Unit): TextView = TextView(this).apply {
            text = title; textSize = 12f; typeface = Typeface.DEFAULT_BOLD; setTextColor(primaryText)
            background = round(0xffe8f2f5.toInt(), 12); gravity = Gravity.CENTER; setPadding(dp(10), dp(8), dp(10), dp(8))
            isClickable = true; isFocusable = true; setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(6) }
        }
        row.addView(smallButton("＋ Watch Later") { addVideoToWatchLater(videoId, video) })
        row.addView(smallButton("▤ Playlist") { choosePlaylistForVideo(videoId, video) })
        parent.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
    }

    private fun showVideoSearch(initialQuery: String) {
        selected = "Home"; base(); heading("Search videos", "Search title, description, or creator username across the latest 500 public videos")
        val searchInput = EditText(this).apply {
            hint = "Video title, description, or @username"
            setHintTextColor(0xff71879b.toInt()); setTextColor(primaryText); textSize = 15f
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            imeOptions = EditorInfo.IME_ACTION_SEARCH; isSingleLine = true
            background = round(Color.WHITE, 16); setPadding(dp(14), dp(12), dp(14), dp(12))
            setText(initialQuery)
        }
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        controls.addView(searchInput, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(6) })
        val clear = TextView(this).apply {
            text = "×"; textSize = 25f; gravity = Gravity.CENTER; setTextColor(secondaryText)
            background = round(Color.WHITE, 14); contentDescription = "Clear search"
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(48)).apply { rightMargin = dp(6) }
            isClickable = true; isFocusable = true
        }
        val search = TextView(this).apply {
            text = "⌕"; textSize = 24f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = round(mint, 14); contentDescription = "Search"
            layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
            isClickable = true; isFocusable = true
        }
        controls.addView(clear); controls.addView(search)
        content.addView(controls)
        val suggestions = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(suggestions)
        val status = label("Search real public videos from Firestore.", 13, secondaryText, false).apply { setPadding(0, dp(12), 0, dp(8)) }
        content.addView(status)
        val progress = ProgressBar(this).apply { isIndeterminate = true; visibility = View.GONE }
        content.addView(progress, LinearLayout.LayoutParams(dp(32), dp(32)).apply { gravity = Gravity.CENTER; bottomMargin = dp(8) })
        val results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(results)

        fun refreshSuggestions() {
            suggestions.removeAllViews()
            val history = getRecentVideoSearches()
            if (history.isEmpty()) return
            suggestions.addView(label("Recent searches", 13, secondaryText, true).apply { setPadding(0, dp(14), 0, dp(7)) })
            history.forEach { term ->
                val item = TextView(this).apply {
                    text = "◷  $term"; textSize = 14f; setTextColor(primaryText)
                    background = round(Color.WHITE, 12); setPadding(dp(12), dp(10), dp(12), dp(10))
                    isClickable = true; isFocusable = true
                    setOnClickListener { searchInput.setText(term); runVideoSearch(term, status, progress, results); refreshSuggestions() }
                }
                suggestions.addView(item, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })
            }
        }
        val runSearch = { runVideoSearch(searchInput.text.toString(), status, progress, results); refreshSuggestions() }
        search.setOnClickListener { runSearch() }
        searchInput.setOnEditorActionListener { _, _, _ -> runSearch(); true }
        clear.setOnClickListener {
            searchInput.text.clear(); results.removeAllViews(); progress.visibility = View.GONE
            status.text = "Search real public videos from Firestore."; refreshSuggestions()
            searchInput.requestFocus()
        }
        refreshSuggestions()
        if (initialQuery.isNotBlank()) runVideoSearch(initialQuery, status, progress, results)
        addBottom()
    }

    private fun getRecentVideoSearches(): List<String> = getSharedPreferences("video_search_history", MODE_PRIVATE)
        .getString("recent", "").orEmpty().split('\n').map { it.trim() }.filter { it.isNotEmpty() }.distinct().take(6)

    private fun saveRecentVideoSearch(query: String) {
        val recent = (listOf(query.trim()) + getRecentVideoSearches()).distinct().take(6)
        getSharedPreferences("video_search_history", MODE_PRIVATE).edit().putString("recent", recent.joinToString("\n")).apply()
    }

    private fun getRecentSearches(): List<String> = getSharedPreferences("hira_search_history", MODE_PRIVATE)
        .getString("recent", "").orEmpty().split('\n').map { it.trim() }.filter { it.isNotEmpty() }.distinct().take(8)

    private fun saveRecentSearch(query: String) {
        val clean = query.trim().take(120)
        if (clean.isEmpty()) return
        val recent = (listOf(clean) + getRecentSearches()).distinct().take(8)
        getSharedPreferences("hira_search_history", MODE_PRIVATE).edit().putString("recent", recent.joinToString("\n")).apply()
    }

    private fun runVideoSearch(rawQuery: String, status: TextView, progress: ProgressBar, results: LinearLayout) {
        val query = rawQuery.trim().removePrefix("@").trim().lowercase()
        results.removeAllViews()
        if (query.isBlank()) {
            progress.visibility = View.GONE
            status.text = "Enter a title, description keyword, or creator username to search."
            return
        }
        val db = FirebaseBackend.db
        if (db == null) {
            progress.visibility = View.GONE
            status.text = "Search is unavailable because Firestore is not configured."
            return
        }
        val projectId = try { com.google.firebase.FirebaseApp.getInstance().options.projectId ?: "unknown" } catch (_: Exception) { "unavailable" }
        val authSignedIn = FirebaseBackend.auth?.currentUser != null
        saveRecentVideoSearch(rawQuery.trim())
        progress.visibility = View.VISIBLE; status.text = "Searching public videos in Firebase project $projectId…"
        Log.i("HiraBhaiVideoSearch", "Starting query: project=$projectId authSignedIn=$authSignedIn path=/videos where visibility=public orderBy createdAt DESC limit=500")
        db.collection("videos").whereEqualTo("visibility", "public")
            .orderBy("createdAt", com.google.firebase.firestore.Query.Direction.DESCENDING).limit(500).get()
            .addOnSuccessListener { snapshot ->
                progress.visibility = View.GONE
                val matches = snapshot.documents.filter { document ->
                    if (document.getString("visibility") != "public" || document.getBoolean("isShort") == true) return@filter false
                    val fields = listOf("title", "description", "creatorUsername", "creatorName")
                    fields.any { field -> document.getString(field).orEmpty().lowercase().contains(query) }
                }.sortedByDescending { it.getTimestamp("createdAt")?.toDate()?.time ?: 0L }
                if (matches.isEmpty()) {
                    status.text = "No public videos found for ‘${rawQuery.trim()}’. Try different words or a username."
                } else {
                    status.text = "${matches.size} public video${if (matches.size == 1) "" else "s"} found"
                    matches.forEach { document -> addHomeVideoCard(results, document.id, document.data ?: emptyMap()) }
                }
            }
            .addOnFailureListener { error ->
                progress.visibility = View.GONE
                val denied = error is com.google.firebase.firestore.FirebaseFirestoreException && error.code == com.google.firebase.firestore.FirebaseFirestoreException.Code.PERMISSION_DENIED
                status.text = if (denied) {
                    "Public video search is blocked by Firestore Rules in project $projectId. Publish the corrected /videos rule for visibility = public, then retry."
                } else "Video search failed: ${friendlyError(error)}"
                Log.e("HiraBhaiVideoSearch", "Firestore query failed: project=$projectId authSignedIn=$authSignedIn path=/videos where visibility=public orderBy createdAt DESC limit=500", error)
            }
    }

    private fun showSection(section:String) {
        if (section == "Shorts") { showShortsFeed(); return }
        selected=section; base()
        when(section) {
            "Subscriptions" -> showSubscriptions()
            "Library" -> { heading("Your library","Private history, saved videos, and playlists"); action("Watch history", "Recently watched videos and resume positions") { showWatchHistory() }; action("Watch Later", "Videos saved privately for later") { showWatchLater() }; action("Playlists", "Create private or public video playlists") { showPlaylists() }; action("${if (FirebaseBackend.auth?.currentUser == null) "Sign in / Create account" else "Your profile"}","Manage your account and public creator profile.") { showAccount() }; action("View a public profile","Find a creator by username.") { showProfileLookup() }; action("Developer Testing Mode","Test subscriptions in isolated Firebase test collections.") { showSubscriptionTest() } }
            else -> { heading("Create something","Tap + for camera. Swipe the bottom feature bar left or right to find every tool."); val card=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; background=glass(0x44ffffff,24); setPadding(dp(20),dp(20),dp(20),dp(20)); addView(label("Create with Hira Bhai",19,primaryText,true)); addView(label("Swipe the bottom bar to reach AI Studio, video editing, your dashboard, uploads, Go Live, Settings, Monetization, and the rest of your tools.",14,secondaryText,false).apply { setPadding(0,dp(7),0,0) }) }; content.addView(card); button("＋  Upload or choose a file") { showUploadOptions() }; button("●  Go Live") { openLiveScreen() } }
        }
        addBottom()
    }

    private fun showShortsFeed() {
        selected = "Shorts"; base()
        shortFeedFullscreen = true
        mainScroll?.let(root::removeView); bottomBar?.let(root::removeView)
        window.statusBarColor = Color.BLACK; window.navigationBarColor = Color.BLACK
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        root.setPadding(0, 0, 0, 0)
        val toolbar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), dp(5), dp(12), dp(5)); setBackgroundColor(Color.BLACK) }
        toolbar.addView(TextView(this).apply { text = "×"; textSize = 28f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setOnClickListener { showHome() } }, LinearLayout.LayoutParams(dp(48), dp(46)))
        toolbar.addView(TextView(this).apply { text = "Shorts"; textSize = 18f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE) }, LinearLayout.LayoutParams(0, -2, 1f))
        toolbar.addView(TextView(this).apply { text = "＋ Upload"; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE); background = round(0xff159bd7.toInt(), 22); gravity = Gravity.CENTER; setPadding(dp(14), dp(9), dp(14), dp(9)); setOnClickListener { chooseShortUpload() } })
        root.addView(toolbar, LinearLayout.LayoutParams(-1, dp(54)))
        val scroll = ScrollView(this).apply { isFillViewport = true; isVerticalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER }
        val feed = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(feed)
        shortsScroll = scroll
        scroll.setOnScrollChangeListener { _, _, _, _, _ -> activateVisibleShort() }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        mainScroll = scroll
        val db = FirebaseBackend.db ?: run { info("Shorts unavailable", "Firestore is not configured."); return }
        db.collection("videos").whereEqualTo("isShort", true).whereEqualTo("visibility", "public")
            .orderBy("createdAt", com.google.firebase.firestore.Query.Direction.DESCENDING).limit(40).get()
            .addOnSuccessListener { snapshot ->
                val docs = snapshot.documents.filter { it.getBoolean("isShort") == true && it.getString("visibility") == "public" }
                if (docs.isEmpty()) { info("No Shorts yet", "No public vertical videos have been uploaded."); return@addOnSuccessListener }
                val pageHeight = scroll.height.takeIf { it > 0 } ?: (resources.displayMetrics.heightPixels - dp(54)).coerceAtLeast(dp(430))
                docs.forEach { doc -> addShortPage(feed, doc.id, doc.data ?: emptyMap(), pageHeight) }
                scroll.post { activateVisibleShort() }
            }
            .addOnFailureListener { info("Shorts unavailable", "Could not load public Shorts: ${friendlyError(it)}"); Log.e("HiraBhaiShorts", "Public query failed: /videos isShort=true visibility=public", it) }
    }

    private fun addShortPage(feed: LinearLayout, videoId: String, video: Map<String, Any>, pageHeight: Int) {
        val page = FrameLayout(this).apply { setBackgroundColor(Color.BLACK); layoutParams = LinearLayout.LayoutParams(-1, pageHeight).apply { bottomMargin = dp(12) } }
        val playerView = PlayerView(this).apply { useController = false; controllerAutoShow = false; setShutterBackgroundColor(Color.BLACK); layoutParams = FrameLayout.LayoutParams(-1, -1) }
        page.addView(playerView)
        val shade = View(this).apply { background = android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x11000000, 0x00000000, 0xe9000000.toInt())) }
        page.addView(shade, FrameLayout.LayoutParams(-1, -1))
        val description = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(92), dp(15)); layoutParams = FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM) }
        val username = video["creatorUsername"] as? String ?: "creator"
        val creatorId = video["creatorId"] as? String ?: ""
        description.addView(TextView(this).apply { text = "@${username}  ·  ${video["creatorName"] ?: "Creator"}"; textSize = 15f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE); setOnClickListener { loadPublicCreator(username, null) } })
        description.addView(TextView(this).apply { text = video["title"] as? String ?: "Short video"; textSize = 17f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE); setPadding(0, dp(7), 0, dp(3)) })
        val caption = (video["description"] as? String).orEmpty()
        if (caption.isNotBlank()) description.addView(TextView(this).apply { text = caption; textSize = 13f; setTextColor(0xfff2f6fa.toInt()); maxLines = 3; ellipsize = android.text.TextUtils.TruncateAt.END })
        val hashtags = (video["hashtags"] as? List<*>)?.filterIsInstance<String>().orEmpty()
        if (hashtags.isNotEmpty()) description.addView(TextView(this).apply { text = hashtags.joinToString(" ") { "#$it" }; textSize = 12f; setTextColor(0xff7de1ce.toInt()); setPadding(0, dp(5), 0, 0) })
        page.addView(description)
        val rail = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; layoutParams = FrameLayout.LayoutParams(dp(76), -2, Gravity.END or Gravity.CENTER_VERTICAL).apply { rightMargin = dp(8) } }
        val like = TextView(this).apply { text = "♡ Like"; textSize = 12f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); background = round(0x66000000, 20); setPadding(dp(7), dp(10), dp(7), dp(10)) }
        val comment = shortAction("▤\nComment") { showShortComments(videoId, video) }
        val share = shortAction("↗\nShare") { val link = "Watch on Hira Bhai: hirabhai:/v/$videoId"; startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, link), "Share Short")) }
        rail.addView(like, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }); rail.addView(comment, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }); rail.addView(share)
        val subHost = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (creatorId.isNotBlank()) {
            addSearchSubscriptionButton(subHost, username, creatorId)
            val sub = subHost.getChildAt(0)
            subHost.removeView(sub)
            (sub as? TextView)?.apply { textSize = 11f; setPadding(dp(5), dp(8), dp(5), dp(8)); background = round(0xff25b9a0.toInt(), 20) }?.let { rail.addView(it, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) }) }
        }
        page.addView(rail)
        feed.addView(page)
        shortsPages.add(Triple(videoId, video, playerView))
        configureVideoLike(videoId, like, creatorId, username, video["creatorName"] as? String ?: username)
    }

    private fun shortAction(title: String, action: () -> Unit) = TextView(this).apply {
        text = title; textSize = 12f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); background = round(0x66000000, 20)
        setPadding(dp(5), dp(9), dp(5), dp(9)); setOnClickListener { action() }
    }

    private fun activateVisibleShort() {
        val scroll = shortsScroll ?: return
        if (shortsPages.isEmpty()) return
        val firstPage = shortsPages.first().third.parent as? View ?: return
        val pageHeight = firstPage.height.takeIf { it > 0 } ?: return
        val index = (scroll.scrollY / (pageHeight + dp(12))).coerceIn(0, shortsPages.lastIndex)
        if (index == activeShortIndex && shortsPlayer?.isPlaying == true) return
        shortsPages.getOrNull(activeShortIndex)?.third?.player = null
        shortsPlayer?.pause()
        activeShortIndex = index
        val (videoId, video, view) = shortsPages[index]
        val path = video["storagePath"] as? String ?: return
        val player = shortsPlayer ?: ExoPlayer.Builder(this).build().also { created ->
            shortsPlayer = created
            created.addListener(object : Player.Listener {
                private var historyId: String? = null
                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    if (!isPlaying) return
                    val active = shortsPages.getOrNull(activeShortIndex) ?: return
                    if (historyId != active.first) { historyId = active.first; recordVideoOpened(active.first, active.second) }
                }
            })
        }
        view.player = player
        val cached = File(cacheDir, "hira_video_${videoId}.media")
        fun start(file: File) {
            if (activeShortIndex != index || isFinishing || isDestroyed) return
            player.setMediaItem(MediaItem.fromUri(Uri.fromFile(file))); player.prepare(); player.playWhenReady = true
        }
        if (cached.exists() && cached.length() > 0L) start(cached)
        else {
            val storage = FirebaseBackend.storage ?: run { info("Shorts", "Firebase Storage is not configured."); return }
            storage.reference.child(path).getFile(cached).addOnSuccessListener { start(cached) }
                .addOnFailureListener { cached.delete(); Log.e("HiraBhaiShorts", "Secure video read failed at $path", it); info("Short unavailable", friendlyError(it)) }
        }
    }

    private fun releaseShortsPlayer() {
        shortsPages.forEach { it.third.player = null }
        shortsPlayer?.pause(); shortsPlayer?.release(); shortsPlayer = null
        shortsPages.clear(); shortsScroll = null; activeShortIndex = -1
    }

    private fun showShortComments(videoId: String, video: Map<String, Any>) {
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(6), dp(18), 0) }
        val count = label("Comments", 13, secondaryText, true); body.addView(count)
        val comments = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; body.addView(comments)
        val input = EditText(this).apply { hint = "Write a comment"; maxLines = 3; filters = arrayOf(android.text.InputFilter.LengthFilter(1000)) }; body.addView(input)
        val dialog = AlertDialog.Builder(this).setTitle("Short comments").setView(ScrollView(this).apply { addView(body) }).setNegativeButton("Close", null).setPositiveButton("Post comment", null).create(); dialog.show()
        val listenerStart = screenFirestoreListeners.size
        loadVideoComments(videoId, comments, count)
        dialog.setOnDismissListener { while (screenFirestoreListeners.size > listenerStart) screenFirestoreListeners.removeAt(screenFirestoreListeners.lastIndex).remove() }
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener { postVideoComment(videoId, input, comments, video["creatorId"] as? String ?: "", video["creatorUsername"] as? String ?: "creator") }
    }

    @OptIn(PublicPreviewAPI::class)
    private fun showAiAssistant(threadId: String? = null) {
        selected = "AI Assistant"
        val user = FirebaseBackend.auth?.currentUser
        if (user == null) {
            base()
            heading("Hira AI", "Your creator assistant in Hindi, English, and Gujarati")
            featureTile("Sign in to chat", "AI conversations are saved privately to your account.", "✦")
            action("Sign in", "Use your Hira Bhai account to continue.") { showAuth(false) }
            addBottom()
            return
        }
        base()
        // A chat screen owns the available height; keep the familiar bottom navigation.
        mainScroll?.let { root.removeView(it) }
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        root.orientation = LinearLayout.VERTICAL
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(8), dp(14), dp(8)); background = round(Color.WHITE, 0)
        }
        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleBox.addView(label("Hira AI", 21, primaryText, true))
        titleBox.addView(label("Hindi · English · ગુજરાતી", 12, secondaryText, false).apply { setPadding(0, dp(2), 0, 0) })
        top.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(chatToolbarButton("Tasks") { showAssistantTasks(user.uid) }, LinearLayout.LayoutParams(-2, dp(40)).apply { rightMargin = dp(7) })
        top.addView(chatToolbarButton("History") { showAiHistory(user.uid) }, LinearLayout.LayoutParams(-2, dp(40)).apply { rightMargin = dp(8) })
        top.addView(chatToolbarButton("Clear") {
            AlertDialog.Builder(this).setMessage("Clear this private conversation?").setNegativeButton("Cancel", null)
                .setPositiveButton("Clear") { _, _ -> clearAiConversation(user.uid) }.show()
        }, LinearLayout.LayoutParams(-2, dp(40)).apply { rightMargin = dp(7) })
        top.addView(chatToolbarButton("＋ New") { startNewAiConversation(user.uid) })
        root.addView(top, LinearLayout.LayoutParams(-1, -2))

        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(8), dp(14), dp(8)); background = round(bg, 0) }
        aiStatus = label("Ask for video ideas, scripts, titles, summaries, or feedback.", 12, secondaryText, false).apply {
            setPadding(dp(12), dp(8), dp(12), dp(8)); background = round(Color.WHITE, 14)
        }
        body.addView(aiStatus, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })
        val messagesScroll = ScrollView(this).apply { isFillViewport = false; clipToPadding = false }
        aiList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(2), dp(4), dp(2), dp(10)) }
        messagesScroll.addView(aiList)
        body.addView(messagesScroll, LinearLayout.LayoutParams(-1, 0, 1f))
        aiLoadingText = label("Hira AI is typing…", 13, secondaryText, false).apply { visibility = View.GONE; setPadding(dp(8), dp(4), dp(8), dp(4)) }
        body.addView(aiLoadingText)
        val composer = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(7), dp(6), dp(7), dp(6)); background = round(Color.WHITE, 24) }
        aiInput = EditText(this).apply {
            hint = "Message Hira AI…"; textSize = 15f; setTextColor(primaryText); setHintTextColor(secondaryText)
            background = null; minLines = 1; maxLines = 4; imeOptions = EditorInfo.IME_ACTION_SEND
            setPadding(dp(10), dp(8), dp(6), dp(8)); isEnabled = false
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEND) { sendAiMessage(user.uid); true } else false
            }
        }
        composer.addView(aiInput, LinearLayout.LayoutParams(0, -2, 1f))
        val voice = TextView(this).apply {
            text = "🎙"; textSize = 19f; gravity = Gravity.CENTER; setTextColor(primaryText); background = glass(0x28ffffff, 100)
            layoutParams = LinearLayout.LayoutParams(dp(40), dp(42)).apply { rightMargin = dp(5) }
            isClickable = true; isFocusable = true
            setOnClickListener { chooseAiVoiceLanguage() }
        }
        composer.addView(voice)
        aiSend = TextView(this).apply {
            text = "➤"; textSize = 20f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); background = round(mint, 100)
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(44)); isClickable = true; isFocusable = true
            setOnClickListener { sendAiMessage(user.uid) }
        }
        composer.addView(aiSend)
        body.addView(composer, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(7) })
        body.addView(label("AI replies are generated by Firebase AI Logic. Chats are private to your account.", 10, secondaryText, false).apply { gravity = Gravity.CENTER; setPadding(0, dp(5), 0, 0) })
        root.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        addBottom()
        aiInput?.isEnabled = false
        if (threadId != null) loadAiConversation(user.uid, threadId) else loadMostRecentAiConversation(user.uid)
    }

    private fun chatToolbarButton(text: String, click: () -> Unit) = TextView(this).apply {
        this.text = text; textSize = 12f; setTextColor(primaryText); gravity = Gravity.CENTER
        setPadding(dp(11), 0, dp(11), 0); background = round(0xffe9f2f5.toInt(), 30)
        isClickable = true; isFocusable = true; setOnClickListener { click() }
    }

    private fun loadMostRecentAiConversation(uid: String) {
        val db = FirebaseBackend.db ?: run { showAiError("Firestore is not configured."); return }
        db.collection("aiConversations").document(uid).collection("threads")
            .orderBy("updatedAt", com.google.firebase.firestore.Query.Direction.DESCENDING).limit(1).get()
            .addOnSuccessListener { threads ->
                val thread = threads.documents.firstOrNull()
                if (thread == null) startNewAiConversation(uid) else loadAiConversation(uid, thread.id)
            }.addOnFailureListener { error ->
                Log.e("HiraBhaiAI", "Conversation list failed: /aiConversations/$uid/threads", error)
                showAiError("Could not load your chat history: ${friendlyError(error)}")
            }
    }

    private fun loadAiConversation(uid: String, threadId: String) {
        val db = FirebaseBackend.db ?: run { showAiError("Firestore is not configured."); return }
        db.collection("aiConversations").document(uid).collection("threads").document(threadId)
            .collection("messages").orderBy("createdAt").limit(100).get()
            .addOnSuccessListener { snapshot ->
                aiThreadId = threadId
                aiMessages = snapshot.documents.mapNotNull { doc ->
                    val role = doc.getString("role") ?: return@mapNotNull null
                    val text = doc.getString("text") ?: return@mapNotNull null
                    AiChatMessage(doc.id, role, text, doc.getTimestamp("createdAt")?.toDate())
                }.toMutableList()
                aiInput?.isEnabled = true
                aiStatus?.text = if (aiMessages.isEmpty()) "Ask for video ideas, scripts, titles, summaries, or feedback." else "Conversation restored. Continue where you left off."
                renderAiMessages()
            }.addOnFailureListener { error ->
                Log.e("HiraBhaiAI", "Message history failed: /aiConversations/$uid/threads/$threadId/messages", error)
                showAiError("Could not load this conversation: ${friendlyError(error)}")
            }
    }

    private fun startNewAiConversation(uid: String) {
        aiJob?.cancel(); aiThreadId = null; aiMessages.clear(); renderAiMessages()
        val db = FirebaseBackend.db ?: run { showAiError("Firestore is not configured."); return }
        aiInput?.isEnabled = false; aiStatus?.text = "Starting a private conversation…"
        val thread = db.collection("aiConversations").document(uid).collection("threads").document()
        thread.set(mapOf("title" to "New chat", "createdAt" to FieldValue.serverTimestamp(), "updatedAt" to FieldValue.serverTimestamp()))
            .addOnSuccessListener {
                aiThreadId = thread.id; aiInput?.isEnabled = true
                aiStatus?.text = "Ask for video ideas, scripts, titles, summaries, or feedback."
                aiInput?.requestFocus()
            }.addOnFailureListener { error ->
                Log.e("HiraBhaiAI", "Thread create failed: ${thread.path}", error)
                showAiError("Could not start a conversation: ${friendlyError(error)}")
            }
    }

    private fun showAiHistory(uid: String) {
        val db = FirebaseBackend.db ?: run { showAiError("Firestore is not configured."); return }
        aiStatus?.text = "Loading chat history…"
        db.collection("aiConversations").document(uid).collection("threads")
            .orderBy("updatedAt", com.google.firebase.firestore.Query.Direction.DESCENDING).limit(30).get()
            .addOnSuccessListener { snapshot ->
                val threads = snapshot.documents
                if (threads.isEmpty()) { aiStatus?.text = "No saved chats yet. Start a new conversation."; return@addOnSuccessListener }
                val names = threads.map { it.getString("title")?.takeIf(String::isNotBlank) ?: "New chat" }.toTypedArray()
                AlertDialog.Builder(this).setTitle("Your AI chats").setItems(names) { _, which -> loadAiConversation(uid, threads[which].id) }
                    .setNegativeButton("Close", null).show()
                aiStatus?.text = "Choose a conversation to continue."
            }.addOnFailureListener { error ->
                Log.e("HiraBhaiAI", "History query failed: /aiConversations/$uid/threads orderBy updatedAt", error)
                showAiError("Could not read chat history: ${friendlyError(error)}")
            }
    }

    @OptIn(PublicPreviewAPI::class)
    private fun sendAiMessage(uid: String) {
        val prompt = aiInput?.text?.toString()?.trim().orEmpty()
        if (prompt.isBlank() || aiJob?.isActive == true) return
        if (prompt.length > 4000) { showAiError("Please keep each message under 4,000 characters."); return }
        val db = FirebaseBackend.db ?: run { showAiError("Firestore is not configured."); return }
        val threadId = aiThreadId ?: run { showAiError("Start a conversation before sending a message."); return }
        val thread = db.collection("aiConversations").document(uid).collection("threads").document(threadId)
        val prior = aiMessages.toList()
        aiInput?.setText(""); aiInput?.isEnabled = false; aiSend?.isEnabled = false
        aiStatus?.text = "Sending securely to Hira AI…"
        val userMessage = thread.collection("messages").document()
        val title = if (prior.isEmpty()) prompt.take(80) else null
        val update = hashMapOf<String, Any>("updatedAt" to FieldValue.serverTimestamp())
        if (title != null) update["title"] = title
        val batch = db.batch()
        batch.set(userMessage, mapOf("role" to "user", "text" to prompt, "createdAt" to FieldValue.serverTimestamp()))
        batch.update(thread, update)
        aiJob = aiScope.launch {
            try {
                batch.commit().await()
                aiMessages.add(AiChatMessage(userMessage.id, "user", prompt, Date()))
                val responseMessage = AiChatMessage(UUID.randomUUID().toString(), "model", "", Date())
                aiMessages.add(responseMessage); renderAiMessages()
                aiLoadingText?.visibility = View.VISIBLE
                aiStatus?.text = "Hira AI is responding…"
                val history = prior.filter { it.text.isNotBlank() }.map { content(it.role) { text(it.text) } }
                val model = Firebase.ai(backend = GenerativeBackend.googleAI(), useLimitedUseAppCheckTokens = true)
                    .generativeModel(
                        modelName = "gemini-3.8-flash",
                        systemInstruction = content {
                            text("You are Hira Bhai's personal assistant. Reply in the same language as the user: Hindi, English, or Gujarati. Help with general questions and guide the user to existing Hira Bhai features, including Video Upload, Creator Dashboard, Search, Movies, File Manager, Browser, and AI tools. Give concise step-by-step navigation guidance. You may suggest actions but cannot execute app actions, publish content, access private files, or change account data. For sensitive actions such as deleting files, sending messages, publishing, or payments, clearly ask the user to confirm in the app before proceeding. Never claim to have performed an action.")
                        }
                    )
                val chat: Chat = model.startChat(history = history)
                val generated = StringBuilder()
                chat.sendMessageStream(prompt).collect { chunk ->
                    chunk.text?.let { piece ->
                        generated.append(piece); responseMessage.text = generated.toString()
                        renderAiMessages(); aiList?.let { list -> (list.parent as? ScrollView)?.post { (list.parent as? ScrollView)?.fullScroll(View.FOCUS_DOWN) } }
                    }
                }
                val answer = generated.toString().trim()
                if (answer.isNotEmpty()) {
                    val modelMessage = thread.collection("messages").document()
                    modelMessage.set(mapOf("role" to "model", "text" to answer, "createdAt" to FieldValue.serverTimestamp())).await()
                    responseMessage.id = modelMessage.id; responseMessage.text = answer
                    aiStatus?.text = "Response ready. Tap Copy to reuse it."
                } else {
                    aiMessages.remove(responseMessage)
                    showAiError("The AI returned an empty response. Please try again.")
                }
            } catch (error: Exception) {
                Log.e("HiraBhaiAI", "Authenticated AI request failed: uid=$uid thread=$threadId backend=Firebase AI Logic", error)
                aiMessages.removeAll { it.role == "model" && it.text.isBlank() }
                val detail = friendlyError(error)
                showAiError(if (detail.contains("permission", true) || detail.contains("app check", true) || detail.contains("403"))
                    "AI access was denied. Enable Firebase AI Logic, require signed-in users, and register this build's App Check debug token in Firebase Console."
                    else "AI request failed: $detail")
            } finally {
                aiLoadingText?.visibility = View.GONE; aiInput?.isEnabled = true; aiSend?.isEnabled = true
                renderAiMessages()
            }
        }
    }

    private fun showAiError(message: String) { aiStatus?.text = message; aiStatus?.setTextColor(0xffa33a36.toInt()) }

    private fun chooseAiVoiceLanguage() {
        val languages = arrayOf("हिन्दी", "ગુજરાતી", "English")
        val tags = arrayOf("hi-IN", "gu-IN", "en-IN")
        AlertDialog.Builder(this).setTitle("Speak in").setItems(languages) { _, which -> startAiVoiceInput(tags[which]) }.setNegativeButton("Cancel", null).show()
    }

    private fun startAiVoiceInput(languageTag: String) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { showAiError("Speech input is unavailable on this device. Install or enable a speech recognition service."); return }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak in Hindi, Gujarati, or English")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        try { startActivityForResult(intent, 2031) } catch (_: Exception) { showAiError("No speech recognition app is available.") }
    }

    private fun clearAiConversation(uid: String) {
        val id = aiThreadId ?: run { aiMessages.clear(); renderAiMessages(); return }
        val db = FirebaseBackend.db ?: return showAiError("Firestore is not configured.")
        val thread = db.collection("aiConversations").document(uid).collection("threads").document(id)
        fun deleteNextBatch() {
            thread.collection("messages").limit(400).get().addOnSuccessListener { snapshot ->
                if (snapshot.isEmpty) { aiMessages.clear(); renderAiMessages(); aiStatus?.text = "Conversation cleared."; startNewAiConversation(uid); return@addOnSuccessListener }
                val batch = db.batch(); snapshot.documents.forEach { batch.delete(it.reference) }
                batch.commit().addOnSuccessListener { deleteNextBatch() }.addOnFailureListener { showAiError("Could not clear conversation: ${friendlyError(it)}") }
            }.addOnFailureListener { showAiError("Could not clear conversation: ${friendlyError(it)}") }
        }
        deleteNextBatch()
    }

    private fun showAssistantTasks(uid: String) {
        selected = "AI Assistant"; base()
        heading("Assistant tasks", "Private reminders and checklists · scheduled on this device")
        action("← Back to Hira AI chat", "Ask a question or get help finding an app feature.") { showAiAssistant(aiThreadId) }
        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = glass(0x35ffffff, 22); setPadding(dp(15), dp(14), dp(15), dp(14)) }
        val title = EditText(this).apply { hint = "Task or reminder"; setTextColor(primaryText); setHintTextColor(secondaryText); background = glass(0x30ffffff, 16); setPadding(dp(13), dp(12), dp(13), dp(12)); maxLines = 2 }
        val checklist = EditText(this).apply { hint = "Checklist items (one per line, optional)"; setTextColor(primaryText); setHintTextColor(secondaryText); background = glass(0x30ffffff, 16); setPadding(dp(13), dp(12), dp(13), dp(12)); minLines = 2; maxLines = 4 }
        val daily = CheckBox(this).apply { text = "Repeat daily"; setTextColor(primaryText); buttonTintList = android.content.res.ColorStateList.valueOf(mint) }
        var dueTime = System.currentTimeMillis() + 60 * 60 * 1000L
        val timeButton = buttonView("Reminder time · in about 1 hour") {
            val cal = java.util.Calendar.getInstance().apply { timeInMillis = dueTime }
            android.app.TimePickerDialog(this@MainActivity, { _, hour, minute ->
                val chosen = java.util.Calendar.getInstance().apply { set(java.util.Calendar.HOUR_OF_DAY, hour); set(java.util.Calendar.MINUTE, minute); set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0) }
                if (chosen.timeInMillis <= System.currentTimeMillis()) chosen.add(java.util.Calendar.DAY_OF_YEAR, 1)
                dueTime = chosen.timeInMillis; timeButtonText = "Reminder time · " + SimpleDateFormat("EEE, h:mm a", Locale.getDefault()).format(Date(dueTime)); renderTaskTimeButton?.text = timeButtonText
            }, cal.get(java.util.Calendar.HOUR_OF_DAY), cal.get(java.util.Calendar.MINUTE), false).show()
        }
        renderTaskTimeButton = timeButton
        form.addView(title, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }); form.addView(checklist, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(5) })
        form.addView(daily); form.addView(timeButton)
        form.addView(buttonView("Save reminder") {
            val name = title.text.toString().trim()
            if (name.isBlank()) { title.error = "Enter a task or reminder"; return@buttonView }
            val db = FirebaseBackend.db ?: run { info("Firebase unavailable", "Sign in and configure Firestore before saving private tasks."); return@buttonView }
            val task = db.collection("assistantTasks").document(uid).collection("items").document()
            val now = Date()
            val checklistItems = checklist.text.toString().lines().map(String::trim).filter(String::isNotBlank).take(20).map { mapOf("text" to it, "done" to false) }
            task.set(mapOf("title" to name, "checklist" to checklistItems, "dueAt" to dueTime, "daily" to daily.isChecked, "completed" to false, "paused" to false, "createdAt" to now))
                .addOnSuccessListener {
                    AssistantReminders.schedule(this, task.id, name, dueTime, daily.isChecked)
                    if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2032)
                    info("Reminder saved", "Android may deliver inexact alarms a little before or after the selected time.")
                    showAssistantTasks(uid)
                }.addOnFailureListener { info("Could not save reminder", friendlyError(it)) }
        })
        content.addView(form, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(label("Your tasks", 19, primaryText, true).apply { setPadding(0, 0, 0, dp(8)) }); content.addView(list)
        val db = FirebaseBackend.db
        if (db == null) { list.addView(label("Firestore is not configured.", 14, secondaryText, false)); addBottom(); return }
        db.collection("assistantTasks").document(uid).collection("items").orderBy("createdAt", com.google.firebase.firestore.Query.Direction.DESCENDING).limit(100).get()
            .addOnSuccessListener { snapshot ->
                if (snapshot.isEmpty) list.addView(label("No tasks yet. Add a reminder or checklist above.", 14, secondaryText, false))
                snapshot.documents.forEach { doc ->
                    val name = doc.getString("title") ?: "Task"
                    val due = doc.getLong("dueAt") ?: 0L; val dailyTask = doc.getBoolean("daily") == true
                    val done = doc.getBoolean("completed") == true; val paused = doc.getBoolean("paused") == true
                    val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = glass(0x35ffffff, 18); setPadding(dp(13), dp(11), dp(13), dp(10)) }
                    val check = CheckBox(this).apply { text = name; isChecked = done; setTextColor(primaryText); buttonTintList = android.content.res.ColorStateList.valueOf(mint); setOnCheckedChangeListener { _, checked ->
                        doc.reference.update("completed", checked).addOnSuccessListener { if (checked) AssistantReminders.cancel(this@MainActivity, doc.id) else if (!paused) AssistantReminders.schedule(this@MainActivity, doc.id, name, due, dailyTask) }
                    } }
                    card.addView(check)
                    val items = (doc.get("checklist") as? List<*>)?.mapNotNull { it as? Map<*, *> }?.map { mapOf("text" to (it["text"] as? String ?: ""), "done" to (it["done"] as? Boolean ?: false)) }?.toMutableList() ?: mutableListOf()
                    items.forEachIndexed { index, item ->
                        val itemText = item["text"] as String
                        card.addView(CheckBox(this).apply {
                            text = itemText; isChecked = item["done"] as Boolean; textSize = 13f; setTextColor(secondaryText)
                            buttonTintList = android.content.res.ColorStateList.valueOf(mint)
                            setOnCheckedChangeListener { _, checked -> items[index] = mapOf("text" to itemText, "done" to checked); doc.reference.update("checklist", items.toList()) }
                        })
                    }
                    card.addView(label("${SimpleDateFormat("EEE, h:mm a", Locale.getDefault()).format(Date(due))}${if (dailyTask) " · daily" else ""}${if (paused) " · paused" else ""}", 12, secondaryText, false))
                    val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                    buttons.addView(buttonView(if (paused) "Resume" else "Pause") {
                        doc.reference.update("paused", !paused).addOnSuccessListener { if (paused && !done) AssistantReminders.schedule(this@MainActivity, doc.id, name, due, dailyTask) else AssistantReminders.cancel(this@MainActivity, doc.id); showAssistantTasks(uid) }
                    }, LinearLayout.LayoutParams(0, -2, 1f))
                    buttons.addView(buttonView("Edit") { editAssistantTask(uid, doc.id, name, due, dailyTask) }, LinearLayout.LayoutParams(0, -2, 1f))
                    buttons.addView(buttonView("Delete") { AlertDialog.Builder(this@MainActivity).setMessage("Delete this task?").setNegativeButton("Cancel", null).setPositiveButton("Delete") { _, _ -> doc.reference.delete().addOnSuccessListener { AssistantReminders.cancel(this@MainActivity, doc.id); showAssistantTasks(uid) } }.show() }, LinearLayout.LayoutParams(0, -2, 1f))
                    card.addView(buttons); list.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) })
                }
            }.addOnFailureListener { list.addView(label("Could not load tasks: ${friendlyError(it)}", 14, secondaryText, false)) }
        addBottom()
    }

    private var renderTaskTimeButton: TextView? = null
    private var timeButtonText = ""

    private fun editAssistantTask(uid: String, id: String, oldTitle: String, dueAt: Long, daily: Boolean) {
        var editedDueAt = dueAt
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(8), dp(18), 0) }
        val input = EditText(this).apply { setText(oldTitle); setSelection(text.length); setTextColor(primaryText); hint = "Task or reminder" }
        val repeat = CheckBox(this).apply { text = "Repeat daily"; isChecked = daily; setTextColor(primaryText); buttonTintList = android.content.res.ColorStateList.valueOf(mint) }
        val dateTime = buttonView("Change date and time") {
            val cal = java.util.Calendar.getInstance().apply { timeInMillis = editedDueAt }
            android.app.DatePickerDialog(this@MainActivity, { _, year, month, day ->
                cal.set(year, month, day)
                android.app.TimePickerDialog(this@MainActivity, { _, hour, minute ->
                    cal.set(java.util.Calendar.HOUR_OF_DAY, hour); cal.set(java.util.Calendar.MINUTE, minute); cal.set(java.util.Calendar.SECOND, 0); cal.set(java.util.Calendar.MILLISECOND, 0)
                    editedDueAt = cal.timeInMillis
                }, cal.get(java.util.Calendar.HOUR_OF_DAY), cal.get(java.util.Calendar.MINUTE), false).show()
            }, cal.get(java.util.Calendar.YEAR), cal.get(java.util.Calendar.MONTH), cal.get(java.util.Calendar.DAY_OF_MONTH)).show()
        }
        box.addView(input); box.addView(dateTime); box.addView(repeat); val dialog = AlertDialog.Builder(this).setTitle("Edit task").setView(box).setNegativeButton("Cancel", null).setPositiveButton("Save", null).create()
        dialog.show()
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val title = input.text.toString().trim(); if (title.isBlank()) { input.error = "Enter a task title"; return@setOnClickListener }
            if (editedDueAt <= System.currentTimeMillis()) { info("Choose a future time", "Reminder time must be in the future."); return@setOnClickListener }
            FirebaseBackend.db?.collection("assistantTasks")?.document(uid)?.collection("items")?.document(id)
                ?.update("title", title, "dueAt", editedDueAt, "daily", repeat.isChecked)
                ?.addOnSuccessListener { AssistantReminders.schedule(this, id, title, editedDueAt, repeat.isChecked); dialog.dismiss(); showAssistantTasks(uid) }
                ?.addOnFailureListener { info("Could not update task", friendlyError(it)) }
        }
    }

    private fun renderAiMessages() {
        val list = aiList ?: return
        list.removeAllViews()
        if (aiMessages.isEmpty()) {
            val welcome = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; background = round(Color.WHITE, 22); setPadding(dp(22), dp(24), dp(22), dp(24)) }
            welcome.addView(label("✦", 32, mint, true).apply { gravity = Gravity.CENTER })
            welcome.addView(label("What would you like to create?", 19, primaryText, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(7), 0, dp(5)) })
            welcome.addView(label("Try: ‘Give me three Gujarati video ideas about local food.’", 13, secondaryText, false).apply { gravity = Gravity.CENTER })
            list.addView(welcome, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })
        }
        aiMessages.forEach { message ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = if (message.role == "user") Gravity.END else Gravity.START; setPadding(0, dp(4), 0, dp(4)) }
            val bubble = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = if (message.role == "user") round(0xffdff4ef.toInt(), 18) else round(Color.WHITE, 18); setPadding(dp(13), dp(10), dp(13), dp(9)) }
            bubble.addView(label(if (message.role == "user") "You" else "Hira AI", 11, if (message.role == "user") mint else secondaryText, true))
            bubble.addView(label(message.text.ifBlank { "…" }, 15, primaryText, false).apply { setPadding(0, dp(5), 0, 0) })
            if (message.role == "model" && message.text.isNotBlank()) {
                val messageActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                messageActions.addView(TextView(this).apply {
                    text = "▢ Copy"; textSize = 12f; setTextColor(mint); setPadding(0, dp(9), dp(14), 0)
                    isClickable = true; isFocusable = true; setOnClickListener {
                        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Hira AI response", message.text))
                        Toast.makeText(this@MainActivity, "Response copied", Toast.LENGTH_SHORT).show()
                    }
                })
                messageActions.addView(TextView(this).apply {
                    text = "↗ Share"; textSize = 12f; setTextColor(mint); setPadding(dp(8), dp(9), 0, 0)
                    isClickable = true; isFocusable = true; setOnClickListener {
                        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, message.text), "Share Hira AI response"))
                    }
                })
                bubble.addView(messageActions)
            }
            row.addView(bubble, LinearLayout.LayoutParams(-2, -2).apply { width = (resources.displayMetrics.widthPixels * .84f).toInt() })
            list.addView(row)
        }
    }

    private fun heading(title:String, sub:String) {
        displayedTitle = title
        displayedSelected = selected
        content.addView(label(title,28,primaryText,true))
        content.addView(label(sub,14,secondaryText,false).apply { setPadding(0,dp(5),0,dp(18)) })
    }

    private fun showSubscriptions() {
        heading("Subscriptions", "Your creator circle")
        featureTile("Find your people", "Follow creators and manage your subscriptions.", "♡")
        val user = FirebaseBackend.auth?.currentUser
        if (user == null) {
            action("Log in to see subscriptions", "Subscriptions are private to your account.") { showAuth(false) }
        } else {
            loadUserSubscriptions(content, user.uid)
        }
        action("Search creators", "Find a public creator by username.") { showProfileLookup() }
    }

    private fun showAiVideoGenerator() {
        selected = "AI Video Generator"
        base()
        heading("AI Video Generator", "Create a short clip from text or a reference image")
        if (FirebaseBackend.auth?.currentUser == null) {
            featureTile("Sign in required", "Video requests are authenticated and handled by the secured server.", "✦")
            action("Sign in", "Sign in to create AI videos.") { showAuth(false) }
            addBottom(); return
        }
        content.addView(label("Describe the scene", 14, primaryText, true))
        aiVideoPrompt = EditText(this).apply {
            hint = "A calm drone shot over a green Himalayan lake at sunrise…"; textSize = 15f
            setTextColor(primaryText); setHintTextColor(secondaryText); gravity = Gravity.TOP
            minLines = 3; maxLines = 6; setPadding(dp(14), dp(12), dp(14), dp(12)); background = round(Color.WHITE, 16)
        }
        content.addView(aiVideoPrompt, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(7); bottomMargin = dp(10) })
        button("Choose reference image (optional)") {
            try { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION), 50) }
            catch (error: Exception) { info("Image picker", friendlyError(error)) }
        }
        val ratios = listOf("16:9 · Landscape", "9:16 · Portrait")
        val ratioPicker = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, ratios) }
        content.addView(label("Aspect ratio", 14, primaryText, true).apply { setPadding(0, dp(10), 0, 0) })
        content.addView(ratioPicker, LinearLayout.LayoutParams(-1, dp(48)))
        val resolutions = listOf("360p · lower cost", "720p · standard")
        val resolutionPicker = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, resolutions) }
        content.addView(label("Resolution", 14, primaryText, true))
        content.addView(resolutionPicker, LinearLayout.LayoutParams(-1, dp(48)))
        content.addView(label("The model chooses the short clip length (typically 3–10 seconds). AI video generation requires a deployed Firebase Functions backend and paid Gemini API access; no video is generated until those are configured.", 12, secondaryText, false).apply { setPadding(0, dp(8), 0, dp(10)) })
        aiVideoProgress = ProgressBar(this).apply { isIndeterminate = true; visibility = View.GONE }
        content.addView(aiVideoProgress, LinearLayout.LayoutParams(dp(30), dp(30)).apply { gravity = Gravity.CENTER })
        aiVideoStatus = label("Backend status: not checked yet.", 13, secondaryText, false).apply { setPadding(0, dp(4), 0, dp(8)) }
        content.addView(aiVideoStatus)
        button("Generate video") {
            val ratio = if (ratioPicker.selectedItemPosition == 1) "9:16" else "16:9"
            val resolution = if (resolutionPicker.selectedItemPosition == 0) "360p" else "720p"
            generateAiVideo(ratio, resolution)
        }
        aiVideoPreview = VideoView(this).apply { visibility = View.GONE; setMediaController(MediaController(this@MainActivity)) }
        content.addView(aiVideoPreview, LinearLayout.LayoutParams(-1, dp(240)).apply { topMargin = dp(12) })
        val resultActions = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        resultActions.tag = "ai_video_actions"
        resultActions.addView(buttonView("Save video to device…") { saveAiVideoAs() })
        resultActions.addView(buttonView("Share video") { shareAiVideo() })
        resultActions.addView(buttonView("Upload to my channel") { uploadAiVideo() })
        resultActions.addView(buttonView("Edit this video") { generatedAiVideoFile?.let { showVideoEditingStudio(Uri.fromFile(it)) } })
        content.addView(resultActions)
        addBottom()
    }

    private fun generateAiVideo(aspectRatio: String, resolution: String) {
        val prompt = aiVideoPrompt?.text?.toString()?.trim().orEmpty()
        if (prompt.isBlank()) { aiVideoPrompt?.error = "Describe the video first"; return }
        if (prompt.length > 2000) { aiVideoPrompt?.error = "Keep the prompt under 2,000 characters"; return }
        val user = FirebaseBackend.auth?.currentUser
        if (user == null) { info("Sign in required", "Sign in before requesting video generation."); return }
        val projectId = try { com.google.firebase.FirebaseApp.getInstance().options.projectId } catch (_: Exception) { null }
        if (projectId.isNullOrBlank()) {
            aiVideoStatus?.text = "Firebase project ID is missing. Check app/google-services.json."
            aiVideoStatus?.setTextColor(0xffa33a36.toInt()); return
        }
        val endpoint = "https://us-central1-$projectId.cloudfunctions.net/generateVideo"
        val reference = aiVideoReferenceUri
        aiVideoProgress?.visibility = View.VISIBLE
        aiVideoStatus?.text = "Gemini is processing your video request… The API does not provide a percentage estimate. Generation is pay-per-use."
        aiVideoStatus?.setTextColor(secondaryText)
        content.findViewWithTag<LinearLayout>("ai_video_actions")?.visibility = View.GONE
        aiVideoPrompt?.isEnabled = false
        aiScope.launch {
            try {
                val token = user.getIdToken(false).await().token ?: throw IllegalStateException("Could not get Firebase sign-in token")
                val imagePayload = reference?.let { encodeReferenceImage(it) }
                val response = withContext(Dispatchers.IO) {
                    val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"; connectTimeout = 30_000; readTimeout = 540_000; doOutput = true
                        setRequestProperty("Content-Type", "application/json")
                        setRequestProperty("Authorization", "Bearer $token")
                    }
                    val request = JSONObject().apply {
                        put("prompt", prompt); put("aspectRatio", aspectRatio); put("resolution", resolution)
                        imagePayload?.let { put("imageBase64", it.first); put("imageMimeType", "image/jpeg") }
                    }
                    try {
                        connection.outputStream.use { it.write(request.toString().toByteArray(Charsets.UTF_8)) }
                        val code = connection.responseCode
                        val body = (if (code in 200..299) connection.inputStream else connection.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
                        JSONObject().put("code", code).put("body", body)
                    } finally { connection.disconnect() }
                }
                val body = JSONObject(response.getString("body"))
                if (response.getInt("code") !in 200..299) throw IllegalStateException(body.optString("error", "Video backend returned HTTP ${response.getInt("code")}"))
                val base64Video = body.optString("videoBase64")
                if (body.optString("status") != "completed" || base64Video.isBlank()) throw IllegalStateException("Backend did not return a completed video")
                val file = withContext(Dispatchers.IO) {
                    val target = File(filesDir, "generated-${UUID.randomUUID()}.mp4")
                    target.writeBytes(Base64.decode(base64Video, Base64.DEFAULT))
                    if (!target.exists() || target.length() < 1000) { target.delete(); throw IllegalStateException("The returned video file was incomplete") }
                    target
                }
                generatedAiVideoFile = file
                aiVideoPreview?.apply { visibility = View.VISIBLE; setVideoURI(Uri.fromFile(file)); setOnPreparedListener { it.isLooping = true; start() } }
                content.findViewWithTag<LinearLayout>("ai_video_actions")?.visibility = View.VISIBLE
                aiVideoStatus?.text = "Video generation complete · ${(file.length() / 1024 / 1024).coerceAtLeast(1)} MB · ${body.optString("interactionId")}" 
                aiVideoStatus?.setTextColor(mint)
            } catch (error: Exception) {
                Log.e("HiraBhaiAIVideo", "Video generation request failed endpoint=$endpoint authUid=${user.uid}", error)
                aiVideoStatus?.text = "Video generation unavailable: ${error.message ?: friendlyError(error)}. Deploy the included backend and set GEMINI_API_KEY in Firebase Secret Manager."
                aiVideoStatus?.setTextColor(0xffa33a36.toInt())
            } finally { aiVideoProgress?.visibility = View.GONE; aiVideoPrompt?.isEnabled = true }
        }
    }

    private fun encodeReferenceImage(uri: Uri): Pair<String, String> = try {
        val bitmap = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } ?: throw IllegalArgumentException("Could not read the selected image")
        val scaled = if (maxOf(bitmap.width, bitmap.height) > 1536) {
            val ratio = 1536f / maxOf(bitmap.width, bitmap.height)
            Bitmap.createScaledBitmap(bitmap, (bitmap.width * ratio).toInt(), (bitmap.height * ratio).toInt(), true).also { if (it !== bitmap) bitmap.recycle() }
        } else bitmap
        val bytes = ByteArrayOutputStream().also { scaled.compress(Bitmap.CompressFormat.JPEG, 78, it) }.toByteArray()
        if (scaled.isRecycled.not()) scaled.recycle()
        if (bytes.size > 4_000_000) throw IllegalArgumentException("Reference image is too large. Choose a smaller image.")
        Base64.encodeToString(bytes, Base64.NO_WRAP) to "image/jpeg"
    } catch (error: Exception) { throw IllegalArgumentException("Could not prepare the reference image: ${friendlyError(error)}", error) }

    private fun saveAiVideoAs() {
        val file = generatedAiVideoFile ?: return
        pendingVideoExportFile = file
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).setType("video/mp4").addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_TITLE, "hira-ai-${System.currentTimeMillis()}.mp4"), 53)
    }

    private fun shareAiVideo() { generatedAiVideoFile?.let { shareVideoFile(it) } }

    private fun shareVideoFile(file: File) {
        aiScope.launch {
            try {
                val uri = withContext(Dispatchers.IO) {
                    val dir = File(cacheDir, "shared_video").apply { mkdirs() }
                    val copy = File(dir, "${UUID.randomUUID()}.mp4"); file.copyTo(copy, overwrite = true)
                    FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", copy)
                }
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "video/mp4"; putExtra(Intent.EXTRA_STREAM, uri); clipData = ClipData.newUri(contentResolver, "Video", uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }, "Share video"))
            } catch (error: Exception) { info("Share failed", friendlyError(error)) }
        }
    }

    private fun uploadAiVideo() {
        val file = generatedAiVideoFile ?: return
        if (FirebaseBackend.auth?.currentUser == null) { showAuth(false); return }
        selectedVideoUri = Uri.fromFile(file); selectedVideoThumbnailUri = null; videoThumbnail = null
        pendingVideoTitle = ""; pendingVideoDescription = ""; pendingVideoVisibility = "public"
        showVideoUploadForm(Uri.fromFile(file))
    }

    private var pendingVideoExportFile: File? = null

    private fun chooseVideoForEditing() {
        try { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).setType("video/*").addCategory(Intent.CATEGORY_OPENABLE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION), 52) }
        catch (error: Exception) { info("Video picker", friendlyError(error)) }
    }

    private fun showVideoEditingStudio(uri: Uri, narrationUri: Uri? = null) {
        videoEditSource = uri; videoEditMusic = narrationUri; videoEditMusicIsNarration = narrationUri != null; videoEditThumbnail = null; editedVideoFile = null
        studioSelectedEffect = 0; studioMuteOriginalAudio = false; studioTextPosition = 0
        selected = "Hira Bhai Studio"; base()
        val studioBg = 0xff071521.toInt(); val panelBg = 0xff0d2638.toInt(); val muted = 0xffa8bdca.toInt(); val accent = 0xff2196f3.toInt()
        root.setBackgroundColor(studioBg); content.setPadding(dp(14), dp(12), dp(14), dp(18))
        window.statusBarColor = studioBg; window.navigationBarColor = Color.BLACK; window.decorView.systemUiVisibility = 0
        val toolbar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, 0, 0, dp(12)) }
        val back = TextView(this).apply { text = "⌂"; textSize = 24f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); layoutParams = LinearLayout.LayoutParams(dp(42), dp(44)); setOnClickListener { showHome() } }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(7), 0, 0, 0) }
        brand.addView(label("Hira Bhai Studio", 18, Color.WHITE, true)); brand.addView(label("Video editing workspace", 11, muted, false))
        toolbar.addView(back); toolbar.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        val more = TextView(this).apply { text = "⋯"; textSize = 25f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); layoutParams = LinearLayout.LayoutParams(dp(40), dp(42)); setOnClickListener { info("Studio project", "Your source clip is preserved. Export creates a separate MP4 copy you can save, share, or upload.") } }
        toolbar.addView(more); content.addView(toolbar)
        val previewBox = FrameLayout(this).apply { background = round(Color.BLACK, 6); layoutParams = LinearLayout.LayoutParams(-1, dp(230)); clipToOutline = true }
        studioPreviewDuration = null; studioPreviewTime = null
        videoEditPreview = VideoView(this).apply {
            setVideoURI(uri)
            setOnPreparedListener { player -> player.isLooping = false; start(); studioPreviewTime?.max = player.duration.coerceAtLeast(1); studioPreviewTime?.progress = 0; studioPreviewDuration?.text = "00:00 / ${formatStudioTime(player.duration)}" }
            setOnCompletionListener { it.seekTo(0); studioPreviewTime?.progress = 0 }
        }
        previewBox.addView(videoEditPreview, FrameLayout.LayoutParams(-1, -1)); content.addView(previewBox)
        val previewTimeRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(5), 0, dp(2)) }
        val previewDuration = label("00:00 / --:--", 12, muted, false); studioPreviewDuration = previewDuration
        previewTimeRow.addView(previewDuration, LinearLayout.LayoutParams(0, -2, 1f))
        previewTimeRow.addView(TextView(this).apply { text = "▶ / ❚❚"; textSize = 13f; setTextColor(Color.WHITE); setPadding(dp(8), dp(4), dp(8), dp(4)); setOnClickListener { videoEditPreview?.let { if (it.isPlaying) it.pause() else it.start() } } })
        content.addView(previewTimeRow)
        val previewTime = SeekBar(this).apply { progressTintList = android.content.res.ColorStateList.valueOf(accent); thumbTintList = android.content.res.ColorStateList.valueOf(Color.WHITE); setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { if (fromUser) { videoEditPreview?.seekTo(progress); previewDuration.text = "${formatStudioTime(progress)} / ${formatStudioTime(seekBar?.max ?: 0)}" } }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        }) }
        studioPreviewTime = previewTime
        content.addView(previewTime)
        val timelineTitle = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(10), 0, dp(4)) }
        timelineTitle.addView(label("TIMELINE", 11, muted, true), LinearLayout.LayoutParams(0, -2, 1f)); timelineTitle.addView(label("1 video clip", 11, muted, false)); content.addView(timelineTitle)
        val timeline = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; background = round(panelBg, 12); setPadding(dp(10), dp(9), dp(10), dp(9)) }
        timeline.addView(label("▣", 20, 0xff51b8ed.toInt(), true), LinearLayout.LayoutParams(dp(30), dp(44)))
        timeline.addView(LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(label("VIDEO 1", 10, 0xff69c9f5.toInt(), true)); addView(label(uri.lastPathSegment?.take(28) ?: "Selected clip", 12, Color.WHITE, false)) }, LinearLayout.LayoutParams(0, -2, 1f))
        timeline.addView(label("＋", 23, Color.WHITE, true).apply { gravity = Gravity.CENTER; background = round(accent, 10); layoutParams = LinearLayout.LayoutParams(dp(42), dp(42)); setOnClickListener { chooseAnotherEditClip() } })
        content.addView(timeline)
        val toolScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; setPadding(0, dp(12), 0, dp(8)) }
        val tools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val panels = linkedMapOf<String, LinearLayout>()
        val toolNames = listOf("Edit", "Audio", "Text", "Effects", "Overlay")
        val toolsPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        toolNames.forEachIndexed { index, title ->
            val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = if (index == 0) View.VISIBLE else View.GONE; background = round(panelBg, 16); setPadding(dp(13), dp(12), dp(13), dp(12)) }
            panels[title] = panel
            val tab = TextView(this).apply { text = "${listOf("✂", "♫", "T", "✦", "▧")[index]}\n$title"; gravity = Gravity.CENTER; textSize = 12f; setTextColor(Color.WHITE); background = round(if (index == 0) accent else panelBg, 12); setPadding(dp(13), dp(7), dp(13), dp(7)); layoutParams = LinearLayout.LayoutParams(dp(74), dp(62)).apply { rightMargin = dp(7) }; setOnClickListener { panels.values.forEach { it.visibility = View.GONE }; panel.visibility = View.VISIBLE; for (childIndex in 0 until tools.childCount) tools.getChildAt(childIndex).background = round(panelBg, 12); background = round(accent, 12) } }
            tools.addView(tab)
        }
        toolScroll.addView(tools); content.addView(toolScroll)
        val editPanel = panels.getValue("Edit")
        editPanel.addView(label("Trim range · seconds", 13, Color.WHITE, true))
        val trimRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val startInput = EditText(this).apply { hint = "Start · 0"; inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL; setText("0"); setTextColor(Color.WHITE); setHintTextColor(muted); background = round(0xff16344a.toInt(), 10) }
        val endInput = EditText(this).apply { hint = "End · full length"; inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL; setTextColor(Color.WHITE); setHintTextColor(muted); background = round(0xff16344a.toInt(), 10) }
        trimRow.addView(startInput, LinearLayout.LayoutParams(0, dp(48), 1f).apply { rightMargin = dp(7) }); trimRow.addView(endInput, LinearLayout.LayoutParams(0, dp(48), 1f)); editPanel.addView(trimRow)
        editPanel.addView(label("Frame shape", 13, Color.WHITE, true).apply { setPadding(0, dp(8), 0, dp(2)) })
        val cropOptions = listOf("Original", "16:9 · Landscape", "9:16 · Portrait", "1:1 · Square")
        val cropPicker = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, cropOptions) }; editPanel.addView(cropPicker, LinearLayout.LayoutParams(-1, dp(44)))
        editPanel.addView(label("Playback speed", 13, Color.WHITE, true).apply { setPadding(0, dp(5), 0, 0) })
        val speedPicker = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("0.5×", "0.75×", "1×", "1.25×", "1.5×", "2×")); setSelection(2) }; editPanel.addView(speedPicker, LinearLayout.LayoutParams(-1, dp(44)))
        val audioPanel = panels.getValue("Audio")
        audioPanel.addView(label("Audio mix", 14, Color.WHITE, true)); val muteOriginal = CheckBox(this).apply { text = "Mute original clip audio"; setTextColor(Color.WHITE); buttonTintList = android.content.res.ColorStateList.valueOf(accent) }; audioPanel.addView(muteOriginal)
        audioPanel.addView(label(if (narrationUri != null) "Generated narration is selected and will be mixed from the start of the clip." else "Add music or use narration generated with the AI Voice Generator.", 12, muted, false))
        audioPanel.addView(buttonView("♫   Choose background music") { chooseStudioAudio() })
        val textPanel = panels.getValue("Text")
        val overlayInput = EditText(this).apply { hint = "Titles, captions, or subtitles"; setTextColor(Color.WHITE); setHintTextColor(muted); background = round(0xff16344a.toInt(), 10) }; textPanel.addView(label("Text overlay · stays through the clip", 13, Color.WHITE, true)); textPanel.addView(overlayInput, LinearLayout.LayoutParams(-1, dp(48)))
        val textPosition = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Bottom", "Top", "Center")) }; textPanel.addView(textPosition, LinearLayout.LayoutParams(-1, dp(45)))
        val effectPanel = panels.getValue("Effects")
        effectPanel.addView(label("Color look", 13, Color.WHITE, true))
        val effectPicker = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Original", "Cinematic", "Warm", "Cool", "Vivid")) }; effectPanel.addView(effectPicker, LinearLayout.LayoutParams(-1, dp(46)))
        val overlayPanel = panels.getValue("Overlay")
        overlayPanel.addView(label("Cover image", 14, Color.WHITE, true)); overlayPanel.addView(label("Choose a thumbnail to use when uploading this edited clip.", 12, muted, false))
        overlayPanel.addView(buttonView("▧   Choose thumbnail") { chooseStudioThumbnail() })
        panels.values.forEach { toolsPanel.addView(it, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(5) }) }
        content.addView(toolsPanel)
        videoEditProgress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE }
        content.addView(videoEditProgress, LinearLayout.LayoutParams(-1, dp(8)).apply { topMargin = dp(8) })
        videoEditStatus = label("Project ready · source clip stays untouched.", 13, muted, false).apply { setPadding(0, dp(6), 0, dp(8)) }
        content.addView(videoEditStatus)
        button("Export MP4") { studioMuteOriginalAudio = muteOriginal.isChecked; studioTextPosition = textPosition.selectedItemPosition; studioSelectedEffect = effectPicker.selectedItemPosition; exportEditedVideo(uri, startInput, endInput, cropPicker.selectedItemPosition, overlayInput.text.toString().trim(), speedPicker.selectedItemPosition) }
        val resultRow = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE; tag = "edited_video_actions" }
        resultRow.addView(buttonView("Save edited video…") { editedVideoFile?.let { pendingVideoExportFile = it; startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).setType("video/mp4").addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_TITLE, "hira-edited-${System.currentTimeMillis()}.mp4"), 53) } })
        resultRow.addView(buttonView("Share edited video") { editedVideoFile?.let { shareVideoFile(it) } })
        resultRow.addView(buttonView("Upload edited copy to my channel") {
            editedVideoFile?.let { selectedVideoUri = Uri.fromFile(it); selectedVideoThumbnailUri = videoEditThumbnail; videoThumbnail = null; pendingVideoTitle = ""; pendingVideoDescription = ""; pendingVideoVisibility = "public"; showVideoUploadForm(Uri.fromFile(it)) }
        })
        content.addView(resultRow); addBottom()
    }

    private fun formatStudioTime(ms: Int): String = String.format(Locale.US, "%02d:%02d", (ms / 60000), (ms / 1000) % 60)

    private fun chooseAnotherEditClip() { info("Timeline", "This version edits one source clip per project. Export the finished MP4, then start another project for another clip.") }
    private fun chooseStudioAudio() { try { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).setType("audio/*").addCategory(Intent.CATEGORY_OPENABLE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION), 54) } catch (error: Exception) { info("Audio picker", friendlyError(error)) } }
    private fun chooseStudioThumbnail() { try { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION), 55) } catch (error: Exception) { info("Thumbnail picker", friendlyError(error)) } }

    @OptIn(UnstableApi::class)
    private fun exportEditedVideo(uri: Uri, startInput: EditText, endInput: EditText, cropIndex: Int, overlayText: String, speedIndex: Int) {
        val startMs = ((startInput.text.toString().toFloatOrNull() ?: 0f) * 1000).toLong().coerceAtLeast(0)
        val endSeconds = endInput.text.toString().toFloatOrNull()
        val endMs = endSeconds?.let { (it * 1000).toLong() } ?: C.TIME_END_OF_SOURCE
        if (endMs != C.TIME_END_OF_SOURCE && endMs <= startMs) { endInput.error = "End must be after start"; return }
        val source = File(cacheDir, "edit-source-${UUID.randomUUID()}.mp4")
        val output = File(filesDir, "edited-${UUID.randomUUID()}.mp4")
        videoEditProgress?.visibility = View.VISIBLE; videoEditProgress?.isIndeterminate = true
        videoEditStatus?.text = "Preparing a new export… Original video is unchanged."
        aiScope.launch {
            try {
                withContext(Dispatchers.IO) { contentResolver.openInputStream(uri)?.use { input -> source.outputStream().use(input::copyTo) } ?: throw IllegalStateException("Could not read selected video") }
                val item = withContext(Dispatchers.IO) {
                    val clipping = MediaItem.ClippingConfiguration.Builder().setStartPositionMs(startMs).apply { if (endMs != C.TIME_END_OF_SOURCE) setEndPositionMs(endMs) }.build()
                    val media = MediaItem.Builder().setUri(Uri.fromFile(source)).setClippingConfiguration(clipping).build()
                    val videoEffects = mutableListOf<androidx.media3.common.Effect>()
                    if (cropIndex > 0) {
                        val retriever = MediaMetadataRetriever(); retriever.setDataSource(this@MainActivity, Uri.fromFile(source))
                        val w = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toFloatOrNull() ?: 16f
                        val h = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toFloatOrNull() ?: 9f
                        retriever.release()
                        val targetRatio = when (cropIndex) { 1 -> 16f / 9f; 2 -> 9f / 16f; else -> 1f }
                        val sourceRatio = w / h
                        val (left, right, bottom, top) = if (sourceRatio > targetRatio) { val half = targetRatio / sourceRatio; val x = (1f - half) / 2f; floatArrayOf(-half, half, -1f, 1f) } else { val half = sourceRatio / targetRatio; floatArrayOf(-1f, 1f, -half, half) }
                        videoEffects.add(Crop(left, right, bottom, top))
                    }
                    if (studioSelectedEffect > 0) {
                        when (studioSelectedEffect) {
                            1 -> videoEffects.add(Contrast(.16f))
                            2 -> videoEffects.add(RgbAdjustment.Builder().setRedScale(1.08f).setGreenScale(1.01f).setBlueScale(.92f).build())
                            3 -> videoEffects.add(RgbAdjustment.Builder().setRedScale(.92f).setGreenScale(1.02f).setBlueScale(1.10f).build())
                            4 -> videoEffects.add(HslAdjustment.Builder().adjustHue(0f).adjustSaturation(.18f).adjustLightness(.01f).build())
                        }
                    }
                    if (overlayText.isNotBlank()) {
                        val width = if (cropIndex == 2) 720 else 1280; val height = if (cropIndex == 2) 1280 else if (cropIndex == 3) 720 else if (cropIndex == 1) 720 else 720
                        val overlay = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                        val canvas = Canvas(overlay); val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = (width * .055f).coerceAtLeast(34f); typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD); setShadowLayer(5f, 2f, 2f, Color.BLACK) }
                        val lines = overlayText.chunked(34).take(4)
                        val lineHeight = paint.textSize * 1.2f
                        val baseline = when (studioTextPosition) { 1 -> height * .14f; 2 -> height * .53f; else -> height * .88f }
                        lines.forEachIndexed { index, line -> canvas.drawText(line, width * .06f, baseline + (index - if (studioTextPosition == 1) 0 else lines.size - 1) * lineHeight, paint) }
                        videoEffects.add(OverlayEffect(listOf(BitmapOverlay.createStaticBitmapOverlay(overlay))))
                    }
                    val speed = listOf(.5f, .75f, 1f, 1.25f, 1.5f, 2f).getOrElse(speedIndex) { 1f }
                    val speedProvider = object : androidx.media3.common.audio.SpeedProvider {
                        override fun getSpeed(timeUs: Long) = speed
                        override fun getNextSpeedChangeTimeUs(timeUs: Long) = C.TIME_UNSET
                    }
                    EditedMediaItem.Builder(media).setEffects(Effects(emptyList(), videoEffects)).setRemoveAudio(studioMuteOriginalAudio).setSpeed(androidx.media3.common.SpeedParameters(speedProvider, true)).build()
                }
                val transformer = Transformer.Builder(this@MainActivity).addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: androidx.media3.transformer.ExportResult) {
                        exportProgressRunnable?.let(exportProgressHandler::removeCallbacks); exportProgressRunnable = null; activeTransformer = null
                        runOnUiThread {
                            editedVideoFile = output; videoEditProgress?.visibility = View.GONE
                            videoEditStatus?.text = "Export complete · ${(output.length() / 1024 / 1024).coerceAtLeast(1)} MB. The source file was preserved."
                            videoEditStatus?.setTextColor(mint); content.findViewWithTag<LinearLayout>("edited_video_actions")?.visibility = View.VISIBLE
                            videoEditPreview?.apply { setVideoURI(Uri.fromFile(output)); setOnPreparedListener { it.isLooping = true; start() } }
                        }
                        source.delete()
                    }
                    override fun onError(composition: Composition, exportResult: androidx.media3.transformer.ExportResult, exportException: androidx.media3.transformer.ExportException) {
                        exportProgressRunnable?.let(exportProgressHandler::removeCallbacks); exportProgressRunnable = null; activeTransformer = null
                        Log.e("HiraBhaiVideoEditor", "Transformer export failed", exportException)
                        runOnUiThread { videoEditProgress?.visibility = View.GONE; videoEditStatus?.text = "Export failed: ${exportException.message ?: "unsupported media format"}"; videoEditStatus?.setTextColor(0xffa33a36.toInt()) }
                        source.delete(); output.delete()
                    }
                }).build()
                activeTransformer = transformer
                val music = videoEditMusic
                if (music == null) transformer.start(item, output.absolutePath) else {
                    val audioItem = EditedMediaItem.Builder(MediaItem.fromUri(music)).build()
                    val videoSequence = EditedMediaItemSequence.withAudioAndVideoFrom(listOf(item))
                    val audioSequence = EditedMediaItemSequence.withAudioFrom(listOf(audioItem)).buildUpon().setIsLooping(!videoEditMusicIsNarration).build()
                    transformer.start(Composition.Builder(videoSequence, audioSequence).build(), output.absolutePath)
                }
                videoEditProgress?.apply { isIndeterminate = false; progress = 0 }
                val progressHolder = ProgressHolder()
                val progressTick = object : Runnable {
                    override fun run() {
                        val current = activeTransformer ?: return
                        try {
                            val state = current.getProgress(progressHolder)
                            if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                                videoEditProgress?.progress = progressHolder.progress
                                videoEditStatus?.text = "Exporting edited copy… ${progressHolder.progress}%"
                            } else if (state == Transformer.PROGRESS_STATE_WAITING_FOR_AVAILABILITY) {
                                videoEditStatus?.text = "Preparing media encoder…"
                            }
                            exportProgressHandler.postDelayed(this, 400)
                        } catch (error: Exception) {
                            Log.w("HiraBhaiVideoEditor", "Progress query failed", error)
                            exportProgressHandler.postDelayed(this, 800)
                        }
                    }
                }
                exportProgressRunnable = progressTick
                exportProgressHandler.post(progressTick)
            } catch (error: Exception) {
                Log.e("HiraBhaiVideoEditor", "Could not start export", error)
                source.delete(); output.delete()
                activeTransformer = null; exportProgressRunnable?.let(exportProgressHandler::removeCallbacks); exportProgressRunnable = null
                runOnUiThread { videoEditProgress?.visibility = View.GONE; videoEditStatus?.text = "Could not export video: ${friendlyError(error)}"; videoEditStatus?.setTextColor(0xffa33a36.toInt()) }
            }
        }
    }

    private fun showAiImageGenerator() {
        selected = "AI Image Generator"
        base()
        val user = FirebaseBackend.auth?.currentUser
        heading("AI Image Generator", "Turn a prompt into an original image")
        if (user == null) {
            featureTile("Sign in required", "Generated images use Firebase AI Logic with your authenticated account.", "✦")
            action("Sign in", "Sign in to generate and save images.") { showAuth(false) }
            addBottom(); return
        }
        content.addView(label("Describe the image", 14, primaryText, true))
        imageGeneratorPrompt = EditText(this).apply {
            hint = "A cinematic Himalayan lake at sunrise…"; textSize = 15f; setTextColor(primaryText); setHintTextColor(secondaryText)
            gravity = Gravity.TOP; minLines = 3; maxLines = 5; setPadding(dp(14), dp(12), dp(14), dp(12)); background = round(Color.WHITE, 16)
        }
        content.addView(imageGeneratorPrompt, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(7); bottomMargin = dp(12) })

        content.addView(label("Style", 14, primaryText, true))
        val styles = listOf("Photorealistic", "Cinematic", "Watercolor illustration", "3D cartoon", "Flat vector art", "Anime-inspired")
        val stylePicker = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, styles) }
        content.addView(stylePicker, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(4); bottomMargin = dp(10) })
        content.addView(label("Aspect ratio", 14, primaryText, true))
        val ratios = listOf("1:1 · Square", "16:9 · Landscape", "9:16 · Portrait", "4:3", "3:2", "21:9 · Wide")
        val ratioPicker = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, ratios) }
        content.addView(ratioPicker, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(4); bottomMargin = dp(8) })
        imageGeneratorProgress = ProgressBar(this).apply { isIndeterminate = true; visibility = View.GONE }
        content.addView(imageGeneratorProgress, LinearLayout.LayoutParams(dp(32), dp(32)).apply { gravity = Gravity.CENTER_HORIZONTAL })
        imageGeneratorStatus = label("Image generation uses Google Gemini. Billing is required for image models.", 13, secondaryText, false).apply { setPadding(0, dp(5), 0, dp(10)) }
        content.addView(imageGeneratorStatus)
        button("Generate image") { generateAiImage(styles[stylePicker.selectedItemPosition], ratios[ratioPicker.selectedItemPosition]) }
        imageGeneratorPreview = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER; adjustViewBounds = true; background = round(Color.WHITE, 18)
            contentDescription = "AI generated image preview"
            generatedAiImage?.let(::setImageBitmap)
        }
        content.addView(imageGeneratorPreview, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12); bottomMargin = dp(8) })
        val saveShare = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val saveButton = buttonView("Save image") { saveGeneratedAiImage() }
        val shareButton = buttonView("Share") { shareGeneratedAiImage() }
        saveShare.addView(saveButton, LinearLayout.LayoutParams(0, dp(48), 1f).apply { rightMargin = dp(6) })
        saveShare.addView(shareButton, LinearLayout.LayoutParams(0, dp(48), 1f).apply { leftMargin = dp(6) })
        saveShare.visibility = if (generatedAiImage == null) View.GONE else View.VISIBLE
        content.addView(saveShare)
        imageGeneratorSaveRow = saveShare
        addBottom()
    }

    private var imageGeneratorSaveRow: View? = null

    @OptIn(PublicPreviewAPI::class)
    private fun generateAiImage(style: String, aspectLabel: String) {
        val prompt = imageGeneratorPrompt?.text?.toString()?.trim().orEmpty()
        if (prompt.isBlank()) { imageGeneratorPrompt?.error = "Describe the image first"; return }
        if (prompt.length > 1500) { imageGeneratorPrompt?.error = "Keep the prompt under 1,500 characters"; return }
        if (FirebaseBackend.auth?.currentUser == null) { showAiError("Sign in before generating an image."); return }
        val aspect = when (aspectLabel.substringBefore(" ·")) {
            "16:9" -> AspectRatio.LANDSCAPE_16x9
            "9:16" -> AspectRatio.PORTRAIT_9x16
            "4:3" -> AspectRatio.LANDSCAPE_4x3
            "3:2" -> AspectRatio.LANDSCAPE_3x2
            "21:9" -> AspectRatio.LANDSCAPE_21x9
            else -> AspectRatio.SQUARE_1x1
        }
        imageGeneratorPrompt?.isEnabled = false
        imageGeneratorProgress?.visibility = View.VISIBLE
        imageGeneratorStatus?.setTextColor(secondaryText)
        imageGeneratorStatus?.text = "Generating your image… This may take a little while."
        imageGeneratorSaveRow?.visibility = View.GONE
        aiScope.launch {
            try {
                val model = Firebase.ai(backend = GenerativeBackend.googleAI(), useLimitedUseAppCheckTokens = true)
                    .generativeModel(
                        modelName = "gemini-nano-banana-2.1",
                        generationConfig = generationConfig {
                            responseModalities = listOf(ResponseModality.IMAGE)
                            imageConfig = imageConfig { aspectRatio = aspect }
                        }
                    )
                val response = model.generateContent("Generate one original image. Visual style: $style. Composition ratio: $aspectLabel. Image prompt: $prompt")
                val bitmap = response.candidates.firstOrNull()?.content?.parts?.filterIsInstance<ImagePart>()?.firstOrNull()?.image
                if (bitmap == null) {
                    imageGeneratorStatus?.text = "The model did not return an image. Try a clearer prompt and ask explicitly for an image."
                    imageGeneratorStatus?.setTextColor(0xffa33a36.toInt())
                } else {
                    generatedAiImage = bitmap
                    imageGeneratorPreview?.setImageBitmap(bitmap)
                    imageGeneratorSaveRow?.visibility = View.VISIBLE
                    imageGeneratorStatus?.text = "Image ready · ${bitmap.width} × ${bitmap.height}"
                }
            } catch (error: Exception) {
                Log.e("HiraBhaiAIImage", "Image generation failed: model=gemini-nano-banana-2.1 uid=${FirebaseBackend.auth?.currentUser?.uid}", error)
                imageGeneratorStatus?.text = "Image generation failed: ${friendlyError(error)}. Confirm Firebase AI Logic is enabled and the project uses the Blaze plan."
                imageGeneratorStatus?.setTextColor(0xffa33a36.toInt())
            } finally {
                imageGeneratorProgress?.visibility = View.GONE
                imageGeneratorPrompt?.isEnabled = true
            }
        }
    }

    private fun saveGeneratedAiImage() {
        val bitmap = generatedAiImage ?: run { info("No image yet", "Generate an image before saving it."); return }
        if (android.os.Build.VERSION.SDK_INT < 29) {
            pendingImageSave = bitmap
            val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "image/png"
                putExtra(Intent.EXTRA_TITLE, "hira-ai-${System.currentTimeMillis()}.png")
            }
            startActivityForResult(intent, 48)
            return
        }
        imageGeneratorStatus?.text = "Saving to Pictures/Hira Bhai…"
        aiScope.launch {
            try {
                val uri = withContext(Dispatchers.IO) {
                    val values = ContentValues().apply {
                        put(MediaStore.Images.Media.DISPLAY_NAME, "hira-ai-${System.currentTimeMillis()}.png")
                        put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                        put(MediaStore.Images.Media.RELATIVE_PATH, "${android.os.Environment.DIRECTORY_PICTURES}/Hira Bhai")
                        put(MediaStore.Images.Media.IS_PENDING, 1)
                    }
                    val output = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                        ?: throw IllegalStateException("Could not create a gallery image")
                    try {
                        val stream = contentResolver.openOutputStream(output) ?: throw IllegalStateException("Could not open the saved image")
                        stream.use { if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)) throw IllegalStateException("Image encoding failed") }
                        contentResolver.update(output, ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }, null, null)
                        output
                    } catch (error: Exception) { contentResolver.delete(output, null, null); throw error }
                }
                imageGeneratorStatus?.text = "Saved to Pictures/Hira Bhai"
                Toast.makeText(this@MainActivity, "Image saved to your gallery", Toast.LENGTH_SHORT).show()
            } catch (error: Exception) {
                Log.e("HiraBhaiAIImage", "Gallery save failed", error)
                imageGeneratorStatus?.text = "Could not save the image: ${friendlyError(error)}"
            }
        }
    }

    private fun shareGeneratedAiImage() {
        val bitmap = generatedAiImage ?: run { info("No image yet", "Generate an image before sharing it."); return }
        aiScope.launch {
            try {
                val uri = withContext(Dispatchers.IO) {
                    val shareDir = File(cacheDir, "shared_images").apply { mkdirs() }
                    shareDir.listFiles()?.filter { System.currentTimeMillis() - it.lastModified() > 24 * 60 * 60 * 1000L }?.forEach { it.delete() }
                    val imageFile = File(shareDir, "hira-ai-${System.currentTimeMillis()}.png")
                    imageFile.outputStream().use { if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)) throw IllegalStateException("Image encoding failed") }
                    FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", imageFile)
                }
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "image/png"; putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    clipData = ClipData.newUri(contentResolver, "Generated image", uri)
                }
                startActivity(Intent.createChooser(shareIntent, "Share image"))
            } catch (error: Exception) {
                Log.e("HiraBhaiAIImage", "Image share failed", error)
                info("Share failed", friendlyError(error))
            }
        }
    }

    private fun showAiContentStudio() {
        selected = "AI Content Studio"
        base()
        heading("AI Content Studio", "Create content for your next post")
        val user = FirebaseBackend.auth?.currentUser
        if (user == null) {
            featureTile("Sign in required", "Your requests are sent through Firebase AI Logic.", "✦")
            action("Sign in", "Sign in to generate creator content.") { showAuth(false) }
            addBottom(); return
        }
        val tasks = listOf("Video titles", "Description", "Video script", "Thumbnail ideas", "Social caption", "Hashtags", "Content ideas")
        val taskScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val taskRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun drawTaskChips() {
            taskRow.removeAllViews()
            tasks.forEach { task ->
                val chip = TextView(this).apply {
                    text = task; textSize = 12f; setTextColor(if (task == contentStudioTask) Color.WHITE else primaryText)
                    background = round(if (task == contentStudioTask) mint else Color.WHITE, 30)
                    setPadding(dp(13), dp(9), dp(13), dp(9)); isClickable = true; isFocusable = true
                    setOnClickListener { contentStudioTask = task; drawTaskChips() }
                }
                taskRow.addView(chip, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(8) })
            }
        }
        drawTaskChips(); taskScroll.addView(taskRow)
        content.addView(taskScroll, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        content.addView(label("Topic or details", 14, primaryText, true))
        contentStudioPrompt = EditText(this).apply {
            hint = "What is your video or post about?"; textSize = 15f; setTextColor(primaryText); setHintTextColor(secondaryText)
            gravity = Gravity.TOP; minLines = 3; maxLines = 6; setPadding(dp(14), dp(12), dp(14), dp(12)); background = round(Color.WHITE, 16)
        }
        content.addView(contentStudioPrompt, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(7); bottomMargin = dp(12) })
        contentStudioProgress = ProgressBar(this).apply { isIndeterminate = true; visibility = View.GONE }
        content.addView(contentStudioProgress, LinearLayout.LayoutParams(dp(32), dp(32)).apply { gravity = Gravity.CENTER_HORIZONTAL })
        content.addView(label("The result follows the language of your prompt.", 12, secondaryText, false).apply { setPadding(0, 0, 0, dp(8)) })
        button("Generate content") { generateAiStudioText() }
        contentStudioResult = label("Your generated content will appear here.", 15, primaryText, false).apply {
            background = round(Color.WHITE, 16); setPadding(dp(15), dp(14), dp(15), dp(14)); setTextIsSelectable(true)
        }
        content.addView(contentStudioResult, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12); bottomMargin = dp(8) })
        content.addView(buttonView("Copy generated content") {
            val text = contentStudioResult?.text?.toString().orEmpty()
            if (text.isNotBlank() && text != "Your generated content will appear here.") {
                (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Hira Bhai AI content", text))
                Toast.makeText(this, "Content copied", Toast.LENGTH_SHORT).show()
            }
        })
        content.addView(buttonView("♫  Create narration from this script") {
            val script = contentStudioResult?.text?.toString().orEmpty()
            if (script.isBlank() || script.startsWith("Your generated") || script.startsWith("Generation failed:") || script.startsWith("Creating ")) {
                info("No script yet", "Generate a script first, then turn it into speech.")
            } else showAiVoiceGenerator(script)
        })
        addBottom()
    }

    private fun showAiVoiceGenerator(initialText: String = "") {
        selected = "AI Voice Generator"; base()
        heading("AI Voice Generator", "Create narration with voices installed on this device")
        content.addView(label("This uses Android Text-to-Speech, not a cloud voice cloning service. Available languages and voice styles depend on the device's installed speech engine.", 13, secondaryText, false).apply { setPadding(0, 0, 0, dp(12)) })
        content.addView(label("Text to speak", 14, primaryText, true))
        val maxChars = TextToSpeech.getMaxSpeechInputLength()
        voiceTextInput = EditText(this).apply {
            hint = "Paste a script or enter narration…"; textSize = 15f; setTextColor(primaryText); setHintTextColor(secondaryText)
            gravity = Gravity.TOP; minLines = 5; maxLines = 12; setPadding(dp(14), dp(12), dp(14), dp(12)); background = round(Color.WHITE, 16)
            filters = arrayOf(android.text.InputFilter.LengthFilter(maxChars))
            if (initialText.isNotBlank()) setText(initialText.take(maxChars))
        }
        content.addView(voiceTextInput, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(7); bottomMargin = dp(10) })
        content.addView(label("Language", 14, primaryText, true))
        voiceLanguageSpinner = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Checking installed voices…")) }
        content.addView(voiceLanguageSpinner, LinearLayout.LayoutParams(-1, dp(48)))
        content.addView(label("Voice style · installed voices only", 14, primaryText, true).apply { setPadding(0, dp(7), 0, 0) })
        voiceStyleSpinner = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Default device voice")) }
        content.addView(voiceStyleSpinner, LinearLayout.LayoutParams(-1, dp(48)))
        content.addView(label("Speaking speed", 14, primaryText, true).apply { setPadding(0, dp(6), 0, 0) })
        val rateLabel = label("100%", 12, secondaryText, false)
        voiceRate = SeekBar(this).apply { max = 150; progress = 50; setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { rateLabel.text = "${(progress + 50)}%" }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        }) }
        content.addView(voiceRate); content.addView(rateLabel)
        voiceProgress = ProgressBar(this).apply { isIndeterminate = true; visibility = View.GONE }
        content.addView(voiceProgress, LinearLayout.LayoutParams(dp(32), dp(32)).apply { gravity = Gravity.CENTER_HORIZONTAL })
        voiceStatus = label("Preparing the Android speech engine…", 13, secondaryText, false).apply { setPadding(0, dp(6), 0, dp(8)) }
        content.addView(voiceStatus)
        button("Generate audio") { generateVoiceAudio() }
        voicePlaybackButton = buttonView("▶  Play generated audio") { playGeneratedVoice() }
        content.addView(voicePlaybackButton)
        content.addView(buttonView("Save audio to device…") { saveGeneratedVoice() })
        content.addView(buttonView("Share audio") { generatedVoiceFile?.let { shareVoiceFile(it) } ?: info("No audio yet", "Generate narration first.") })
        content.addView(buttonView("Use narration in Video Editing Studio") { chooseVideoForNarration() })
        content.addView(label("Android's speech engine has a per-request text limit (shown by the input limit). Some voices may download or require network access; availability and quality vary by device.", 12, secondaryText, false).apply { setPadding(0, dp(10), 0, dp(8)) })
        addBottom()
        ensureVoiceEngine()
    }

    private fun ensureVoiceEngine() {
        if (voiceTts != null) { if (voiceTtsReady) populateVoiceLanguages(); return }
        voiceTts = TextToSpeech(this) { status -> runOnUiThread {
            if (status != TextToSpeech.SUCCESS) { voiceStatus?.text = "The device speech engine could not start. Install or enable a Text-to-Speech engine in Android settings."; return@runOnUiThread }
            voiceTtsReady = true
            voiceTts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) { runOnUiThread { voiceStatus?.text = "Generating audio…" } }
                override fun onDone(utteranceId: String?) { runOnUiThread {
                    voiceProgress?.visibility = View.GONE
                    val file = generatedVoiceFile
                    if (file?.exists() == true && file.length() > 0) {
                        voiceStatus?.text = "Audio generated (${file.length() / 1024} KB). Ready to play, save, or share."
                        voicePlaybackButton?.isEnabled = true
                    } else voiceStatus?.text = "The speech engine finished but produced no audio file. Try another installed voice."
                } }
                @Deprecated("Legacy callback") override fun onError(utteranceId: String?) { onError(utteranceId, TextToSpeech.ERROR) }
                override fun onError(utteranceId: String?, errorCode: Int) { runOnUiThread { voiceProgress?.visibility = View.GONE; voiceStatus?.text = "Audio generation failed (engine error $errorCode). Try a different installed voice or shorter text." } }
            })
            populateVoiceLanguages()
        } }
    }

    private fun populateVoiceLanguages() {
        val engine = voiceTts ?: return
        val desired = listOf("English" to listOf(Locale("en", "IN"), Locale.US, Locale.UK), "Hindi" to listOf(Locale("hi", "IN")), "Gujarati" to listOf(Locale("gu", "IN")))
        voiceLanguageOptions.clear()
        desired.forEach { (name, candidates) ->
            val available = candidates.firstOrNull { candidate -> engine.isLanguageAvailable(candidate) >= TextToSpeech.LANG_AVAILABLE }
            if (available != null) voiceLanguageOptions.add(name to available)
        }
        val languageAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, voiceLanguageOptions.map { "${it.first} · ${it.second.toLanguageTag()}" }.ifEmpty { listOf("No supported voice installed") })
        voiceLanguageSpinner?.adapter = languageAdapter
        voiceLanguageSpinner?.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { populateVoiceStyles(position) }
        }
        if (voiceLanguageOptions.isNotEmpty()) { voiceLanguageSpinner?.setSelection(0); voiceStatus?.text = "Device speech engine ready. Languages shown are detected on this device." }
        else voiceStatus?.text = "No Hindi, English, or Gujarati voice is installed. Add a voice in Android Text-to-Speech settings."
    }

    private fun populateVoiceStyles(position: Int) {
        val locale = voiceLanguageOptions.getOrNull(position)?.second ?: return
        val voices = voiceTts?.voices.orEmpty().filter { it.locale.language == locale.language && (it.locale.country.isBlank() || it.locale.country == locale.country) }.sortedBy { it.name }
        voiceChoices.clear(); voiceChoices.add(null); voiceChoices.addAll(voices)
        val labels = listOf("Default device voice") + voices.map { it.name }
        voiceStyleSpinner?.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        voiceStatus?.text = "${voiceLanguageOptions[position].first} available · ${voices.size} installed voice style${if (voices.size == 1) "" else "s"}."
    }

    private fun generateVoiceAudio() {
        val text = voiceTextInput?.text?.toString()?.trim().orEmpty()
        val engine = voiceTts
        if (text.isBlank()) { voiceTextInput?.error = "Enter text to speak"; return }
        if (!voiceTtsReady || engine == null) { voiceStatus?.text = "Speech engine is not ready yet. Please try again."; return }
        val language = voiceLanguageOptions.getOrNull(voiceLanguageSpinner?.selectedItemPosition ?: 0)
        if (language == null) { voiceStatus?.text = "Install a supported voice in Android Text-to-Speech settings first."; return }
        if (text.length > TextToSpeech.getMaxSpeechInputLength()) { voiceTextInput?.error = "This device supports up to ${TextToSpeech.getMaxSpeechInputLength()} characters per generation"; return }
        releaseVoicePreview(); generatedVoiceFile?.delete()
        val directory = File(cacheDir, "voice_generated").apply { mkdirs() }
        val output = File(directory, "hira-narration-${UUID.randomUUID()}.wav")
        generatedVoiceFile = output
        engine.stop()
        engine.setLanguage(language.second)
        engine.setSpeechRate(((voiceRate?.progress ?: 50) + 50) / 100f)
        val selectedVoice = voiceChoices.getOrNull(voiceStyleSpinner?.selectedItemPosition ?: 0)
        if (selectedVoice != null) engine.setVoice(selectedVoice)
        else engine.voices?.firstOrNull { it.locale.language == language.second.language }?.let(engine::setVoice)
        voiceProgress?.visibility = View.VISIBLE; voicePlaybackButton?.isEnabled = false; voiceStatus?.text = "Generating audio with ${language.first} device voice…"
        val id = UUID.randomUUID().toString()
        val result = engine.synthesizeToFile(text, Bundle(), output, id)
        if (result != TextToSpeech.SUCCESS) { voiceProgress?.visibility = View.GONE; voiceStatus?.text = "Could not start speech generation (engine code $result). Try another voice." }
    }

    private fun playGeneratedVoice() {
        val file = generatedVoiceFile?.takeIf { it.exists() && it.length() > 0 } ?: run { info("No audio yet", "Generate narration before previewing it."); return }
        val player = voicePreviewPlayer
        if (player?.isPlaying == true) { player.pause(); voicePlaybackButton?.text = "▶  Resume audio"; return }
        if (player != null) { player.start(); voicePlaybackButton?.text = "Ⅱ  Pause audio"; return }
        try {
            voicePreviewPlayer = MediaPlayer().apply {
                setDataSource(file.absolutePath)
                setOnPreparedListener { it.start(); voicePlaybackButton?.text = "Ⅱ  Pause audio"; voiceStatus?.text = "Playing generated narration…" }
                setOnCompletionListener { voicePlaybackButton?.text = "▶  Play generated audio"; voiceStatus?.text = "Playback complete." }
                setOnErrorListener { _, what, extra -> voiceStatus?.text = "Audio preview failed ($what/$extra). The device voice engine may use an unsupported format."; releaseVoicePreview(); true }
                prepareAsync()
            }
            voiceStatus?.text = "Preparing audio preview…"
        } catch (error: Exception) { voiceStatus?.text = "Preview failed: ${friendlyError(error)}"; releaseVoicePreview() }
    }

    private fun releaseVoicePreview() { try { voicePreviewPlayer?.release() } catch (_: Exception) {}; voicePreviewPlayer = null; voicePlaybackButton?.text = "▶  Play generated audio" }

    private fun saveGeneratedVoice() {
        val file = generatedVoiceFile?.takeIf { it.exists() && it.length() > 0 } ?: run { info("No audio yet", "Generate narration before saving it."); return }
        pendingAudioExportFile = file
        try { startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).setType("audio/wav").addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_TITLE, "hira-narration.wav"), 76) }
        catch (error: Exception) { pendingAudioExportFile = null; info("Save audio", friendlyError(error)) }
    }

    private fun shareVoiceFile(file: File) {
        try {
            val uri = FileProvider.getUriForFile(this, "${this.packageName}.fileprovider", file)
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("audio/wav").putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Share generated narration"))
        } catch (error: Exception) { info("Share audio", friendlyError(error)) }
    }

    private fun chooseVideoForNarration() {
        val file = generatedVoiceFile?.takeIf { it.exists() && it.length() > 0 } ?: run { info("No narration yet", "Generate your narration before adding it to a video."); return }
        pendingNarrationUri = Uri.fromFile(file)
        try { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).setType("video/*").addCategory(Intent.CATEGORY_OPENABLE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION), 77) }
        catch (error: Exception) { pendingNarrationUri = null; info("Choose video", friendlyError(error)) }
    }

    private fun showSubtitleGenerator(uri: Uri? = subtitleVideoUri) {
        stopSubtitleRecognition()
        subtitleVideoUri = uri; subtitleCues.clear(); subtitleRows = null
        selected = "Subtitle Generator"; base(); heading("AI Subtitle Generator", "Transcribe speech from a video you choose")
        content.addView(label("Uses Android's on-device speech recognition, when installed. The recognizer must support audio-file input and word timings; otherwise the app reports that limitation. No speech is sent to Hira Bhai servers. Language packs must be installed on the device.", 13, secondaryText, false).apply { setPadding(0, 0, 0, dp(12)) })
        content.addView(buttonView("Choose video…") { chooseVideoForSubtitles() })
        val selectedLabel = label(uri?.lastPathSegment ?: "No video selected", 13, secondaryText, false).apply { setPadding(0, dp(6), 0, dp(8)) }
        content.addView(selectedLabel)
        val languages = listOf("English · en-US" to "en-US", "Hindi · hi-IN" to "hi-IN", "Gujarati · gu-IN" to "gu-IN")
        val languagePicker = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, languages.map { it.first }) }
        languagePicker.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { subtitleLanguage = languages[position].second }
        }
        content.addView(languagePicker, LinearLayout.LayoutParams(-1, dp(48)))
        subtitleProgress = ProgressBar(this).apply { isIndeterminate = true; visibility = View.GONE }
        content.addView(subtitleProgress, LinearLayout.LayoutParams(dp(32), dp(32)).apply { gravity = Gravity.CENTER_HORIZONTAL })
        subtitleStatus = label("Choose a video to begin.", 13, secondaryText, false).apply { setPadding(0, dp(6), 0, dp(8)) }
        content.addView(subtitleStatus)
        button("Generate subtitles from video audio") { transcribeSelectedVideo() }
        content.addView(buttonView("Use these captions on my next video upload") {
            val srt = buildSrt()
            if (srt.isBlank()) subtitleStatus?.text = "Generate or edit captions before attaching them to a future upload."
            else { pendingUploadCaptionsSrt = srt; pendingUploadCaptionLanguage = subtitleLanguage; subtitleStatus?.text = "Captions are ready. On the next upload, check the optional ‘Attach generated captions’ box." }
        })
        content.addView(buttonView("Attach subtitles to one of my uploaded videos") { chooseOwnedVideoForCaptions() })
        content.addView(buttonView("Save SRT…") { saveSubtitleSrt() })
        subtitleRows = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(subtitleRows)
        addBottom()
        if (uri != null) {
            selectedLabel.text = queryDisplayName(uri) ?: uri.lastPathSegment ?: "Selected video"
            subtitleVideoDurationMs = readVideoDuration(uri)
        }
    }

    private fun chooseVideoForSubtitles() {
        try { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).setType("video/*").addCategory(Intent.CATEGORY_OPENABLE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION), 79) }
        catch (error: Exception) { info("Choose video", friendlyError(error)) }
    }

    private fun readVideoDuration(uri: Uri): Long = try {
        MediaMetadataRetriever().let { retriever -> retriever.setDataSource(this, uri); val duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L; retriever.release(); duration }
    } catch (_: Exception) { 0L }

    private fun queryDisplayName(uri: Uri): String? = try {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(cursor.getColumnIndexOrThrow(android.provider.OpenableColumns.DISPLAY_NAME)) else null
        }
    } catch (_: Exception) { null }

    private fun transcribeSelectedVideo() {
        val uri = subtitleVideoUri ?: run { subtitleStatus?.text = "Choose a video first."; return }
        if (android.os.Build.VERSION.SDK_INT < 34) { subtitleStatus?.text = "Timed on-device captions require Android 14 or newer, including a recognition service that supports audio-file input and word timings."; return }
        if (!SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) { subtitleStatus?.text = "No on-device speech recognition service is installed. Add a compatible Android speech recognition service and language pack, then try again."; return }
        stopSubtitleRecognition(); subtitleCues.clear(); subtitleRows?.removeAllViews()
        subtitleProgress?.visibility = View.VISIBLE; subtitleStatus?.text = "Preparing video audio for on-device recognition…"
        try {
            val pipe = ParcelFileDescriptor.createPipe(); subtitleAudioPipe = pipe
            val recognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(this); subtitleRecognizer = recognizer
            val request = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, subtitleLanguage)
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                .putExtra(RecognizerIntent.EXTRA_SEGMENTED_SESSION, RecognizerIntent.EXTRA_AUDIO_SOURCE)
                .putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE, pipe[0])
                .putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_CHANNEL_COUNT, 1)
                .putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_ENCODING, AudioFormat.ENCODING_PCM_16BIT)
                .putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_SAMPLING_RATE, 16_000)
                .putExtra("android.speech.extra.REQUEST_WORD_TIMING", true)
            recognizer.setRecognitionListener(object : RecognitionListener {
                private val parts = sortedMapOf<Long, String>()
                override fun onReadyForSpeech(params: Bundle?) { subtitleStatus?.text = "Recognizing speech from the selected video's audio…" }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) {
                    closeSubtitlePipe(); subtitleProgress?.visibility = View.GONE
                    subtitleStatus?.text = "Speech recognition could not transcribe this video (error $error). This device's recognition service may not support audio-file input, the language, or word timings."
                    stopSubtitleRecognition(keepStatus = true)
                }
                override fun onResults(results: Bundle?) {
                    collectTimedSpeechParts(results, parts)
                    finishSubtitleRecognition(parts)
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
                override fun onSegmentResults(segmentResults: Bundle) { collectTimedSpeechParts(segmentResults, parts) }
                override fun onEndOfSegmentedSession() { finishSubtitleRecognition(parts) }
            })
            recognizer.startListening(request)
            subtitleDecodeThread = Thread({
                try { decodeVideoAudioToPcm(uri, pipe[1]) }
                catch (error: Exception) { Log.e("HiraBhaiSubtitles", "Audio decoding failed", error); runOnUiThread {
                    if (subtitleRecognizer != null && subtitleProgress?.visibility == View.VISIBLE) {
                        subtitleProgress?.visibility = View.GONE; subtitleStatus?.text = "Could not decode this video's audio: ${friendlyError(error)}"; stopSubtitleRecognition(keepStatus = true)
                    }
                } }
                finally { try { pipe[1].close() } catch (_: Exception) {} }
            }, "hira-subtitle-audio-decoder").apply { start() }
        } catch (error: Exception) {
            subtitleProgress?.visibility = View.GONE; subtitleStatus?.text = "Could not start speech recognition: ${friendlyError(error)}"; stopSubtitleRecognition(keepStatus = true)
        }
    }

    private fun collectTimedSpeechParts(bundle: Bundle?, target: MutableMap<Long, String>) {
        if (bundle == null) return
        val raw = bundle.getParcelableArrayList<android.os.Parcelable>(SpeechRecognizer.RECOGNITION_PARTS).orEmpty()
        raw.filterIsInstance<RecognitionPart>().forEach { part ->
            val text = part.formattedText?.takeIf { it.isNotBlank() } ?: part.rawText
            if (text.isNotBlank()) target[part.timestampMillis] = text
        }
    }

    private fun finishSubtitleRecognition(parts: Map<Long, String>) {
        if (subtitleProgress?.visibility != View.VISIBLE) return
        closeSubtitlePipe(); subtitleProgress?.visibility = View.GONE
        if (parts.isEmpty()) { subtitleStatus?.text = "The recognition service returned no word-level timestamps. No timed captions were created."; stopSubtitleRecognition(keepStatus = true); return }
        val words = parts.entries.sortedBy { it.key }
        if (words.size < 2 || words.last().key <= words.first().key) {
            subtitleStatus?.text = "The recognition service returned words without usable timing information. No timed captions were created."
            stopSubtitleRecognition(keepStatus = true); return
        }
        val grouped = mutableListOf<CaptionCue>(); var start = 0; var collected = mutableListOf<String>()
        fun flush(nextStart: Long) {
            if (collected.isEmpty()) return
            val from = words[start].key.coerceAtLeast(0)
            val to = nextStart.coerceAtLeast(from + 250)
            grouped.add(CaptionCue(from, to, collected.joinToString(" "))); collected = mutableListOf()
        }
        words.forEachIndexed { index, entry ->
            if (collected.isEmpty()) start = index
            collected.add(entry.value)
            if (collected.size >= 7 || entry.value.lastOrNull() in listOf('.', '!', '?', '।', '؟')) flush(words.getOrNull(index + 1)?.key ?: subtitleVideoDurationMs)
        }
        if (collected.isNotEmpty()) flush(subtitleVideoDurationMs.takeIf { it > words.last().key } ?: words.last().key + 1200)
        subtitleCues = grouped
        renderSubtitleRows()
        subtitleStatus?.text = "${grouped.size} timed caption lines recognized in ${subtitleLanguage}. Start times come from speech recognition; check the final line's end time, then edit or save."
        stopSubtitleRecognition(keepStatus = true)
    }

    private fun renderSubtitleRows() {
        val list = subtitleRows ?: return; list.removeAllViews()
        subtitleCues.forEachIndexed { index, cue ->
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = round(Color.WHITE, 14); setPadding(dp(11), dp(9), dp(11), dp(8)); layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) } }
            val times = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val start = field("Start seconds", android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL).apply { setText((cue.startMs / 1000.0).toString()); setSingleLine(true) }
            val end = field("End seconds", android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL).apply { setText((cue.endMs / 1000.0).toString()); setSingleLine(true) }
            times.addView(start, LinearLayout.LayoutParams(0, dp(46), 1f).apply { rightMargin = dp(6) }); times.addView(end, LinearLayout.LayoutParams(0, dp(46), 1f))
            val text = field("Caption text", android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE).apply { minLines = 2; setText(cue.text) }
            start.addTextChangedListener(simpleTextWatcher { cue.startMs = ((start.text.toString().toDoubleOrNull() ?: 0.0) * 1000).toLong().coerceAtLeast(0) })
            end.addTextChangedListener(simpleTextWatcher { cue.endMs = ((end.text.toString().toDoubleOrNull() ?: 0.0) * 1000).toLong().coerceAtLeast(cue.startMs + 100) })
            text.addTextChangedListener(simpleTextWatcher { cue.text = text.text.toString() })
            card.addView(label("Caption ${index + 1}", 12, mint, true)); card.addView(times); card.addView(text); list.addView(card)
        }
    }

    private fun simpleTextWatcher(onChanged: () -> Unit) = object : android.text.TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { onChanged() }
        override fun afterTextChanged(s: android.text.Editable?) {}
    }

    private fun srtTimestamp(ms: Long): String { val safe = ms.coerceAtLeast(0); return String.format(Locale.ROOT, "%02d:%02d:%02d,%03d", safe / 3_600_000, (safe / 60_000) % 60, (safe / 1000) % 60, safe % 1000) }
    private fun buildSrt(): String = subtitleCues.mapIndexedNotNull { index, cue ->
        val text = cue.text.trim(); if (text.isBlank()) null else "${index + 1}\n${srtTimestamp(cue.startMs)} --> ${srtTimestamp(cue.endMs.coerceAtLeast(cue.startMs + 100))}\n$text"
    }.joinToString("\n\n")

    private fun saveSubtitleSrt() {
        val srt = buildSrt(); if (srt.isBlank()) { subtitleStatus?.text = "Generate or enter captions before saving."; return }
        val file = File(cacheDir, "hira_captions_${System.currentTimeMillis()}.srt"); file.writeText(srt, Charsets.UTF_8); pendingSubtitleSave = file
        try { startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).setType("application/x-subrip").addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_TITLE, "hira-captions-${subtitleLanguage}.srt"), 78) }
        catch (error: Exception) { pendingSubtitleSave = null; subtitleStatus?.text = "Could not open the save picker: ${friendlyError(error)}" }
    }

    private fun chooseOwnedVideoForCaptions() {
        val user = FirebaseBackend.auth?.currentUser ?: run { subtitleStatus?.text = "Sign in to attach captions to your uploaded videos."; return }
        if (buildSrt().isBlank()) { subtitleStatus?.text = "Generate or edit captions before attaching them."; return }
        val db = FirebaseBackend.db ?: run { subtitleStatus?.text = "Firestore is not configured."; return }
        db.collection("videos").whereEqualTo("ownerUid", user.uid).limit(100).get()
            .addOnSuccessListener { docs ->
                val videos = docs.documents
                if (videos.isEmpty()) { subtitleStatus?.text = "No uploaded videos were found for this account."; return@addOnSuccessListener }
                AlertDialog.Builder(this).setTitle("Attach captions to video")
                    .setItems(videos.map { it.getString("title") ?: "Video" }.toTypedArray()) { _, which -> videos.getOrNull(which)?.let { uploadCaptionsForVideo(it.id, it.data ?: emptyMap()) } }
                    .setNegativeButton("Cancel", null).show()
            }.addOnFailureListener { subtitleStatus?.text = "Could not load your videos: ${friendlyError(it)}" }
    }

    private fun uploadCaptionsForVideo(videoId: String, video: Map<String, Any>) {
        val uid = FirebaseBackend.auth?.currentUser?.uid ?: return
        val creatorId = video["creatorId"] as? String ?: run { subtitleStatus?.text = "Video creator information is missing."; return }
        if (video["ownerUid"] != uid || FirebaseBackend.storage == null) { subtitleStatus?.text = "Only the video owner can attach captions. Check Firebase Storage setup."; return }
        subtitleProgress?.visibility = View.VISIBLE; subtitleStatus?.text = "Uploading caption file securely…"
        uploadCaptionAsset(videoId, video["storagePath"].toString().substringBeforeLast('/'), video["visibility"] as? String ?: "public", creatorId, subtitleLanguage, buildSrt(), subtitleCues.size,
            onSuccess = { subtitleProgress?.visibility = View.GONE; subtitleStatus?.text = "Captions attached to this video. Viewers can choose the caption language and turn captions on." },
            onFailure = { message -> subtitleProgress?.visibility = View.GONE; subtitleStatus?.text = message })
    }

    private fun uploadCaptionAsset(videoId: String, basePath: String, visibility: String, creatorId: String, language: String, srt: String, cueCount: Int, onSuccess: () -> Unit, onFailure: (String) -> Unit) {
        val storage = FirebaseBackend.storage ?: run { onFailure("Firebase Storage is not configured."); return }
        val db = FirebaseBackend.db ?: run { onFailure("Firestore is not configured."); return }
        val key = language.replace('-', '_'); val path = "$basePath/captions_${key}.srt"
        storage.reference.child(path).putBytes(srt.toByteArray(Charsets.UTF_8), com.google.firebase.storage.StorageMetadata.Builder().setContentType("application/x-subrip").build())
            .addOnSuccessListener {
                db.collection("videos").document(videoId).collection("captions").document(key)
                    .set(mapOf("language" to language, "storagePath" to path, "creatorId" to creatorId, "cueCount" to cueCount, "updatedAt" to FieldValue.serverTimestamp()))
                    .addOnSuccessListener { onSuccess() }
                    .addOnFailureListener { error -> storage.reference.child(path).delete(); onFailure("Caption file uploaded but Firestore rejected its metadata: ${friendlyError(error)}. Publish the updated Firestore rules.") }
            }.addOnFailureListener { onFailure("Caption upload failed: ${friendlyError(it)}. Publish the updated Storage rules if caption writes are denied.") }
    }

    private fun closeSubtitlePipe() { subtitleAudioPipe?.forEach { try { it.close() } catch (_: Exception) {} }; subtitleAudioPipe = null }
    private fun stopSubtitleRecognition(keepStatus: Boolean = false) {
        try { subtitleRecognizer?.cancel(); subtitleRecognizer?.destroy() } catch (_: Exception) {}; subtitleRecognizer = null
        closeSubtitlePipe(); subtitleDecodeThread?.interrupt(); subtitleDecodeThread = null
        if (!keepStatus) subtitleProgress?.visibility = View.GONE
    }

    private fun decodeVideoAudioToPcm(uri: Uri, outputFd: ParcelFileDescriptor) {
        val extractor = MediaExtractor(); var decoder: MediaCodec? = null
        try { ParcelFileDescriptor.AutoCloseOutputStream(outputFd).use { stream ->
            extractor.setDataSource(this, uri, null)
            val audioTrack = (0 until extractor.trackCount).firstOrNull { extractor.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true }
                ?: throw IllegalArgumentException("No audio track found")
            extractor.selectTrack(audioTrack); val format = extractor.getTrackFormat(audioTrack); val mime = format.getString(MediaFormat.KEY_MIME) ?: throw IllegalArgumentException("Unknown audio codec")
            decoder = MediaCodec.createDecoderByType(mime).apply { configure(format, null, null, 0); start() }
            val codec = decoder!!; val info = MediaCodec.BufferInfo(); val inputTimeout = 10_000L
            var inputEnded = false; var outputEnded = false; var sampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE); var channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT); var rateAccumulator = 0
            var lastProgress = -1L
            while (!outputEnded && !Thread.currentThread().isInterrupted) {
                if (!inputEnded) {
                    val inputIndex = codec.dequeueInputBuffer(inputTimeout)
                    if (inputIndex >= 0) {
                        val input = codec.getInputBuffer(inputIndex) ?: continue; input.clear()
                        val sampleSize = extractor.readSampleData(input, 0)
                        if (sampleSize < 0) { codec.queueInputBuffer(inputIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inputEnded = true }
                        else { val time = extractor.sampleTime; codec.queueInputBuffer(inputIndex, 0, sampleSize, time, 0); extractor.advance() }
                    }
                }
                val outputIndex = codec.dequeueOutputBuffer(info, inputTimeout)
                if (outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val outFormat = codec.outputFormat; sampleRate = outFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE); channels = outFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                } else if (outputIndex >= 0) {
                    val buffer = codec.getOutputBuffer(outputIndex)
                    if (buffer != null && info.size > 0) {
                        buffer.position(info.offset); buffer.limit(info.offset + info.size); val pcm = buffer.slice().order(java.nio.ByteOrder.LITTLE_ENDIAN)
                        val frames = pcm.remaining() / (2 * channels); val out = ByteArrayOutputStream()
                        repeat(frames) { frame ->
                            var sum = 0; repeat(channels) { channel -> sum += pcm.getShort((frame * channels + channel) * 2).toInt() }
                            rateAccumulator += 16_000
                            if (rateAccumulator >= sampleRate) { rateAccumulator -= sampleRate; val mono = (sum / channels).coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()); out.write(mono and 0xff); out.write((mono shr 8) and 0xff) }
                        }
                        if (out.size() > 0) stream.write(out.toByteArray())
                        val currentMs = info.presentationTimeUs / 1000
                        if (currentMs - lastProgress >= 5000) { lastProgress = currentMs; runOnUiThread { subtitleStatus?.text = "Reading video audio… ${formatDuration(currentMs)}" } }
                    }
                    outputEnded = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                    codec.releaseOutputBuffer(outputIndex, false)
                }
            }
            stream.flush()
        } } finally {
            try { decoder?.stop() } catch (_: Exception) {}
            try { decoder?.release() } catch (_: Exception) {}
            try { extractor.release() } catch (_: Exception) {}
        }
    }

    @OptIn(PublicPreviewAPI::class)
    private fun generateAiStudioText() {
        val topic = contentStudioPrompt?.text?.toString()?.trim().orEmpty()
        if (topic.isBlank()) { contentStudioPrompt?.error = "Add a topic first"; return }
        if (topic.length > 4000) { contentStudioPrompt?.error = "Keep details under 4,000 characters"; return }
        val taskInstruction = when (contentStudioTask) {
            "Video titles" -> "Write 10 distinct, engaging YouTube video title options. Avoid misleading clickbait."
            "Description" -> "Write a polished YouTube video description with a concise opening, useful details, and a natural call to action."
            "Video script" -> "Write a clear, engaging video script with a hook, organized sections, and a concise ending."
            "Thumbnail ideas" -> "Give 5 specific thumbnail concepts, each with subject, composition, color, and short optional overlay text."
            "Social caption" -> "Write 5 social media caption options, with varied tones and a natural call to action."
            "Hashtags" -> "Suggest relevant, non-spammy hashtags grouped by broad and topic-specific tags."
            else -> "Suggest 10 original, practical content ideas, each with a one-line angle."
        }
        contentStudioProgress?.visibility = View.VISIBLE
        contentStudioResult?.text = "Creating ${contentStudioTask.lowercase()}…"
        aiScope.launch {
            try {
                val model = Firebase.ai(backend = GenerativeBackend.googleAI(), useLimitedUseAppCheckTokens = true)
                    .generativeModel(
                        modelName = "gemini-3.8-flash",
                        systemInstruction = content { text("You are Hira Bhai AI, a helpful creator assistant. Use the same language as the user's topic. Produce original and practical content. Do not claim you published or uploaded anything.") }
                    )
                val response = model.generateContent("$taskInstruction\n\nTopic and context:\n$topic")
                contentStudioResult?.text = response.text?.takeIf { it.isNotBlank() } ?: "The model returned no text. Try adding more detail."
            } catch (error: Exception) {
                Log.e("HiraBhaiContentStudio", "Content generation failed: uid=${FirebaseBackend.auth?.currentUser?.uid} task=$contentStudioTask", error)
                contentStudioResult?.text = "Generation failed: ${friendlyError(error)}. Check that Firebase AI Logic is enabled for this project."
            } finally { contentStudioProgress?.visibility = View.GONE }
        }
    }

    private fun findSubscribedCreator(creatorId: String) {
        FirebaseBackend.db?.collection("publicProfiles")?.whereEqualTo("creatorId", creatorId)?.limit(1)?.get()
            ?.addOnSuccessListener { matches ->
                val creator = matches.documents.firstOrNull() ?: return@addOnSuccessListener
                addSubscribedCreatorCard(content, creator.data ?: emptyMap())
            }
    }

    private fun loadUserSubscriptions(target: LinearLayout, uid: String) {
        val db = FirebaseBackend.db ?: run {
            target.addView(label("Subscriptions are unavailable because Firestore is not configured.", 13, secondaryText, false))
            return
        }
        val status = label("Loading subscriptions…", 13, secondaryText, false).apply { setPadding(0, 0, 0, dp(8)) }
        target.addView(status)
        db.collection("subscriptions").document(uid).collection("creators").get()
            .addOnSuccessListener { records ->
                if (records.isEmpty) status.text = "You have not subscribed to any creators yet."
                else {
                    status.text = ""
                    records.documents.forEach { record ->
                        val username = record.getString("creatorUsername") ?: return@forEach
                        db.collection("publicProfiles").document(username).get()
                            .addOnSuccessListener { profile ->
                                if (profile.exists() && profile.getString("creatorId") == record.id) {
                                    addSubscribedCreatorCard(target, profile.data ?: emptyMap())
                                }
                            }
                    }
                }
            }
            .addOnFailureListener { status.text = "Could not load subscriptions: ${friendlyError(it)}" }
    }

    private fun addSubscribedCreatorCard(target: LinearLayout, profile: Map<String, Any>) {
        val username = profile["username"] as? String ?: return
        val creatorId = profile["creatorId"] as? String ?: return
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = round(Color.WHITE, 16)
            setPadding(dp(12), dp(11), dp(12), dp(11))
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            isClickable = true; isFocusable = true; setOnClickListener { showPublicProfile(profile) }
        }
        val avatar = ImageView(this).apply {
            setImageResource(android.R.drawable.ic_menu_camera); scaleType = ImageView.ScaleType.CENTER_CROP
            background = round(0xffdce8ed.toInt(), 100); clipToOutline = true
            layoutParams = LinearLayout.LayoutParams(dp(42), dp(42)).apply { rightMargin = dp(10) }
        }
        (profile["photoData"] as? String)?.let { showProfilePhoto(it, avatar) }
        val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        details.addView(label(profile["fullName"] as? String ?: username, 15, primaryText, true))
        details.addView(label("@$username", 12, secondaryText, false).apply { setPadding(0, dp(2), 0, 0) })
        row.addView(avatar); row.addView(details, LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(row)
        val count = label("Loading subscriber count…", 12, secondaryText, false).apply { setPadding(dp(52), dp(5), 0, dp(2)) }
        card.addView(count)
        FirebaseBackend.db?.collection("creatorStats")?.document(creatorId)?.get()
            ?.addOnSuccessListener { stats ->
                val total = (stats.getLong("subscriberCount") ?: 0L).coerceAtLeast(0L)
                count.text = "$total ${if (total == 1L) "subscriber" else "subscribers"}"
            }
            ?.addOnFailureListener { count.text = "Subscriber count unavailable" }
        addSearchSubscriptionButton(card, username, creatorId, count)
        target.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
    }

    private fun showSubscriptionTest() {
        selected = "Create"; base()
        heading("Developer Testing Mode", "Subscription Test")
        val warning = label("TEST DATA ONLY · Writes go to subscriptionTests and subscriptionTestStats. Production subscriptions and subscriber counts are not changed.", 14, 0xff8b5810.toInt(), true).apply {
            background = round(0xfffff1d6.toInt(), 16); setPadding(dp(14), dp(14), dp(14), dp(14))
        }
        content.addView(warning, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        val user = FirebaseBackend.auth?.currentUser
        if (user == null) {
            action("Sign in required", "Use your existing Firebase account. Test mode does not bypass authentication.") { showAuth(false) }
            addBottom(); return
        }
        content.addView(label("Signed in as ${user.email ?: user.uid}", 13, secondaryText, false).apply { setPadding(0, 0, 0, dp(12)) })
        val username = field("Creator username to test", android.text.InputType.TYPE_CLASS_TEXT)
        username.setText("@")
        content.addView(username)
        val feedback = label("Enter a public creator username to test a sandbox subscribe/unsubscribe.", 13, secondaryText, false)
        content.addView(feedback)
        button("Load test target") {
            val handle = username.text.toString().trim().removePrefix("@").lowercase()
            if (!Regex("^[a-z0-9_]{3,24}$").matches(handle)) { username.error = "Enter a valid creator username"; return@button }
            val db = FirebaseBackend.db
            if (db == null) { feedback.text = "Firebase is unavailable; no test operation was attempted."; return@button }
            feedback.text = "Checking the public creator profile…"
            db.collection("publicProfiles").document(handle).get()
                .addOnSuccessListener { creator ->
                    val creatorId = creator.getString("creatorId")
                    if (!creator.exists() || creatorId == null) { feedback.text = "No compatible public creator profile found for @$handle."; return@addOnSuccessListener }
                    db.collection("profiles").document(user.uid).get()
                        .addOnSuccessListener { ownProfile ->
                            if (!ownProfile.exists()) { feedback.text = "Create your Hira Bhai creator profile first. Test mode requires the authenticated account’s profile and Firestore rules."; return@addOnSuccessListener }
                            if (ownProfile.getString("creatorId") == creatorId) { feedback.text = "Self-subscription test is blocked."; return@addOnSuccessListener }
                            renderSubscriptionTestTarget(user.uid, handle, creatorId, creator.getString("fullName") ?: handle, feedback)
                        }
                        .addOnFailureListener { feedback.text = "Could not validate your profile: ${friendlyError(it)}" }
                }
                .addOnFailureListener { feedback.text = "Could not load target: ${friendlyError(it)}" }
        }
        val recordHeading = label("Your isolated test records", 18, primaryText, true).apply { setPadding(0, dp(18), 0, dp(6)) }
        content.addView(recordHeading)
        val records = label("Loading test records…", 13, secondaryText, false)
        content.addView(records)
        subscriptionTestRecordsView = records
        refreshSubscriptionTestRecords(user.uid, records)
        addBottom()
    }

    private fun renderSubscriptionTestTarget(uid: String, username: String, creatorId: String, displayName: String, feedback: TextView) {
        val db = FirebaseBackend.db ?: return
        feedback.text = "Test target: $displayName (@$username)"
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = round(Color.WHITE, 18); setPadding(dp(16), dp(15), dp(16), dp(15)) }
        card.addView(label("Sandbox creator: @$username", 17, primaryText, true))
        val count = label("Loading test subscriber count…", 13, secondaryText, false).apply { setPadding(0, dp(6), 0, dp(6)) }
        card.addView(count)
        val recordState = label("Checking your test record…", 13, secondaryText, false)
        card.addView(recordState)
        content.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8); bottomMargin = dp(10) })
        val edge = db.collection("subscriptionTests").document(uid).collection("creators").document(creatorId)
        val stats = db.collection("subscriptionTestStats").document(creatorId)
        val toggle = TextView(this).apply {
            textSize = 15f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setTextColor(Color.WHITE); background = round(mint, 16)
            setPadding(dp(14), dp(14), dp(14), dp(14)); isClickable = true; isFocusable = true; isEnabled = false
        }
        content.addView(toggle, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        fun refresh() {
            edge.get().addOnSuccessListener { saved ->
                val active = saved.exists()
                toggle.text = if (active) "Unsubscribe · TEST ONLY" else "Subscribe · TEST ONLY"
                toggle.isEnabled = true
                recordState.text = if (active) "Test subscription record exists for your account." else "No test subscription record for your account."
            }.addOnFailureListener { recordState.text = "Record read failed: ${friendlyError(it)}"; toggle.isEnabled = false }
            stats.get().addOnSuccessListener { snapshot ->
                val total = (snapshot.getLong("subscriberCount") ?: 0L).coerceAtLeast(0L)
                count.text = "$total test subscriber${if (total == 1L) "" else "s"} · isolated test count"
            }.addOnFailureListener { count.text = "Test count read failed: ${friendlyError(it)}" }
        }
        toggle.setOnClickListener {
            toggle.isEnabled = false
            db.runTransaction { tx ->
                val existing = tx.get(edge)
                val currentStats = tx.get(stats)
                val total = (currentStats.getLong("subscriberCount") ?: 0L).coerceAtLeast(0L)
                if (existing.exists()) {
                    tx.delete(edge)
                    if (currentStats.exists()) tx.update(stats, "subscriberCount", (total - 1).coerceAtLeast(0L))
                    false to (total - 1).coerceAtLeast(0L)
                } else {
                    tx.set(edge, mapOf("testerUid" to uid, "creatorId" to creatorId, "creatorUsername" to username, "createdAt" to FieldValue.serverTimestamp()))
                    tx.set(stats, mapOf("creatorId" to creatorId, "subscriberCount" to total + 1))
                    true to (total + 1)
                }
            }.addOnSuccessListener { result ->
                val added = result.first
                val expectedCount = result.second
                // Read the written edge and count back before reporting verification.
                edge.get().addOnSuccessListener { saved ->
                    stats.get().addOnSuccessListener { updatedStats ->
                        val actualCount = (updatedStats.getLong("subscriberCount") ?: 0L).coerceAtLeast(0L)
                        val verified = saved.exists() == added && updatedStats.exists() && actualCount == expectedCount
                        feedback.text = if (verified) "Verified Firestore ${if (added) "subscribe" else "unsubscribe"} write and count update ($actualCount)." else "Write completed, but read-back verification did not match the expected count."
                        refresh(); refreshSubscriptionTestRecords(uid, subscriptionTestRecordsView)
                    }.addOnFailureListener { feedback.text = "Write completed; count read-back failed: ${friendlyError(it)}"; refresh() }
                }.addOnFailureListener { feedback.text = "Write completed; record read-back failed: ${friendlyError(it)}"; refresh() }
            }.addOnFailureListener { failure -> toggle.isEnabled = true; feedback.text = "Firestore rejected the test operation: ${friendlyError(failure)}"; refresh() }
        }
        refresh()
    }

    private fun refreshSubscriptionTestRecords(uid: String, target: TextView?) {
        if (target == null) return
        FirebaseBackend.db?.collection("subscriptionTests")?.document(uid)?.collection("creators")?.get()
            ?.addOnSuccessListener { result ->
                target.text = if (result.isEmpty) "No isolated test records yet." else result.documents.joinToString("\n") { doc ->
                    "@${doc.getString("creatorUsername") ?: "unknown"} · ${doc.id.take(8)} · test record"
                }
            }
            ?.addOnFailureListener { target.text = "Could not read test records: ${friendlyError(it)}" }
    }

    private fun featureTile(title:String,sub:String,emoji:String) { val card=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; background=round(Color.WHITE,24); setPadding(dp(22),dp(30),dp(22),dp(30)) }; card.addView(label(emoji,42,mint,true)); card.addView(label(title,20,primaryText,true).apply { gravity=Gravity.CENTER; setPadding(0,dp(12),0,dp(5)) }); card.addView(label(sub,14,secondaryText,false).apply { gravity=Gravity.CENTER }); content.addView(card) }
    private fun action(text:String,sub:String,click:()->Unit = { info(text,"This is a preview flow in the Hira Bhai prototype.") }) { val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; background=round(Color.WHITE,18); setPadding(dp(16),dp(15),dp(16),dp(15)); isClickable=true; isFocusable=true; setOnClickListener { click() } }; box.addView(label(text,17,primaryText,true)); box.addView(label(sub,13,secondaryText,false).apply { setPadding(0,dp(5),0,0) }); content.addView(box,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(10) }) }
    private fun addBottom() {
        val homeTheme = selected == "Home"
        bottomBar?.animate()?.cancel()
        val bar=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; background=android.graphics.drawable.ColorDrawable(Color.TRANSPARENT); setPadding(dp(4),dp(6),dp(4),dp(6)) }
        val allItems = listOf(AppFeature("Home", "⌂"), AppFeature("Create", "+"), AppFeature("Notifications", "🔔")) + appFeatures()
        val activeItem = currentNavFeature(allItems)
        val navItems = allItems.filterNot { it.title == activeItem.title }
        navItems.forEach { item ->
            val name = item.title
            val btn=LinearLayout(this).apply {
                orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER
                setPadding(dp(2),dp(4),dp(2),dp(4)); isClickable=true; isFocusable=true
                contentDescription=name
                setOnClickListener { when(name) { "Home", "Home Feed" -> showHome(); "Create" -> showUploadOptions(); "Notifications" -> showNotifications(); else -> openAppFeature(name) } }
            }
            val glyph=TextView(this).apply {
                text=item.icon; textSize=if(name=="Create")23f else 21f; gravity=Gravity.CENTER
                typeface=Typeface.create("sans-serif-medium",Typeface.NORMAL)
                setTextColor(Color.WHITE)
                background = when {
                    name == "Create" -> glass(if (homeTheme) 0xcc168fce.toInt() else 0xcc23a48f.toInt(), 100)
                    else -> glass(0x28ffffff, 100)
                }
                layoutParams=LinearLayout.LayoutParams(dp(36),dp(34))
            }
            val caption=TextView(this).apply {
                text=featureCaption(name); textSize=9f; gravity=Gravity.CENTER; maxLines=1
                ellipsize=android.text.TextUtils.TruncateAt.END
                setTextColor(Color.WHITE)
                typeface=Typeface.create("sans-serif-medium",Typeface.NORMAL)
                setPadding(0,dp(4),0,0)
            }
            if (name == "Notifications") attachUnreadBadge(glyph)
            btn.addView(glyph); btn.addView(caption)
            bar.addView(btn,LinearLayout.LayoutParams(dp(72),-2))
        }
        val navShell = FrameLayout(this).apply {
            background = glass(if (homeTheme) 0x493b8e84 else 0x35ffffff, 34)
            clipToOutline = true
            minimumHeight = dp(78)
        }
        val horizontalNav = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            isFillViewport = false
            clipToPadding = true
            clipChildren = true
            setPadding(dp(2), 0, dp(6), 0)
            addView(bar, ViewGroup.LayoutParams(-2, -1))
        }
        navShell.addView(horizontalNav, FrameLayout.LayoutParams(-1, -1).apply { leftMargin = dp(82); rightMargin = dp(4) })
        val activeGlyph = TextView(this).apply {
            text = activeItem.icon; textSize = 22f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            background = glass(0xcc23a48f.toInt(), 100)
            layoutParams = LinearLayout.LayoutParams(dp(38), dp(36))
        }
        if (activeItem.title == "Notifications") attachUnreadBadge(activeGlyph)
        val activeCaption = TextView(this).apply {
            text = featureCaption(activeItem.title); textSize = 9f; gravity = Gravity.CENTER; maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END; setTextColor(0xffa4f0df.toInt())
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD); setPadding(0, dp(4), 0, 0)
        }
        val pinnedFeature = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(2), dp(4), dp(2), dp(4))
            contentDescription = "Current feature: ${activeItem.title}"
            addView(activeGlyph); addView(activeCaption)
        }
        navShell.addView(pinnedFeature, FrameLayout.LayoutParams(dp(76), -1, Gravity.START or Gravity.CENTER_VERTICAL).apply { leftMargin = dp(4) })
        val mini = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = if (homeTheme) glass(0xd9366682.toInt(), 18) else round(0xffe8f2f5.toInt(), 18)
            setPadding(dp(12), dp(7), dp(12), dp(7)); isClickable = true
            setOnClickListener { showMusicPlayer() }
        }
        val miniTitle = label("♫  Music player", 13, if (homeTheme) Color.WHITE else primaryText, true).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        mini.addView(miniTitle, LinearLayout.LayoutParams(0, -2, 1f))
        val miniPlay = TextView(this).apply {
            text = "▶"; textSize = 18f; gravity = Gravity.CENTER; setTextColor(if (homeTheme) Color.WHITE else mint)
            setPadding(dp(10), 0, dp(4), 0); isClickable = true
            setOnClickListener { musicController?.let { player -> if (player.isPlaying) player.pause() else player.play(); refreshMusicMini() } }
        }
        mini.addView(miniPlay)
        musicMiniTitle = miniTitle; musicMiniPlay = miniPlay; musicMiniContainer = mini
        root.addView(mini, LinearLayout.LayoutParams(-1, -2).apply { leftMargin = dp(12); rightMargin = dp(12); bottomMargin = dp(5) })
        refreshMusicMini()
        bottomBar = horizontalNav
        root.addView(navShell,LinearLayout.LayoutParams(-1,dp(78)).apply { leftMargin=dp(8); rightMargin=dp(8); bottomMargin=dp(7) })
        bottomBar = navShell
        displayedSelected = selected
    }

    private fun currentNavFeature(items: List<AppFeature>): AppFeature {
        val titleAlias = when (displayedTitle.lowercase(Locale.ROOT)) {
            "watch later" -> "Watch Later"
            "watch history" -> "Watch History"
            "search creators" -> "Creator Search"
            "search videos", "video search" -> "Video Search"
            "creator profile" -> "Creator Profile"
            "ai subtitle generator" -> "Subtitle Generator"
            "website builder", "creator website" -> "Creator Website"
            "creator dashboard" -> "Creator Dashboard"
            "creator monetization" -> "Creator Monetization"
            "your audio favorites", "music" -> "Music Player"
            "settings & privacy" -> "Settings & Privacy"
            "search videos and creators" -> "Search videos and creators"
            "all features" -> "More"
            else -> selected
        }
        return items.firstOrNull { it.title == titleAlias }
            ?: AppFeature(displayedTitle.ifBlank { selected }, when (titleAlias) {
                "More" -> "▦"; "Library" -> "▤"; "Playlists" -> "▧"; "Website Builder" -> "⌘"; else -> "✦"
            })
    }

    private fun featureCaption(name: String): String = when (name) {
        "AI Assistant" -> "AI Chat"; "AI App Builder" -> "App Builder"; "AI Image Generator" -> "AI Image"; "AI Content Studio" -> "AI Studio"; "AI Voice Generator" -> "AI Voice"
        "Subtitle Generator" -> "Captions"; "AI Video Generator" -> "AI Video"; "Hira Bhai Studio" -> "Studio"; "Creator Dashboard" -> "Dashboard"; "Creator Monetization" -> "Earnings"
        "Creator Website" -> "Website"; "Creator Profile" -> "Profile"; "Upload Document" -> "Document"; "Upload Any File" -> "Any File"; "File Manager" -> "Files"
        "Settings & Privacy" -> "Settings"; "Search videos and creators" -> "Search"; "Create Community Post" -> "Create Post"; "Watch History" -> "History"
        "Watch Later" -> "Watch Later"; "Subscriptions" -> "Subs"; "Community Feed" -> "Community"; "Upload Audio" -> "Audio"; "Upload Short" -> "Short"
        "Creator Search" -> "Creators"; "More" -> "Features"; "Library" -> "Library"; "Playlists" -> "Playlists"; "Website Builder" -> "Website"
        else -> name
    }

    private data class AppFeature(val title: String, val icon: String)

    private fun appFeatures() = listOf(
        AppFeature("Video Search", "⌕"), AppFeature("Creator Search", "◉"), AppFeature("Music Player", "♫"), AppFeature("Upload Audio", "♫"),
        AppFeature("Shorts", "▷"), AppFeature("Upload Short", "⬆"), AppFeature("Subscriptions", "♡"), AppFeature("Library", "▤"),
        AppFeature("Watch History", "◷"), AppFeature("Watch Later", "＋"), AppFeature("Playlists", "▤"),
        AppFeature("Community Feed", "▤"), AppFeature("Create Community Post", "✎"),
        AppFeature("AI Assistant", "✦"), AppFeature("AI App Builder", "✧"), AppFeature("AI Image Generator", "▧"), AppFeature("AI Content Studio", "✎"), AppFeature("AI Voice Generator", "♫"),
        AppFeature("Subtitle Generator", "▤"),
        AppFeature("AI Video Generator", "▶"), AppFeature("Hira Bhai Studio", "✂"), AppFeature("Creator Dashboard", "▥"),
        AppFeature("Creator Monetization", "₹"), AppFeature("Admin Panel", "⚑"), AppFeature("Creator Website", "⌘"), AppFeature("Creator Profile", "◉"),
        AppFeature("Upload Video", "⬆"), AppFeature("Upload Image", "▧"), AppFeature("Upload Document", "▤"),
        AppFeature("Upload Any File", "＋"), AppFeature("File Manager", "▣"), AppFeature("Go Live", "●"),
        AppFeature("Settings & Privacy", "⚙"), AppFeature("Search videos and creators", "⌕")
    )

    private fun showFeatureHub() {
        selected = "More"; base(); heading("All features", "Your Hira Bhai tools, together")
        content.addView(label("Open a feature below. New app features will be added to this menu.", 13, secondaryText, false).apply { setPadding(0, 0, 0, dp(12)) })
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(grid)
        var row: LinearLayout? = null
        appFeatures().forEachIndexed { index, feature ->
            if (index % 2 == 0) {
                row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                grid.addView(row)
            }
            val tile = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; background = round(Color.WHITE, 18)
                setPadding(dp(8), dp(13), dp(8), dp(13)); isClickable = true; isFocusable = true
                contentDescription = feature.title
                setOnClickListener { openAppFeature(feature.title) }
            }
            tile.addView(label(feature.icon, 26, mint, true).apply { gravity = Gravity.CENTER })
            tile.addView(label(feature.title, 12, primaryText, true).apply { gravity = Gravity.CENTER; maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END; setPadding(0, dp(5), 0, 0) })
            row?.addView(tile, LinearLayout.LayoutParams(0, dp(84), 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
        }
        addBottom()
    }

    private fun openAppFeature(name: String) {
        when (name) {
            "Home Feed" -> showHome()
            "Video Search" -> showVideoSearch("")
            "Music Player" -> showMusicDiscovery("")
            "Upload Audio" -> chooseAudioUpload()
            "Creator Search" -> showCreatorSearch("")
            "Shorts", "Subscriptions", "Library" -> showSection(name)
            "Watch History" -> showWatchHistory()
            "Watch Later" -> showWatchLater()
            "Playlists" -> showPlaylists()
            "Community Feed" -> showCommunityFeed()
            "Create Community Post" -> showCommunityPostComposer()
            "AI Assistant" -> showAiAssistant()
            "AI App Builder" -> showAiAppBuilder()
            "AI Image Generator" -> showAiImageGenerator()
            "AI Content Studio" -> showAiContentStudio()
            "AI Voice Generator" -> showAiVoiceGenerator()
            "Subtitle Generator" -> showSubtitleGenerator()
            "AI Video Generator" -> showAiVideoGenerator()
            "Hira Bhai Studio" -> chooseVideoForEditing()
            "Creator Dashboard" -> showCreatorDashboard()
            "Creator Monetization" -> openCreatorMonetization()
            "Admin Panel" -> showAdminPanel()
            "Creator Website" -> websiteDialog()
            "Creator Profile" -> showAccount()
            "Upload Video" -> chooseVideoUpload()
            "Upload Short" -> chooseShortUpload()
            "Upload Image" -> chooseImageForUpload()
            "Upload Document" -> chooseDocumentForUpload()
            "Upload Any File" -> pickMedia()
            "File Manager" -> startActivity(Intent(this, FileManagerActivity::class.java))
            "Go Live" -> showUploadOptions(openLive = true)
            "Settings & Privacy" -> showSettings()
            "Search videos and creators" -> showProfileLookup()
        }
    }

    private fun openCreatorMonetization() {
        val user = FirebaseBackend.auth?.currentUser ?: run { showAuth(false); return }
        val db = FirebaseBackend.db ?: run { info("Monetization unavailable", "Connect Firestore to open creator earnings."); return }
        db.collection("profiles").document(user.uid).get().addOnSuccessListener { profile ->
            val creatorId = profile.getString("creatorId")
            if (creatorId.isNullOrBlank()) { info("Creator profile needed", "Set up a creator profile before opening monetization."); showProfileEditor() }
            else showCreatorMonetization(creatorId)
        }.addOnFailureListener { info("Monetization unavailable", friendlyError(it)) }
    }

    private fun showReportDialog(type: String, targetId: String, videoId: String = "", commentId: String = "") {
        val user = FirebaseBackend.auth?.currentUser ?: run { showAuth(false); return }
        val reasons = listOf("harassment" to "Harassment or bullying", "hate" to "Hateful content", "sexual" to "Sexual content", "violence" to "Violence or dangerous activity", "spam" to "Spam or misleading", "copyright" to "Copyright concern", "other" to "Other policy concern")
        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(8), dp(18), 0) }
        val reasonGroup = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        reasons.forEachIndexed { index, (key, title) ->
            val option = RadioButton(this).apply { text = title; tag = key; id = View.generateViewId() }
            reasonGroup.addView(option); if (index == 0) reasonGroup.check(option.id)
        }
        form.addView(reasonGroup)
        val details = EditText(this).apply { hint = "Optional details (up to 500 characters)"; minLines = 2; maxLines = 4; gravity = Gravity.TOP; filters = arrayOf(android.text.InputFilter.LengthFilter(500)) }
        form.addView(details)
        AlertDialog.Builder(this).setTitle("Report ${if (type == "user") "creator" else type}")
            .setMessage("Reports are reviewed by Hira Bhai moderators. Please report content that violates platform rules.")
            .setView(form).setNegativeButton("Cancel", null).setPositiveButton("Send report", null)
            .create().also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val reason = reasonGroup.findViewById<RadioButton>(reasonGroup.checkedRadioButtonId)?.tag as? String
                        if (reason.isNullOrBlank()) { info("Choose a reason", "Select the closest report reason."); return@setOnClickListener }
                        val projectId = try { com.google.firebase.FirebaseApp.getInstance().options.projectId } catch (_: Exception) { null }
                        if (projectId.isNullOrBlank()) { info("Report unavailable", "Firebase Functions are not configured."); return@setOnClickListener }
                        val request = JSONObject().put("type", type).put("targetId", targetId).put("reason", reason).put("details", details.text.toString())
                        if (videoId.isNotBlank()) request.put("videoId", videoId)
                        if (commentId.isNotBlank()) request.put("commentId", commentId)
                        dialog.dismiss(); setBusy(true)
                        aiScope.launch {
                            try {
                                val token = user.getIdToken(false).await().token.orEmpty()
                                val response = withContext(Dispatchers.IO) { postPaymentFunction(projectId, "submitContentReport", token, request) }
                                info("Report submitted", response.optString("message", "The moderation team will review your report."))
                            } catch (error: Exception) { info("Report not sent", error.message ?: friendlyError(error)) }
                            finally { setBusy(false) }
                        }
                    }
                }
                dialog.show()
            }
    }

    private fun showAdminPanel() {
        val user = FirebaseBackend.auth?.currentUser ?: run { showAuth(false); return }
        selected = "Admin Panel"; base(); heading("Admin dashboard", "Platform moderation")
        val status = label("Verifying administrator access…", 14, secondaryText, false); content.addView(status); addBottom()
        aiScope.launch {
            try {
                val projectId = com.google.firebase.FirebaseApp.getInstance().options.projectId ?: throw IllegalStateException("Firebase project is not configured.")
                // The callable endpoint is the authority: it verifies the server-issued
                // platformAdmin custom claim on the Firebase ID token for every request.
                val token = user.getIdToken(true).await().token.orEmpty()
                val result = withContext(Dispatchers.IO) { postPaymentFunction(projectId, "adminModeration", token, JSONObject().put("mode", "dashboard")) }
                renderAdminDashboard(result)
            } catch (error: Exception) { status.text = "Admin dashboard unavailable: ${error.message ?: friendlyError(error)}" }
        }
    }

    private fun renderAdminDashboard(data: JSONObject) {
        selected = "Admin Panel"; base(); heading("Admin dashboard", "Verified administrator · moderation controls")
        val metrics = listOf("Total users" to data.optLong("users"), "Creators" to data.optLong("creators"), "Videos" to data.optLong("videos"), "Open reports" to data.optLong("openReports"), "All reports" to data.optLong("totalReports"))
        metrics.forEach { (name, count) -> content.addView(label("$name  ·  $count", 16, primaryText, true).apply { background = round(Color.WHITE, 14); setPadding(dp(14), dp(12), dp(14), dp(12)); layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) } }) }
        section("Platform activity · recent moderation")
        val activity = data.optJSONArray("activity") ?: JSONArray()
        if (activity.length() == 0) content.addView(label("No moderation actions recorded yet.", 13, secondaryText, false))
        else for (i in 0 until activity.length()) {
            val item = activity.optJSONObject(i) ?: continue
            content.addView(label("${item.optString("action")} · ${item.optString("targetType")} · ${item.optString("createdAt")}", 12, secondaryText, false).apply { setPadding(0, dp(3), 0, dp(3)) })
        }
        button("Review reports") { showAdminReports() }
        button("Suspended accounts") { showAdminSuspendedAccounts() }
        button("Moderation history") { showAdminAudit() }
        button("Refresh dashboard") { showAdminPanel() }
        addBottom()
    }

    private fun adminRequest(payload: JSONObject, onSuccess: (JSONObject) -> Unit, onFailure: (String) -> Unit = {}) {
        val user = FirebaseBackend.auth?.currentUser ?: run { onFailure("Sign in with an administrator account."); return }
        val projectId = try { com.google.firebase.FirebaseApp.getInstance().options.projectId } catch (_: Exception) { null }
        if (projectId.isNullOrBlank()) { onFailure("Firebase project is not configured."); return }
        setBusy(true)
        aiScope.launch {
            try {
                val token = user.getIdToken(false).await().token.orEmpty()
                val response = withContext(Dispatchers.IO) { postPaymentFunction(projectId, "adminModeration", token, payload) }
                onSuccess(response)
            } catch (error: Exception) { onFailure(error.message ?: friendlyError(error)) }
            finally { setBusy(false) }
        }
    }

    private fun showAdminReports() {
        selected = "Admin Panel"; base(); heading("Reported content", "Review videos, creators and comments")
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; content.addView(list)
        list.addView(label("Loading open reports…", 13, secondaryText, false)); addBottom()
        adminRequest(JSONObject().put("mode", "reports"), { response ->
            list.removeAllViews(); val reports = response.optJSONArray("reports") ?: JSONArray()
            if (reports.length() == 0) list.addView(label("No open reports.", 14, secondaryText, false))
            for (i in 0 until reports.length()) {
                val report = reports.optJSONObject(i) ?: continue
                val type = report.optString("type")
                val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = round(Color.WHITE, 16); setPadding(dp(13), dp(12), dp(13), dp(12)) }
                card.addView(label("${type.uppercase(Locale.ROOT)} · ${report.optString("contentSummary", "Reported item")}", 15, primaryText, true))
                card.addView(label("Reason: ${report.optString("reason")} · @${report.optString("targetUsername", "unknown")}", 12, secondaryText, false).apply { setPadding(0, dp(4), 0, dp(3)) })
                val details = report.optString("details"); if (details.isNotBlank()) card.addView(label(details, 13, secondaryText, false))
                card.addView(label("Report ${report.optString("id").take(12)} · ${report.optString("createdAt")}", 11, secondaryText, false).apply { setPadding(0, dp(4), 0, dp(7)) })
                val actions = mutableListOf("Dismiss report" to "dismiss")
                if (type == "video") actions.add(0, "Remove video" to "remove_video")
                if (type == "comment") actions.add(0, "Remove comment" to "remove_comment")
                if (type == "user") actions.add(0, "Suspend account" to "suspend_user")
                val review = TextView(this).apply { text = "Review actions"; textSize = 13f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setTextColor(Color.WHITE); background = round(mint, 12); setPadding(dp(12), dp(10), dp(12), dp(10)); setOnClickListener { AlertDialog.Builder(this@MainActivity).setTitle("Moderate report").setItems(actions.map { it.first }.toTypedArray()) { _, which -> confirmAdminAction(report.optString("id"), actions[which].second, report.optString("contentSummary")) }.setNegativeButton("Cancel", null).show() } }
                card.addView(review); list.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) })
            }
        }, { message -> list.removeAllViews(); list.addView(label("Could not load reports: $message", 14, secondaryText, false)) })
    }

    private fun confirmAdminAction(reportId: String, action: String, summary: String) {
        val destructive = action != "dismiss"
        AlertDialog.Builder(this).setTitle(if (destructive) "Confirm moderation action" else "Dismiss report?")
            .setMessage(if (destructive) "Apply $action to: $summary? This action is recorded in the moderation audit log." else "Close this report without taking action?")
            .setNegativeButton("Cancel", null).setPositiveButton("Confirm") { _, _ ->
                adminRequest(JSONObject().put("mode", "resolve").put("reportId", reportId).put("action", action), { info("Moderation saved", "The action was applied and recorded in the audit log."); showAdminReports() }, { info("Moderation failed", it) })
            }.show()
    }

    private fun showAdminSuspendedAccounts() {
        selected = "Admin Panel"; base(); heading("Suspended accounts", "Restore access after review")
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; content.addView(list); addBottom()
        adminRequest(JSONObject().put("mode", "suspended"), { response ->
            list.removeAllViews(); val accounts = response.optJSONArray("accounts") ?: JSONArray()
            if (accounts.length() == 0) list.addView(label("No suspended accounts.", 14, secondaryText, false))
            for (i in 0 until accounts.length()) {
                val item = accounts.optJSONObject(i) ?: continue; val uid = item.optString("uid")
                val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = round(Color.WHITE, 14); setPadding(dp(12), dp(10), dp(12), dp(10)) }
                card.addView(label("UID · $uid", 13, primaryText, true)); card.addView(label(item.optString("reason"), 12, secondaryText, false))
                val restore = TextView(this).apply { text = "Restore account"; gravity = Gravity.CENTER; setTextColor(Color.WHITE); background = round(mint, 12); setPadding(dp(10), dp(8), dp(10), dp(8)); setOnClickListener { AlertDialog.Builder(this@MainActivity).setTitle("Restore this account?").setMessage("The user will be able to sign in again.").setNegativeButton("Cancel", null).setPositiveButton("Restore") { _, _ -> adminRequest(JSONObject().put("mode", "resolve").put("action", "restore_user").put("targetUid", uid), { info("Account restored", "The account can sign in again."); showAdminSuspendedAccounts() }, { info("Restore failed", it) }) }.show() } }
                card.addView(restore); list.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
            }
        }, { message -> list.addView(label("Could not load suspended accounts: $message", 13, secondaryText, false)) })
    }

    private fun showAdminAudit() {
        selected = "Admin Panel"; base(); heading("Moderation history", "Server-written audit records")
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; content.addView(list); addBottom()
        adminRequest(JSONObject().put("mode", "audit"), { response ->
            list.removeAllViews(); val entries = response.optJSONArray("entries") ?: JSONArray()
            if (entries.length() == 0) list.addView(label("No moderation history yet.", 14, secondaryText, false))
            for (i in 0 until entries.length()) {
                val e = entries.optJSONObject(i) ?: continue
                list.addView(label("${e.optString("action")} · ${e.optString("targetType")} · ${e.optString("targetId")}\nAdmin ${e.optString("adminUid")} · ${e.optString("createdAt")}\n${e.optString("notes")}", 13, primaryText, false).apply { background = round(Color.WHITE, 14); setPadding(dp(12), dp(10), dp(12), dp(10)); layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) } })
            }
        }, { message -> list.addView(label("Audit history unavailable: $message", 13, secondaryText, false)) })
    }

    private fun attachUnreadBadge(glyph: TextView) {
        val user = FirebaseBackend.auth?.currentUser ?: return
        val db = FirebaseBackend.db ?: return
        db.collection("profiles").document(user.uid).get().addOnSuccessListener { profile ->
            val creatorId = profile.getString("creatorId") ?: return@addOnSuccessListener
            val listener = db.collection("notifications").document(creatorId).collection("items")
                .whereEqualTo("read", false).addSnapshotListener { snapshot, error ->
                    if (error != null) { Log.e("HiraBhaiNotifications", "Unread query failed: /notifications/$creatorId/items", error); return@addSnapshotListener }
                    val count = snapshot?.size() ?: 0
                    glyph.text = if (count > 0) "🔔 $count" else "🔔"
                }
            screenFirestoreListeners.add(listener)
        }.addOnFailureListener { Log.e("HiraBhaiNotifications", "Could not resolve notification owner profile", it) }
    }

    private fun showNotifications() {
        selected = "Notifications"; base(); heading("Notifications", "Updates about your channel and videos")
        val user = FirebaseBackend.auth?.currentUser
        if (user == null) {
            content.addView(label("Log in to see your notifications.", 15, secondaryText, false))
            button("Log in") { showAuth(false) }; addBottom(); return
        }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val status = label("Loading notifications…", 14, secondaryText, false)
        content.addView(status); content.addView(list)
        val db = FirebaseBackend.db
        if (db == null) { status.text = "Notifications are unavailable until Firestore is configured."; addBottom(); return }
        db.collection("profiles").document(user.uid).get().addOnSuccessListener { profile ->
            val creatorId = profile.getString("creatorId")
            if (creatorId.isNullOrBlank()) { status.text = "Create your creator profile to receive notifications."; return@addOnSuccessListener }
            val items = db.collection("notifications").document(creatorId).collection("items")
            val clear = TextView(this).apply {
                text = "Clear all"; textSize = 13f; gravity = Gravity.END; setTextColor(mint)
                isClickable = true; isFocusable = true
                setOnClickListener {
                    isEnabled = false
                    items.get().addOnSuccessListener { docs ->
                        if (docs.isEmpty) { isEnabled = true; return@addOnSuccessListener }
                        deleteNotificationDocuments(docs.documents, 0) { error ->
                            isEnabled = true
                            if (error != null) info("Notifications", friendlyError(error))
                        }
                    }.addOnFailureListener { isEnabled = true; info("Notifications", friendlyError(it)) }
                }
            }
            content.addView(clear, 0)
            val listener = items.orderBy("createdAt", com.google.firebase.firestore.Query.Direction.DESCENDING).limit(100)
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        status.text = "Could not load notifications: ${friendlyError(error)}"
                        Log.e("HiraBhaiNotifications", "Read failed: /notifications/$creatorId/items", error); return@addSnapshotListener
                    }
                    val localSettings = getSharedPreferences("hira_user_preferences", MODE_PRIVATE)
                    if (!localSettings.getBoolean("notifications_enabled", true)) {
                        list.removeAllViews(); status.text = "Creator notifications are paused. Change this in Settings."; return@addSnapshotListener
                    }
                    val showPreviews = localSettings.getBoolean("notification_previews", true)
                    list.removeAllViews(); val docs = snapshot?.documents.orEmpty()
                    status.text = if (docs.isEmpty()) "You’re all caught up." else ""
                    if (docs.isEmpty()) list.addView(label("No notifications yet. New subscribers, likes, and comments will appear here.", 14, secondaryText, false).apply { setPadding(0, dp(10), 0, dp(10)) })
                    docs.forEach { doc ->
                        val username = doc.getString("senderUsername") ?: "creator"
                        val name = doc.getString("senderName") ?: username
                        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; background = round(Color.WHITE, 16); setPadding(dp(12), dp(11), dp(12), dp(11)); isClickable = true; isFocusable = true }
                        val avatar = ImageView(this).apply { setImageResource(android.R.drawable.ic_menu_camera); scaleType = ImageView.ScaleType.CENTER_CROP; background = round(0xffdce8ed.toInt(), 100); clipToOutline = true; layoutParams = LinearLayout.LayoutParams(dp(44), dp(44)).apply { rightMargin = dp(10) }; contentDescription = "$name profile photo" }
                        if (showPreviews) loadCommentAvatar(username, avatar) else avatar.visibility = View.GONE
                        row.addView(avatar)
                        val textCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                        textCol.addView(label(if (showPreviews) name else "Hira Bhai update", 14, primaryText, true))
                        textCol.addView(label(if (showPreviews) doc.getString("message") ?: "You have a new update." else "Open Hira Bhai to view this notification.", 13, secondaryText, false).apply { setPadding(0, dp(2), 0, 0) })
                        val time = doc.getTimestamp("createdAt")?.toDate()?.let { SimpleDateFormat("MMM d · h:mm a", Locale.getDefault()).format(it) } ?: "Just now"
                        textCol.addView(label(time + if (doc.getBoolean("read") == true) " · Read" else " · New", 11, if (doc.getBoolean("read") == true) secondaryText else mint, false).apply { setPadding(0, dp(3), 0, 0) })
                        val markRead = doc.getBoolean("read") != true
                        textCol.addView(label(if (markRead) "Mark as read" else "Mark as unread", 11, mint, true).apply {
                            setPadding(0, dp(4), 0, 0); isClickable = true; isFocusable = true
                            setOnClickListener { doc.reference.update("read", markRead).addOnFailureListener { info("Notification", friendlyError(it)) } }
                        })
                        row.addView(textCol, LinearLayout.LayoutParams(0, -2, 1f))
                        val delete = TextView(this).apply { text = "×"; textSize = 22f; setTextColor(secondaryText); setPadding(dp(8), dp(4), dp(2), dp(4)); setOnClickListener { doc.reference.delete().addOnFailureListener { info("Delete notification", friendlyError(it)) } } }
                        row.addView(delete)
                        row.setOnClickListener {
                            if (doc.getBoolean("read") != true) doc.reference.update("read", true).addOnFailureListener { Log.e("HiraBhaiNotifications", "Mark-read failed: ${doc.reference.path}", it) }
                            val videoId = doc.getString("relatedVideoId").orEmpty()
                            val communityPostId = doc.getString("relatedCommunityPostId").orEmpty()
                            val creatorUsername = doc.getString("relatedCreatorUsername").orEmpty()
                            if (videoId.isNotBlank()) openVideoById(videoId)
                            else if (communityPostId.isNotBlank()) showCommunityPost(communityPostId)
                            else if (creatorUsername.isNotBlank()) loadPublicCreator(creatorUsername, null)
                        }
                        list.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
                    }
                }
            screenFirestoreListeners.add(listener)
        }.addOnFailureListener { status.text = "Could not load your profile: ${friendlyError(it)}" }
        addBottom()
    }

    private fun deleteNotificationDocuments(documents: List<com.google.firebase.firestore.DocumentSnapshot>, start: Int, done: (Exception?) -> Unit) {
        if (start >= documents.size) { done(null); return }
        val end = minOf(start + 450, documents.size)
        val batch = FirebaseBackend.db?.batch() ?: run { done(IllegalStateException("Firestore is unavailable")); return }
        documents.subList(start, end).forEach { batch.delete(it.reference) }
        batch.commit().addOnSuccessListener { deleteNotificationDocuments(documents, end, done) }
            .addOnFailureListener { done(it) }
    }

    private fun notificationData(type: String, senderCreatorId: String, senderUsername: String, senderName: String, message: String, targetCreatorId: String, targetUsername: String, videoId: String = "", commentId: String = "", communityPostId: String = ""): Map<String, Any> = mapOf(
        "type" to type, "senderCreatorId" to senderCreatorId, "senderUsername" to senderUsername,
        "senderName" to senderName, "message" to message, "relatedCreatorId" to targetCreatorId,
        "relatedCreatorUsername" to targetUsername, "relatedVideoId" to videoId,
        "relatedCommentId" to commentId, "relatedCommunityPostId" to communityPostId,
        "createdAt" to FieldValue.serverTimestamp(), "read" to false
    )

    private fun showAccount() {
        selected = "Library"; base()
        val user = FirebaseBackend.auth?.currentUser
        if (user == null) {
            heading("Your Hira Bhai account", "Sign in to create and manage your public profile")
            if (!FirebaseBackend.isConfigured) {
                action("Firebase setup needed", "Add your Firebase app values and enable Email/Password sign-in before creating accounts.") { firebaseSetupInfo() }
            }
            action("Log in", "Use your email and password") { showAuth(false) }
            action("Create account", "Sign up with email and password") { showAuth(true) }
            addBottom(); return
        }
        heading("Your profile", user.email ?: "Signed in")
        action("Settings & privacy", "Notifications, playback and account security") { showSettings() }
        action("Account information", "Private Firebase account details") { showAccountInformation() }
        val status = label("Loading your profile…", 14, 0xff647b8c.toInt(), false); content.addView(status)
        if (!FirebaseBackend.isConfigured) status.text = "Firebase connection unavailable. Check the project setup and network."
        FirebaseBackend.db?.collection("profiles")?.document(user.uid)?.get()
            ?.addOnSuccessListener { doc ->
                if (doc.exists()) {
                    currentProfile = hashMapOf<String, Any>().apply { putAll(doc.data ?: emptyMap()) }
                    status.text = "@${doc.getString("username") ?: "creator"}"
                    ensurePublicCreatorProfile(user.uid, currentProfile)
                    status.setOnClickListener { showPublicProfile(currentProfile) }
                    action("View public profile", "Public route: /u/${doc.getString("username") ?: "username"}") { showPublicProfile(currentProfile) }
                    action("Creator dashboard", "Manage your channel, videos and subscriber total") { showCreatorDashboard() }
                } else status.text = "Your profile is not set up yet. Add your details below."
                action("Edit profile", "Name, username, profile photo, bio and website") { showProfileEditor() }
                section("Creators you follow")
                loadUserSubscriptions(content, user.uid)
            }
            ?.addOnFailureListener { status.text = "Could not load profile: ${friendlyError(it)}"; action("Try again", "Reload your profile") { showAccount() } }
        action("Log out", "Sign out of this account on this device") { confirmLogout() }
        addBottom()
    }

    private fun showSettings() {
        val user = FirebaseBackend.auth?.currentUser ?: run { showAuth(false); return }
        selected = "Library"; base(); heading("Settings & privacy", "Your preferences are stored in your private account settings")
        val status = label("Loading your settings…", 13, secondaryText, false); content.addView(status)
        val db = FirebaseBackend.db ?: run { status.text = "Settings require a configured Firebase connection."; addBottom(); return }
        db.collection("userSettings").document(user.uid).get().addOnSuccessListener { doc ->
            status.visibility = View.GONE
            var notificationsEnabled = doc.getBoolean("notificationsEnabled") ?: true
            var notificationPreviews = doc.getBoolean("notificationPreviews") ?: true
            var playbackSpeed = doc.getDouble("playbackSpeed") ?: 1.0
            var recommendationsEnabled = doc.getBoolean("recommendationsEnabled") ?: true
            val ref = db.collection("userSettings").document(user.uid)
            fun save() {
                if (FirebaseBackend.auth?.currentUser?.uid != user.uid) { info("Settings not saved", "Your sign-in session changed. Sign in again."); return }
                ref.set(mapOf("notificationsEnabled" to notificationsEnabled, "notificationPreviews" to notificationPreviews, "playbackSpeed" to playbackSpeed, "recommendationsEnabled" to recommendationsEnabled, "updatedAt" to FieldValue.serverTimestamp()), SetOptions.merge())
                    .addOnSuccessListener { getSharedPreferences("hira_user_preferences", MODE_PRIVATE).edit().putFloat("playback_speed", playbackSpeed.toFloat()).putBoolean("notifications_enabled", notificationsEnabled).putBoolean("notification_previews", notificationPreviews).apply() }
                    .addOnFailureListener { error -> info("Settings not saved", friendlyError(error)); Log.e("HiraBhaiSettings", "Secure preference write failed for uid=${user.uid}", error) }
            }
            action("Edit display name and profile", "Update the existing creator profile") { showProfileEditor() }
            action("Account information", "View your private sign-in and verification details") { showAccountInformation() }
            section("Notifications")
            val notificationsSwitch = Switch(this).apply { text = "Creator notifications"; setTextColor(primaryText); isChecked = notificationsEnabled }
            content.addView(notificationsSwitch); notificationsSwitch.setOnCheckedChangeListener { _, checked -> notificationsEnabled = checked; save() }
            val previewsSwitch = Switch(this).apply { text = "Show notification details"; setTextColor(primaryText); isChecked = notificationPreviews; isEnabled = notificationsEnabled }
            content.addView(previewsSwitch); previewsSwitch.setOnCheckedChangeListener { _, checked -> notificationPreviews = checked; save() }
            notificationsSwitch.setOnCheckedChangeListener { _, checked -> notificationsEnabled = checked; previewsSwitch.isEnabled = checked; save() }
            section("Playback")
            action("Default playback speed · ${playbackSpeed}×", "Choose the initial speed for videos") {
                val speeds = arrayOf("0.5×", "0.75×", "1×", "1.25×", "1.5×", "2×")
                val values = doubleArrayOf(0.5, 0.75, 1.0, 1.25, 1.5, 2.0)
                val selectedIndex = values.indices.minByOrNull { kotlin.math.abs(values[it] - playbackSpeed) } ?: 2
                AlertDialog.Builder(this).setTitle("Default playback speed").setSingleChoiceItems(speeds, selectedIndex) { dialog, which ->
                    playbackSpeed = values[which]; save(); dialog.dismiss(); showSettings()
                }.setNegativeButton("Cancel", null).show()
            }
            section("Privacy")
            section("Video recommendations")
            val recommendationsSwitch = Switch(this).apply {
                text = "Use my activity for personal recommendations"
                setTextColor(primaryText)
                isChecked = recommendationsEnabled
            }
            content.addView(recommendationsSwitch)
            recommendationsSwitch.setOnCheckedChangeListener { _, checked ->
                recommendationsEnabled = checked
                save()
                homeFeedPages.clear()
            }
            content.addView(label("When disabled, Hira Bhai does not read your watch history, likes, subscriptions, or local search/page history for the For you feed. Public recent, trending, and popular lists remain available.", 12, secondaryText, false).apply { setPadding(0, dp(3), 0, dp(8)) })
            action("Reset recommendation feedback", "Clear videos marked Not interested and excluded creators") {
                AlertDialog.Builder(this).setTitle("Reset recommendation preferences?")
                    .setMessage("This clears your Not Interested and creator exclusion choices. Watch history, likes, and subscriptions are not deleted.")
                    .setNegativeButton("Cancel", null).setPositiveButton("Reset") { _, _ -> resetRecommendationFeedback() }.show()
            }
            action("Clear watch history", "Delete the private viewing signals used for recommendations") {
                AlertDialog.Builder(this).setTitle("Clear watch history?")
                    .setMessage("This removes your private watch history from recommendations. Your likes and subscriptions remain unchanged.")
                    .setNegativeButton("Cancel", null).setPositiveButton("Clear") { _, _ -> clearRecommendationHistory() }.show()
            }
            action("Public profile visibility", "This app currently publishes creator profiles publicly; a private-profile switch is not supported by the existing profile/search rules.") { info("Profile visibility", "Your creator profile is public so it can appear in creator search and profile links. Hiding it safely requires a visibility-aware profile migration; this setting is not offered as a nonfunctional switch.") }
            action("Private videos and files", "Private video and file access remains restricted by Firebase rules to the owner or explicitly shared users.") { info("Private content", "Private video and file access is enforced by the existing Firestore and Storage rules.") }
            action("Blocked users", "Manage the private block list for your account") { showBlockedUsers() }
            action("Private message controls", "Message restrictions apply only when a message system is connected.") { info("Messaging privacy", "The current source has no private-message screen or message collection, so the block list cannot prevent message delivery until messaging is implemented.") }
            section("Appearance and language")
            action("Language · English", "Hindi and Gujarati translations are not included in the current app resources.") { info("Language", "The current app UI is English. Hindi and Gujarati selection will be available after the app screens are translated.") }
            action("Theme · Light", "A full dark theme is not supported by the existing fixed-color screens.") { info("Theme", "The current app uses its existing light visual theme. A dark-theme switch is not shown because the screens do not yet support it consistently.") }
            section("Account security")
            action("Change password", "Re-enter your current password before updating it") { showChangePassword(user.email) }
            action(if (user.isEmailVerified) "Email verified" else "Verify email address", if (user.isEmailVerified) "Your sign-in email is verified" else "Send a verification link to ${user.email ?: "your sign-in email"}") {
                if (user.isEmailVerified) info("Email verified", "Your email address is already verified.")
                else user.sendEmailVerification().addOnSuccessListener { info("Verification sent", "Check your inbox and spam folder for Firebase's verification email.") }.addOnFailureListener { info("Could not send verification", friendlyError(it)) }
            }
            action("Reset password", "Send a secure Firebase password-reset email") {
                val email = user.email ?: run { info("Password reset unavailable", "This account does not have an email address."); return@action }
                FirebaseBackend.auth?.sendPasswordResetEmail(email)?.addOnSuccessListener { info("Reset email sent", "If an account uses this address, Firebase has sent a password reset link.") }?.addOnFailureListener { info("Could not send reset email", friendlyError(it)) }
            }
            action("Sign out", "Sign out of Hira Bhai on this device") { confirmLogout() }
            action("Delete account", "Permanently remove your account and associated content") { confirmAccountDeletion(user.email) }
        }.addOnFailureListener { status.text = "Could not load your private settings: ${friendlyError(it)}" }
        addBottom()
    }

    private fun showAccountInformation() {
        val user = FirebaseBackend.auth?.currentUser ?: run { showAuth(false); return }
        selected = "Library"; base(); heading("Account information", "Private information from Firebase Authentication")
        content.addView(label("Email", 13, secondaryText, true))
        content.addView(label(user.email ?: "No email address", 16, primaryText, false).apply { setPadding(0, dp(4), 0, dp(14)) })
        content.addView(label("Email status", 13, secondaryText, true))
        content.addView(label(if (user.isEmailVerified) "Verified" else "Not verified", 16, primaryText, false).apply { setPadding(0, dp(4), 0, dp(14)) })
        content.addView(label("Account created", 13, secondaryText, true))
        content.addView(label(user.metadata?.creationTimestamp?.let { SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date(it)) } ?: "Unavailable", 16, primaryText, false).apply { setPadding(0, dp(4), 0, dp(14)) })
        content.addView(label("Last sign-in", 13, secondaryText, true))
        content.addView(label(user.metadata?.lastSignInTimestamp?.let { SimpleDateFormat("MMM d, yyyy · h:mm a", Locale.getDefault()).format(Date(it)) } ?: "Unavailable", 16, primaryText, false).apply { setPadding(0, dp(4), 0, dp(14)) })
        button("Back to settings") { showSettings() }; addBottom()
    }

    private fun showBlockedUsers() {
        val user = FirebaseBackend.auth?.currentUser ?: run { showAuth(false); return }
        val db = FirebaseBackend.db ?: run { info("Block list unavailable", "Connect Firestore to manage blocked users."); return }
        selected = "Library"; base(); heading("Blocked users", "Only you can read or manage this list")
        content.addView(label("The list is saved privately under your Firebase UID. The current project has no direct-message flow to enforce blocks against.", 13, secondaryText, false).apply { setPadding(0, 0, 0, dp(12)) })
        val handle = field("Username to block", android.text.InputType.TYPE_CLASS_TEXT)
        content.addView(handle)
        button("Add to block list") {
            val username = handle.text.toString().trim().removePrefix("@").lowercase(Locale.ROOT)
            if (!Regex("^[a-z0-9_]{3,24}$").matches(username)) { handle.error = "Enter a valid Hira Bhai username"; return@button }
            db.collection("userDirectory").document(username).get().addOnSuccessListener { target ->
                val targetUid = target.getString("uid")
                if (targetUid.isNullOrBlank()) { handle.error = "No Hira Bhai user found with this username"; return@addOnSuccessListener }
                if (targetUid == user.uid) { handle.error = "You cannot block your own account"; return@addOnSuccessListener }
                db.collection("userSettings").document(user.uid).collection("blockedUsers").document(targetUid)
                    .set(mapOf("uid" to targetUid, "username" to username, "createdAt" to FieldValue.serverTimestamp()))
                    .addOnSuccessListener { handle.setText(""); Toast.makeText(this, "@$username added to your block list", Toast.LENGTH_SHORT).show() }
                    .addOnFailureListener { info("Could not block user", friendlyError(it)) }
            }.addOnFailureListener { info("Could not find user", friendlyError(it)) }
        }
        section("Your block list")
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(list)
        db.collection("userSettings").document(user.uid).collection("blockedUsers").orderBy("username").addSnapshotListener { snapshot, error ->
            list.removeAllViews()
            if (error != null) { list.addView(label("Could not load your private block list: ${friendlyError(error)}", 13, secondaryText, false)); return@addSnapshotListener }
            if (snapshot?.isEmpty != false) { list.addView(label("No blocked users.", 14, secondaryText, false)); return@addSnapshotListener }
            snapshot.documents.forEach { doc ->
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; background = round(Color.WHITE, 14); setPadding(dp(12), dp(8), dp(8), dp(8)) }
                row.addView(label("@${doc.getString("username") ?: "user"}", 15, primaryText, true), LinearLayout.LayoutParams(0, -2, 1f))
                val remove = TextView(this).apply { text = "Unblock"; textSize = 13f; setTextColor(mint); setPadding(dp(10), dp(8), dp(8), dp(8)); setOnClickListener { doc.reference.delete().addOnFailureListener { info("Could not unblock user", friendlyError(it)) } } }
                row.addView(remove); list.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
            }
        }.also { screenFirestoreListeners.add(it) }
        button("Back to settings") { showSettings() }; addBottom()
    }

    private fun showChangePassword(email: String?) {
        val address = email ?: run { info("Password change unavailable", "This Firebase account has no email/password sign-in address."); return }
        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(8), dp(18), 0) }
        val current = EditText(this).apply { hint = "Current password"; inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD }
        val next = EditText(this).apply { hint = "New password (at least 6 characters)"; inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD }
        form.addView(current); form.addView(next)
        AlertDialog.Builder(this).setTitle("Change password").setView(form).setNegativeButton("Cancel", null).setPositiveButton("Update") { _, _ ->
            val oldPassword = current.text.toString(); val newPassword = next.text.toString()
            if (newPassword.length < 6) { info("Password not changed", "Use at least 6 characters for the new password."); return@setPositiveButton }
            val user = FirebaseBackend.auth?.currentUser ?: run { info("Password not changed", "Sign in again first."); return@setPositiveButton }
            val credential = com.google.firebase.auth.EmailAuthProvider.getCredential(address, oldPassword)
            user.reauthenticate(credential).continueWithTask { task -> if (!task.isSuccessful) throw task.exception ?: IllegalStateException("Could not verify your current password"); user.updatePassword(newPassword) }
                .addOnSuccessListener { info("Password changed", "Your Firebase password was updated.") }
                .addOnFailureListener { error -> info("Password not changed", friendlyError(error)) }
        }.show()
    }

    private fun confirmLogout() {
        AlertDialog.Builder(this).setTitle("Sign out?").setMessage("You can sign in again with your Firebase account.")
            .setNegativeButton("Cancel", null).setPositiveButton("Sign out") { _, _ -> clearAudioSessionOnSignOut(); FirebaseBackend.auth?.signOut(); currentProfile.clear(); selectedPhoto = null; showHome() }.show()
    }

    private fun confirmAccountDeletion(email: String?) {
        if (email.isNullOrBlank()) { info("Account deletion unavailable", "This account has no email/password credentials for secure reauthentication."); return }
        val input = EditText(this).apply { hint = "Enter your current password"; inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD; setPadding(dp(16), dp(12), dp(16), dp(12)) }
        AlertDialog.Builder(this).setTitle("Delete your account?").setMessage("This permanently deletes your Firebase account, profile, videos, files and related account data. This cannot be undone.").setView(input)
            .setNegativeButton("Cancel", null).setPositiveButton("Delete account") { _, _ ->
                val user = FirebaseBackend.auth?.currentUser ?: run { info("Deletion stopped", "Sign in again before deleting your account."); return@setPositiveButton }
                val credential = com.google.firebase.auth.EmailAuthProvider.getCredential(email, input.text.toString())
                user.reauthenticate(credential).continueWithTask { task ->
                    if (!task.isSuccessful) throw task.exception ?: IllegalStateException("Could not verify your password")
                    user.getIdToken(true)
                }.addOnSuccessListener { token ->
                    deleteAccountOnBackend(token.token.orEmpty())
                }.addOnFailureListener { error -> info("Deletion stopped", friendlyError(error)) }
            }.show()
    }

    private fun deleteAccountOnBackend(idToken: String) {
        val projectId = try { com.google.firebase.FirebaseApp.getInstance().options.projectId } catch (_: Exception) { null }
        if (projectId.isNullOrBlank() || idToken.isBlank()) { info("Deletion unavailable", "Firebase account deletion service is not configured."); return }
        setBusy(true)
        aiScope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    val connection = (URL("https://us-central1-$projectId.cloudfunctions.net/deleteAccount").openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"; connectTimeout = 15000; readTimeout = 60000; doOutput = true
                        setRequestProperty("Authorization", "Bearer $idToken"); setRequestProperty("Content-Type", "application/json")
                    }
                    connection.outputStream.use { it.write("{}".toByteArray()) }
                    val code = connection.responseCode; val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                    val body = stream.bufferedReader().use { it.readText() }; connection.disconnect()
                    if (code !in 200..299) throw IllegalStateException(JSONObject(body).optString("error", "Account deletion failed ($code)"))
                    JSONObject(body)
                }
                if (result.optBoolean("deleted")) { clearAudioSessionOnSignOut(); FirebaseBackend.auth?.signOut(); currentProfile.clear(); selectedPhoto = null; showHome() }
                else info("Deletion incomplete", "The server did not confirm account deletion.")
            } catch (error: Exception) { info("Deletion failed", error.message ?: friendlyError(error)) }
            finally { setBusy(false) }
        }
    }

    private fun showCreatorDashboard() {
        val user = FirebaseBackend.auth?.currentUser
        if (user == null) { showAuth(false); return }
        val db = FirebaseBackend.db ?: run { info("Dashboard unavailable", "Connect Firestore to load your channel data."); return }
        selected = "Library"; base(); heading("Creator dashboard", "Private channel management")
        val loading = label("Loading your channel…", 14, secondaryText, false); content.addView(loading)
        db.collection("profiles").document(user.uid).get()
            .addOnSuccessListener { profile ->
                if (!profile.exists()) {
                    loading.text = "Set up your creator profile before opening the dashboard."
                    button("Set up creator profile") { showProfileEditor() }
                    return@addOnSuccessListener
                }
                if (FirebaseBackend.auth?.currentUser?.uid != user.uid) {
                    loading.text = "Your sign-in session changed. Open the dashboard again."
                    return@addOnSuccessListener
                }
                currentProfile = hashMapOf<String, Any>().apply { putAll(profile.data ?: emptyMap()) }
                val creatorId = profile.getString("creatorId")
                if (creatorId.isNullOrBlank()) {
                    loading.text = "Your creator profile is incomplete. Save your profile before managing videos."
                    button("Edit channel profile") { showProfileEditor() }
                    return@addOnSuccessListener
                }
                loading.text = "${profile.getString("fullName") ?: "Creator channel"} · @${profile.getString("username") ?: ""}"
                button("Edit channel name, bio and picture") { showProfileEditor() }
                button("Creator monetization and earnings") { showCreatorMonetization(creatorId) }
                val stats = label("Loading subscriber count…", 15, primaryText, true)
                content.addView(stats)
                db.collection("creatorStats").document(creatorId).get()
                    .addOnSuccessListener { document ->
                        val total = (document.getLong("subscriberCount") ?: 0L).coerceAtLeast(0L)
                        stats.text = "$total ${if (total == 1L) "subscriber" else "subscribers"}"
                    }
                    .addOnFailureListener { stats.text = "Subscriber count unavailable: ${friendlyError(it)}" }
                section("Uploaded videos")
                val totalLabel = label("Counting your videos…", 13, secondaryText, false); content.addView(totalLabel)
                val videos = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                content.addView(videos)
                val ownedVideos = db.collection("videos").whereEqualTo("creatorId", creatorId)
                ownedVideos.count().get(com.google.firebase.firestore.AggregateSource.SERVER)
                    .addOnSuccessListener { totalLabel.text = "${it.count} uploaded video${if (it.count == 1L) "" else "s"}" }
                    .addOnFailureListener { totalLabel.text = "Video total unavailable: ${friendlyError(it)}" }
                ownedVideos.orderBy("createdAt", com.google.firebase.firestore.Query.Direction.DESCENDING).limit(100).get()
                    .addOnSuccessListener { snapshot ->
                        videos.removeAllViews()
                        if (snapshot.isEmpty) videos.addView(label("You have not uploaded any videos yet.", 14, secondaryText, false))
                        snapshot.documents.forEach { document -> addDashboardVideo(videos, document.id, document.data ?: emptyMap(), user.uid, creatorId) }
                    }
                    .addOnFailureListener { error ->
                        videos.addView(label("Could not load your videos: ${friendlyError(error)}", 14, secondaryText, false))
                        Log.e("HiraBhaiDashboard", "Owner query failed: /videos where creatorId=$creatorId authUid=${user.uid}", error)
                    }
            }
            .addOnFailureListener { error ->
                loading.text = "Could not verify the signed-in creator profile: ${friendlyError(error)}"
                Log.e("HiraBhaiDashboard", "Profile ownership check failed at /profiles/${user.uid}", error)
            }
        addBottom()
    }

    private fun showCreatorMonetization(creatorId: String) {
        val user = FirebaseBackend.auth?.currentUser ?: run { showAuth(false); return }
        val db = FirebaseBackend.db ?: run { info("Monetization unavailable", "Connect Firestore to load creator earnings."); return }
        selected = "Library"; base(); heading("Creator monetization", "Donations and verified earnings")
        val status = label("Checking payment and eligibility setup…", 15, primaryText, true); content.addView(status)
        section("Eligibility")
        content.addView(label("Creator profile and audience metrics are shown below. Hira Bhai eligibility thresholds are not configured yet, so this screen will not mark a creator payout eligible based on invented requirements.", 13, secondaryText, false))
        val metrics = label("Loading your audience metrics…", 14, secondaryText, false).apply { setPadding(0, dp(8), 0, dp(8)) }; content.addView(metrics)
        db.collection("creatorStats").document(creatorId).get().addOnSuccessListener { stats ->
            metrics.text = "${(stats.getLong("subscriberCount") ?: 0L).coerceAtLeast(0)} subscribers"
        }.addOnFailureListener { metrics.text = "Audience metrics unavailable: ${friendlyError(it)}" }
        section("Donations")
        content.addView(label("Donations require Hira Bhai’s Razorpay merchant approval and Razorpay Route approval, plus a verified linked account for this creator. The app will only open checkout after the secure backend confirms both are configured.", 13, secondaryText, false))
        button("Configure donation amounts") { configureDonationAmounts(creatorId) }
        section("Earnings")
        val earnings = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; content.addView(earnings)
        earnings.addView(label("Loading verified transaction ledger…", 14, secondaryText, false))
        db.collection("creatorEarnings").document(creatorId).collection("transactions")
            .orderBy("createdAt", com.google.firebase.firestore.Query.Direction.DESCENDING).limit(100).get()
            .addOnSuccessListener { rows ->
                earnings.removeAllViews()
                var pending = 0L; var final = 0L
                rows.documents.forEach { row ->
                    val amount = row.getLong("amountPaise") ?: 0L
                    when (row.getString("status")) { "settled" -> final += (row.getLong("settledAmountPaise") ?: 0L); "captured" -> pending += amount }
                }
                earnings.addView(label("Estimated gross · ₹${pending / 100}.${(pending % 100).toString().padStart(2, '0')} (captured, transfer settlement pending)", 15, primaryText, true))
                earnings.addView(label("Finalized net · ₹${final / 100}.${(final % 100).toString().padStart(2, '0')} (settled transfer after recorded fees)", 15, primaryText, true).apply { setPadding(0, dp(5), 0, dp(8)) })
                if (rows.isEmpty) earnings.addView(label("No verified donations yet. Unverified payment attempts are not counted.", 13, secondaryText, false))
                rows.documents.forEach { row ->
                    val amount = row.getLong("settledAmountPaise") ?: row.getLong("amountPaise") ?: 0L
                    val state = row.getString("status") ?: "unknown"
                    val date = row.getTimestamp("createdAt")?.toDate()?.let { SimpleDateFormat("MMM d, yyyy · h:mm a", Locale.getDefault()).format(it) } ?: "Date pending"
                    earnings.addView(label("₹${amount / 100}.${(amount % 100).toString().padStart(2, '0')} · ${state.replaceFirstChar { it.uppercase() }} · $date", 13, secondaryText, false).apply { setPadding(0, dp(6), 0, dp(4)) })
                }
            }.addOnFailureListener { earnings.removeAllViews(); earnings.addView(label("Verified earnings are unavailable: ${friendlyError(it)}", 13, secondaryText, false)) }
        section("Payouts")
        val payouts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; content.addView(payouts)
        payouts.addView(label("Loading verified transfer history…", 13, secondaryText, false))
        db.collection("creatorEarnings").document(creatorId).collection("payouts")
            .orderBy("createdAt", com.google.firebase.firestore.Query.Direction.DESCENDING).limit(100).get()
            .addOnSuccessListener { rows ->
                payouts.removeAllViews()
                if (rows.isEmpty) payouts.addView(label("No verified payouts yet. Route settlement events populate this history when configured.", 13, secondaryText, false))
                rows.documents.forEach { row ->
                    val amount = row.getLong("amountPaise") ?: 0L
                    val date = row.getTimestamp("createdAt")?.toDate()?.let { SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(it) } ?: "Date pending"
                    payouts.addView(label("₹${amount / 100}.${(amount % 100).toString().padStart(2, '0')} · ${row.getString("status") ?: "pending"} · $date", 13, secondaryText, false).apply { setPadding(0, dp(6), 0, dp(4)) })
                }
            }.addOnFailureListener { payouts.removeAllViews(); payouts.addView(label("Payout history unavailable: ${friendlyError(it)}", 13, secondaryText, false)) }
        db.collection("creatorPayouts").document(creatorId).get().addOnSuccessListener { payout ->
            val configured = payout.getString("status") == "active" && payout.getString("accountId").orEmpty().isNotBlank()
            status.text = if (configured) "Payout account connected · eligibility still requires configured Hira Bhai policy" else "Payments not configured · no donations can be accepted yet"
        }.addOnFailureListener { status.text = "Payments not configured or unavailable · ${friendlyError(it)}" }
        addBottom()
    }

    private fun startCreatorDonation(creatorId: String, amountPaise: Int) {
        val user = FirebaseBackend.auth?.currentUser ?: run { showAuth(false); return }
        if (!user.isEmailVerified) { info("Verify your email", "Verify your Firebase email before making a donation."); return }
        val projectId = try { com.google.firebase.FirebaseApp.getInstance().options.projectId } catch (_: Exception) { null }
        if (projectId.isNullOrBlank()) { info("Donations unavailable", "Firebase payment backend is not configured."); return }
        setBusy(true)
        aiScope.launch {
            try {
                val token = user.getIdToken(false).await().token.orEmpty()
                val order = withContext(Dispatchers.IO) { postPaymentFunction(projectId, "createDonationOrder", token, JSONObject().put("creatorId", creatorId).put("amountPaise", amountPaise)) }
                val keyId = order.optString("keyId"); val orderId = order.optString("orderId")
                if (keyId.isBlank() || orderId.isBlank()) throw IllegalStateException("Payment service returned an incomplete order.")
                pendingDonationCreatorId = creatorId; pendingDonationOrderId = orderId
                val checkout = com.razorpay.Checkout().apply { setKeyID(keyId) }
                val options = JSONObject().put("key", keyId).put("order_id", orderId).put("amount", amountPaise)
                    .put("currency", "INR").put("name", "Hira Bhai").put("description", "Support creator")
                    .put("prefill", JSONObject().put("email", user.email.orEmpty()))
                checkout.open(this@MainActivity, options)
            } catch (error: Exception) { info("Donation unavailable", error.message ?: friendlyError(error)) }
            finally { setBusy(false) }
        }
    }

    private fun postPaymentFunction(projectId: String, function: String, token: String, payload: JSONObject): JSONObject {
        val connection = (URL("https://us-central1-$projectId.cloudfunctions.net/$function").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 15000; readTimeout = 30000; doOutput = true
            setRequestProperty("Authorization", "Bearer $token"); setRequestProperty("Content-Type", "application/json")
        }
        connection.outputStream.use { it.write(payload.toString().toByteArray()) }
        val code = connection.responseCode; val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val body = stream.bufferedReader().use { it.readText() }; connection.disconnect()
        val result = JSONObject(body)
        if (code !in 200..299) throw IllegalStateException(result.optString("error", "Payment service failed ($code)"))
        return result
    }

    override fun onPaymentSuccess(paymentId: String?, data: com.razorpay.PaymentData?) {
        val user = FirebaseBackend.auth?.currentUser ?: return info("Payment pending", "Sign in again to verify the payment status.")
        val orderId = data?.orderId ?: pendingDonationOrderId
        if (paymentId.isNullOrBlank() || orderId.isNullOrBlank()) { info("Payment pending", "The payment response is incomplete. Check your donation history later."); return }
        val projectId = try { com.google.firebase.FirebaseApp.getInstance().options.projectId } catch (_: Exception) { null }
        if (projectId.isNullOrBlank()) return info("Payment pending", "The secure verification service is unavailable.")
        setBusy(true)
        aiScope.launch {
            try {
                val token = user.getIdToken(true).await().token.orEmpty()
                val verified = withContext(Dispatchers.IO) { postPaymentFunction(projectId, "verifyDonationPayment", token, JSONObject().put("paymentId", paymentId).put("orderId", orderId).put("signature", data?.signature.orEmpty())) }
                info("Donation ${if (verified.optBoolean("verified")) "verified" else "processing"}", verified.optString("message", "Payment status was checked by the secure server."))
            } catch (error: Exception) { info("Payment verification pending", error.message ?: "The server could not confirm this payment. It will not appear as earnings until verified.") }
            finally { pendingDonationOrderId = null; pendingDonationCreatorId = null; setBusy(false) }
        }
    }

    override fun onPaymentError(code: Int, response: String?, data: com.razorpay.PaymentData?) {
        pendingDonationOrderId = null; pendingDonationCreatorId = null
        info("Donation not completed", "Razorpay did not confirm a successful payment. No earnings were recorded.")
    }

    private fun addDashboardVideo(parent: LinearLayout, videoId: String, video: Map<String, Any>, ownerUid: String, creatorId: String) {
        val title = video["title"] as? String ?: "Untitled video"
        val visibility = (video["visibility"] as? String ?: "unknown").replaceFirstChar { it.uppercase() }
        val createdAt = (video["createdAt"] as? com.google.firebase.Timestamp)?.toDate()?.let {
            SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(it)
        } ?: "Upload date unavailable"
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = round(Color.WHITE, 16)
            setPadding(dp(13), dp(12), dp(13), dp(12))
        }
        card.addView(label(title, 16, primaryText, true))
        card.addView(label("Published · $visibility · $createdAt", 12, secondaryText, false).apply { setPadding(0, dp(4), 0, dp(10)) })
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun actionButton(text: String, click: () -> Unit) {
            val button = TextView(this).apply {
                this.text = text; textSize = 13f; gravity = Gravity.CENTER; setTextColor(primaryText)
                background = round(0xffe8f1f3.toInt(), 12); setPadding(dp(15), dp(10), dp(15), dp(10))
                isClickable = true; isFocusable = true; setOnClickListener { click() }
            }
            actions.addView(button, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(7) })
        }
        actionButton("Watch") { openVideoById(videoId, video) }
        actionButton("Edit details") { editOwnedVideo(videoId, title, video["description"] as? String ?: "", ownerUid, creatorId) }
        actionButton("Delete") { confirmDeleteOwnedVideo(videoId, title, video, ownerUid, creatorId, parent) }
        card.addView(actions)
        parent.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) })
    }

    private fun editOwnedVideo(videoId: String, currentTitle: String, currentDescription: String, ownerUid: String, creatorId: String) {
        val user = FirebaseBackend.auth?.currentUser
        if (user == null || user.uid != ownerUid) { info("Edit denied", "Only the signed-in channel owner can edit this video."); return }
        val db = FirebaseBackend.db ?: return
        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val title = EditText(this).apply { hint = "Video title"; setText(currentTitle); setSingleLine(true) }
        val description = EditText(this).apply { hint = "Description"; setText(currentDescription); minLines = 3; gravity = Gravity.TOP }
        form.addView(title); form.addView(description)
        AlertDialog.Builder(this).setTitle("Edit video details").setView(form)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                val nextTitle = title.text.toString().trim(); val nextDescription = description.text.toString().trim()
                if (nextTitle.isBlank() || nextTitle.length > 120 || nextDescription.length > 4000) {
                    info("Invalid details", "Add a title of 1–120 characters and a description up to 4,000 characters.")
                    return@setPositiveButton
                }
                if (FirebaseBackend.auth?.currentUser?.uid != ownerUid) { info("Edit denied", "Your sign-in session changed."); return@setPositiveButton }
                db.collection("videos").document(videoId).update(mapOf("title" to nextTitle, "description" to nextDescription))
                    .addOnSuccessListener { showCreatorDashboard() }
                    .addOnFailureListener { error -> info("Could not save video", friendlyError(error)); Log.e("HiraBhaiDashboard", "Video edit denied at /videos/$videoId for creatorId=$creatorId", error) }
            }.show()
    }

    private fun confirmDeleteOwnedVideo(videoId: String, title: String, video: Map<String, Any>, ownerUid: String, creatorId: String, list: LinearLayout) {
        val user = FirebaseBackend.auth?.currentUser
        if (user == null || user.uid != ownerUid) { info("Delete denied", "Only the signed-in channel owner can delete this video."); return }
        AlertDialog.Builder(this).setTitle("Delete video?")
            .setMessage("“$title” will be removed from your channel. This cannot be undone.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Delete") { _, _ ->
                if (FirebaseBackend.auth?.currentUser?.uid != ownerUid) { info("Delete denied", "Your sign-in session changed."); return@setPositiveButton }
                val db = FirebaseBackend.db ?: return@setPositiveButton
                db.collection("videos").document(videoId).delete()
                    .addOnSuccessListener {
                        val paths = listOfNotNull(video["storagePath"] as? String, video["thumbnailStoragePath"] as? String)
                        val storage = FirebaseBackend.storage
                        if (storage == null || paths.isEmpty()) { showCreatorDashboard(); return@addOnSuccessListener }
                        var remaining = paths.size
                        var failed = false
                        paths.forEach { path -> storage.reference.child(path).delete()
                            .addOnSuccessListener { if (--remaining == 0) { if (failed) info("Video removed", "Video details were deleted, but some Storage files could not be removed."); showCreatorDashboard() } }
                            .addOnFailureListener { error ->
                                failed = true; Log.e("HiraBhaiDashboard", "Storage cleanup failed at $path for creatorId=$creatorId", error)
                                if (--remaining == 0) { info("Video removed", "Video details were deleted, but some Storage files could not be removed."); showCreatorDashboard() }
                            }
                        }
                    }
                    .addOnFailureListener { error -> info("Could not delete video", friendlyError(error)); Log.e("HiraBhaiDashboard", "Video delete denied at /videos/$videoId for creatorId=$creatorId", error) }
            }.show()
    }

    private fun showAuth(signUp: Boolean) {
        base(); heading(if (signUp) "Create your account" else "Welcome back", "Secure sign-in with Firebase Authentication")
        val email = field("Email address", android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS)
        val password = field("Password", android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD)
        content.addView(email); content.addView(password)
        val error = label("", 13, 0xffffaaa5.toInt(), false); content.addView(error)
        if (!FirebaseBackend.isConfigured) action("Firebase not configured", "Connect a Firebase project to enable real sign-in.") { firebaseSetupInfo() }
        button(if (signUp) "Create account" else "Log in") {
            val address = email.text.toString().trim(); val pass = password.text.toString()
            email.error = null; password.error = null; error.text = ""
            if (!Patterns.EMAIL_ADDRESS.matcher(address).matches()) { email.error = "Enter a valid email address"; return@button }
            if (pass.length < 6) { password.error = "Password must be at least 6 characters"; return@button }
            val auth = FirebaseBackend.auth
            if (auth == null) { error.text = "Firebase is not configured. No sign-in was attempted."; return@button }
            setBusy(true)
            val task = if (signUp) auth.createUserWithEmailAndPassword(address, pass) else auth.signInWithEmailAndPassword(address, pass)
            task.addOnCompleteListener { result ->
                setBusy(false)
                if (result.isSuccessful && auth.currentUser != null) {
                    error.text = ""
                    if (signUp) showProfileEditor() else showAccount()
                } else error.text = friendlyError(result.exception)
            }
        }
        if (!signUp) {
            button("Forgot password?") {
                val address = email.text.toString().trim()
                if (!Patterns.EMAIL_ADDRESS.matcher(address).matches()) { email.error = "Enter your account email first"; return@button }
                val auth = FirebaseBackend.auth
                if (auth == null) { error.text = "Firebase is not configured. Password reset is unavailable."; return@button }
                setBusy(true); auth.sendPasswordResetEmail(address).addOnCompleteListener { task -> setBusy(false); error.text = if (task.isSuccessful) "If an account uses this address, a reset email has been sent." else friendlyError(task.exception) }
            }
            button("Create account") { showAuth(true) }
        } else button("Already have an account? Log in") { showAuth(false) }
        addBottom()
    }

    private fun showProfileEditor() {
        val user = FirebaseBackend.auth?.currentUser
        if (user == null) { showAuth(false); return }
        selected = "Library"; base(); heading("Set up your profile", "Your public profile is separate from your private sign-in details.")
        val photo = ImageView(this).apply { setImageResource(android.R.drawable.ic_menu_camera); scaleType = ImageView.ScaleType.CENTER_CROP; background = round(0xff315573.toInt(), 100); clipToOutline = true; layoutParams = LinearLayout.LayoutParams(dp(96), dp(96)).apply { gravity = Gravity.CENTER; bottomMargin = dp(8) } }
        content.addView(photo)
        (currentProfile["photoData"] as? String)?.let { showProfilePhoto(it, photo) }
        selectedPhoto?.let { try { photo.setImageURI(it) } catch (_: Exception) {} }
        button("Choose profile picture") {
            try { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION), 45) }
            catch (_: Exception) { info("Photo picker", "Could not open the photo picker.") }
        }
        val fullName = field("Full name", android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_WORDS)
        val username = field("Unique username (3–24 letters, digits, _)", android.text.InputType.TYPE_CLASS_TEXT)
        val bio = field("Biography", android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE); bio.minLines = 3; bio.gravity = Gravity.TOP
        val website = field("Personal website (optional)", android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI)
        fullName.setText(currentProfile["fullName"] as? String ?: user.displayName.orEmpty())
        username.setText(currentProfile["username"] as? String ?: "")
        bio.setText(currentProfile["bio"] as? String ?: "")
        website.setText(currentProfile["websiteUrl"] as? String ?: "")
        listOf(fullName, username, bio, website).forEach(content::addView)
        val error = label("", 13, 0xffffaaa5.toInt(), false); content.addView(error)
        button("Save profile") {
            val name = fullName.text.toString().trim(); val handle = username.text.toString().trim().lowercase(); val about = bio.text.toString().trim(); val url = website.text.toString().trim()
            listOf(fullName, username, website).forEach { it.error = null }; error.text = ""
            if (name.length < 2) { fullName.error = "Enter your full name"; return@button }
            if (!Regex("^[a-z0-9_]{3,24}$").matches(handle)) { username.error = "Use 3–24 lowercase letters, numbers or underscores"; return@button }
            if (about.length > 500) { bio.error = "Biography must be 500 characters or fewer"; return@button }
            if (url.isNotEmpty() && (!Patterns.WEB_URL.matcher(url).matches() || !url.contains('.'))) { website.error = "Enter a valid website URL"; return@button }
            if (FirebaseBackend.db == null) { error.text = "Firebase is unavailable. Your profile was not saved."; return@button }
            setBusy(true)
            val normalizedUrl = if (url.isEmpty()) "" else if (url.startsWith("http://") || url.startsWith("https://")) url else "https://$url"
            val uri = selectedPhoto
            if (uri != null) {
                Thread {
                    val photoData = try { encodeProfilePhoto(uri) } catch (e: Exception) { null }
                    runOnUiThread {
                        if (photoData == null) { setBusy(false); error.text = "Could not prepare that image. Try another photo." }
                        else saveProfile(user.uid, name, handle, about, normalizedUrl, photoData, error)
                    }
                }.start()
            } else saveProfile(user.uid, name, handle, about, normalizedUrl, currentProfile["photoData"] as? String, error)
        }
        button("View public profile") { showPublicProfile(currentProfile) }
        addBottom()
    }

    private fun saveProfile(uid: String, name: String, handle: String, bio: String, website: String, photoData: String?, error: TextView) {
        val db = FirebaseBackend.db ?: run { setBusy(false); error.text = "Firebase is unavailable."; return }
        val authUid = FirebaseBackend.auth?.currentUser?.uid
        if (authUid == null || authUid != uid) {
            Log.w("HiraBhaiProfile", "Profile save stopped: authUid=$authUid targetProfileUid=$uid")
            setBusy(false); error.text = "Your sign-in session changed. Sign in again before saving your username."; return
        }
        Log.i("HiraBhaiProfile", "Saving authenticated profile: authUid=$authUid privatePath=/profiles/$uid usernamePath=/usernames/$handle publicPath=/publicProfiles/$handle")
        val profileRef = db.collection("profiles").document(uid)
        db.runTransaction { tx ->
            // Read the authoritative UID document first. Do not rely on the
            // editor's cached profile when deciding which username to release.
            val existingProfile = tx.get(profileRef)
            val storedUid = existingProfile.getString("uid")
            if (existingProfile.exists() && storedUid != null && storedUid != authUid) {
                throw IllegalStateException("The saved profile belongs to a different account. Sign out and sign back in before trying again.")
            }
            val oldHandle = (existingProfile.getString("username") ?: currentProfile["username"] as? String)
                ?.lowercase(Locale.ROOT)
            val creatorId = existingProfile.getString("creatorId")
                ?: currentProfile["creatorId"] as? String
                ?: UUID.randomUUID().toString()
            val newNameRef = db.collection("usernames").document(handle)
            val newPublicRef = db.collection("publicProfiles").document(handle)
            val oldNameRef = oldHandle?.takeIf { it != handle }?.let { db.collection("usernames").document(it) }
            val oldPublicRef = oldHandle?.takeIf { it != handle }?.let { db.collection("publicProfiles").document(it) }
            val claimed = tx.get(newNameRef)
            val oldClaim = if (oldNameRef != null) tx.get(oldNameRef) else null
            val oldPublic = if (oldPublicRef != null) tx.get(oldPublicRef) else null
            if (claimed.exists() && claimed.getString("creatorId") != creatorId && claimed.getString("uid") != authUid) throw IllegalArgumentException("That username is already taken. Choose another one.")

            // Keep the profile schema deliberately small while retaining its
            // existing creator ID and photo when the user leaves the photo alone.
            val profile = hashMapOf<String, Any>(
                "uid" to authUid,
                "creatorId" to creatorId,
                "fullName" to name,
                "username" to handle,
                "bio" to bio,
                "websiteUrl" to website,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            val retainedPhoto = photoData?.takeIf { it.isNotBlank() }
                ?: existingProfile.getString("photoData")
                ?: currentProfile["photoData"] as? String
            if (!retainedPhoto.isNullOrBlank()) profile["photoData"] = retainedPhoto
            val publicProfile = publicProfileFields(profile)

            if (!claimed.exists() || claimed.getString("creatorId") != creatorId) tx.set(newNameRef, mapOf("creatorId" to creatorId))
            if (oldNameRef != null) {
                if (oldClaim?.getString("creatorId") == creatorId || oldClaim?.getString("uid") == authUid) tx.delete(oldNameRef)
            }
            if (oldPublicRef != null && oldPublic?.getString("username") == oldHandle) tx.delete(oldPublicRef)
            tx.set(profileRef, profile)
            tx.set(newPublicRef, publicProfile)
            profile
        }.addOnSuccessListener { savedProfile ->
            setBusy(false)
            currentProfile = hashMapOf<String, Any>().apply { putAll(savedProfile) }
            val authUpdate = com.google.firebase.auth.UserProfileChangeRequest.Builder().setDisplayName(name).build()
            FirebaseBackend.auth?.currentUser?.updateProfile(authUpdate)?.addOnFailureListener { Log.w("HiraBhaiProfile", "Firebase Auth display name did not update although the Firestore creator profile saved", it) }
            Log.i("HiraBhaiProfile", "Firestore committed profile save: authUid=$authUid path=/profiles/$uid username=$handle")
            val resumeVideoUpload = returnToVideoUploadAfterProfileSave && selectedVideoUri != null
            returnToVideoUploadAfterProfileSave = false
            if (resumeVideoUpload) {
                info("Profile saved", "Your creator profile is ready. Tap Upload video to continue.")
                showVideoUploadForm(selectedVideoUri!!)
            } else {
                info("Profile saved", "Your profile was saved to Firebase and is available at @$handle.")
                showAccount()
            }
        }.addOnFailureListener {
            Log.e("HiraBhaiProfile", "Firestore profile transaction failed: authUid=$authUid target=/profiles/$uid username=/usernames/$handle public=/publicProfiles/$handle", it)
            setBusy(false)
            val detail = if (it is com.google.firebase.firestore.FirebaseFirestoreException && it.code == com.google.firebase.firestore.FirebaseFirestoreException.Code.PERMISSION_DENIED) {
                "Firebase rejected the secure profile transaction for /profiles/$uid, /usernames/$handle, or /publicProfiles/$handle. Confirm the deployed Firestore rules allow the signed-in UID to update its own profile and claim this username. No save was confirmed."
            } else friendlyError(it)
            error.text = detail
        }
    }

    private fun publicProfileFields(profile: Map<String, Any>): HashMap<String, Any> {
        val safe = hashMapOf<String, Any>(
            "username" to (profile["username"] as? String).orEmpty(),
            "searchName" to (profile["fullName"] as? String).orEmpty().trim().lowercase(),
            "creatorId" to (profile["creatorId"] as? String).orEmpty(),
            "fullName" to (profile["fullName"] as? String).orEmpty(),
            "bio" to (profile["bio"] as? String).orEmpty(),
            "websiteUrl" to (profile["websiteUrl"] as? String).orEmpty(),
            "updatedAt" to (profile["updatedAt"] ?: FieldValue.serverTimestamp())
        )
        (profile["photoData"] as? String)?.let { safe["photoData"] = it }
        return safe
    }

    private fun ensurePublicCreatorProfile(uid: String, profile: Map<String, Any>) {
        val handle = profile["username"] as? String ?: return
        if (!Regex("^[a-z0-9_]{3,24}$").matches(handle)) return
        val db = FirebaseBackend.db ?: return
        if (FirebaseBackend.auth?.currentUser?.uid != uid) return
        val privateRef = db.collection("profiles").document(uid)
        val publicRef = db.collection("publicProfiles").document(handle)
        val directoryRef = db.collection("userDirectory").document(handle)
        db.runTransaction { tx ->
            val privateSnapshot = tx.get(privateRef)
            if (!privateSnapshot.exists()) return@runTransaction false
            val directorySnapshot = tx.get(directoryRef)
            val privateData = HashMap(privateSnapshot.data ?: emptyMap())
            val creatorId = privateData["creatorId"] as? String ?: UUID.randomUUID().toString()
            privateData["creatorId"] = creatorId
            val existingPublic = tx.get(publicRef)
            val shouldUpdatePrivate = privateSnapshot.getString("creatorId") == null
            val shouldUpdatePublic = !existingPublic.exists() || existingPublic.getString("creatorId") != creatorId || existingPublic.getString("searchName") == null
            val shouldUpdateDirectory = directorySnapshot.getString("uid") != uid
            if (shouldUpdatePrivate) {
                privateData["updatedAt"] = FieldValue.serverTimestamp()
                tx.set(privateRef, privateData)
            }
            if (shouldUpdatePublic) tx.set(publicRef, publicProfileFields(privateData))
            if (shouldUpdateDirectory) tx.set(directoryRef, mapOf("uid" to uid))
            shouldUpdatePrivate || shouldUpdatePublic || shouldUpdateDirectory
        }.addOnFailureListener { Log.w("HiraBhai", "Could not publish creator profile", it) }
    }

    private fun showProfileLookup() = showCreatorSearch("")

    private fun showCreatorSearch(initialQuery: String) {
        selected = "Subscriptions"; base(); heading("Search creators", "Search public profiles by username or display name")
        val query = field("Creator name or username", android.text.InputType.TYPE_CLASS_TEXT).apply {
            setText(initialQuery); imeOptions = EditorInfo.IME_ACTION_SEARCH
        }
        content.addView(query)
        val loading = ProgressBar(this).apply { isIndeterminate = true; visibility = View.GONE }
        content.addView(loading, LinearLayout.LayoutParams(dp(36), dp(36)).apply { gravity = Gravity.CENTER; bottomMargin = dp(8) })
        val status = label("Enter a creator username or display name to search.", 14, secondaryText, false)
        content.addView(status)
        val results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        button("Search") { runCreatorSearch(query.text.toString(), loading, status, results) }
        content.addView(results)
        query.setOnEditorActionListener { _, _, _ -> runCreatorSearch(query.text.toString(), loading, status, results); true }
        if (initialQuery.isNotBlank()) runCreatorSearch(initialQuery, loading, status, results)
        addBottom()
    }

    private fun runCreatorSearch(rawQuery: String, loading: ProgressBar, status: TextView, results: LinearLayout) {
        val entered = rawQuery.trim().removePrefix("@").trim()
        val query = entered.lowercase()
        results.removeAllViews()
        if (query.isBlank()) { loading.visibility = View.GONE; status.text = "Enter a creator username or display name to search."; return }
        val db = FirebaseBackend.db
        if (db == null) { loading.visibility = View.GONE; status.text = "Creator search is unavailable because Firebase is not configured."; return }
        val signedIn = FirebaseBackend.auth?.currentUser != null
        val projectId = try { com.google.firebase.FirebaseApp.getInstance().options.projectId ?: "unknown" } catch (_: Exception) { "unavailable" }
        Log.i("CreatorSearch", "Search started; project=$projectId; authSignedIn=$signedIn; collection=/publicProfiles")
        loading.visibility = View.VISIBLE; status.text = "Searching public creator profiles…"
        val collection = db.collection("publicProfiles")
        val end = "$query\uf8ff"
        val usernameTask = collection.whereGreaterThanOrEqualTo("username", query).whereLessThanOrEqualTo("username", end).limit(20).get()
        val displayNameTask = collection.whereGreaterThanOrEqualTo("searchName", query).whereLessThanOrEqualTo("searchName", end).limit(20).get()
        val exactCaseNameTask = collection.whereGreaterThanOrEqualTo("fullName", entered).whereLessThanOrEqualTo("fullName", "$entered\uf8ff").limit(20).get()
        val titleCase = entered.split(Regex("\\s+")).joinToString(" ") { word -> word.replaceFirstChar { it.uppercase() } }
        val titleCaseNameTask = collection.whereGreaterThanOrEqualTo("fullName", titleCase).whereLessThanOrEqualTo("fullName", "$titleCase\uf8ff").limit(20).get()
        val matches = LinkedHashMap<String, com.google.firebase.firestore.DocumentSnapshot>()
        val failures = mutableListOf<String>()
        var completed = 0
        val tasks = mutableListOf(
            "username prefix range" to usernameTask,
            "normalized display-name prefix range" to displayNameTask,
            "entered-case display-name prefix range" to exactCaseNameTask
        )
        if (titleCase != entered) tasks.add("title-case display-name prefix range" to titleCaseNameTask)
        tasks.forEach { task ->
            val (operation, firestoreTask) = task
            firestoreTask.addOnCompleteListener { result ->
                if (result.isSuccessful) result.result?.documents?.forEach { doc -> matches[doc.getString("creatorId") ?: doc.id] = doc }
                else {
                    val error = result.exception
                    val detail = "/publicProfiles ($operation)"
                    failures.add(detail)
                    Log.e("CreatorSearch", "Firestore query failed: collection=/publicProfiles operation=$operation authSignedIn=$signedIn project=$projectId", error)
                }
                completed++
                if (completed == tasks.size) {
                    loading.visibility = View.GONE
                    if (failures.isNotEmpty()) {
                        val issue = failures.joinToString("; ")
                        status.text = "Search failed for $issue. Check Firebase rules and try again."
                        Log.e("CreatorSearch", "Search completed with denied/failed operations: $issue")
                        return@addOnCompleteListener
                    }
                    if (matches.isEmpty()) { status.text = "No creators found for ‘$query’. Try a username or display name."; return@addOnCompleteListener }
                    status.text = "${matches.size} creator${if (matches.size == 1) "" else "s"} found"
                    matches.values.forEach { doc -> addCreatorSearchResult(results, doc.data ?: emptyMap()) }
                }
            }
        }
    }

    private fun addCreatorSearchResult(results: LinearLayout, profile: Map<String, Any>) {
        val username = profile["username"] as? String ?: return
        val creatorId = profile["creatorId"] as? String
        val name = profile["fullName"] as? String ?: username
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = round(Color.WHITE, 18)
            setPadding(dp(14), dp(13), dp(14), dp(13)); isClickable = true; isFocusable = true
            setOnClickListener { showPublicProfile(profile) }
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val photo = ImageView(this).apply {
            setImageResource(android.R.drawable.ic_menu_camera); scaleType = ImageView.ScaleType.CENTER_CROP
            background = round(0xffdce8ed.toInt(), 100); clipToOutline = true
            layoutParams = LinearLayout.LayoutParams(dp(54), dp(54)).apply { rightMargin = dp(12) }
        }
        (profile["photoData"] as? String)?.let { showProfilePhoto(it, photo) }
        val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        details.addView(label(name, 16, primaryText, true))
        details.addView(label("@$username", 13, secondaryText, false).apply { setPadding(0, dp(3), 0, 0) })
        top.addView(photo); top.addView(details, LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(top)
        if (creatorId != null) {
            addSearchSubscriptionButton(card, username, creatorId)
            val support = TextView(this).apply {
                text = "Support this creator"; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
                setTextColor(primaryText); background = round(0xffffeddf.toInt(), 14)
                setPadding(dp(12), dp(11), dp(12), dp(11)); isClickable = true; isFocusable = true
                setOnClickListener { showDonationAmounts(creatorId, name) }
            }
            card.addView(support, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        }
        else card.addView(label("Subscribe is unavailable until this creator profile is updated.", 12, secondaryText, false).apply { setPadding(0, dp(10), 0, 0) })
        results.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
    }

    private fun showDonationAmounts(creatorId: String, creatorName: String) {
        val user = FirebaseBackend.auth?.currentUser ?: run { showAuth(false); return }
        val projectId = try { com.google.firebase.FirebaseApp.getInstance().options.projectId } catch (_: Exception) { null }
        if (projectId.isNullOrBlank()) return info("Donations unavailable", "Firebase payment backend is not configured.")
        setBusy(true)
        aiScope.launch {
            try {
                val token = user.getIdToken(false).await().token.orEmpty()
                val response = withContext(Dispatchers.IO) { postPaymentFunction(projectId, "getDonationOptions", token, JSONObject().put("creatorId", creatorId)) }
                val paise = response.optJSONArray("amounts") ?: JSONArray()
                if (paise.length() == 0) throw IllegalStateException("This creator has not enabled donations yet.")
                val values = (0 until paise.length()).map { paise.getInt(it) }.filter { it in listOf(5000, 10000, 50000) }
                val labels = values.map { "₹${it / 100}" }.toTypedArray()
                runOnUiThread {
                    AlertDialog.Builder(this@MainActivity).setTitle("Support $creatorName")
                        .setMessage("Choose a one-time donation. Payment is verified by the secure Hira Bhai server.")
                        .setItems(labels) { _, which -> startCreatorDonation(creatorId, values[which]) }
                        .setNegativeButton("Cancel", null).show()
                }
            } catch (error: Exception) { info("Donations unavailable", error.message ?: friendlyError(error)) }
            finally { setBusy(false) }
        }
    }

    private fun configureDonationAmounts(creatorId: String) {
        val choices = arrayOf("₹50", "₹100", "₹500")
        val selectedAmounts = booleanArrayOf(true, true, true)
        AlertDialog.Builder(this).setTitle("Donation options")
            .setMessage("Choose which suggested amounts viewers can send. Saving requires an active, verified payout account.")
            .setMultiChoiceItems(choices, selectedAmounts) { _, which, checked -> selectedAmounts[which] = checked }
            .setNegativeButton("Cancel", null).setPositiveButton("Save") { _, _ ->
                val amounts = JSONArray()
                selectedAmounts.forEachIndexed { index, checked -> if (checked) amounts.put(intArrayOf(5000, 10000, 50000)[index]) }
                if (amounts.length() == 0) { info("Options not saved", "Choose at least one donation amount."); return@setPositiveButton }
                val user = FirebaseBackend.auth?.currentUser ?: run { showAuth(false); return@setPositiveButton }
                val projectId = try { com.google.firebase.FirebaseApp.getInstance().options.projectId } catch (_: Exception) { null }
                if (projectId.isNullOrBlank()) { info("Options not saved", "Firebase payment backend is not configured."); return@setPositiveButton }
                setBusy(true)
                aiScope.launch {
                    try {
                        val token = user.getIdToken(true).await().token.orEmpty()
                        withContext(Dispatchers.IO) { postPaymentFunction(projectId, "updateDonationOptions", token, JSONObject().put("creatorId", creatorId).put("amounts", amounts)) }
                        info("Donation options saved", "Viewers can now choose from your selected suggested amounts.")
                    } catch (error: Exception) { info("Options not saved", error.message ?: friendlyError(error)) }
                    finally { setBusy(false) }
                }
            }.show()
    }

    private fun addSearchSubscriptionButton(card: LinearLayout, username: String, creatorId: String, countLabel: TextView? = null) {
        val user = FirebaseBackend.auth?.currentUser
        val button = TextView(this).apply {
            text = if (user == null) "Log in to subscribe" else "Checking…"
            textSize = 14f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setTextColor(Color.WHITE); background = round(mint, 14)
            setPadding(dp(12), dp(11), dp(12), dp(11)); isClickable = true; isFocusable = true
        }
        button.setOnClickListener { if (user == null) showAuth(false) }
        card.addView(button, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        if (user == null) return
        val db = FirebaseBackend.db ?: run { button.text = "Subscriptions unavailable"; button.isEnabled = false; return }
        db.collection("profiles").document(user.uid).get().addOnSuccessListener { own ->
            if (!own.exists()) { button.text = "Create a profile to subscribe"; button.isEnabled = false; return@addOnSuccessListener }
            if (own.getString("creatorId") == creatorId) { button.text = "Your profile"; button.isEnabled = false; return@addOnSuccessListener }
            val edge = db.collection("subscriptions").document(user.uid).collection("creators").document(creatorId)
            val stats = db.collection("creatorStats").document(creatorId)
            val notification = db.collection("notifications").document(creatorId).collection("items").document("subscribe_${user.uid}")
            edge.get().addOnSuccessListener { saved ->
                var subscribed = saved.exists()
                fun setLabel() { button.text = if (subscribed) "Unsubscribe" else "Subscribe" }
                setLabel(); button.setOnClickListener {
                    button.isEnabled = false
                    db.runTransaction { tx ->
                        val current = tx.get(edge); val countDoc = tx.get(stats)
                        val count = (countDoc.getLong("subscriberCount") ?: 0L).coerceAtLeast(0L)
                        if (current.exists()) { tx.delete(edge); if (countDoc.exists()) tx.update(stats, "subscriberCount", (count - 1).coerceAtLeast(0L)); false }
                        else {
                            tx.set(edge, mapOf("subscriberUid" to user.uid, "creatorId" to creatorId, "creatorUsername" to username, "createdAt" to FieldValue.serverTimestamp()))
                            tx.set(stats, mapOf("creatorId" to creatorId, "subscriberCount" to count + 1))
                            tx.set(notification, notificationData("subscribe", own.getString("creatorId") ?: "", usernameOrFallback(own), own.getString("fullName") ?: "Creator", "subscribed to your channel", creatorId, username))
                            true
                        }
                    }.addOnSuccessListener { subscribed = it; setLabel(); button.isEnabled = true
                        stats.get().addOnSuccessListener { countDoc ->
                            val total = (countDoc.getLong("subscriberCount") ?: 0L).coerceAtLeast(0L)
                            countLabel?.text = "$total ${if (total == 1L) "subscriber" else "subscribers"}"
                        }
                    }
                        .addOnFailureListener { button.isEnabled = true; info("Subscription", friendlyError(it)) }
                }
            }.addOnFailureListener { button.text = "Could not check subscription"; button.isEnabled = false }
        }.addOnFailureListener { button.text = "Could not verify account profile"; button.isEnabled = false }
    }

    private fun usernameOrFallback(profile: com.google.firebase.firestore.DocumentSnapshot): String = profile.getString("username") ?: "creator"

    private fun loadPublicCreator(handle: String, errorView: TextView?) {
        if (!Regex("^[a-z0-9_]{3,24}$").matches(handle)) {
            if (errorView != null) errorView.text = "That creator URL is invalid." else info("Creator profile", "That creator URL is invalid.")
            return
        }
        val db = FirebaseBackend.db
        if (db == null) {
            if (errorView != null) errorView.text = "Firebase is not configured." else info("Creator profile", "Firebase is not configured.")
            return
        }
        if (errorView == null) { selected = "Subscriptions"; base(); heading("Creator profile", "Loading /u/$handle …"); addBottom() }
        db.collection("publicProfiles").document(handle).get()
            .addOnSuccessListener { doc ->
                if (doc.exists()) showPublicProfile(doc.data ?: emptyMap())
                else if (errorView != null) errorView.text = "No public creator profile found for @$handle."
                else { base(); heading("Creator not found", "There is no published profile at /u/$handle."); action("Search creators", "Try another username.") { showProfileLookup() }; addBottom() }
            }
            .addOnFailureListener { error ->
                if (errorView != null) errorView.text = friendlyError(error)
                else { base(); heading("Could not load creator", friendlyError(error)); addBottom() }
            }
    }

    private fun showPublicProfile(profile: Map<String, Any>, communityTab: Boolean = false) {
        val handle = profile["username"] as? String ?: "creator"
        val channelName = profile["fullName"] as? String ?: "Creator channel"
        base(); heading(channelName, "@$handle")
        val photoData = profile["photoData"] as? String
        if (!photoData.isNullOrBlank()) {
            val image = ImageView(this).apply { setImageResource(android.R.drawable.ic_menu_camera); scaleType = ImageView.ScaleType.CENTER_CROP; background = round(0xff315573.toInt(), 100); clipToOutline = true; layoutParams = LinearLayout.LayoutParams(dp(112), dp(112)).apply { gravity = Gravity.CENTER; bottomMargin = dp(16) } }
            content.addView(image); showProfilePhoto(photoData, image)
        }
        val bio = (profile["bio"] as? String).orEmpty().ifBlank { "This creator hasn’t added a bio yet." }
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = round(Color.WHITE, 18); setPadding(dp(18), dp(18), dp(18), dp(18)) }
        card.addView(label(bio, 16, primaryText, false))
        val site = profile["websiteUrl"] as? String
        if (!site.isNullOrBlank()) { val link = label(site, 15, mint, true).apply { setPadding(0, dp(16), 0, 0); setOnClickListener { try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(site))) } catch (_: Exception) {} } }; card.addView(link) }
        content.addView(card)
        content.addView(label("Public profile route: /u/$handle", 13, secondaryText, false).apply { setPadding(0, dp(14), 0, dp(8)) })
        val creatorId = profile["creatorId"] as? String
        val countLabel = if (creatorId != null) subscriberCountLabel(creatorId) else null
        addSubscriptionControl(handle, creatorId, countLabel)
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(4)) }
        listOf("Videos" to false, "Community" to true).forEach { (title, community) ->
            val tab = TextView(this).apply { text = title; textSize = 14f; gravity = Gravity.CENTER; setTextColor(if (community == communityTab) 0xff073344.toInt() else primaryText); background = if (community == communityTab) round(0xff25b9a0.toInt(), 30) else glass(0x22ffffff, 30); setPadding(dp(20), dp(9), dp(20), dp(9)); setOnClickListener { showPublicProfile(profile, community) } }
            tabs.addView(tab, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(6) })
        }
        content.addView(tabs)
        if (creatorId != null && communityTab) {
            loadCreatorCommunityPosts(creatorId, profile["uid"] == FirebaseBackend.auth?.currentUser?.uid)
        } else if (creatorId != null) {
            loadCreatorVideos(profile, creatorId, handle)
            loadCreatorShorts(profile, creatorId)
            loadCreatorPublicPlaylists(creatorId)
            loadCreatorAudios(creatorId)
        }
        section("About")
        content.addView(label("Channel name", 12, secondaryText, true))
        content.addView(label(channelName, 16, primaryText, false).apply { setPadding(0, dp(3), 0, dp(10)) })
        button("Share creator profile") {
            val share = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, "Hira Bhai creator profile: hirabhai:/u/$handle ( /u/$handle )")
            startActivity(Intent.createChooser(share, "Share creator profile"))
        }
        if (FirebaseBackend.auth?.currentUser?.uid != profile["uid"]) {
            button("⚑  Report this creator") { creatorId?.let { showReportDialog("user", it) } }
        }
        button("Search creators") { showProfileLookup() }; addBottom()
    }

    private fun loadCreatorPublicPlaylists(creatorId: String) {
        section("Public playlists")
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(list)
        val db = FirebaseBackend.db ?: run { list.addView(label("Public playlists are unavailable.", 13, secondaryText, false)); return }
        db.collection("publicPlaylists").whereEqualTo("creatorId", creatorId).whereEqualTo("visibility", "public")
            .orderBy("updatedAt", com.google.firebase.firestore.Query.Direction.DESCENDING).limit(20).get()
            .addOnSuccessListener { snapshot ->
                if (snapshot.isEmpty) list.addView(label("This creator has no public playlists yet.", 13, secondaryText, false))
                snapshot.documents.forEach { doc ->
                    val row = LinearLayout(this).apply {
                        orientation = LinearLayout.VERTICAL; background = round(Color.WHITE, 15); setPadding(dp(13), dp(12), dp(13), dp(12))
                        isClickable = true; isFocusable = true; setOnClickListener { showPublicPlaylist(doc.id) }
                    }
                    row.addView(label(doc.getString("name") ?: "Playlist", 15, primaryText, true))
                    row.addView(label("${doc.getLong("videoCount") ?: 0L} videos", 12, secondaryText, false).apply { setPadding(0, dp(3), 0, 0) })
                    if (!doc.getString("description").isNullOrBlank()) row.addView(label(doc.getString("description") ?: "", 12, secondaryText, false).apply { setPadding(0, dp(4), 0, 0) })
                    list.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
                }
            }
            .addOnFailureListener { list.addView(label("Could not load public playlists: ${friendlyError(it)}", 13, secondaryText, false)) }
    }

    private val communityImageUris = mutableListOf<Uri>()

    private fun showCommunityPostComposer() {
        val user = FirebaseBackend.auth?.currentUser ?: run { showAuth(false); return }
        selected = "Create Community Post"; base(); heading("Create a post", "Share an update or images with your community")
        val input = EditText(this).apply { hint = "What would you like to share?"; minLines = 4; maxLines = 9; gravity = Gravity.TOP; textSize = 15f; setTextColor(primaryText); setHintTextColor(secondaryText); background = round(Color.WHITE, 16); setPadding(dp(14), dp(12), dp(14), dp(12)); filters = arrayOf(android.text.InputFilter.LengthFilter(4000)) }
        content.addView(input, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        val imageStatus = label("No images selected. Add up to 4 images.", 13, secondaryText, false)
        imageStatus.text = if (communityImageUris.isEmpty()) "No images selected. Add up to 4 images." else "${communityImageUris.size} image(s) selected."
        content.addView(imageStatus)
        button("Choose images") { chooseCommunityImages() }
        button("Remove selected images") { communityImageUris.clear(); imageStatus.text = "No images selected. Add up to 4 images." }
        val visibility = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Public", "Private · only me")) }
        content.addView(label("Visibility", 14, primaryText, true)); content.addView(visibility, LinearLayout.LayoutParams(-1, dp(48)))
        content.addView(label("Images are uploaded to your Firebase Storage bucket. Public images are readable only with a public post; private posts remain owner-only. Upload requires Firebase Storage to be enabled.", 12, secondaryText, false).apply { setPadding(0, dp(12), 0, dp(14)) })
        button("Publish post") {
            val text = input.text.toString().trim()
            if (text.isBlank() && communityImageUris.isEmpty()) { input.error = "Add text or at least one image"; return@button }
            if (communityImageUris.size > 4) { info("Too many images", "Select up to 4 images per post."); return@button }
            createCommunityPost(user.uid, text, if (visibility.selectedItemPosition == 0) "public" else "private")
        }
        addBottom()
    }

    private fun chooseCommunityImages() {
        if (FirebaseBackend.auth?.currentUser == null) { showAuth(false); return }
        try { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).setType("image/*").putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true).addCategory(Intent.CATEGORY_OPENABLE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION), 74) }
        catch (error: Exception) { info("Image picker unavailable", friendlyError(error)) }
    }

    private fun createCommunityPost(uid: String, text: String, visibility: String) {
        val db = FirebaseBackend.db ?: run { info("Post unavailable", "Firestore is not configured."); return }
        val storage = FirebaseBackend.storage ?: run { info("Image upload unavailable", FirebaseBackend.storageSetupError ?: "Firebase Storage is not configured."); return }
        val uris = communityImageUris.toList()
        if (uris.size > 4) { info("Too many images", "Select up to 4 images."); return }
        db.collection("profiles").document(uid).get().addOnSuccessListener { profile ->
            val creatorId = profile.getString("creatorId")
            val username = profile.getString("username")
            val fullName = profile.getString("fullName")
            if (!profile.exists() || creatorId.isNullOrBlank() || username.isNullOrBlank() || fullName.isNullOrBlank()) { info("Creator profile required", "Complete your creator profile before posting."); return@addOnSuccessListener }
            val postRef = db.collection("communityPosts").document()
            val paths = mutableListOf<String>()
            val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
            val status = label("Preparing post…", 13, primaryText, false)
            val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0); addView(status); addView(progress, LinearLayout.LayoutParams(-1, dp(12)).apply { topMargin = dp(10) }) }
            val dialog = AlertDialog.Builder(this).setTitle("Publishing post").setView(body).setNegativeButton("Hide", null).create(); dialog.show()
            fun fail(error: Exception) {
                paths.forEach { path -> storage.reference.child(path).delete() }
                dialog.dismiss(); Log.e("HiraBhaiCommunity", "Post upload failed id=${postRef.id}", error); info("Post failed", friendlyError(error))
            }
            fun savePost() {
                val payload = mapOf("postId" to postRef.id, "ownerUid" to uid, "creatorId" to creatorId, "creatorUsername" to username, "creatorName" to fullName, "text" to text, "visibility" to visibility, "imagePaths" to paths.toList(), "createdAt" to FieldValue.serverTimestamp(), "updatedAt" to FieldValue.serverTimestamp(), "likeCount" to 0, "commentCount" to 0)
                postRef.set(payload).addOnSuccessListener { dialog.dismiss(); communityImageUris.clear(); info("Post published", "Your community post is saved."); showCommunityFeed() }.addOnFailureListener(::fail)
            }
            if (uris.isEmpty()) { savePost(); return@addOnSuccessListener }
            fun uploadAt(index: Int) {
                if (index >= uris.size) { savePost(); return }
                val uri = uris[index]
                val mime = contentResolver.getType(uri) ?: "image/jpeg"
                if (!mime.startsWith("image/")) { fail(IllegalArgumentException("Selected file is not an image")); return }
                val path = "communityPosts/$visibility/$creatorId/${postRef.id}/image_$index"
                val metadata = com.google.firebase.storage.StorageMetadata.Builder().setContentType(mime).build()
                status.text = "Uploading image ${index + 1} of ${uris.size}…"
                storage.reference.child(path).putFile(uri, metadata)
                    .addOnProgressListener { task -> if (task.totalByteCount > 0) progress.progress = ((index * 100) + (task.bytesTransferred * 100 / task.totalByteCount) / uris.size).toInt() }
                    .addOnSuccessListener { paths.add(path); uploadAt(index + 1) }
                    .addOnFailureListener(::fail)
            }
            uploadAt(0)
        }.addOnFailureListener { info("Post unavailable", friendlyError(it)) }
    }

    private fun showCommunityFeed() {
        selected = "Community Feed"; base(); heading("Community", "Posts from creators you follow")
        val user = FirebaseBackend.auth?.currentUser ?: run { action("Sign in to see your community", "Your creator feed is based on your subscriptions.") { showAuth(false) }; addBottom(); return }
        button("Create a post") { showCommunityPostComposer() }
        button("Refresh community feed") { showCommunityFeed() }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; content.addView(list)
        val db = FirebaseBackend.db ?: run { list.addView(label("Firestore is not configured.", 13, secondaryText, false)); addBottom(); return }
        db.collection("subscriptions").document(user.uid).collection("creators").limit(200).get().addOnSuccessListener { subs ->
            val ids = subs.documents.mapNotNull { it.getString("creatorId") }.distinct()
            if (ids.isEmpty()) { list.addView(label("Subscribe to creators to see their community posts here.", 14, secondaryText, false)); return@addOnSuccessListener }
            val requests = ids.chunked(10).map { batch ->
                db.collection("communityPosts").whereIn("creatorId", batch).whereEqualTo("visibility", "public").orderBy("createdAt", com.google.firebase.firestore.Query.Direction.DESCENDING).limit(50).get()
            }
            com.google.android.gms.tasks.Tasks.whenAllSuccess<com.google.firebase.firestore.QuerySnapshot>(requests).addOnSuccessListener { results ->
                val posts = results.flatMap { it.documents }.distinctBy { it.id }.sortedByDescending { it.getTimestamp("createdAt")?.toDate()?.time ?: 0L }.take(50)
                if (posts.isEmpty()) list.addView(label("No public community posts from your subscriptions yet.", 14, secondaryText, false))
                posts.forEach { addCommunityPostCard(list, it.id, it.data ?: emptyMap(), false) }
            }.addOnFailureListener { list.addView(label("Could not load community posts: ${friendlyError(it)}", 13, secondaryText, false)) }
        }.addOnFailureListener { list.addView(label("Could not load subscriptions: ${friendlyError(it)}", 13, secondaryText, false)) }
        addBottom()
    }

    private fun showCommunityPost(postId: String) {
        selected = "Community Feed"; base(); heading("Community post", "Shared from Hira Bhai")
        val holder = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; content.addView(holder)
        val db = FirebaseBackend.db ?: run { holder.addView(label("Firestore is not configured.", 13, secondaryText, false)); addBottom(); return }
        db.collection("communityPosts").document(postId).get().addOnSuccessListener { doc ->
            if (!doc.exists()) { holder.addView(label("This post is unavailable or private.", 14, secondaryText, false)); return@addOnSuccessListener }
            addCommunityPostCard(holder, doc.id, doc.data ?: emptyMap(), FirebaseBackend.auth?.currentUser?.uid == doc.getString("ownerUid"))
        }.addOnFailureListener { holder.addView(label("This post could not be opened. It may be private: ${friendlyError(it)}", 13, secondaryText, false)) }
        addBottom()
    }

    private fun loadCreatorCommunityPosts(creatorId: String, isOwner: Boolean) {
        section("Community posts")
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; content.addView(list)
        val db = FirebaseBackend.db ?: run { list.addView(label("Community posts are unavailable.", 13, secondaryText, false)); return }
        val currentUid = FirebaseBackend.auth?.currentUser?.uid
        val profileTask = currentUid?.let { db.collection("profiles").document(it).get() }
        profileTask?.addOnSuccessListener { ownProfile -> runCreatorCommunityQuery(db, list, creatorId, ownProfile.getString("creatorId") == creatorId) }
            ?.addOnFailureListener { error -> list.addView(label("Could not verify profile ownership: ${friendlyError(error)}", 13, secondaryText, false)) }
            ?: runCreatorCommunityQuery(db, list, creatorId, isOwner)
    }

    private fun runCreatorCommunityQuery(db: com.google.firebase.firestore.FirebaseFirestore, list: LinearLayout, creatorId: String, isOwner: Boolean) {
        if (isOwner) button("Create a post") { showCommunityPostComposer() }
        val currentUid = FirebaseBackend.auth?.currentUser?.uid
        val query: com.google.firebase.firestore.Query = if (isOwner && currentUid != null) db.collection("communityPosts").whereEqualTo("ownerUid", currentUid)
            else db.collection("communityPosts").whereEqualTo("creatorId", creatorId).whereEqualTo("visibility", "public")
        query.orderBy("createdAt", com.google.firebase.firestore.Query.Direction.DESCENDING).limit(40).get().addOnSuccessListener { snapshot ->
            if (snapshot.isEmpty) list.addView(label("No community posts yet.", 13, secondaryText, false))
            snapshot.documents.forEach { addCommunityPostCard(list, it.id, it.data ?: emptyMap(), isOwner) }
        }.addOnFailureListener { list.addView(label("Could not load community posts: ${friendlyError(it)}", 13, secondaryText, false)); Log.e("HiraBhaiCommunity", "Read failed: /communityPosts creatorId=$creatorId", it) }
    }

    private fun addCommunityPostCard(parent: LinearLayout, postId: String, post: Map<String, Any>, isOwner: Boolean) {
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = round(Color.WHITE, 16); setPadding(dp(14), dp(13), dp(14), dp(13)) }
        card.addView(label("${post["creatorName"] ?: "Creator"}  ·  @${post["creatorUsername"] ?: "creator"}", 13, mint, true))
        val date = (post["createdAt"] as? com.google.firebase.Timestamp)?.toDate()?.let { SimpleDateFormat("MMM d · h:mm a", Locale.getDefault()).format(it) } ?: "Just now"
        card.addView(label(date + if (post["visibility"] == "private") " · Private" else "", 11, secondaryText, false).apply { setPadding(0, dp(3), 0, dp(7)) })
        val postText = post["text"] as? String ?: ""
        if (postText.isNotBlank()) card.addView(label(postText, 15, primaryText, false).apply { setPadding(0, 0, 0, dp(8)) })
        val paths = (post["imagePaths"] as? List<*>)?.filterIsInstance<String>().orEmpty()
        paths.forEach { path ->
            val image = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; background = round(0xffdce8ed.toInt(), 12); layoutParams = LinearLayout.LayoutParams(-1, dp(220)).apply { bottomMargin = dp(7) }; contentDescription = "Community post image" }
            card.addView(image)
            FirebaseBackend.storage?.reference?.child(path)?.getBytes(5L * 1024 * 1024)?.addOnSuccessListener { bytes -> if (image.isAttachedToWindow) BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.let(image::setImageBitmap) }
                ?.addOnFailureListener { Log.w("HiraBhaiCommunity", "Image fetch failed for protected object $path", it) }
        }
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val like = TextView(this).apply { text = "♡ ${post["likeCount"] ?: 0}"; textSize = 13f; setTextColor(mint); setPadding(0, dp(7), dp(14), dp(5)); setOnClickListener { toggleCommunityLike(postId, this) } }
        controls.addView(like)
        controls.addView(TextView(this).apply { text = "Comments · ${post["commentCount"] ?: 0}"; textSize = 13f; setTextColor(primaryText); setPadding(dp(8), dp(7), dp(12), dp(5)); setOnClickListener { showCommunityComments(postId, post) } })
        controls.addView(TextView(this).apply { text = "Share"; textSize = 13f; setTextColor(primaryText); setPadding(dp(8), dp(7), dp(12), dp(5)); setOnClickListener { val shareText = (postText.ifBlank { "Community post on Hira Bhai" }) + "\nHira Bhai: hirabhai:/p/$postId"; startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, shareText), "Share post")) } })
        val own = FirebaseBackend.auth?.currentUser?.uid == post["ownerUid"]
        if (own) controls.addView(TextView(this).apply { text = "Delete"; textSize = 13f; setTextColor(0xffa33d46.toInt()); setPadding(dp(8), dp(7), 0, dp(5)); setOnClickListener { AlertDialog.Builder(this@MainActivity).setTitle("Delete post?").setMessage("This removes the post and its uploaded images.").setNegativeButton("Cancel", null).setPositiveButton("Delete") { _, _ -> deleteCommunityPost(postId, paths) }.show() } })
        if (own) controls.addView(TextView(this).apply { text = "Edit"; textSize = 13f; setTextColor(mint); setPadding(dp(8), dp(7), 0, dp(5)); setOnClickListener { editCommunityPost(postId, postText, paths.isNotEmpty()) } })
        card.addView(controls)
        val db = FirebaseBackend.db
        val uid = FirebaseBackend.auth?.currentUser?.uid
        if (db != null && uid != null) db.collection("communityPosts").document(postId).collection("likes").document(uid).get().addOnSuccessListener { if (it.exists()) like.text = "♥ ${post["likeCount"] ?: 0}" }
        parent.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
    }

    private fun toggleCommunityLike(postId: String, view: TextView) {
        val user = FirebaseBackend.auth?.currentUser ?: run { showAuth(false); return }
        val db = FirebaseBackend.db ?: return
        val post = db.collection("communityPosts").document(postId); val edge = post.collection("likes").document(user.uid)
        db.collection("profiles").document(user.uid).get().addOnSuccessListener { profile ->
            val senderCreatorId = profile.getString("creatorId").orEmpty()
            val senderUsername = profile.getString("username").orEmpty()
            val senderName = profile.getString("fullName").orEmpty()
            db.runTransaction { tx ->
                val postSnap = tx.get(post); val likeSnap = tx.get(edge); val count = (postSnap.getLong("likeCount") ?: 0L).coerceAtLeast(0)
                if (likeSnap.exists()) { tx.delete(edge); tx.update(post, "likeCount", (count - 1).coerceAtLeast(0)) }
                else {
                    tx.set(edge, mapOf("uid" to user.uid, "createdAt" to FieldValue.serverTimestamp())); tx.update(post, "likeCount", count + 1)
                    val targetCreator = postSnap.getString("creatorId").orEmpty(); val targetUsername = postSnap.getString("creatorUsername").orEmpty()
                    if (targetCreator.isNotBlank() && targetCreator != senderCreatorId && senderCreatorId.isNotBlank() && senderUsername.isNotBlank()) {
                        val notification = db.collection("notifications").document(targetCreator).collection("items").document("community_like_${postId}_${user.uid}")
                        tx.set(notification, notificationData("community_like", senderCreatorId, senderUsername, senderName, "liked your community post", targetCreator, targetUsername, communityPostId = postId))
                    }
                }
                !likeSnap.exists()
            }.addOnSuccessListener { liked -> view.text = (if (liked) "♥ " else "♡ ") + (view.text.toString().substringAfter(' ').toLongOrNull()?.let { if (liked) it + 1 else (it - 1).coerceAtLeast(0) } ?: "") }
                .addOnFailureListener { info("Like failed", friendlyError(it)); Log.e("HiraBhaiCommunity", "Like failed for communityPosts/$postId", it) }
        }.addOnFailureListener { info("Like failed", friendlyError(it)) }
    }

    private fun showCommunityComments(postId: String, post: Map<String, Any>) {
        val user = FirebaseBackend.auth?.currentUser ?: run { showAuth(false); return }
        val db = FirebaseBackend.db ?: return
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(5), dp(18), 0) }
        val comments = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        body.addView(comments)
        val input = EditText(this).apply { hint = "Write a comment"; maxLines = 3; filters = arrayOf(android.text.InputFilter.LengthFilter(1000)) }
        body.addView(input)
        val dialog = AlertDialog.Builder(this).setTitle("Community comments").setView(body).setNegativeButton("Close", null).setPositiveButton("Post", null).create(); dialog.show()
        val ref = db.collection("communityPosts").document(postId)
        val listener = ref.collection("comments").orderBy("createdAt", com.google.firebase.firestore.Query.Direction.ASCENDING).limit(100).addSnapshotListener { snapshot, error ->
            comments.removeAllViews()
            if (error != null) { comments.addView(label("Comments unavailable: ${friendlyError(error)}", 13, secondaryText, false)); return@addSnapshotListener }
            snapshot?.documents.orEmpty().forEach { doc -> comments.addView(label("@${doc.getString("authorUsername") ?: "creator"} · ${doc.getString("text") ?: ""}", 13, primaryText, false).apply { setPadding(0, dp(5), 0, dp(5)) }) }
            if (snapshot?.isEmpty == true) comments.addView(label("No comments yet.", 13, secondaryText, false))
        }
        dialog.setOnDismissListener { listener.remove() }
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val value = input.text.toString().trim()
            if (value.isBlank() || value.length > 1000) { input.error = "Enter 1–1,000 characters"; return@setOnClickListener }
            db.collection("profiles").document(user.uid).get().addOnSuccessListener { profile ->
                val creatorId = profile.getString("creatorId"); val username = profile.getString("username")
                if (creatorId.isNullOrBlank() || username.isNullOrBlank()) { info("Creator profile required", "Complete your creator profile before commenting."); return@addOnSuccessListener }
                val comment = ref.collection("comments").document()
                db.runTransaction { tx ->
                    val postSnap = tx.get(ref)
                    tx.set(comment, mapOf("uid" to user.uid, "authorCreatorId" to creatorId, "authorUsername" to username, "text" to value, "createdAt" to FieldValue.serverTimestamp()))
                    tx.update(ref, mapOf("commentCount" to (postSnap.getLong("commentCount") ?: 0L) + 1, "lastCommentId" to comment.id))
                    val targetCreator = postSnap.getString("creatorId").orEmpty(); val targetUsername = postSnap.getString("creatorUsername").orEmpty()
                    if (targetCreator.isNotBlank() && targetCreator != creatorId) {
                        val notification = db.collection("notifications").document(targetCreator).collection("items").document("community_comment_${postId}_${comment.id}")
                        tx.set(notification, notificationData("community_comment", creatorId, username, profile.getString("fullName") ?: "Creator", "commented on your community post", targetCreator, targetUsername, commentId = comment.id, communityPostId = postId))
                    }
                    null
                }
                    .addOnSuccessListener { input.text.clear() }.addOnFailureListener { info("Comment failed", friendlyError(it)) }
            }.addOnFailureListener { info("Comment failed", friendlyError(it)) }
        }
    }

    private fun deleteCommunityPost(postId: String, paths: List<String>) {
        val db = FirebaseBackend.db ?: return
        db.collection("communityPosts").document(postId).delete().addOnSuccessListener {
            paths.forEach { path -> FirebaseBackend.storage?.reference?.child(path)?.delete() }
            info("Post deleted", "Your post was removed."); showCommunityFeed()
        }.addOnFailureListener { info("Delete failed", friendlyError(it)) }
    }

    private fun editCommunityPost(postId: String, oldText: String, hasImages: Boolean) {
        val input = EditText(this).apply { setText(oldText); minLines = 3; maxLines = 8; gravity = Gravity.TOP; filters = arrayOf(android.text.InputFilter.LengthFilter(4000)) }
        AlertDialog.Builder(this).setTitle("Edit post").setView(input).setNegativeButton("Cancel", null).setPositiveButton("Save", null).create().also { dialog ->
            dialog.setOnShowListener { dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val value = input.text.toString().trim()
                if (value.isBlank() && !hasImages) { info("Post text required", "Posts need text or at least one image."); return@setOnClickListener }
                if (value.length > 4000) { input.error = "Maximum 4,000 characters"; return@setOnClickListener }
                FirebaseBackend.db?.collection("communityPosts")?.document(postId)?.update(mapOf("text" to value, "updatedAt" to FieldValue.serverTimestamp()))
                    ?.addOnSuccessListener { dialog.dismiss(); info("Post updated", "Your changes were saved."); showCommunityFeed() }
                    ?.addOnFailureListener { info("Edit failed", friendlyError(it)) }
            } }
            dialog.show()
        }
    }

    private fun loadCreatorVideos(profile: Map<String, Any>, creatorId: String, username: String) {
        section("Videos")
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(list)
        val db = FirebaseBackend.db ?: run { list.addView(label("Videos are unavailable right now.", 13, secondaryText, false)); return }
        val user = FirebaseBackend.auth?.currentUser
        val isOwner = user != null && profile["uid"] == user.uid
        val ownershipCheck = user?.let { db.collection("profiles").document(it.uid).get() }
        ownershipCheck?.addOnSuccessListener { ownProfile ->
            runCreatorVideoQuery(db, list, creatorId, ownProfile.getString("creatorId") == creatorId)
        }?.addOnFailureListener { error ->
            list.addView(label("Could not verify profile ownership: ${friendlyError(error)}", 13, secondaryText, false))
            Log.e("HiraBhaiVideo", "Owner profile check failed before reading videos", error)
        } ?: runCreatorVideoQuery(db, list, creatorId, false)
    }

    private fun runCreatorVideoQuery(db: com.google.firebase.firestore.FirebaseFirestore, list: LinearLayout, creatorId: String, isOwner: Boolean) {
        var query = db.collection("videos").whereEqualTo("creatorId", creatorId)
        if (!isOwner) query = query.whereEqualTo("visibility", "public")
        query.limit(40).get().addOnSuccessListener { snapshot ->
            val videos = snapshot.documents.filter { it.getBoolean("isShort") != true && (isOwner || it.getString("visibility") == "public") }
                .sortedByDescending { it.getTimestamp("createdAt")?.toDate()?.time ?: 0L }
            if (videos.isEmpty()) list.addView(label("No public videos yet.", 13, secondaryText, false))
            else videos.forEach { doc -> addVideoCard(list, doc.id, doc.data ?: emptyMap()) }
            if (isOwner) button("Upload a video") { chooseVideoUpload() }
        }.addOnFailureListener { error ->
            list.addView(label("Could not load creator videos: ${friendlyError(error)}", 13, secondaryText, false))
            Log.e("HiraBhaiVideo", "Read failed: /videos creatorId=$creatorId visibility=${if (isOwner) "owner" else "public"}", error)
        }
    }

    private fun loadCreatorShorts(profile: Map<String, Any>, creatorId: String) {
        section("Shorts")
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; content.addView(list)
        val db = FirebaseBackend.db ?: run { list.addView(label("Shorts are unavailable.", 13, secondaryText, false)); return }
        val user = FirebaseBackend.auth?.currentUser
        val ownTask = user?.let { db.collection("profiles").document(it.uid).get() }
        ownTask?.addOnSuccessListener { own -> runCreatorShortQuery(db, list, creatorId, own.getString("creatorId") == creatorId) }
            ?.addOnFailureListener { list.addView(label("Could not verify channel ownership: ${friendlyError(it)}", 13, secondaryText, false)) }
            ?: runCreatorShortQuery(db, list, creatorId, profile["uid"] == user?.uid)
    }

    private fun runCreatorShortQuery(db: com.google.firebase.firestore.FirebaseFirestore, list: LinearLayout, creatorId: String, isOwner: Boolean) {
        var query: com.google.firebase.firestore.Query = db.collection("videos").whereEqualTo("creatorId", creatorId).whereEqualTo("isShort", true)
        if (!isOwner) query = query.whereEqualTo("visibility", "public")
        query.orderBy("createdAt", com.google.firebase.firestore.Query.Direction.DESCENDING).limit(30).get()
            .addOnSuccessListener { snapshot ->
                val shorts = snapshot.documents.filter { it.getBoolean("isShort") == true && (isOwner || it.getString("visibility") == "public") }
                if (shorts.isEmpty()) list.addView(label("No public Shorts yet.", 13, secondaryText, false))
                shorts.forEach { addVideoCard(list, it.id, it.data ?: emptyMap()) }
                if (isOwner) button("＋ Upload a Short") { chooseShortUpload() }
            }
            .addOnFailureListener { list.addView(label("Could not load Shorts: ${friendlyError(it)}", 13, secondaryText, false)); Log.e("HiraBhaiShorts", "Creator Shorts query failed for $creatorId", it) }
    }

    private fun addVideoCard(parent: LinearLayout, videoId: String, video: Map<String, Any>) {
        val title = video["title"] as? String ?: "Untitled video"
        val creator = video["creatorName"] as? String ?: video["creatorUsername"] as? String ?: "Creator"
        val duration = (video["durationMs"] as? Number)?.toLong() ?: 0L
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = round(Color.WHITE, 18); setPadding(dp(10), dp(10), dp(10), dp(10))
            isClickable = true; isFocusable = true; setOnClickListener { openVideoById(videoId, video) }
        }
        val thumb = ImageView(this).apply {
            setImageResource(android.R.drawable.ic_media_play); scaleType = ImageView.ScaleType.CENTER_CROP
            background = round(0xffdce8ed.toInt(), 16); clipToOutline = true
            layoutParams = LinearLayout.LayoutParams(dp(112), dp(82))
        }
        row.addView(thumb)
        val text = columnText(title, "$creator  ·  ${formatDuration(duration)}").apply { setPadding(dp(12), 0, 0, 0) }
        row.addView(text, LinearLayout.LayoutParams(0, -2, 1f))
        parent.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        addVideoLibraryButtons(parent, videoId, video)
        (video["thumbnailStoragePath"] as? String)?.let { loadVideoThumbnail(it, thumb) }
    }

    private fun loadVideoThumbnail(path: String, target: ImageView) {
        val storage = FirebaseBackend.storage ?: return
        storage.reference.child(path).getBytes(5L * 1024L * 1024L)
            .addOnSuccessListener { bytes ->
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.let { target.setImageBitmap(it) }
            }
            .addOnFailureListener { Log.w("HiraBhaiVideo", "Thumbnail read failed at $path", it) }
    }

    private fun chooseVideoUpload() {
        if (FirebaseBackend.auth?.currentUser == null) { showAuth(false); return }
        if (FirebaseBackend.storage == null) {
            info("Video upload unavailable", FirebaseBackend.storageSetupError ?: "Firebase Storage is not configured. Set up a bucket and publish secure Storage Rules first.")
            return
        }
        try {
            pendingVideoIsShort = false; pendingVideoHashtags = ""
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).setType("video/*").addCategory(Intent.CATEGORY_OPENABLE)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION), 46)
        } catch (error: Exception) { info("Video picker", "Could not open phone storage: ${friendlyError(error)}") }
    }

    private fun chooseShortUpload() {
        if (FirebaseBackend.auth?.currentUser == null) { showAuth(false); return }
        if (FirebaseBackend.storage == null) { info("Short upload unavailable", FirebaseBackend.storageSetupError ?: "Configure Firebase Storage before uploading Shorts."); return }
        pendingVideoIsShort = true; pendingVideoHashtags = ""; pendingVideoTitle = ""; pendingVideoDescription = ""; pendingVideoVisibility = "public"
        try { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).setType("video/*").addCategory(Intent.CATEGORY_OPENABLE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION), 75) }
        catch (error: Exception) { info("Short picker", friendlyError(error)) }
    }

    private fun chooseAudioUpload() {
        if (FirebaseBackend.auth?.currentUser == null) { showAuth(false); return }
        if (FirebaseBackend.storage == null) { info("Audio upload unavailable", FirebaseBackend.storageSetupError ?: "Configure Firebase Storage and publish secure Storage Rules first."); return }
        selectedAudioCoverUri = null; pendingAudioTitle = ""; pendingAudioArtist = ""; pendingAudioDescription = ""; pendingAudioVisibility = "public"
        try {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).setType("audio/*").addCategory(Intent.CATEGORY_OPENABLE)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION), 48)
        } catch (error: Exception) { info("Audio picker", "Could not open phone storage: ${friendlyError(error)}") }
    }

    private fun showAudioUploadForm(uri: Uri) {
        selected = "Create"; base(); heading("Upload audio", "Publish audio stored in your Firebase Storage bucket")
        val cover = ImageView(this).apply {
            setImageResource(android.R.drawable.ic_media_play); scaleType = ImageView.ScaleType.CENTER_CROP
            background = round(0xffdce8ed.toInt(), 18); clipToOutline = true
            layoutParams = LinearLayout.LayoutParams(dp(128), dp(128)).apply { gravity = Gravity.CENTER; bottomMargin = dp(8) }
        }
        selectedAudioCoverUri?.let { try { cover.setImageURI(it) } catch (_: Exception) {} }
        content.addView(cover)
        button("Choose cover artwork") {
            pendingAudioTitle = content.findViewWithTag<EditText>("audio_title")?.text?.toString() ?: pendingAudioTitle
            pendingAudioArtist = content.findViewWithTag<EditText>("audio_artist")?.text?.toString() ?: pendingAudioArtist
            pendingAudioDescription = content.findViewWithTag<EditText>("audio_description")?.text?.toString() ?: pendingAudioDescription
            try { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION), 49) }
            catch (error: Exception) { info("Cover artwork", friendlyError(error)) }
        }
        val title = field("Audio title", android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES).apply { tag = "audio_title"; setText(pendingAudioTitle) }
        val artist = field("Artist name", android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES).apply { tag = "audio_artist"; setText(pendingAudioArtist) }
        val description = field("Description", android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES).apply { tag = "audio_description"; minLines = 3; gravity = Gravity.TOP; setText(pendingAudioDescription) }
        content.addView(title); content.addView(artist); content.addView(description)
        content.addView(label("Who can listen?", 15, primaryText, true).apply { setPadding(0, dp(2), 0, dp(6)) })
        val visibility = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        listOf("Public" to "public", "Unlisted" to "unlisted", "Private" to "private").forEach { (caption, value) ->
            val option = RadioButton(this).apply { text = caption; tag = value; setTextColor(primaryText); id = View.generateViewId() }
            visibility.addView(option); if (pendingAudioVisibility == value) visibility.check(option.id)
        }
        content.addView(visibility)
        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; this.visibility = View.GONE }
        content.addView(progress, LinearLayout.LayoutParams(-1, dp(8)).apply { topMargin = dp(8) })
        val status = label("Choose MP3, WAV, AAC, or another Android-supported audio file (up to 100 MB).", 13, secondaryText, false)
        content.addView(status)
        button("Upload audio") {
            pendingAudioTitle = title.text.toString().trim(); pendingAudioArtist = artist.text.toString().trim(); pendingAudioDescription = description.text.toString().trim()
            pendingAudioVisibility = visibility.checkedRadioButtonId.let { findViewById<RadioButton>(it)?.tag as? String } ?: "public"
            if (pendingAudioTitle.isBlank() || pendingAudioTitle.length > 120) { title.error = "Add a title of 1–120 characters"; return@button }
            if (pendingAudioArtist.isBlank() || pendingAudioArtist.length > 100) { artist.error = "Add an artist name of 1–100 characters"; return@button }
            if (pendingAudioDescription.length > 4000) { description.error = "Description must be 4,000 characters or fewer"; return@button }
            val size = try { contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L } catch (_: Exception) { -1L }
            if (size > 100L * 1024 * 1024) { status.text = "Audio files must be 100 MB or smaller."; return@button }
            progress.visibility = View.VISIBLE; progress.progress = 0; status.text = "Checking creator account…"
            uploadSelectedAudio(uri, pendingAudioTitle, pendingAudioArtist, pendingAudioDescription, pendingAudioVisibility, progress, status)
        }
        addBottom()
    }

    private fun uploadSelectedAudio(uri: Uri, title: String, artist: String, description: String, visibility: String, progress: ProgressBar, status: TextView) {
        val user = FirebaseBackend.auth?.currentUser ?: run { progress.visibility = View.GONE; status.text = "Sign in before uploading."; return }
        val db = FirebaseBackend.db ?: run { progress.visibility = View.GONE; status.text = "Firestore is not configured."; return }
        val storage = FirebaseBackend.storage ?: run { progress.visibility = View.GONE; status.text = "Firebase Storage is unavailable."; return }
        db.collection("profiles").document(user.uid).get().addOnSuccessListener { profile ->
            val creatorId = profile.getString("creatorId"); val username = profile.getString("username"); val name = profile.getString("fullName")
            if (!profile.exists() || creatorId.isNullOrBlank() || username.isNullOrBlank() || name.isNullOrBlank()) {
                progress.visibility = View.GONE; status.text = "Create your creator profile before uploading audio."; return@addOnSuccessListener
            }
            val audioId = UUID.randomUUID().toString(); val basePath = "audio/$visibility/$creatorId/$audioId"
            val audioPath = "$basePath/audio"; val coverPath = if (selectedAudioCoverUri != null) "$basePath/cover" else ""
            val mime = contentResolver.getType(uri)?.takeIf { it.startsWith("audio/") } ?: "application/octet-stream"
            val audioRef = storage.reference.child(audioPath)
            status.text = "Uploading audio…"
            val task = audioRef.putFile(uri, com.google.firebase.storage.StorageMetadata.Builder().setContentType(mime).build())
            task.addOnProgressListener { snap ->
                val percent = ((snap.bytesTransferred * 100L) / snap.totalByteCount.coerceAtLeast(1L)).toInt().coerceIn(0, 100)
                progress.progress = percent; status.text = "Uploading audio… $percent%"
            }.addOnFailureListener { error ->
                progress.visibility = View.GONE; status.text = "Audio upload failed: ${friendlyError(error)}"; Log.e("HiraBhaiAudio", "Upload failed at $audioPath", error)
            }.addOnSuccessListener {
                fun saveMetadata(savedCoverPath: String) {
                    val data = hashMapOf<String, Any>("audioId" to audioId, "creatorId" to creatorId, "creatorUsername" to username, "creatorName" to name,
                        "title" to title, "searchTitle" to title.lowercase(Locale.ROOT), "artist" to artist, "searchArtist" to artist.lowercase(Locale.ROOT), "description" to description, "visibility" to visibility,
                        "storagePath" to audioPath, "mimeType" to mime, "createdAt" to FieldValue.serverTimestamp())
                    if (savedCoverPath.isNotBlank()) data["coverStoragePath"] = savedCoverPath
                    db.collection("audios").document(audioId).set(data).addOnSuccessListener {
                        progress.visibility = View.GONE; status.text = "Audio uploaded and published as ${visibility.replaceFirstChar { it.uppercase() }}."
                        button("Play uploaded audio") { openAudio(audioId, data) }
                    }.addOnFailureListener { error ->
                        audioRef.delete(); if (savedCoverPath.isNotBlank()) storage.reference.child(savedCoverPath).delete()
                        progress.visibility = View.GONE; status.text = "File uploaded, but Firestore could not save its details: ${friendlyError(error)}"
                        Log.e("HiraBhaiAudio", "Metadata write failed at /audios/$audioId", error)
                    }
                }
                val coverUri = selectedAudioCoverUri
                if (coverUri == null) saveMetadata("") else {
                    val coverType = contentResolver.getType(coverUri)?.takeIf { it.startsWith("image/") } ?: "image/jpeg"
                    status.text = "Uploading cover artwork…"
                    storage.reference.child(coverPath).putFile(coverUri, com.google.firebase.storage.StorageMetadata.Builder().setContentType(coverType).build())
                        .addOnProgressListener { snap -> progress.progress = ((snap.bytesTransferred * 100L) / snap.totalByteCount.coerceAtLeast(1L)).toInt().coerceIn(0, 100) }
                        .addOnSuccessListener { saveMetadata(coverPath) }
                        .addOnFailureListener { error -> audioRef.delete(); progress.visibility = View.GONE; status.text = "Audio uploaded, but cover failed: ${friendlyError(error)}" }
                }
            }
        }.addOnFailureListener { error -> progress.visibility = View.GONE; status.text = "Could not verify creator account: ${friendlyError(error)}" }
    }

    private fun showMusicDiscovery(initialQuery: String) {
        selected = "Music Player"; base(); heading("Music", "Discover creator-uploaded audio")
        val search = field("Search title or artist", android.text.InputType.TYPE_CLASS_TEXT).apply { setText(initialQuery); imeOptions = EditorInfo.IME_ACTION_SEARCH }
        content.addView(search)
        val results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        button("Search audio") { loadPublicAudioFeed(results, search.text.toString().trim()) }
        button("♡ My audio favorites") { showFavoriteAudio() }
        button("Manage my audio uploads") { showMyAudio() }
        button("＋ Upload audio") { chooseAudioUpload() }
        button("♫ Open music player") { showMusicPlayer() }
        section("Recently uploaded")
        content.addView(results)
        loadPublicAudioFeed(results, initialQuery)
        addBottom()
    }

    private fun loadPublicAudioFeed(target: LinearLayout, searchTerm: String) {
        target.removeAllViews()
        val db = FirebaseBackend.db ?: run { target.addView(label("Audio discovery needs Firebase Firestore.", 13, secondaryText, false)); return }
        val term = searchTerm.trim().lowercase(Locale.ROOT)
        val queries = if (term.isBlank()) listOf(db.collection("audios").whereEqualTo("visibility", "public")
            .orderBy("createdAt", com.google.firebase.firestore.Query.Direction.DESCENDING).limit(30).get())
        else listOf("title", "artist").map { fieldName ->
            db.collection("audios").whereEqualTo("visibility", "public").orderBy(if (fieldName == "title") "searchTitle" else "searchArtist")
                .startAt(term).endAt(term + "\uf8ff").limit(20).get()
        }
        var finished = 0
        val found = linkedMapOf<String, com.google.firebase.firestore.DocumentSnapshot>()
        queries.forEach { query -> query.addOnSuccessListener { snapshot ->
            snapshot.documents.forEach { found[it.id] = it }
            finished++
            if (finished == queries.size) renderAudioResults(target, found.values.sortedByDescending { it.getTimestamp("createdAt")?.toDate()?.time ?: 0L })
        }.addOnFailureListener { error ->
            finished++
            if (finished == queries.size && found.isEmpty()) target.addView(label("Audio could not load: ${friendlyError(error)}. Publish the current Firestore rules and indexes first.", 13, secondaryText, false))
            else if (finished == queries.size) renderAudioResults(target, found.values.sortedByDescending { it.getTimestamp("createdAt")?.toDate()?.time ?: 0L })
        } }
    }

    private fun renderAudioResults(target: LinearLayout, docs: List<com.google.firebase.firestore.DocumentSnapshot>) {
        renderAudioMaps(target, docs.map { doc -> (doc.data ?: emptyMap()).toMutableMap().also { it["audioId"] = doc.id } })
    }

    private fun renderAudioMaps(target: LinearLayout, audio: List<Map<String, Any>>) {
        target.removeAllViews()
        val trending = TextView(this).apply {
            text = "🔥 Trending audio"; textSize = 13f; gravity = Gravity.CENTER
            setTextColor(mint); background = round(0xffe8f4f2.toInt(), 16); setPadding(dp(14), dp(10), dp(14), dp(10))
            isClickable = true; isFocusable = true; setOnClickListener { loadTrendingAudio(target) }
        }
        target.addView(trending, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        if (audio.isEmpty()) { target.addView(label("No public audio matches yet. Upload an audio file from Create or Music.", 13, secondaryText, false)); return }
        val queue = audio.map { it.toMutableMap() }
        queue.forEachIndexed { index, item -> addAudioCard(target, item["audioId"] as? String ?: return@forEachIndexed, item, queue, index) }
        val playAll = TextView(this).apply {
            text = "▶ Play all ${queue.size} audio tracks"; textSize = 13f; gravity = Gravity.CENTER
            setTextColor(Color.WHITE); background = round(mint, 16); setPadding(dp(14), dp(11), dp(14), dp(11))
            isClickable = true; isFocusable = true; setOnClickListener { startMusicQueue(queue, 0, false) }
        }
        target.addView(playAll, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4); bottomMargin = dp(10) })
    }

    private fun loadTrendingAudio(target: LinearLayout) {
        target.removeAllViews(); target.addView(label("Loading real trending audio…", 13, secondaryText, false))
        aiScope.launch {
            try {
                val list = withContext(Dispatchers.IO) {
                    val connection = URL("https://us-central1-hira-bhai.cloudfunctions.net/trendingAudio?limit=20").openConnection() as HttpURLConnection
                    connection.connectTimeout = 10000; connection.readTimeout = 15000; connection.requestMethod = "GET"
                    try {
                        if (connection.responseCode !in 200..299) throw IllegalStateException("Trending service returned HTTP ${connection.responseCode}")
                        val root = JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
                        val array = root.optJSONArray("audios") ?: JSONArray()
                        (0 until array.length()).mapNotNull { index ->
                            val obj = array.optJSONObject(index) ?: return@mapNotNull null
                            buildMap<String, Any> {
                                for (key in listOf("audioId", "creatorId", "creatorUsername", "creatorName", "title", "searchTitle", "artist", "searchArtist", "description", "visibility", "storagePath", "mimeType", "coverStoragePath"))
                                    obj.optString(key).takeIf { it.isNotBlank() && it != "null" }?.let { put(key, it) }
                                put("playCount", obj.optLong("playCount", 0L))
                            }
                        }
                    } finally { connection.disconnect() }
                }
                withContext(Dispatchers.Main) { renderAudioMaps(target, list) }
            } catch (error: Exception) {
                withContext(Dispatchers.Main) { target.removeAllViews(); target.addView(label("Trending audio is unavailable until the audio play-count Cloud Functions are deployed. ${friendlyError(error)}", 13, secondaryText, false)) }
            }
        }
    }

    private fun addAudioCard(parent: LinearLayout, audioId: String, audio: Map<String, Any>, queue: List<Map<String, Any>>, index: Int) {
        val title = audio["title"] as? String ?: "Untitled audio"
        val artist = audio["artist"] as? String ?: audio["creatorName"] as? String ?: "Creator"
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; background = round(Color.WHITE, 16)
            setPadding(dp(9), dp(9), dp(9), dp(9)); isClickable = true; isFocusable = true
            setOnClickListener { startMusicQueue(queue, index, false) }
        }
        val cover = ImageView(this).apply {
            setImageResource(android.R.drawable.ic_media_play); scaleType = ImageView.ScaleType.CENTER_CROP
            background = round(0xffdce8ed.toInt(), 12); clipToOutline = true
            layoutParams = LinearLayout.LayoutParams(dp(64), dp(64))
        }
        row.addView(cover)
        val details = columnText(title, artist).apply { setPadding(dp(11), 0, dp(3), 0) }
        val visibility = audio["visibility"] as? String
        if (visibility != null && visibility != "public") details.addView(label(visibility.replaceFirstChar { it.uppercase() }, 11, secondaryText, false).apply { setPadding(0, dp(3), 0, 0) })
        val playCount = (audio["playCount"] as? Number)?.toLong() ?: 0L
        if (playCount > 0) details.addView(label("$playCount verified play starts", 11, secondaryText, false).apply { setPadding(0, dp(3), 0, 0) })
        row.addView(details, LinearLayout.LayoutParams(0, -2, 1f))
        val play = TextView(this).apply { text = "▶"; textSize = 20f; setTextColor(mint); gravity = Gravity.CENTER; setPadding(dp(7), dp(8), dp(7), dp(8)); setOnClickListener { startMusicQueue(queue, index, false) } }
        row.addView(play)
        parent.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        fun actionChip(text: String, click: () -> Unit) = TextView(this).apply {
            this.text = text; textSize = 12f; setTextColor(mint); background = round(0xffe8f4f2.toInt(), 14)
            setPadding(dp(11), dp(7), dp(11), dp(7)); isClickable = true; isFocusable = true; setOnClickListener { click() }
            layoutParams = LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6); bottomMargin = dp(8) }
        }
        actions.addView(actionChip("♡ Save audio") { toggleAudioFavorite(audioId, audio) })
        val deleteChip = actionChip("Delete my audio") { deleteAudio(audioId, audio, parent) }.apply { this.visibility = View.GONE }
        actions.addView(deleteChip)
        parent.addView(actions)
        val user = FirebaseBackend.auth?.currentUser
        val db = FirebaseBackend.db
        val coverPath = audio["coverStoragePath"] as? String
        if (!coverPath.isNullOrBlank()) loadAudioCover(coverPath, cover)
        if (user != null && db != null) db.collection("profiles").document(user.uid).get().addOnSuccessListener { profile ->
            if (profile.getString("creatorId") == audio["creatorId"]) deleteChip.visibility = View.VISIBLE
        }
    }

    private fun loadAudioCover(path: String, image: ImageView) {
        val storage = FirebaseBackend.storage ?: return
        val file = File(cacheDir, "audio-covers/${path.hashCode()}.cover")
        if (file.exists() && file.length() > 0) { BitmapFactory.decodeFile(file.absolutePath)?.let { image.setImageBitmap(it) }; return }
        file.parentFile?.mkdirs()
        storage.reference.child(path).getFile(file).addOnSuccessListener { BitmapFactory.decodeFile(file.absolutePath)?.let { image.setImageBitmap(it) } }
            .addOnFailureListener { file.delete(); Log.w("HiraBhaiAudio", "Cover artwork could not be loaded", it) }
    }

    private fun toggleAudioFavorite(audioId: String, audio: Map<String, Any>) {
        val user = FirebaseBackend.auth?.currentUser ?: run { showAuth(false); return }
        val db = FirebaseBackend.db ?: run { info("Audio favorite", "Firestore is not configured."); return }
        val ref = db.collection("userActivity").document(user.uid).collection("favoriteAudio").document(audioId)
        ref.get().addOnSuccessListener { saved ->
            if (saved.exists()) ref.delete().addOnSuccessListener { info("Music", "Removed from your favorites.") }
                .addOnFailureListener { info("Music", "Could not remove favorite: ${friendlyError(it)}") }
            else {
                val item = mapOf("audioId" to audioId, "title" to (audio["title"] as? String ?: "Audio"),
                    "artist" to (audio["artist"] as? String ?: "Creator"), "creatorId" to (audio["creatorId"] as? String ?: ""),
                    "coverStoragePath" to (audio["coverStoragePath"] as? String ?: ""), "savedAt" to FieldValue.serverTimestamp())
                ref.set(item).addOnSuccessListener { info("Music", "Saved to your audio favorites.") }
                    .addOnFailureListener { info("Music", "Could not save favorite: ${friendlyError(it)}") }
            }
        }.addOnFailureListener { info("Music", "Could not check favorite: ${friendlyError(it)}") }
    }

    private fun deleteAudio(audioId: String, audio: Map<String, Any>, target: LinearLayout) {
        AlertDialog.Builder(this).setTitle("Delete this audio?").setMessage("The audio file and its public listing will be deleted.")
            .setNegativeButton("Cancel", null).setPositiveButton("Delete") { _, _ ->
                val user = FirebaseBackend.auth?.currentUser ?: return@setPositiveButton
                val db = FirebaseBackend.db ?: return@setPositiveButton
                val creatorId = audio["creatorId"] as? String ?: return@setPositiveButton
                db.collection("profiles").document(user.uid).get().addOnSuccessListener { profile ->
                    if (profile.getString("creatorId") != creatorId) { info("Audio", "Only the owner can delete this upload."); return@addOnSuccessListener }
                    val storage = FirebaseBackend.storage
                    val paths = listOfNotNull(audio["storagePath"] as? String, audio["coverStoragePath"] as? String).filter { it.isNotBlank() }
                    val deletes = paths.map { path -> storage?.reference?.child(path)?.delete() }
                    com.google.android.gms.tasks.Tasks.whenAllComplete(deletes.filterNotNull()).addOnCompleteListener {
                        db.collection("audios").document(audioId).delete().addOnSuccessListener { target.removeAllViews(); info("Audio", "Audio removed.") }
                            .addOnFailureListener { info("Audio", "Could not remove listing: ${friendlyError(it)}") }
                    }
                }.addOnFailureListener { info("Audio", "Could not verify upload ownership: ${friendlyError(it)}") }
            }.show()
    }

    private fun ensureMusicController(onReady: (MediaController) -> Unit) {
        musicController?.let { onReady(it); return }
        val future = musicControllerFuture ?: MediaController.Builder(this,
            SessionToken(this, ComponentName(this, MusicPlaybackService::class.java))).buildAsync().also { musicControllerFuture = it }
        future.addListener({
            try {
                val controller = future.get(); musicController = controller; onReady(controller); refreshMusicMini()
                if (!musicListenerAttached) {
                    musicListenerAttached = true
                    controller.addListener(object : Player.Listener {
                        override fun onIsPlayingChanged(isPlaying: Boolean) { refreshMusicMini(); refreshMusicPlayerControls(); if (isPlaying) recordAudioPlayForCurrentTrack() }
                        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) { refreshMusicMini(); refreshMusicPlayerControls(); if (musicController?.isPlaying == true) recordAudioPlayForCurrentTrack() }
                        override fun onPlaybackStateChanged(playbackState: Int) {
                            refreshMusicMini(); refreshMusicPlayerControls()
                            if (playbackState == Player.STATE_ENDED && !advancingAudioQueue) playQueueStep(1)
                        }
                    })
                }
            } catch (error: Exception) { info("Music player", "Could not connect to playback: ${friendlyError(error)}") }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun clearAudioSessionOnSignOut() {
        musicController?.let { controller -> controller.stop(); controller.clearMediaItems() }
        musicQueue = emptyList(); musicQueueIndex = 0; lastAudioPlayNotifiedId = null
        File(cacheDir, "music").deleteRecursively()
        File(cacheDir, "audio-covers").deleteRecursively()
        refreshMusicMini()
    }

    private fun startMusicQueue(queue: List<Map<String, Any>>, startIndex: Int, shuffle: Boolean) {
        if (queue.isEmpty()) return
        musicQueue = queue; musicQueueIndex = startIndex.coerceIn(queue.indices)
        musicShuffleEnabled = shuffle
        lastAudioPlayNotifiedId = null
        ensureMusicController { controller ->
            prepareQueueAudio(controller, musicQueueIndex, true)
        }
    }

    private fun prepareQueueAudio(controller: MediaController, index: Int, autoPlay: Boolean) {
        val audio = musicQueue.getOrNull(index) ?: return
        advancingAudioQueue = true; musicQueueIndex = index; lastAudioPlayNotifiedId = null
        val id = audio["audioId"] as? String
        val path = audio["storagePath"] as? String
        val db = FirebaseBackend.db
        if (id.isNullOrBlank() || path.isNullOrBlank() || db == null) { advancingAudioQueue = false; info("Music", "Audio storage details are missing."); return }
        // Firestore authorizes this user's access before the Storage DataSource
        // opens its authenticated progressive stream.
        db.collection("audios").document(id).get().addOnSuccessListener { doc ->
            if (!doc.exists() || doc.getString("storagePath") != path) {
                advancingAudioQueue = false; info("Music", "This audio is private or no longer available to this account."); return@addOnSuccessListener
            }
            val coverPath = audio["coverStoragePath"] as? String
            val metadata = MediaMetadata.Builder().setTitle(audio["title"] as? String ?: doc.getString("title") ?: "Audio")
                .setArtist(audio["artist"] as? String ?: doc.getString("artist") ?: "Creator").build()
            val streamUri = Uri.Builder().scheme("hirabhai-audio").authority(id).appendQueryParameter("path", path).build()
            val item = MediaItem.Builder().setMediaId(id).setUri(streamUri).setMediaMetadata(metadata).build()
            controller.setMediaItem(item); controller.prepare(); if (autoPlay) controller.play()
            advancingAudioQueue = false; refreshMusicMini(); refreshMusicPlayerControls(); if (autoPlay) recordAudioPlayForCurrentTrack()
            if (currentAudioScreen && !coverPath.isNullOrBlank()) {
                musicPlayerCover?.let { loadAudioCover(coverPath, it) }
            }
        }.addOnFailureListener { error ->
            advancingAudioQueue = false; info("Music", "Could not verify audio access: ${friendlyError(error)}")
        }
    }

    private fun playQueueStep(direction: Int) {
        val controller = musicController ?: return
        if (musicQueue.size < 2 || advancingAudioQueue) return
        if (direction < 0 && controller.currentPosition > 4000L) { controller.seekTo(0); controller.play(); return }
        val next = if (musicShuffleEnabled) {
            (musicQueue.indices.filter { it != musicQueueIndex }).random()
        } else musicQueueIndex + direction
        if (next !in musicQueue.indices) return
        prepareQueueAudio(controller, next, true)
    }

    private fun openAudio(audioId: String, audio: Map<String, Any>) {
        val track = audio.toMutableMap().also { it["audioId"] = audioId }
        showMusicPlayer()
        startMusicQueue(listOf(track), 0, false)
    }

    private fun recordAudioPlayForCurrentTrack() {
        val controller = musicController ?: return
        val item = controller.currentMediaItem ?: return
        val audioId = item.mediaId.takeIf { it.isNotBlank() } ?: return
        if (lastAudioPlayNotifiedId == audioId) return
        lastAudioPlayNotifiedId = audioId
        val auth = FirebaseBackend.auth ?: return
        aiScope.launch {
            try {
                val token = auth.currentUser?.getIdToken(false)?.await()?.token ?: return@launch
                withContext(Dispatchers.IO) {
                    val connection = URL("https://us-central1-hira-bhai.cloudfunctions.net/recordAudioPlay").openConnection() as HttpURLConnection
                    connection.connectTimeout = 10000; connection.readTimeout = 12000; connection.requestMethod = "POST"
                    connection.setRequestProperty("Authorization", "Bearer $token"); connection.setRequestProperty("Content-Type", "application/json")
                    connection.doOutput = true
                    try {
                        connection.outputStream.use { it.write(JSONObject().put("audioId", audioId).toString().toByteArray(Charsets.UTF_8)) }
                        if (connection.responseCode !in 200..299) throw IllegalStateException("Play count request failed (${connection.responseCode})")
                    } finally { connection.disconnect() }
                }
            } catch (error: Exception) { Log.w("HiraBhaiAudio", "Playback count was not recorded", error) }
        }
    }

    private fun showFavoriteAudio() {
        val user = FirebaseBackend.auth?.currentUser ?: run { showAuth(false); return }
        val db = FirebaseBackend.db ?: run { info("Music", "Firestore is not configured."); return }
        selected = "Music Player"; base(); heading("Your audio favorites", "Private to your account")
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; content.addView(list)
        db.collection("userActivity").document(user.uid).collection("favoriteAudio").orderBy("savedAt", com.google.firebase.firestore.Query.Direction.DESCENDING).limit(100).get()
            .addOnSuccessListener { saved ->
                if (saved.isEmpty) { list.addView(label("You have not saved any audio yet.", 13, secondaryText, false)); return@addOnSuccessListener }
                val loaded = mutableListOf<Pair<String, Map<String, Any>>>()
                var remaining = saved.size()
                saved.documents.forEach { favorite ->
                    db.collection("audios").document(favorite.id).get().addOnSuccessListener { doc ->
                        if (doc.exists()) loaded.add(doc.id to (doc.data ?: emptyMap()))
                        remaining--
                        if (remaining == 0) {
                            if (loaded.isEmpty()) list.addView(label("Saved audio is no longer available.", 13, secondaryText, false))
                            val queue = loaded.map { (id, data) -> data.toMutableMap().also { it["audioId"] = id } }
                            loaded.forEachIndexed { index, pair -> addAudioCard(list, pair.first, pair.second, queue, index) }
                        }
                    }.addOnFailureListener { error ->
                        remaining--; Log.w("HiraBhaiAudio", "Saved track ${favorite.id} is no longer readable", error)
                        if (remaining == 0 && loaded.isEmpty()) list.addView(label("Saved audio could not load: ${friendlyError(error)}", 13, secondaryText, false))
                    }
                }
            }.addOnFailureListener { list.addView(label("Favorites are private and could not load: ${friendlyError(it)}", 13, secondaryText, false)) }
        addBottom()
    }

    private fun showMusicPlayer() {
        currentAudioScreen = true; selected = "Music Player"; base(); currentAudioScreen = true
        heading("Music Player", "Creator audio · background playback supported")
        val cover = ImageView(this).apply {
            setImageResource(android.R.drawable.ic_media_play); scaleType = ImageView.ScaleType.CENTER_CROP
            background = round(0xffdce8ed.toInt(), 22); clipToOutline = true
            layoutParams = LinearLayout.LayoutParams(dp(210), dp(210)).apply { gravity = Gravity.CENTER; bottomMargin = dp(15) }
        }
        content.addView(cover)
        musicPlayerCover = cover
        musicPlayerTitle = label("Choose a track", 21, primaryText, true).apply { gravity = Gravity.CENTER }
        musicPlayerArtist = label("Hira Bhai Music", 14, secondaryText, false).apply { gravity = Gravity.CENTER; setPadding(0, dp(4), 0, dp(8)) }
        content.addView(musicPlayerTitle); content.addView(musicPlayerArtist)
        val time = label("0:00 / 0:00", 12, secondaryText, false); musicPlayerTime = time; content.addView(time)
        val seek = SeekBar(this); musicPlayerProgress = seek; content.addView(seek)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(bar: SeekBar) {}
            override fun onStopTrackingTouch(bar: SeekBar) { musicController?.seekTo(bar.progress.toLong()) }
            override fun onProgressChanged(bar: SeekBar, progress: Int, fromUser: Boolean) {}
        })
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        fun control(text: String, action: () -> Unit) { val view = TextView(this).apply { this.text = text; textSize = 21f; gravity = Gravity.CENTER; setTextColor(mint); setPadding(dp(17), dp(8), dp(17), dp(8)); setOnClickListener { action() } }; controls.addView(view) }
        control("⏮") { playQueueStep(-1) }
        control("▶ / ❚❚") { musicController?.let { if (it.isPlaying) it.pause() else it.play(); refreshMusicPlayerControls() } }
        control("⏭") { playQueueStep(1) }
        control("⇄") { musicShuffleEnabled = !musicShuffleEnabled; info("Music", if (musicShuffleEnabled) "Shuffle is on." else "Shuffle is off.") }
        content.addView(controls)
        button("♡  Save current audio to favorites") { musicQueue.getOrNull(musicQueueIndex)?.let { audio -> toggleAudioFavorite(audio["audioId"] as? String ?: return@button, audio) } }
        button("Browse public audio") { showMusicDiscovery("") }
        button("♫ Upload audio") { chooseAudioUpload() }
        ensureMusicController { controller ->
            val item = controller.currentMediaItem
            if (item != null) { musicPlayerTitle?.text = item.mediaMetadata.title?.toString() ?: "Audio"; musicPlayerArtist?.text = item.mediaMetadata.artist?.toString() ?: "Creator" }
            refreshMusicPlayerControls()
            val id = item?.mediaId
            val map = musicQueue.firstOrNull { it["audioId"] == id }
            val coverPath = map?.get("coverStoragePath") as? String
            if (!coverPath.isNullOrBlank()) loadAudioCover(coverPath, cover)
        }
        val ticker = object : Runnable {
            override fun run() {
                if (!currentAudioScreen) return
                musicController?.let { controller ->
                    val duration = controller.duration.coerceAtLeast(0L); val position = controller.currentPosition.coerceAtLeast(0L)
                    seek.max = duration.coerceAtMost(Int.MAX_VALUE.toLong()).toInt(); seek.progress = position.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
                    time.text = "${formatDuration(position)} / ${formatDuration(duration)}"
                }
                playbackProgressHandler.postDelayed(this, 500)
            }
        }
        musicProgressRunnable = ticker; playbackProgressHandler.post(ticker)
        addBottom()
    }

    private fun refreshMusicPlayerControls() {
        val controller = musicController ?: return
        if (!currentAudioScreen) return
        val item = controller.currentMediaItem ?: return
        musicPlayerTitle?.text = item.mediaMetadata.title?.toString() ?: "Audio"
        musicPlayerArtist?.text = item.mediaMetadata.artist?.toString() ?: "Creator"
    }

    private fun refreshMusicMini() {
        val controller = musicController
        val item = controller?.currentMediaItem
        musicMiniContainer?.visibility = if (item == null || selected == "Music Player") View.GONE else View.VISIBLE
        if (item != null) {
            val title = item.mediaMetadata.title?.toString() ?: "Audio"
            val artist = item.mediaMetadata.artist?.toString() ?: "Creator"
            musicMiniTitle?.text = "♫  $title · $artist"
            musicMiniPlay?.text = if (controller.isPlaying) "❚❚" else "▶"
        }
    }

    private fun loadCreatorAudios(creatorId: String) {
        section("Music")
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; content.addView(list)
        val db = FirebaseBackend.db ?: run { list.addView(label("Creator audio is unavailable.", 13, secondaryText, false)); return }
        val user = FirebaseBackend.auth?.currentUser
        if (user == null) { runCreatorAudioQuery(db, list, creatorId, false); return }
        db.collection("profiles").document(user.uid).get().addOnSuccessListener { profile ->
            runCreatorAudioQuery(db, list, creatorId, profile.getString("creatorId") == creatorId)
        }.addOnFailureListener { error -> list.addView(label("Could not check creator audio visibility: ${friendlyError(error)}", 13, secondaryText, false)) }
    }

    private fun runCreatorAudioQuery(db: com.google.firebase.firestore.FirebaseFirestore, list: LinearLayout, creatorId: String, owner: Boolean) {
        var query = db.collection("audios").whereEqualTo("creatorId", creatorId)
        if (!owner) query = query.whereEqualTo("visibility", "public")
        query.orderBy("createdAt", com.google.firebase.firestore.Query.Direction.DESCENDING).limit(30).get()
            .addOnSuccessListener { snapshot ->
                if (snapshot.isEmpty) list.addView(label(if (owner) "You have not uploaded audio yet." else "No public audio yet.", 13, secondaryText, false))
                val queue = snapshot.documents.map { (it.data ?: emptyMap()).toMutableMap().also { map -> map["audioId"] = it.id } }
                queue.forEachIndexed { index, audio -> addAudioCard(list, audio["audioId"] as String, audio, queue, index) }
            }.addOnFailureListener { list.addView(label("Could not load creator audio: ${friendlyError(it)}", 13, secondaryText, false)) }
    }

    private fun showMyAudio() {
        val user = FirebaseBackend.auth?.currentUser ?: run { showAuth(false); return }
        val db = FirebaseBackend.db ?: run { info("My audio", "Firestore is not configured."); return }
        selected = "Music Player"; base(); heading("My audio uploads", "Manage your public, unlisted, and private audio")
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; content.addView(list)
        db.collection("profiles").document(user.uid).get().addOnSuccessListener { profile ->
            val creatorId = profile.getString("creatorId")
            if (creatorId.isNullOrBlank()) { list.addView(label("Create a creator profile before uploading audio.", 13, secondaryText, false)); return@addOnSuccessListener }
            runCreatorAudioQuery(db, list, creatorId, true)
        }.addOnFailureListener { list.addView(label("Could not load your creator profile: ${friendlyError(it)}", 13, secondaryText, false)) }
        button("＋ Upload audio") { chooseAudioUpload() }
        addBottom()
    }

    private fun showVideoUploadForm(uri: Uri) {
        val isShort = pendingVideoIsShort
        selected = "Create"; base(); heading(if (isShort) "Upload a Short" else "Upload video", if (isShort) "Vertical 9:16 video · publish to the separate Shorts feed" else "Choose details and who can watch")
        val thumbnail = ImageView(this).apply {
            setImageResource(android.R.drawable.ic_media_play); scaleType = ImageView.ScaleType.CENTER_CROP
            background = round(0xffdce8ed.toInt(), 18); clipToOutline = true
            layoutParams = LinearLayout.LayoutParams(-1, dp(190)).apply { bottomMargin = dp(8) }
        }
        content.addView(thumbnail)
        selectedVideoThumbnailUri?.let { try { thumbnail.setImageURI(it) } catch (_: Exception) {} }
        videoThumbnail?.let { thumbnail.setImageBitmap(it) }
        button("Choose thumbnail image") {
            pendingVideoTitle = (content.findViewWithTag<EditText>("video_title")?.text?.toString() ?: pendingVideoTitle)
            pendingVideoDescription = content.findViewWithTag<EditText>("video_description")?.text?.toString() ?: pendingVideoDescription
            pendingVideoHashtags = content.findViewWithTag<EditText>("video_hashtags")?.text?.toString() ?: pendingVideoHashtags
            (content.findViewWithTag<RadioGroup>("video_visibility")?.checkedRadioButtonId?.let { content.findViewById<RadioButton>(it)?.tag as? String })?.let { pendingVideoVisibility = it }
            try {
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION), 47)
            } catch (error: Exception) { info("Thumbnail picker", friendlyError(error)) }
        }
        val title = field("Video title", android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES).apply {
            tag = "video_title"; setText(pendingVideoTitle)
        }
        val description = field("Description", android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES).apply {
            tag = "video_description"; minLines = 3; gravity = Gravity.TOP; setText(pendingVideoDescription)
        }
        content.addView(title); content.addView(description)
        val hashtags = if (isShort) field("Hashtags (space or comma separated)", android.text.InputType.TYPE_CLASS_TEXT).apply {
            tag = "video_hashtags"; setText(pendingVideoHashtags); hint = "#travel #food #music"
            filters = arrayOf(android.text.InputFilter.LengthFilter(600))
        } else null
        hashtags?.let { content.addView(it) }
        if (isShort) content.addView(label("Shorts must be portrait 9:16 (about 8% tolerance). Your source video is uploaded unchanged; crop/edit it first if needed.", 12, secondaryText, false).apply { setPadding(0, dp(5), 0, dp(8)) })
        content.addView(label("Visibility", 15, primaryText, true).apply { setPadding(0, dp(2), 0, dp(6)) })
        val visibility = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL; tag = "video_visibility" }
        listOf("Public" to "public", "Unlisted" to "unlisted", "Private" to "private").forEach { (caption, value) ->
            val option = RadioButton(this).apply { text = caption; tag = value; setTextColor(primaryText); id = View.generateViewId() }
            visibility.addView(option)
            if (value == pendingVideoVisibility) visibility.check(option.id)
        }
        content.addView(visibility)
        val includeCaptions = if (pendingUploadCaptionsSrt != null) CheckBox(this).apply {
            text = "Attach generated ${pendingUploadCaptionLanguage} captions"; setTextColor(primaryText); buttonTintList = android.content.res.ColorStateList.valueOf(mint)
        } else null
        includeCaptions?.let(content::addView)
        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; this.visibility = View.GONE }
        content.addView(progress, LinearLayout.LayoutParams(-1, dp(8)).apply { topMargin = dp(8) })
        val status = label("Video stays on your phone until you upload it.", 13, secondaryText, false)
        content.addView(status)
        if (selectedVideoThumbnailUri == null && videoThumbnail == null) {
            Thread {
                val extracted = extractVideoThumbnail(uri)
                runOnUiThread {
                    if (selectedVideoUri == uri && selectedVideoThumbnailUri == null && extracted.first != null) {
                        videoThumbnail = extracted.first; selectedVideoDurationMs = extracted.second
                        thumbnail.setImageBitmap(extracted.first)
                    }
                }
            }.start()
        }
        button("Upload video") {
            pendingVideoTitle = title.text.toString().trim()
            pendingVideoDescription = description.text.toString().trim()
            pendingVideoHashtags = hashtags?.text?.toString().orEmpty()
            pendingVideoVisibility = visibility.checkedRadioButtonId.let { content.findViewById<RadioButton>(it)?.tag as? String } ?: "public"
            if (pendingVideoTitle.isBlank() || pendingVideoTitle.length > 120) { title.error = "Add a title of 1–120 characters"; return@button }
            if (pendingVideoDescription.length > 4000) { description.error = "Description must be 4,000 characters or fewer"; return@button }
            val normalizedHashtags = pendingVideoHashtags.split(Regex("[\\s,]+"))
                .map { it.trim().removePrefix("#").lowercase(Locale.ROOT) }.filter { it.isNotBlank() }.distinct()
            if (isShort && (normalizedHashtags.size > 15 || normalizedHashtags.any { !Regex("^[a-z0-9_]{1,30}$").matches(it) })) {
                hashtags?.error = "Use up to 15 hashtags; each can have 1–30 letters, numbers, or underscores"; return@button
            }
            val dimensions = readVideoDimensions(uri)
            if (isShort && (dimensions.first <= 0 || dimensions.second <= 0 || dimensions.first.toFloat() / dimensions.second.toFloat() !in 0.5175f..0.6075f)) {
                status.text = "This video is not vertical 9:16. Choose a portrait video within about 8% of the 9:16 aspect ratio and try again."; return@button
            }
            progress.visibility = View.VISIBLE; progress.progress = 0; status.text = "Preparing secure upload…"
            attachCaptionsToCurrentUpload = includeCaptions?.isChecked == true
            uploadSelectedVideo(uri, pendingVideoTitle, pendingVideoDescription, pendingVideoVisibility, progress, status, isShort, normalizedHashtags)
        }
        addBottom()
    }

    private fun extractVideoThumbnail(uri: Uri): Pair<Bitmap?, Long> {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(this, uri)
            val duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            (retriever.getFrameAtTime(1_000_000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: retriever.getFrameAtTime()) to duration
        } catch (error: Exception) {
            Log.w("HiraBhaiVideo", "Could not extract video thumbnail", error); null to 0L
        } finally { try { retriever.release() } catch (_: Exception) {} }
    }

    private fun readVideoDimensions(uri: Uri): Pair<Int, Int> {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(this, uri)
            var width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            var height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rotation = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rotation % 180 != 0) { val oldWidth = width; width = height; height = oldWidth }
            width to height
        } catch (error: Exception) { Log.w("HiraBhaiShorts", "Could not read video dimensions", error); 0 to 0 }
        finally { try { retriever.release() } catch (_: Exception) {} }
    }

    private fun uploadSelectedVideo(uri: Uri, title: String, description: String, visibility: String, progress: ProgressBar, status: TextView, isShort: Boolean = false, hashtags: List<String> = emptyList()) {
        val user = FirebaseBackend.auth?.currentUser ?: run { status.text = "Sign in again before uploading."; progress.visibility = View.GONE; return }
        val db = FirebaseBackend.db ?: run { status.text = "Firestore is not configured."; progress.visibility = View.GONE; return }
        val storage = FirebaseBackend.storage ?: run {
            status.text = "Firebase Storage is unavailable: ${FirebaseBackend.storageSetupError ?: "check bucket setup and project billing"}"
            progress.visibility = View.GONE; return
        }
        status.text = "Checking your creator profile…"
        db.collection("profiles").document(user.uid).get().addOnSuccessListener { profile ->
            val creatorId = profile.getString("creatorId")
            val username = profile.getString("username")
            val creatorName = profile.getString("fullName")
            if (!profile.exists() || creatorId.isNullOrBlank() || username.isNullOrBlank() || creatorName.isNullOrBlank()) {
                progress.visibility = View.GONE
                status.text = "Creator profile required. Tap here to set up your profile, then return to upload."
                status.setTextColor(mint)
                status.isClickable = true
                status.setOnClickListener {
                    returnToVideoUploadAfterProfileSave = true
                    showProfileEditor()
                }
                return@addOnSuccessListener
            }
            val cachedThumbnail = videoThumbnail
            if (selectedVideoDurationMs <= 0L || (selectedVideoThumbnailUri == null && cachedThumbnail == null)) {
                status.text = if (selectedVideoThumbnailUri == null) "Creating video thumbnail…" else "Reading video duration…"
                Thread {
                    val extracted = extractVideoThumbnail(uri)
                    runOnUiThread {
                        selectedVideoDurationMs = extracted.second
                        val uploadThumb = if (selectedVideoThumbnailUri == null) extracted.first else cachedThumbnail
                        if (selectedVideoThumbnailUri == null && uploadThumb == null) { progress.visibility = View.GONE; status.text = "Could not create a thumbnail. Choose a thumbnail image and retry." }
                        else { if (selectedVideoThumbnailUri == null) videoThumbnail = uploadThumb; startVideoStorageUpload(uri, uploadThumb, title, description, visibility, creatorId, username, creatorName, progress, status, db, storage, user.uid, isShort, hashtags) }
                    }
                }.start()
            } else startVideoStorageUpload(uri, cachedThumbnail, title, description, visibility, creatorId, username, creatorName, progress, status, db, storage, user.uid, isShort, hashtags)
        }.addOnFailureListener { error ->
            progress.visibility = View.GONE; status.text = "Could not verify creator profile: ${friendlyError(error)}"
            Log.e("HiraBhaiVideo", "Profile read failed: /profiles/${user.uid} before upload", error)
        }
    }

    private fun startVideoStorageUpload(
        videoUri: Uri, thumbnailBitmap: Bitmap?, title: String, description: String, visibility: String,
        creatorId: String, username: String, creatorName: String, progress: ProgressBar,
        status: TextView, db: com.google.firebase.firestore.FirebaseFirestore, storage: com.google.firebase.storage.FirebaseStorage,
        ownerUid: String, isShort: Boolean, hashtags: List<String>
    ) {
        val videoId = UUID.randomUUID().toString()
        val basePath = "videos/$visibility/$creatorId/$videoId"
        val videoPath = "$basePath/video"
        val thumbPath = "$basePath/thumbnail"
        val videoRef = storage.reference.child(videoPath)
        val thumbRef = storage.reference.child(thumbPath)
        val videoType = contentResolver.getType(videoUri)?.takeIf { it.startsWith("video/") } ?: "video/mp4"
        val videoMetadata = com.google.firebase.storage.StorageMetadata.Builder().setContentType(videoType).build()
        status.text = "Uploading video…"
        val task = videoRef.putFile(videoUri, videoMetadata)
        task.addOnProgressListener { snapshot ->
            val total = snapshot.totalByteCount.coerceAtLeast(1L)
            val percent = ((snapshot.bytesTransferred * 100L) / total).toInt().coerceIn(0, 100)
            progress.progress = percent; status.text = "Uploading video… $percent%"
        }.addOnFailureListener { error ->
            progress.visibility = View.GONE; status.text = "Video upload failed: ${friendlyError(error)}"
            Log.e("HiraBhaiVideo", "Storage upload failed at $videoPath", error)
        }.addOnSuccessListener {
            status.text = "Uploading thumbnail…"; progress.progress = 100
            val thumbUpload = selectedVideoThumbnailUri?.let { picked ->
                val type = contentResolver.getType(picked)?.takeIf { it.startsWith("image/") } ?: "image/jpeg"
                thumbRef.putFile(picked, com.google.firebase.storage.StorageMetadata.Builder().setContentType(type).build())
            } ?: run {
                val output = ByteArrayOutputStream()
                if (thumbnailBitmap == null || !thumbnailBitmap.compress(Bitmap.CompressFormat.JPEG, 84, output)) {
                    videoRef.delete(); progress.visibility = View.GONE; status.text = "Could not encode thumbnail."; return@addOnSuccessListener
                }
                thumbRef.putBytes(output.toByteArray(), com.google.firebase.storage.StorageMetadata.Builder().setContentType("image/jpeg").build())
            }
            thumbUpload.addOnFailureListener { error ->
                videoRef.delete(); progress.visibility = View.GONE; status.text = "Thumbnail upload failed: ${friendlyError(error)}"
                Log.e("HiraBhaiVideo", "Thumbnail upload failed at $thumbPath", error)
            }.addOnSuccessListener {
                val document = hashMapOf<String, Any>(
                    "videoId" to videoId, "ownerUid" to ownerUid, "creatorId" to creatorId,
                    "creatorUsername" to username, "creatorName" to creatorName,
                    "title" to title, "description" to description, "visibility" to visibility,
                    "storagePath" to videoPath, "thumbnailStoragePath" to thumbPath,
                    "durationMs" to selectedVideoDurationMs, "createdAt" to FieldValue.serverTimestamp(),
                    "isShort" to isShort, "hashtags" to hashtags,
                    "aspectRatio" to if (isShort) "9:16" else "video"
                )
                db.collection("videos").document(videoId).set(document)
                    .addOnSuccessListener {
                        val finishVideoUpload: (String) -> Unit = { message ->
                            progress.visibility = View.GONE; status.text = message
                            button("Watch uploaded video") { openVideoById(videoId, document) }
                        }
                        val captions = pendingUploadCaptionsSrt
                        if (attachCaptionsToCurrentUpload && captions != null) {
                            val captionLanguage = pendingUploadCaptionLanguage
                            val captionCount = captions.split(Regex("\\n\\s*\\n")).count { "-->" in it }
                            uploadCaptionAsset(videoId, basePath, visibility, creatorId, captionLanguage, captions, captionCount,
                                onSuccess = { pendingUploadCaptionsSrt = null; attachCaptionsToCurrentUpload = false; finishVideoUpload("Video and ${captionLanguage} captions uploaded as ${visibility.replaceFirstChar { it.uppercase() }}.") },
                                onFailure = { message -> attachCaptionsToCurrentUpload = false; finishVideoUpload("Video uploaded, but captions were not attached: $message") })
                        } else finishVideoUpload("Video uploaded and published as ${visibility.replaceFirstChar { it.uppercase() }}.")
                    }
                    .addOnFailureListener { error ->
                        videoRef.delete(); thumbRef.delete(); progress.visibility = View.GONE
                        status.text = "Video uploaded, but Firestore could not save its details: ${friendlyError(error)}"
                        Log.e("HiraBhaiVideo", "Metadata write failed: /videos/$videoId", error)
                    }
            }
        }
    }

    private fun openVideoById(videoId: String, loaded: Map<String, Any>? = null) {
        playlistQueue = emptyList(); playlistQueueIndex = -1
        if (loaded != null) { showVideoPlayer(videoId, loaded); return }
        val db = FirebaseBackend.db ?: run { info("Video unavailable", "Firestore is not configured."); return }
        db.collection("videos").document(videoId).get()
            .addOnSuccessListener { doc ->
                if (!doc.exists()) info("Video unavailable", "This video was removed or you do not have permission to view it.")
                else showVideoPlayer(videoId, doc.data ?: emptyMap())
            }
            .addOnFailureListener { error ->
                Log.e("HiraBhaiVideo", "Video metadata read failed: /videos/$videoId", error)
                info("Video unavailable", friendlyError(error))
            }
    }

    private fun showVideoPlayer(videoId: String, video: Map<String, Any>) {
        val storagePath = video["storagePath"] as? String ?: run { info("Video unavailable", "The video file path is missing."); return }
        selected = "Home"; base(); currentVideoId = videoId; activeHistoryVideoId = null
        val title = video["title"] as? String ?: "Video"
        val creator = video["creatorName"] as? String ?: video["creatorUsername"] as? String ?: "Creator"
        val frame = FrameLayout(this).apply { background = round(Color.BLACK, 16) }
        val playerView = PlayerView(this).apply {
            useController = true
            controllerAutoShow = true
            layoutParams = FrameLayout.LayoutParams(-1, -1)
        }
        val poster = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(Color.BLACK)
            layoutParams = FrameLayout.LayoutParams(-1, -1); isClickable = false
        }
        frame.addView(playerView)
        frame.addView(poster)
        (video["thumbnailStoragePath"] as? String)?.let { loadVideoThumbnail(it, poster) }
        val fullscreen = TextView(this).apply {
            text = "⛶"; textSize = 22f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = round(0xcc172b3b.toInt(), 10); setPadding(dp(8), dp(4), dp(8), dp(4))
            setOnClickListener { if (videoFullscreen) exitVideoFullscreen() else enterVideoFullscreen() }
            layoutParams = FrameLayout.LayoutParams(dp(44), dp(44), Gravity.TOP or Gravity.END).apply { topMargin = dp(10); rightMargin = dp(10) }
        }
        frame.addView(fullscreen)
        videoCaptionOverlay = TextView(this).apply {
            textSize = 17f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = round(0xdd071521.toInt(), 8); setPadding(dp(10), dp(7), dp(10), dp(7)); visibility = View.GONE
            layoutParams = FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { leftMargin = dp(18); rightMargin = dp(18); bottomMargin = dp(20) }
        }
        frame.addView(videoCaptionOverlay)
        videoPlayerFrame = frame; videoPlayerView = playerView
        content.addView(frame, LinearLayout.LayoutParams(-1, dp(228)).apply { bottomMargin = dp(12) })
        val captionControls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; visibility = View.GONE }
        videoCaptionToggle = CheckBox(this).apply { text = "Captions"; setTextColor(primaryText); isEnabled = false; setOnCheckedChangeListener { _, checked -> videoCaptionOverlay?.visibility = if (checked) View.VISIBLE else View.GONE; videoPlayer?.let { updateCaptionAt(it.currentPosition) } } }
        val captionLanguage = Spinner(this)
        captionControls.addView(videoCaptionToggle, LinearLayout.LayoutParams(-2, dp(48)))
        captionControls.addView(captionLanguage, LinearLayout.LayoutParams(0, dp(48), 1f))
        content.addView(captionControls)
        loadVideoCaptionOptions(videoId, captionControls, captionLanguage)
        content.addView(label(title, 22, primaryText, true))
        content.addView(label("$creator  ·  ${formatDuration((video["durationMs"] as? Number)?.toLong() ?: 0L)}", 14, secondaryText, false).apply { setPadding(0, dp(5), 0, dp(10)) })
        if (FirebaseBackend.auth?.currentUser?.uid != video["ownerUid"]) {
            val reportVideo = TextView(this).apply {
                text = "⚑  Report video"; textSize = 13f; setTextColor(secondaryText); setPadding(0, dp(2), 0, dp(10))
                isClickable = true; isFocusable = true; setOnClickListener { showReportDialog("video", videoId) }
            }
            content.addView(reportVideo)
        }
        val descriptionCard = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = round(Color.WHITE, 16); setPadding(dp(15), dp(14), dp(15), dp(14)) }
        descriptionCard.addView(label((video["description"] as? String).orEmpty().ifBlank { "No description provided." }, 15, primaryText, false))
        content.addView(descriptionCard)
        val status = label("Preparing video…", 13, secondaryText, false).apply { setPadding(0, dp(10), 0, dp(4)) }
        val downloadProgress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE }
        content.addView(downloadProgress); content.addView(status)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val likeButton = TextView(this).apply { text = "Loading likes…"; textSize = 15f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE); background = round(mint, 14); gravity = Gravity.CENTER; setPadding(dp(18), dp(12), dp(18), dp(12)) }
        actions.addView(likeButton)
        if ((video["visibility"] as? String) != "private") {
            val shareButton = TextView(this).apply {
                text = "Share"; textSize = 14f; setTextColor(primaryText); gravity = Gravity.CENTER; setPadding(dp(16), dp(12), dp(16), dp(12))
                setOnClickListener {
                    val share = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, "Watch on Hira Bhai: hirabhai:/v/$videoId")
                    startActivity(Intent.createChooser(share, "Share video"))
                }
            }
            actions.addView(shareButton)
        }
        content.addView(actions, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        addVideoLibraryButtons(content, videoId, video)
        loadRelatedVideos(content, videoId, video)
        configureVideoLike(videoId, likeButton, video["creatorId"] as? String ?: "", video["creatorUsername"] as? String ?: "creator", creator)
        section("Comments")
        val commentCount = label("Loading comment count…", 12, secondaryText, false).apply { setPadding(0, 0, 0, dp(8)) }
        content.addView(commentCount)
        val commentInput = field("Write a comment", android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE)
        commentInput.maxLines = 3
        content.addView(commentInput)
        val comments = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        button("Post comment") { postVideoComment(videoId, commentInput, comments, video["creatorId"] as? String ?: "", video["creatorUsername"] as? String ?: "creator") }
        content.addView(comments)
        loadVideoComments(videoId, comments, commentCount)
        val storage = FirebaseBackend.storage
        if (storage == null) status.text = "Firebase Storage is unavailable: ${FirebaseBackend.storageSetupError ?: "check bucket configuration"}"
        else {
            val cacheFile = File(cacheDir, "hira_video_$videoId.media")
            if (cacheFile.exists() && cacheFile.length() > 0L) prepareMediaPlayer(playerView, poster, cacheFile, status, videoId, video)
            else {
                downloadProgress.visibility = View.VISIBLE
                status.text = "Downloading video securely…"
                val task = storage.reference.child(storagePath).getFile(cacheFile)
                task.addOnProgressListener { snapshot ->
                    val total = snapshot.totalByteCount.coerceAtLeast(1L)
                    downloadProgress.progress = ((snapshot.bytesTransferred * 100L) / total).toInt().coerceIn(0, 100)
                    status.text = "Downloading video… ${downloadProgress.progress}%"
                }.addOnSuccessListener { downloadProgress.visibility = View.GONE; prepareMediaPlayer(playerView, poster, cacheFile, status, videoId, video) }
                    .addOnFailureListener { error ->
                        downloadProgress.visibility = View.GONE; status.text = "Video download failed: ${friendlyError(error)}"
                        cacheFile.delete(); Log.e("HiraBhaiVideo", "Storage read failed at $storagePath", error)
                    }
            }
        }
        addBottom()
    }

    private fun prepareMediaPlayer(view: PlayerView, poster: ImageView, file: File, status: TextView, videoId: String, video: Map<String, Any>) {
        val player = ExoPlayer.Builder(this).build()
        var recordedSession = false
        val playbackSpeed = getSharedPreferences("hira_user_preferences", MODE_PRIVATE).getFloat("playback_speed", 1.0f)
        player.setPlaybackSpeed(playbackSpeed)
        videoPlayer = player; view.player = player
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (isPlaying) {
                    activeHistoryVideoId = videoId
                    if (!recordedSession) { recordedSession = true; recordVideoOpened(videoId, video) }
                    schedulePlaybackProgress(videoId, player)
                    startCaptionTicker(player)
                }
                else {
                    playbackProgressRunnable?.let { playbackProgressHandler.removeCallbacks(it) }
                    playbackProgressRunnable = null
                    savePlaybackProgress(videoId, player)
                    stopCaptionTicker(); updateCaptionAt(player.currentPosition)
                }
            }
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) { poster.visibility = View.GONE; status.text = "Ready to play" }
                else if (playbackState == Player.STATE_BUFFERING) status.text = "Buffering video…"
                else if (playbackState == Player.STATE_ENDED) {
                    savePlaybackProgress(videoId, player)
                    if (!playNextPlaylistVideo()) status.text = "Video finished"
                }
            }
            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                status.text = "Could not play this video: ${error.message ?: "unsupported or damaged video format"}"
                Log.e("HiraBhaiVideo", "Media3 playback failed", error)
            }
        })
        player.setMediaItem(MediaItem.fromUri(Uri.fromFile(file)))
        player.prepare()
        val user = FirebaseBackend.auth?.currentUser
        val history = user?.let { FirebaseBackend.db?.collection("userActivity")?.document(it.uid)?.collection("watchHistory")?.document(videoId) }
        if (history == null) player.playWhenReady = true
        else history.get().addOnSuccessListener { snapshot ->
            val savedPosition = (snapshot.getLong("positionMs") ?: 0L).coerceAtLeast(0L)
            val savedDuration = (snapshot.getLong("durationMs") ?: 0L).coerceAtLeast(0L)
            if (savedPosition > 5_000L && (savedDuration == 0L || savedPosition < savedDuration - 3_000L)) {
                player.seekTo(savedPosition)
                status.text = "Resuming from ${formatDuration(savedPosition)}"
            }
            player.playWhenReady = true
        }.addOnFailureListener {
            Log.w("HiraBhaiHistory", "Resume position lookup failed", it)
            player.playWhenReady = true
        }
    }

    private fun loadVideoCaptionOptions(videoId: String, controls: LinearLayout, languageSpinner: Spinner) {
        captionLanguageOptions.clear(); activeVideoCaptions = emptyList(); videoCaptionToggle?.isChecked = false
        val db = FirebaseBackend.db ?: return
        db.collection("videos").document(videoId).collection("captions").get()
            .addOnSuccessListener { docs ->
                captionLanguageOptions = docs.documents.mapNotNull { doc ->
                    val language = doc.getString("language") ?: return@mapNotNull null
                    language to doc.id
                }.toMutableList()
                if (captionLanguageOptions.isEmpty()) return@addOnSuccessListener
                controls.visibility = View.VISIBLE
                languageSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, captionLanguageOptions.map { it.first })
                videoCaptionToggle?.isEnabled = true
                languageSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                    override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
                    override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                        captionLanguageOptions.getOrNull(position)?.second?.let { languageKey -> loadVideoCaptionTrack(videoId, languageKey) }
                    }
                }
            }
            .addOnFailureListener { Log.w("HiraBhaiCaptions", "Caption track listing failed for video $videoId", it) }
    }

    private fun loadVideoCaptionTrack(videoId: String, languageKey: String) {
        val doc = FirebaseBackend.db?.collection("videos")?.document(videoId)?.collection("captions")?.document(languageKey) ?: return
        doc.get().addOnSuccessListener { snapshot ->
            val path = snapshot.getString("storagePath") ?: return@addOnSuccessListener
            val cache = File(cacheDir, "hira-captions-${videoId}-${languageKey}.srt")
            fun showTrack() {
                try { activeVideoCaptions = parseSrt(cache.readText(Charsets.UTF_8)); videoPlayer?.let { updateCaptionAt(it.currentPosition) } }
                catch (error: Exception) { Log.w("HiraBhaiCaptions", "Caption parse failed", error); activeVideoCaptions = emptyList() }
            }
            if (cache.exists() && cache.length() > 0) showTrack()
            else FirebaseBackend.storage?.reference?.child(path)?.getFile(cache)?.addOnSuccessListener { showTrack() }
                ?.addOnFailureListener { cache.delete(); info("Captions unavailable", friendlyError(it)) }
        }
    }

    private fun parseSrt(source: String): List<CaptionCue> {
        fun timeMs(value: String): Long? {
            val groups = Regex("(\\d{2}):(\\d{2}):(\\d{2}),(\\d{3})").matchEntire(value.trim())?.groupValues ?: return null
            return groups[1].toLong() * 3_600_000 + groups[2].toLong() * 60_000 + groups[3].toLong() * 1000 + groups[4].toLong()
        }
        return source.replace("\r", "").split(Regex("\\n\\s*\\n")).mapNotNull { block ->
            val lines = block.lines().filter { it.isNotBlank() }
            val timeLine = lines.firstOrNull { "-->" in it } ?: return@mapNotNull null
            val range = timeLine.split("-->", limit = 2)
            val start = timeMs(range[0]) ?: return@mapNotNull null; val end = timeMs(range[1]) ?: return@mapNotNull null
            val text = lines.dropWhile { it != timeLine }.drop(1).joinToString(" ").trim()
            if (text.isBlank()) null else CaptionCue(start, end, text)
        }.sortedBy { it.startMs }
    }

    private fun updateCaptionAt(positionMs: Long) {
        val toggle = videoCaptionToggle
        val overlay = videoCaptionOverlay
        if (toggle?.isChecked != true || overlay == null) { overlay?.visibility = View.GONE; return }
        val cue = activeVideoCaptions.firstOrNull { positionMs >= it.startMs && positionMs < it.endMs }
        overlay.text = cue?.text.orEmpty(); overlay.visibility = if (cue == null) View.GONE else View.VISIBLE
    }

    private fun startCaptionTicker(player: ExoPlayer) {
        stopCaptionTicker()
        val ticker = object : Runnable { override fun run() { if (videoPlayer !== player || !player.isPlaying) return; updateCaptionAt(player.currentPosition); playbackProgressHandler.postDelayed(this, 120) } }
        captionTicker = ticker; playbackProgressHandler.post(ticker)
    }

    private fun stopCaptionTicker() { captionTicker?.let(playbackProgressHandler::removeCallbacks); captionTicker = null; videoCaptionOverlay?.visibility = View.GONE }

    private fun configureVideoLike(videoId: String, button: TextView, targetCreatorId: String, targetUsername: String, targetName: String) {
        val db = FirebaseBackend.db ?: run { button.text = "Likes unavailable"; button.isEnabled = false; return }
        val videoRef = db.collection("videos").document(videoId)
        val likesRef = videoRef.collection("likes")
        val statsRef = db.collection("videoStats").document(videoId)
        var liked = false
        var count = 0L
        fun updateLabel() {
            val user = FirebaseBackend.auth?.currentUser
            button.text = when {
                user == null -> "♡ Like · $count"
                liked -> "♥ Liked · $count"
                else -> "♡ Like · $count"
            }
        }
        val countListener = statsRef.addSnapshotListener { snapshot, error ->
            if (error != null) {
                button.text = "Like count unavailable"
                Log.e("HiraBhaiVideo", "Like count read failed: /videoStats/$videoId", error)
                return@addSnapshotListener
            }
            count = (snapshot?.getLong("likeCount") ?: 0L).coerceAtLeast(0L)
            updateLabel()
        }
        screenFirestoreListeners.add(countListener)
        val initialUser = FirebaseBackend.auth?.currentUser
        if (initialUser != null) {
            val ownLike = likesRef.document(initialUser.uid)
            val ownListener = ownLike.addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("HiraBhaiVideo", "Own like read failed: /videos/$videoId/likes/${initialUser.uid}", error)
                    return@addSnapshotListener
                }
                liked = snapshot?.exists() == true
                updateLabel()
            }
            screenFirestoreListeners.add(ownListener)
        }
        button.setOnClickListener {
            val user = FirebaseBackend.auth?.currentUser
            if (user == null) { showAuth(false); return@setOnClickListener }
            val ownLike = likesRef.document(user.uid)
            db.collection("profiles").document(user.uid).get().addOnFailureListener { error ->
                button.isEnabled = true; info("Like", friendlyError(error)); Log.e("HiraBhaiNotifications", "Could not resolve sender profile for video like", error)
            }.addOnSuccessListener { ownProfile ->
            val senderCreatorId = ownProfile.getString("creatorId") ?: run { button.isEnabled = true; info("Like", "Create a creator profile before liking videos."); return@addOnSuccessListener }
            val senderUsername = ownProfile.getString("username") ?: "creator"
            val notification = if (targetCreatorId.isNotBlank() && senderCreatorId != targetCreatorId)
                db.collection("notifications").document(targetCreatorId).collection("items").document("like_${videoId}_${user.uid}") else null
            button.isEnabled = false
            db.runTransaction { tx ->
                val current = tx.get(ownLike)
                val stats = tx.get(statsRef)
                val currentCount = (stats.getLong("likeCount") ?: 0L).coerceAtLeast(0L)
                if (current.exists()) {
                    if (!stats.exists() || currentCount < 1L) throw IllegalStateException("Like count data is inconsistent")
                    tx.delete(ownLike)
                    tx.update(statsRef, "likeCount", currentCount - 1L)
                    false
                } else {
                    tx.set(ownLike, mapOf("uid" to user.uid, "createdAt" to FieldValue.serverTimestamp()))
                    if (stats.exists()) tx.update(statsRef, "likeCount", currentCount + 1L)
                    else tx.set(statsRef, mapOf("videoId" to videoId, "likeCount" to 1L))
                    if (notification != null) tx.set(notification, notificationData("like", senderCreatorId, senderUsername, ownProfile.getString("fullName") ?: "Creator", "liked your video", targetCreatorId, targetUsername, videoId))
                    true
                }
            }.addOnSuccessListener { liked = it; setRecommendationLike(videoId, it); updateLabel(); button.isEnabled = true }
                .addOnFailureListener { error -> button.isEnabled = true; info("Like", friendlyError(error)); Log.e("HiraBhaiVideo", "Like write failed: /videos/$videoId/likes/${user.uid}", error) }
            }
        }
    }

    private fun loadVideoComments(videoId: String, target: LinearLayout, countLabel: TextView) {
        val db = FirebaseBackend.db ?: run { countLabel.text = "Comments unavailable"; return }
        val commentRef = db.collection("videos").document(videoId).collection("comments")
        val ownUid = FirebaseBackend.auth?.currentUser?.uid
        val ownProfileTask = ownUid?.let { db.collection("profiles").document(it).get() }
        ownProfileTask?.addOnSuccessListener { profile ->
            attachVideoCommentListener(commentRef, target, countLabel, videoId, ownUid, profile.getString("creatorId"))
        }?.addOnFailureListener { error ->
            Log.w("HiraBhaiVideo", "Could not load comment owner profile", error)
            attachVideoCommentListener(commentRef, target, countLabel, videoId, ownUid, null)
        } ?: attachVideoCommentListener(commentRef, target, countLabel, videoId, null, null)
    }

    private fun attachVideoCommentListener(
        commentRef: com.google.firebase.firestore.CollectionReference,
        target: LinearLayout, countLabel: TextView, videoId: String,
        ownUid: String?, ownCreatorId: String?
    ) {
        val listener = commentRef.orderBy("createdAt", com.google.firebase.firestore.Query.Direction.ASCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    countLabel.text = "Comment count unavailable"
                    target.removeAllViews()
                    target.addView(label("Comments could not be loaded: ${friendlyError(error)}", 13, secondaryText, false))
                    Log.e("HiraBhaiVideo", "Comment query failed: /videos/$videoId/comments", error)
                    return@addSnapshotListener
                }
                val documents = snapshot?.documents.orEmpty()
                countLabel.text = "Comments · ${documents.size}"
                target.removeAllViews()
                if (documents.isEmpty()) {
                    target.addView(label("No comments yet. Start the conversation.", 13, secondaryText, false))
                    return@addSnapshotListener
                }
                documents.takeLast(50).forEach { doc ->
                    val username = doc.getString("authorUsername") ?: "creator"
                    val card = LinearLayout(this).apply {
                        orientation = LinearLayout.VERTICAL; background = round(Color.WHITE, 14)
                        setPadding(dp(12), dp(11), dp(12), dp(11))
                    }
                    val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                    val avatar = ImageView(this).apply {
                        setImageResource(android.R.drawable.ic_menu_camera); scaleType = ImageView.ScaleType.CENTER_CROP
                        background = round(0xffdce8ed.toInt(), 100); clipToOutline = true
                        layoutParams = LinearLayout.LayoutParams(dp(38), dp(38)).apply { rightMargin = dp(9) }
                        contentDescription = "@$username profile picture"
                    }
                    loadCommentAvatar(username, avatar)
                    val author = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                    author.addView(label("@$username", 13, mint, true))
                    val time = doc.getTimestamp("createdAt")?.toDate()?.let {
                        SimpleDateFormat("MMM d, yyyy · h:mm a", Locale.getDefault()).format(it)
                    } ?: "Just now"
                    author.addView(label(time, 11, secondaryText, false).apply { setPadding(0, dp(2), 0, 0) })
                    header.addView(avatar); header.addView(author, LinearLayout.LayoutParams(0, -2, 1f))
                    val isOwnComment = (ownCreatorId != null && doc.getString("authorCreatorId") == ownCreatorId)
                        || (ownUid != null && doc.getString("uid") == ownUid) // legacy comments
                    if (isOwnComment) {
                        val delete = TextView(this).apply {
                            text = "Delete"; textSize = 12f; setTextColor(0xffa33d46.toInt())
                            setPadding(dp(8), dp(6), dp(4), dp(6)); isClickable = true; isFocusable = true
                            setOnClickListener {
                                isEnabled = false
                                doc.reference.delete().addOnFailureListener { failure ->
                                    isEnabled = true; info("Delete comment", friendlyError(failure))
                                    Log.e("HiraBhaiVideo", "Comment delete failed: /videos/$videoId/comments/${doc.id}", failure)
                                }
                            }
                        }
                        header.addView(delete)
                    } else {
                        val report = TextView(this).apply {
                            text = "Report"; textSize = 12f; setTextColor(0xffa33d46.toInt())
                            setPadding(dp(8), dp(6), dp(4), dp(6)); isClickable = true; isFocusable = true
                            setOnClickListener { showReportDialog("comment", doc.id, videoId, doc.id) }
                        }
                        header.addView(report)
                    }
                    card.addView(header)
                    card.addView(label(doc.getString("text") ?: "", 14, primaryText, false).apply { setPadding(0, dp(8), 0, 0) })
                    target.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
                }
            }
        screenFirestoreListeners.add(listener)
    }

    private fun loadCommentAvatar(username: String, target: ImageView) {
        if (publicPhotoCache.containsKey(username)) {
            publicPhotoCache[username]?.let { showProfilePhoto(it, target) }
            return
        }
        val db = FirebaseBackend.db ?: return
        db.collection("publicProfiles").document(username).get()
            .addOnSuccessListener { profile ->
                val photo = profile.getString("photoData")
                publicPhotoCache[username] = photo
                if (photo != null && target.isAttachedToWindow) showProfilePhoto(photo, target)
            }
            .addOnFailureListener { Log.w("HiraBhaiVideo", "Public comment avatar lookup failed: /publicProfiles/$username", it) }
    }

    private fun postVideoComment(videoId: String, input: EditText, comments: LinearLayout, targetCreatorId: String, targetUsername: String) {
        val user = FirebaseBackend.auth?.currentUser ?: run { showAuth(false); return }
        val text = input.text.toString().trim()
        if (text.isBlank() || text.length > 1000) { input.error = "Enter a comment of 1–1,000 characters"; return }
        val db = FirebaseBackend.db ?: run { info("Comment", "Firestore is unavailable."); return }
        db.collection("profiles").document(user.uid).get().addOnSuccessListener { profile ->
            val username = profile.getString("username")
            val creatorId = profile.getString("creatorId")
            if (!profile.exists() || username.isNullOrBlank() || creatorId.isNullOrBlank()) { info("Comment", "Set up your creator profile before commenting."); return@addOnSuccessListener }
            val comment = db.collection("videos").document(videoId).collection("comments").document()
            val payload = mapOf("authorCreatorId" to creatorId, "authorUsername" to username, "text" to text, "createdAt" to FieldValue.serverTimestamp())
            val batch = db.batch(); batch.set(comment, payload)
            if (targetCreatorId.isNotBlank() && targetCreatorId != creatorId) {
                val notification = db.collection("notifications").document(targetCreatorId).collection("items").document("comment_${videoId}_${comment.id}")
                batch.set(notification, notificationData("comment", creatorId, username, profile.getString("fullName") ?: "Creator", "commented on your video", targetCreatorId, targetUsername, videoId, comment.id))
            }
            batch.commit()
                .addOnSuccessListener { input.text.clear() }
                .addOnFailureListener { error -> info("Comment failed", friendlyError(error)); Log.e("HiraBhaiVideo", "Comment write failed: /videos/$videoId/comments/${comment.id}", error) }
        }.addOnFailureListener { info("Comment", friendlyError(it)) }
    }

    private fun enterVideoFullscreen() {
        val frame = videoPlayerFrame ?: return
        val scroll = mainScroll ?: return
        (frame.parent as? ViewGroup)?.removeView(frame)
        frame.layoutParams = FrameLayout.LayoutParams(-1, -1)
        root.removeView(scroll); bottomBar?.let { root.removeView(it) }
        root.setPadding(0, 0, 0, 0)
        root.addView(frame, LinearLayout.LayoutParams(-1, -1))
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        videoFullscreen = true
    }

    private fun exitVideoFullscreen() {
        val frame = videoPlayerFrame ?: return
        root.removeView(frame)
        content.addView(frame, 0, LinearLayout.LayoutParams(-1, dp(228)).apply { bottomMargin = dp(12) })
        mainScroll?.let { root.addView(it, LinearLayout.LayoutParams(-1, 0, 1f)) }
        bottomBar?.let { root.addView(it, LinearLayout.LayoutParams(-1, -2)) }
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        root.setPadding(0, 0, 0, systemNavigationInset)
        content.setPadding(dp(20), dp(14) + statusBarInset, dp(20), dp(20))
        videoFullscreen = false
        root.requestApplyInsets()
    }

    private fun releaseVideoPlayer() {
        stopCaptionTicker(); videoCaptionOverlay = null; videoCaptionToggle = null; activeVideoCaptions = emptyList(); captionLanguageOptions.clear()
        stopPlaybackProgress(save = true)
        if (videoFullscreen) {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            videoFullscreen = false
        }
        videoPlayer?.release(); videoPlayer = null; videoPlayerView = null; videoPlayerFrame = null; currentVideoId = null; activeHistoryVideoId = null
    }

    private fun startPlaylistPlayback(videoIds: List<String>) {
        playlistQueue = videoIds.distinct()
        playlistQueueIndex = -1
        if (!playNextPlaylistVideo()) info("Playlist empty", "Add public videos to this playlist before playing it.")
    }

    private fun playNextPlaylistVideo(): Boolean {
        val nextIndex = playlistQueueIndex + 1
        if (nextIndex !in playlistQueue.indices) {
            playlistQueue = emptyList(); playlistQueueIndex = -1
            return false
        }
        playlistQueueIndex = nextIndex
        val id = playlistQueue[nextIndex]
        val db = FirebaseBackend.db ?: run { playlistQueue = emptyList(); playlistQueueIndex = -1; return false }
        db.collection("videos").document(id).get().addOnSuccessListener { doc ->
            if (doc.exists()) showVideoPlayer(id, doc.data ?: emptyMap())
            else if (!playNextPlaylistVideo()) info("Playlist ended", "The next video is no longer available.")
        }.addOnFailureListener { error ->
            Log.w("HiraBhaiPlaylist", "Could not load next public playlist video", error)
            if (!playNextPlaylistVideo()) info("Playlist ended", "The next video could not be opened.")
        }
        return true
    }

    private fun formatDuration(durationMs: Long): String {
        if (durationMs <= 0L) return "Video"
        val seconds = durationMs / 1000L
        return if (seconds >= 3600) "%d:%02d:%02d".format(seconds / 3600, (seconds % 3600) / 60, seconds % 60)
        else "%d:%02d".format(seconds / 60, seconds % 60)
    }

    private fun subscriberCountLabel(creatorId: String): TextView {
        val countLabel = label("Loading subscribers…", 13, secondaryText, false).apply { setPadding(0, dp(4), 0, dp(8)) }
        content.addView(countLabel)
        FirebaseBackend.db?.collection("creatorStats")?.document(creatorId)?.get()
            ?.addOnSuccessListener { stats ->
                val count = (stats.getLong("subscriberCount") ?: 0L).coerceAtLeast(0L)
                countLabel.text = "$count ${if (count == 1L) "subscriber" else "subscribers"}"
            }
            ?.addOnFailureListener { countLabel.text = "Subscriber count unavailable" }
        return countLabel
    }

    private fun addSubscriptionControl(creatorUsername: String, creatorId: String?, countLabel: TextView?) {
        val me = FirebaseBackend.auth?.currentUser
        if (me == null) { button("Log in to subscribe") { showAuth(false) }; return }
        if (creatorId == null) { content.addView(label("This creator profile needs to be refreshed by its owner before subscriptions are available.", 13, secondaryText, false)); return }
        val db = FirebaseBackend.db
        if (db == null) { content.addView(label("Subscriptions are unavailable until Firebase is configured.", 13, secondaryText, false)); return }
        val status = label("Checking subscription…", 13, secondaryText, false).apply { setPadding(0, dp(4), 0, dp(8)) }
        content.addView(status)
        db.collection("profiles").document(me.uid).get()
            .addOnSuccessListener { ownProfile ->
                if (!ownProfile.exists()) {
                    status.text = "Set up your creator profile before subscribing."
                    return@addOnSuccessListener
                }
                if (ownProfile.getString("creatorId") == creatorId) {
                    status.text = "This is your creator profile."
                    return@addOnSuccessListener
                }
                val ref = db.collection("subscriptions").document(me.uid).collection("creators").document(creatorId)
                val statsRef = db.collection("creatorStats").document(creatorId)
                val notificationRef = db.collection("notifications").document(creatorId).collection("items").document("subscribe_${me.uid}")
                    ref.get().addOnSuccessListener { current ->
                    val alreadySubscribed = current.exists()
                    var subscribed = alreadySubscribed
                    val toggle = TextView(this).apply {
                        textSize = 15f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
                        setTextColor(Color.WHITE); background = round(mint, 16)
                        setPadding(dp(14), dp(14), dp(14), dp(14)); isClickable = true; isFocusable = true
                    }
                    fun updateLabel() { toggle.text = if (subscribed) "✓ Subscribed · tap to unsubscribe" else "＋ Subscribe" }
                    updateLabel()
                    toggle.setOnClickListener {
                        toggle.isEnabled = false
                        db.runTransaction { tx ->
                            val saved = tx.get(ref)
                            val stats = tx.get(statsRef)
                            val count = (stats.getLong("subscriberCount") ?: 0L).coerceAtLeast(0L)
                            if (saved.exists()) {
                                tx.delete(ref)
                                if (stats.exists()) tx.update(statsRef, "subscriberCount", (count - 1).coerceAtLeast(0L))
                                false
                            } else {
                                tx.set(ref, mapOf(
                                    "subscriberUid" to me.uid,
                                    "creatorId" to creatorId,
                                    "creatorUsername" to creatorUsername,
                                    "createdAt" to FieldValue.serverTimestamp()
                                ))
                                tx.set(statsRef, mapOf("creatorId" to creatorId, "subscriberCount" to count + 1))
                                tx.set(notificationRef, notificationData(
                                    "subscribe", ownProfile.getString("creatorId") ?: "", ownProfile.getString("username") ?: "creator",
                                    ownProfile.getString("fullName") ?: "Creator", "subscribed to your channel", creatorId, creatorUsername
                                ))
                                true
                            }
                        }.addOnSuccessListener { result ->
                            subscribed = result; updateLabel(); toggle.isEnabled = true
                            statsRef.get().addOnSuccessListener { stats ->
                                val count = (stats.getLong("subscriberCount") ?: 0L).coerceAtLeast(0L)
                                countLabel?.text = "$count ${if (count == 1L) "subscriber" else "subscribers"}"
                            }
                        }
                            .addOnFailureListener { failure -> toggle.isEnabled = true; info("Subscription", friendlyError(failure)) }
                    }
                    content.addView(toggle, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
                    status.text = ""
                }.addOnFailureListener { status.text = friendlyError(it) }
            }
            .addOnFailureListener { status.text = friendlyError(it) }
    }

    private fun field(hintText: String, inputType: Int) = EditText(this).apply {
        hint = hintText; setHintTextColor(0xff71879b.toInt()); setTextColor(primaryText); textSize = 15f; this.inputType = inputType
        background = round(Color.WHITE, 14); setPadding(dp(14), dp(12), dp(14), dp(12))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }
    }

    private fun button(title: String, click: () -> Unit) {
        val b = buttonView(title, click)
        content.addView(b, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
    }

    private fun buttonView(title: String, click: () -> Unit) = TextView(this).apply {
        text = title; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; minHeight = dp(48)
        setTextColor(Color.WHITE); background = glass(0x7723a48f, 18); setPadding(dp(14), dp(14), dp(14), dp(14))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }
        isClickable = true; isFocusable = true; setOnClickListener { click() }
    }

    private fun showProfilePhoto(encoded: String, target: ImageView) {
        try {
            val bytes = Base64.decode(encoded, Base64.NO_WRAP)
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.let { target.setImageBitmap(it) }
        } catch (_: Exception) { /* Keep the neutral placeholder for invalid legacy data. */ }
    }

    private fun encodeProfilePhoto(uri: Uri): String? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (bounds.outWidth / sample > 768 || bounds.outHeight / sample > 768) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        var bitmap = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) } ?: return null
        if (bitmap.width > 512 || bitmap.height > 512) {
            val scale = minOf(512f / bitmap.width, 512f / bitmap.height)
            val scaled = Bitmap.createScaledBitmap(bitmap, (bitmap.width * scale).toInt(), (bitmap.height * scale).toInt(), true)
            if (scaled !== bitmap) bitmap.recycle()
            bitmap = scaled
        }
        var jpeg = ByteArrayOutputStream()
        var quality = 76
        do {
            jpeg = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, quality, jpeg)
            quality -= 10
        } while (jpeg.size() > 400_000 && quality >= 46)
        bitmap.recycle()
        val bytes = jpeg.toByteArray()
        return if (bytes.size <= 400_000) Base64.encodeToString(bytes, Base64.NO_WRAP) else null
    }

    private fun setBusy(busy: Boolean) { window.decorView.isEnabled = !busy; window.decorView.alpha = if (busy) .65f else 1f }

    private fun friendlyError(error: Throwable?): String {
        val code = (error as? com.google.firebase.auth.FirebaseAuthException)?.errorCode.orEmpty()
        return when (code) {
            "ERROR_INVALID_EMAIL" -> "That email address is not valid."
            "ERROR_USER_NOT_FOUND", "ERROR_WRONG_PASSWORD", "ERROR_INVALID_CREDENTIAL" -> "Email or password is incorrect."
            "ERROR_EMAIL_ALREADY_IN_USE" -> "An account already uses that email. Try logging in."
            "ERROR_WEAK_PASSWORD" -> "Choose a stronger password with at least 6 characters."
            "ERROR_TOO_MANY_REQUESTS" -> "Too many attempts. Wait a little and try again."
            "ERROR_NETWORK_REQUEST_FAILED" -> "Network connection failed. Check your internet and try again."
            else -> error?.localizedMessage ?: "Something went wrong. Please try again."
        }
    }

    private fun firebaseSetupInfo() = info("Connect Firebase", "1. Create a Firebase project and register an Android app with package name com.hirabhai.platform.\n2. Enable Authentication → Email/Password and create a Cloud Firestore database.\n3. Download google-services.json and place it at the app/google-services.json path in this project.\n4. Create/enable the Cloud Storage bucket and deploy firestore.rules and storage.rules.\n5. File sharing rules check Firestore metadata from Storage rules; enable the cross-service permission when Firebase prompts.\n\nCloud Storage for Firebase now requires the pay-as-you-go Blaze plan, even while usage stays within no-cost quotas. A billing account must be linked to the Firebase project. Set a budget alert in Google Cloud.\n\nPasswords are handled only by Firebase Authentication; they are never stored in Firestore. Profile photos are compressed before being saved in the owner's Firestore profile document.")

    @Deprecated("Profile image picker callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 2031 && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) { aiInput?.setText(spoken); aiInput?.setSelection(spoken.length) }
        } else if (requestCode == 45 && resultCode == RESULT_OK) {
            selectedPhoto = data?.data
            try { selectedPhoto?.let { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) } } catch (_: Exception) {}
            showProfileEditor()
        } else if ((requestCode == 46 || requestCode == 75) && resultCode == RESULT_OK) {
            pendingVideoIsShort = requestCode == 75
            selectedVideoUri = data?.data
            selectedVideoThumbnailUri = null; videoThumbnail = null; selectedVideoDurationMs = 0L
            pendingVideoTitle = ""; pendingVideoDescription = ""; pendingVideoVisibility = "public"; pendingVideoHashtags = ""
            try { selectedVideoUri?.let { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) } } catch (_: Exception) {}
            selectedVideoUri?.let { showVideoUploadForm(it) }
        } else if (requestCode == 47 && resultCode == RESULT_OK) {
            selectedVideoThumbnailUri = data?.data
            try { selectedVideoThumbnailUri?.let { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) } } catch (_: Exception) {}
            selectedVideoUri?.let { showVideoUploadForm(it) }
        } else if (requestCode == 48 && resultCode == RESULT_OK) {
            selectedAudioUri = data?.data
            try { selectedAudioUri?.let { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) } } catch (_: Exception) {}
            selectedAudioUri?.let { showAudioUploadForm(it) }
        } else if (requestCode == 49 && resultCode == RESULT_OK) {
            selectedAudioCoverUri = data?.data
            try { selectedAudioCoverUri?.let { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) } } catch (_: Exception) {}
            selectedAudioUri?.let { showAudioUploadForm(it) }
        } else if (requestCode == 50 && resultCode == RESULT_OK) {
            aiVideoReferenceUri = data?.data
            try { aiVideoReferenceUri?.let { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) } } catch (_: Exception) {}
            aiVideoStatus?.text = if (aiVideoReferenceUri == null) "No reference image selected." else "Reference image selected. Enter a motion prompt and generate."
        } else if (requestCode == 52 && resultCode == RESULT_OK) {
            val uri = data?.data
            if (uri != null) {
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                showVideoEditingStudio(uri)
            }
        } else if (requestCode == 76 && resultCode == RESULT_OK) {
            val target = data?.data
            val source = pendingAudioExportFile
            pendingAudioExportFile = null
            if (target != null && source != null) aiScope.launch {
                try {
                    withContext(Dispatchers.IO) { contentResolver.openOutputStream(target)?.use { output -> source.inputStream().use { it.copyTo(output) } } ?: throw IllegalStateException("Could not open the save destination") }
                    voiceStatus?.text = "Narration saved to the selected location."
                    Toast.makeText(this@MainActivity, "Audio saved", Toast.LENGTH_SHORT).show()
                } catch (error: Exception) { info("Save audio failed", friendlyError(error)) }
            }
        } else if (requestCode == 77 && resultCode == RESULT_OK) {
            val video = data?.data
            val narration = pendingNarrationUri
            pendingNarrationUri = null
            if (video != null && narration != null) {
                try { contentResolver.takePersistableUriPermission(video, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                showVideoEditingStudio(video, narration)
            }
        } else if (requestCode == 78 && resultCode == RESULT_OK) {
            val target = data?.data; val source = pendingSubtitleSave; pendingSubtitleSave = null
            if (target != null && source != null) aiScope.launch {
                try { withContext(Dispatchers.IO) { contentResolver.openOutputStream(target)?.use { output -> source.inputStream().use { it.copyTo(output) } } ?: throw IllegalStateException("Could not open the save destination") }; subtitleStatus?.text = "SRT captions saved." }
                catch (error: Exception) { subtitleStatus?.text = "Could not save SRT: ${friendlyError(error)}" }
            }
        } else if (requestCode == 79 && resultCode == RESULT_OK) {
            val uri = data?.data
            if (uri != null) { try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}; subtitleVideoUri = uri; showSubtitleGenerator(uri) }
        } else if (requestCode == 53 && resultCode == RESULT_OK) {
            val target = data?.data
            val source = pendingVideoExportFile
            pendingVideoExportFile = null
            if (target != null && source != null) aiScope.launch {
                try {
                    withContext(Dispatchers.IO) { contentResolver.openOutputStream(target)?.use { output -> source.inputStream().use { it.copyTo(output) } } ?: throw IllegalStateException("Could not open the save destination") }
                    Toast.makeText(this@MainActivity, "Video saved", Toast.LENGTH_SHORT).show()
                    if (generatedAiVideoFile === source) aiVideoStatus?.text = "Video saved to the selected location."
                    else videoEditStatus?.text = "Edited copy saved to the selected location. The source remains unchanged."
                } catch (error: Exception) { info("Save failed", friendlyError(error)) }
            }
        } else if (requestCode == 54 && resultCode == RESULT_OK) {
            videoEditMusic = data?.data
            videoEditMusicIsNarration = false
            try { videoEditMusic?.let { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) } } catch (_: Exception) {}
            videoEditStatus?.text = if (videoEditMusic == null) "No background track selected." else "Background music selected and will be mixed into the export."
        } else if (requestCode == 55 && resultCode == RESULT_OK) {
            videoEditThumbnail = data?.data
            try { videoEditThumbnail?.let { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) } } catch (_: Exception) {}
            selectedVideoThumbnailUri = videoEditThumbnail
            videoEditStatus?.text = if (videoEditThumbnail == null) "No upload thumbnail selected." else "Thumbnail selected; it will be used if you upload the edited video to your channel."
        } else if (requestCode == 56 && resultCode == RESULT_OK) {
            data?.data?.let { uri ->
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                onWebsiteImageSelected(uri)
            }
        } else if (requestCode == 74 && resultCode == RESULT_OK) {
            communityImageUris.clear()
            val selectedUris = mutableListOf<Uri>()
            data?.clipData?.let { clip -> for (index in 0 until minOf(clip.itemCount, 4)) selectedUris.add(clip.getItemAt(index).uri) }
            if (selectedUris.isEmpty()) data?.data?.let(selectedUris::add)
            selectedUris.take(4).forEach { uri -> try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}; communityImageUris.add(uri) }
            if (communityImageUris.isNotEmpty()) showCommunityPostComposer()
            else if (resultCode == RESULT_OK) info("No images selected", "Choose one or more images to attach to your post.")
        } else if (requestCode == 48) {
            val bitmap = pendingImageSave; pendingImageSave = null
            val target = data?.data
            if (resultCode == RESULT_OK && bitmap != null && target != null) {
                aiScope.launch {
                    try {
                        withContext(Dispatchers.IO) {
                            val stream = contentResolver.openOutputStream(target) ?: throw IllegalStateException("Could not open the selected destination")
                            stream.use { if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)) throw IllegalStateException("Image encoding failed") }
                        }
                        imageGeneratorStatus?.text = "Image saved to the selected location."
                        Toast.makeText(this@MainActivity, "Image saved", Toast.LENGTH_SHORT).show()
                    } catch (error: Exception) {
                        Log.e("HiraBhaiAIImage", "Document save failed", error)
                        imageGeneratorStatus?.text = "Could not save the image: ${friendlyError(error)}"
                    }
                }
            }
        } else if (requestCode == 64 && resultCode == RESULT_OK) {
            val recorded = data?.data
            if (recorded != null) {
                try { contentResolver.takePersistableUriPermission(recorded, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                selectedVideoUri = recorded; selectedVideoThumbnailUri = null; videoThumbnail = null
                pendingVideoTitle = ""; pendingVideoDescription = ""; pendingVideoVisibility = "public"
                showVideoUploadForm(recorded)
            } else info("Recording unavailable", "The camera did not return a video. Try recording again or choose a video from your phone.")
        } else if ((requestCode == 44 || requestCode == 61 || requestCode == 62 || requestCode == 63) && resultCode == RESULT_OK) {
            val picked = data?.data
            if (picked != null) { try { contentResolver.takePersistableUriPermission(picked, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}; uploadCreatorFile(picked) }
        }
    }
    private fun section(s:String) { content.addView(label(s,20,primaryText,true).apply { setPadding(0,dp(20),0,dp(12)) }) }
    private fun rowChips(items: List<String>, onSelect: (String) -> Unit) {
        val horiz = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            isHorizontalFadingEdgeEnabled = false
            background = round(Color.TRANSPARENT, 28)
            clipToOutline = true
            clipToPadding = true
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val chips = mutableMapOf<String, TextView>()
        fun select(mode: String) {
            chips.forEach { (name, view) ->
                view.setTextColor(if (name == mode) 0xff073344.toInt() else Color.WHITE)
                view.background = if (name == mode) round(0xff25b9a0.toInt(), 100) else glass(0x3fffffff, 100)
            }
            onSelect(mode)
        }
        items.forEach { mode ->
            val chip = TextView(this).apply {
                text = mode; textSize = 13f; setTextColor(if (mode == "For you") 0xff073344.toInt() else Color.WHITE)
                background = if (mode == "For you") round(0xff25b9a0.toInt(), 100) else glass(0x3fffffff, 100)
                setPadding(dp(16), dp(9), dp(16), dp(9)); setOnClickListener { select(mode) }
            }
            chips[mode] = chip
            row.addView(chip, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(8) })
        }
        horiz.addView(row, ViewGroup.LayoutParams(-2, -2))
        content.addView(horiz, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })
    }
    private fun homeSection(title: String) { content.addView(label(title,21,Color.WHITE,true).apply { setPadding(0,dp(21),0,dp(12)) }) }
    private fun glass(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius=dp(radius).toFloat(); setStroke(dp(1),0x88ffffff.toInt()) }
    private fun websiteDialog() = showWebsiteBuilder()

    private fun showAiAppBuilder() {
        val user = FirebaseBackend.auth?.currentUser ?: run { info("Sign in required", "Sign in to create and save AI app projects."); return }
        selected = "AI App Builder"; base(); heading("AI App Builder", "Describe an Android app, preview it, save its source, then build an APK")
        val builderInfo = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = glass(0x24ffffff, 18)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        builderInfo.addView(label("Creates native Android Java source for screens, navigation, forms and local interactions. Preview is a UI mock based on the generated screen specification. Generation is limited to 4 requests/minute and 20/day; APK builds to 3/day. Cloud builds use billable Google Cloud services and require backend setup. APKs are debug-signed for testing; review generated code before installation.", 12, secondaryText, false))
        content.addView(builderInfo, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        appBuilderProjectId = getSharedPreferences("hira_ai_app_projects", MODE_PRIVATE).getString("active_${user.uid}", null) ?: UUID.randomUUID().toString()
        appBuilderName = EditText(this).apply { hint = "App name"; setText("My AI App"); setTextColor(primaryText); setHintTextColor(secondaryText); background = glass(0x30ffffff, 16); setPadding(dp(14), dp(10), dp(14), dp(10)) }
        appBuilderPackage = EditText(this).apply { hint = "Android package name"; setText("com.hirabuilder.apps.myapp"); inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI; setTextColor(primaryText); setHintTextColor(secondaryText); background = glass(0x30ffffff, 16); setPadding(dp(14), dp(10), dp(14), dp(10)) }
        appBuilderPrompt = EditText(this).apply { hint = "Describe the app in English, Hindi or Gujarati…"; minLines = 4; maxLines = 7; gravity = Gravity.TOP; setTextColor(primaryText); setHintTextColor(secondaryText); background = glass(0x30ffffff, 16); setPadding(dp(14), dp(12), dp(14), dp(12)) }
        content.addView(label("App name", 14, primaryText, true)); content.addView(appBuilderName, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(8) })
        content.addView(label("Package name", 14, primaryText, true)); content.addView(appBuilderPackage, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(8) })
        val templates = listOf("counter" to "Counter", "notes" to "Notes", "checklist" to "Checklist", "contact" to "Contact form", "blank" to "Blank app")
        val templateSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, templates.map { it.second })
            onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener { override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}; override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { appBuilderTemplate = templates[position].first } }
        }
        content.addView(label("Starter template", 14, primaryText, true)); content.addView(templateSpinner, LinearLayout.LayoutParams(-1, dp(48)))
        val themes = listOf("teal" to "Teal", "blue" to "Blue", "orange" to "Orange", "purple" to "Purple")
        val themeSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, themes.map { it.second })
            onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener { override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}; override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { appBuilderTheme = themes[position].first } }
        }
        content.addView(label("Accent color", 14, primaryText, true)); content.addView(themeSpinner, LinearLayout.LayoutParams(-1, dp(48)))
        content.addView(label("Describe what your app should do", 14, primaryText, true).apply { setPadding(0, dp(9), 0, dp(4)) }); content.addView(appBuilderPrompt, LinearLayout.LayoutParams(-1, -2))
        content.addView(buttonView("Generate Android source with Hira Bhai AI") { generateAiAndroidSource() })
        content.addView(buttonView("Preview app UI") { showAiAndroidPreview() })
        appBuilderStatus = label("Generated source appears below. Save it to keep a private cloud copy.", 12, secondaryText, false).apply { setPadding(0, dp(8), 0, dp(5)) }
        content.addView(appBuilderStatus)
        appBuilderProgress = ProgressBar(this).apply { visibility = View.GONE; isIndeterminate = true }
        content.addView(appBuilderProgress, LinearLayout.LayoutParams(dp(36), dp(36)).apply { gravity = Gravity.CENTER })
        appBuilderSource = websiteCodeEditor("Generated Android Java source · edit if needed", "", 12).apply { maxLines = 30 }
        content.addView(appBuilderSource, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5); bottomMargin = dp(8) })
        content.addView(buttonView("Save app project") { saveAiAppProject() })
        content.addView(buttonView("My app projects · load, duplicate, rename, delete") { showAiAppProjects() })
        content.addView(buttonView("Export Android project source (.zip)") { exportAiAndroidProject() })
        content.addView(buttonView("Build APK in Google Cloud Build") { buildAiAndroidApk() })
        addBottom()
    }

    private fun generateAiAndroidSource() {
        val prompt = appBuilderPrompt?.text?.toString()?.trim().orEmpty()
        if (prompt.length !in 5..1800) { appBuilderPrompt?.error = "Describe the app in 5–1,800 characters"; return }
        val packageName = appBuilderPackage?.text?.toString()?.trim().orEmpty()
        if (packageName.length > 64 || !Regex("^[a-z][a-z0-9_]*(\\.[a-z][a-z0-9_]*){1,5}$").matches(packageName) || packageName.startsWith("android.") || packageName.startsWith("java.")) { appBuilderPackage?.error = "Use a package like com.example.myapp (64 characters maximum)"; return }
        val user = FirebaseBackend.auth?.currentUser ?: run { info("Sign in required", "Sign in to generate an app."); return }
        val project = try { com.google.firebase.FirebaseApp.getInstance().options.projectId } catch (_: Exception) { null } ?: run { info("App Builder unavailable", "Firebase is not connected to a project."); return }
        appBuilderStatus?.text = "Generating real Android Java source…"; appBuilderProgress?.visibility = View.VISIBLE
        val current = appBuilderSource?.text?.toString().orEmpty()
        aiScope.launch {
            try {
                val token = user.getIdToken(false).await().token ?: error("Could not verify sign-in")
                val response = withContext(Dispatchers.IO) { callAndroidBuilderFunction(project, token, "generateAndroidApp", JSONObject().put("prompt", prompt).put("appName", appBuilderName?.text?.toString()?.trim().orEmpty()).put("packageName", packageName).put("template", appBuilderTemplate).put("theme", appBuilderTheme).put("currentSource", current)) }
                runOnUiThread {
                    appBuilderSource?.setText(response.optString("mainActivityJava"))
                    appBuilderPreview = try { JSONObject(response.optString("previewSpec", "{}")) } catch (_: Exception) { JSONObject() }
                    appBuilderStatus?.text = "Android source generated. Review it, preview the UI, and save the project."; appBuilderProgress?.visibility = View.GONE
                }
            } catch (error: Exception) { runOnUiThread { appBuilderStatus?.text = "Generation failed: ${error.message ?: friendlyError(error)}. Check GEMINI_API_KEY, function deployment, quota and billing."; appBuilderProgress?.visibility = View.GONE } }
        }
    }

    private fun callAndroidBuilderFunction(project: String, token: String, function: String, body: JSONObject): JSONObject {
        val connection = (URL("https://us-central1-$project.cloudfunctions.net/$function").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 15000; readTimeout = 60000; doOutput = true
            setRequestProperty("Content-Type", "application/json"); setRequestProperty("Authorization", "Bearer $token")
        }
        try {
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode; val text = (if (code in 200..299) connection.inputStream else connection.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
            val result = try { JSONObject(text) } catch (_: Exception) { error("App Builder service returned an unreadable response (HTTP $code).") }
            if (code !in 200..299) error(result.optString("error", "Request failed (HTTP $code)."))
            return result
        } finally { connection.disconnect() }
    }

    private fun showAiAndroidPreview() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = glass(0x30ffffff, 22); setPadding(dp(18), dp(18), dp(18), dp(18)) }
        val accent = when (appBuilderTheme) { "blue" -> 0xff2879d0.toInt(); "orange" -> 0xffdf7840.toInt(); "purple" -> 0xff7755b8.toInt(); else -> 0xff168f86.toInt() }
        box.addView(TextView(this).apply { text = appBuilderPreview.optString("title", appBuilderName?.text?.toString()?.ifBlank { "My App" } ?: "My App"); textSize = 24f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD })
        val subtitle = appBuilderPreview.optString("subtitle", "Your app preview")
        if (subtitle.isNotBlank()) box.addView(TextView(this).apply { text = subtitle; textSize = 14f; setTextColor(secondaryText); setPadding(0, dp(5), 0, dp(12)) })
        val fields = appBuilderPreview.optJSONArray("fields") ?: JSONArray()
        for (i in 0 until minOf(fields.length(), 5)) box.addView(EditText(this).apply { hint = fields.optString(i); setTextColor(Color.WHITE); setHintTextColor(secondaryText); setPadding(dp(11), dp(9), dp(11), dp(9)); background = glass(0x24ffffff, 12); textSize = 14f }, LinearLayout.LayoutParams(-1, dp(46)).apply { bottomMargin = dp(7) })
        val items = appBuilderPreview.optJSONArray("items") ?: JSONArray()
        for (i in 0 until minOf(items.length(), 8)) box.addView(TextView(this).apply { text = "•  ${items.optString(i)}"; textSize = 15f; setTextColor(Color.WHITE); background = glass(0x24ffffff, 12); setPadding(dp(12), dp(12), dp(12), dp(12)) }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })
        val button = TextView(this).apply { text = appBuilderPreview.optString("primaryAction", "Continue"); gravity = Gravity.CENTER; textSize = 15f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE); background = round(accent, 14); setPadding(dp(10), dp(13), dp(10), dp(13)); setOnClickListener { Toast.makeText(this@MainActivity, "Preview action: ${text}", Toast.LENGTH_SHORT).show() } }
        box.addView(button, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        AlertDialog.Builder(this).setTitle("Android app preview").setView(ScrollView(this).apply { addView(box) }).setPositiveButton("Done", null).show()
    }

    private fun currentAiAppData(): HashMap<String, Any> = hashMapOf(
        "name" to appBuilderName?.text?.toString()?.trim().orEmpty().take(60).ifBlank { "My App" },
        "packageName" to appBuilderPackage?.text?.toString()?.trim().orEmpty(), "prompt" to appBuilderPrompt?.text?.toString()?.trim().orEmpty().take(1800),
        "template" to appBuilderTemplate, "theme" to appBuilderTheme, "mainActivityJava" to appBuilderSource?.text?.toString().orEmpty().take(80000),
        "previewSpec" to appBuilderPreview.toString(), "updatedAt" to FieldValue.serverTimestamp()
    )

    private fun saveAiAppProject(onSaved: (() -> Unit)? = null) {
        val user = FirebaseBackend.auth?.currentUser ?: run { info("Sign in required", "Sign in to save app projects."); return }
        val db = FirebaseBackend.db ?: run { info("Project not saved", "Firebase Firestore is unavailable."); return }
        val source = appBuilderSource?.text?.toString().orEmpty()
        if (source.isBlank()) { info("Generate source first", "Describe your app and generate its Android source before saving."); return }
        val id = appBuilderProjectId ?: UUID.randomUUID().toString().also { appBuilderProjectId = it }
        db.collection("aiAppProjects").document(user.uid).collection("projects").document(id).set(currentAiAppData(), SetOptions.merge())
            .addOnSuccessListener { getSharedPreferences("hira_ai_app_projects", MODE_PRIVATE).edit().putString("active_${user.uid}", id).apply(); appBuilderStatus?.text = "Project saved privately to your Firebase account."; onSaved?.invoke() }
            .addOnFailureListener { appBuilderStatus?.text = "Project save failed: ${friendlyError(it)}. Check the deployed aiAppProjects Firestore rules."; appBuilderProgress?.visibility = View.GONE }
    }

    private fun showAiAppProjects() {
        val user = FirebaseBackend.auth?.currentUser ?: return; val db = FirebaseBackend.db ?: return
        db.collection("aiAppProjects").document(user.uid).collection("projects").orderBy("updatedAt", com.google.firebase.firestore.Query.Direction.DESCENDING).limit(40).get()
            .addOnSuccessListener { snapshot ->
                if (snapshot.isEmpty) { info("My app projects", "Save a generated app to create your first project."); return@addOnSuccessListener }
                val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(4), dp(10), dp(4)) }
                snapshot.documents.forEach { doc ->
                    val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = glass(0x2affffff, 14); setPadding(dp(10), dp(8), dp(10), dp(8)) }
                    row.addView(label(doc.getString("name") ?: "Untitled app", 16, primaryText, true))
                    val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                    actions.addView(buttonView("Load") { val data = doc.data ?: emptyMap(); appBuilderProjectId = doc.id; appBuilderName?.setText(data["name"] as? String ?: "My App"); appBuilderPackage?.setText(data["packageName"] as? String ?: "com.hirabuilder.apps.myapp"); appBuilderPrompt?.setText(data["prompt"] as? String ?: ""); appBuilderSource?.setText(data["mainActivityJava"] as? String ?: ""); appBuilderTemplate = data["template"] as? String ?: "blank"; appBuilderTheme = data["theme"] as? String ?: "teal"; appBuilderPreview = try { JSONObject(data["previewSpec"] as? String ?: "{}") } catch (_: Exception) { JSONObject() }; getSharedPreferences("hira_ai_app_projects", MODE_PRIVATE).edit().putString("active_${user.uid}", doc.id).apply(); appBuilderStatus?.text = "Loaded ${data["name"] ?: "app project"}." }, LinearLayout.LayoutParams(0, -2, 1f))
                    actions.addView(buttonView("Rename") { renameAiAppProject(doc.id, doc.getString("name") ?: "My App") }, LinearLayout.LayoutParams(0, -2, 1f))
                    actions.addView(buttonView("Duplicate") { duplicateAiAppProject(doc.id, doc.data ?: emptyMap()) }, LinearLayout.LayoutParams(0, -2, 1f))
                    actions.addView(buttonView("Delete") { AlertDialog.Builder(this).setMessage("Delete this app project?").setNegativeButton("Cancel", null).setPositiveButton("Delete") { _, _ -> doc.reference.delete().addOnSuccessListener { showAiAppProjects() }.addOnFailureListener { info("Delete failed", friendlyError(it)) } }.show() }, LinearLayout.LayoutParams(0, -2, 1f))
                    row.addView(actions); list.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
                }
                AlertDialog.Builder(this).setTitle("My AI app projects").setView(ScrollView(this).apply { addView(list) }).setPositiveButton("Done", null).show()
            }.addOnFailureListener { info("Projects unavailable", "Could not load app projects: ${friendlyError(it)}") }
    }

    private fun renameAiAppProject(id: String, oldName: String) {
        val input = EditText(this).apply { setText(oldName); setSelection(text.length) }
        AlertDialog.Builder(this).setTitle("Rename project").setView(input).setNegativeButton("Cancel", null).setPositiveButton("Save") { _, _ ->
            val uid = FirebaseBackend.auth?.currentUser?.uid ?: return@setPositiveButton; val name = input.text.toString().trim().take(60); if (name.length < 2) return@setPositiveButton
            FirebaseBackend.db?.collection("aiAppProjects")?.document(uid)?.collection("projects")?.document(id)?.update("name", name, "updatedAt", FieldValue.serverTimestamp())?.addOnSuccessListener { showAiAppProjects() }?.addOnFailureListener { info("Rename failed", friendlyError(it)) }
        }.show()
    }

    private fun duplicateAiAppProject(id: String, source: Map<String, Any>) {
        val user = FirebaseBackend.auth?.currentUser ?: return; val copy = source.toMutableMap().apply { put("name", "Copy of ${source["name"] ?: "App"}".take(60)); put("updatedAt", FieldValue.serverTimestamp()) }
        val newId = UUID.randomUUID().toString()
        FirebaseBackend.db?.collection("aiAppProjects")?.document(user.uid)?.collection("projects")?.document(newId)?.set(copy)
            ?.addOnSuccessListener { info("Project duplicated", "The private copy is ready in My app projects.") }?.addOnFailureListener { info("Duplicate failed", friendlyError(it)) }
    }

    private fun exportAiAndroidProject() {
        val javaSource = appBuilderSource?.text?.toString().orEmpty(); val packageName = appBuilderPackage?.text?.toString()?.trim().orEmpty()
        if (javaSource.isBlank() || packageName.length > 64 || !Regex("^[a-z][a-z0-9_]*(\\.[a-z][a-z0-9_]*){1,5}$").matches(packageName)) { info("App source not ready", "Generate Android source and check the package name (64 characters maximum) before exporting."); return }
        try {
            val folder = File(cacheDir, "app_builder_exports").apply { mkdirs() }; val file = File(folder, "${appBuilderName?.text?.toString()?.replace(Regex("[^A-Za-z0-9_-]"), "_")?.take(40)?.ifBlank { "ai-app"} ?: "ai-app"}.zip")
            writeGeneratedAndroidProjectZip(file, packageName, javaSource)
            val uri = FileProvider.getUriForFile(this, "${this.packageName}.fileprovider", file)
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("application/zip").putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Export Android source project"))
        } catch (error: Exception) { info("Export failed", friendlyError(error)) }
    }

    private fun generatedAndroidProjectEntries(packageName: String, javaSource: String): Map<String, String> {
        val packagePath = packageName.replace('.', '/')
        val escapedName = (appBuilderName?.text?.toString()?.trim().orEmpty().ifBlank { "My App" }).replace("&", "&amp;").replace("<", "&lt;").replace("\"", "&quot;")
        val source = javaSource.replace("@@PACKAGE@@", packageName)
        return linkedMapOf(
            "settings.gradle" to "pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }\ndependencyResolutionManagement { repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS); repositories { google(); mavenCentral() } }\nrootProject.name = \"${escapedName.replace(Regex("[^A-Za-z0-9_-]"), "_")}\"\ninclude ':app'\n",
            "build.gradle" to "plugins { id 'com.android.application' version '9.4.1' apply false }\n",
            "gradle.properties" to "org.gradle.jvmargs=-Xmx2g -Dfile.encoding=UTF-8\nandroid.useAndroidX=true\n",
            "app/build.gradle" to "plugins { id 'com.android.application' }\nandroid { namespace '$packageName'; compileSdk 36; defaultConfig { applicationId '$packageName'; minSdk 26; targetSdk 36; versionCode 1; versionName '1.0' } }\ntasks.withType(JavaCompile).configureEach { options.compilerArgs += ['-proc:none'] }\n",
            "app/src/main/AndroidManifest.xml" to "<manifest xmlns:android=\"http://schemas.android.com/apk/res/android\"><application android:theme=\"@android:style/Theme.Material.Light.NoActionBar\" android:label=\"$escapedName\" android:allowBackup=\"false\"><activity android:name=\".MainActivity\" android:exported=\"true\"><intent-filter><action android:name=\"android.intent.action.MAIN\"/><category android:name=\"android.intent.category.LAUNCHER\"/></intent-filter></activity></application></manifest>\n",
            "app/src/main/java/$packagePath/MainActivity.java" to source,
            "README.md" to "# $escapedName\n\nGenerated native Android project. Build a debug APK with Gradle 9.7.1 and JDK 17 or newer using `gradle assembleDebug`. Review generated source before installing. This template includes no credentials, annotation processors or third-party dependencies; generated APKs are debug-signed for testing, not Play Store release.\n"
        )
    }

    private fun writeGeneratedAndroidProjectZip(file: File, packageName: String, javaSource: String) {
        java.util.zip.ZipOutputStream(file.outputStream().buffered()).use { zip -> generatedAndroidProjectEntries(packageName, javaSource).forEach { (name, value) -> zip.putNextEntry(java.util.zip.ZipEntry(name)); zip.write(value.toByteArray(Charsets.UTF_8)); zip.closeEntry() } }
    }

    private fun buildAiAndroidApk() {
        if (appBuilderSource?.text?.isNullOrBlank() != false) { info("Generate source first", "Create and review the app source before requesting an APK build."); return }
        appBuilderStatus?.text = "Saving app project before build…"; appBuilderProgress?.visibility = View.VISIBLE
        saveAiAppProject { startAiAndroidCloudBuild() }
    }

    private fun startAiAndroidCloudBuild() {
        val user = FirebaseBackend.auth?.currentUser ?: return; val project = try { com.google.firebase.FirebaseApp.getInstance().options.projectId } catch (_: Exception) { null } ?: return
        val id = appBuilderProjectId ?: return
        aiScope.launch {
            try {
                val token = user.getIdToken(false).await().token ?: error("Could not verify sign-in")
                val started = withContext(Dispatchers.IO) { callAndroidBuilderFunction(project, token, "startAndroidAppBuild", JSONObject().put("projectId", id)) }
                val buildId = started.optString("buildId").takeIf { it.isNotBlank() } ?: error("Build service did not return a real build ID")
                runOnUiThread { appBuilderStatus?.text = "Cloud Build queued · $buildId" }
                var complete = false
                for (attempt in 0 until 240) {
                    delay(5000)
                    val status = withContext(Dispatchers.IO) { callAndroidBuilderFunction(project, token, "androidAppBuildStatus", JSONObject().put("buildId", buildId)) }
                    val state = status.optString("status", "UNKNOWN")
                    val steps = status.optJSONArray("steps") ?: JSONArray()
                    val stepSummary = if (steps.length() > 0) " · Gradle ${steps.optJSONObject(0)?.optString("status", "QUEUED")}" else ""
                    runOnUiThread { appBuilderStatus?.text = when (state) { "QUEUED" -> "Cloud build queued…"; "WORKING" -> "Cloud Build compiling Android source$stepSummary"; else -> "Cloud Build: $state$stepSummary" } }
                    if (state == "SUCCESS") {
                        val download = status.optString("downloadUrl").takeIf { it.startsWith("https://") } ?: error("Build succeeded but no APK download URL was returned")
                        runOnUiThread { appBuilderStatus?.text = "APK built successfully. Starting the download…"; appBuilderProgress?.visibility = View.GONE; beginApkDownload(download) }
                        complete = true; break
                    }
                    if (state in listOf("FAILURE", "CANCELLED", "EXPIRED", "INTERNAL_ERROR", "TIMEOUT")) {
                        val detail = status.optString("error", "Cloud Build ended with $state.")
                        runOnUiThread { appBuilderStatus?.text = "Build failed ($state): $detail"; appBuilderProgress?.visibility = View.GONE }
                        complete = true; break
                    }
                }
                if (!complete) runOnUiThread { appBuilderStatus?.text = "Build is still running. Check Cloud Build job $buildId in Google Cloud Console."; appBuilderProgress?.visibility = View.GONE }
            } catch (error: Exception) { runOnUiThread { appBuilderStatus?.text = "APK build unavailable: ${error.message ?: friendlyError(error)}"; appBuilderProgress?.visibility = View.GONE } }
        }
    }

    private fun beginApkDownload(url: String) {
        if (android.os.Build.VERSION.SDK_INT <= 28 && ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) { pendingApkDownloadUrl = url; requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 96); return }
        startApkDownload(url)
    }

    private fun startApkDownload(url: String) {
        try {
            val request = android.app.DownloadManager.Request(Uri.parse(url)).apply { setTitle("${appBuilderName?.text?.toString()?.ifBlank { "AI app" } ?: "AI app"}.apk"); setDescription("Hira Bhai Cloud Build APK"); setMimeType("application/vnd.android.package-archive"); setNotificationVisibility(android.app.DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED); setDestinationInExternalPublicDir(android.os.Environment.DIRECTORY_DOWNLOADS, "hira-ai-app-${System.currentTimeMillis()}.apk") }
            (getSystemService(DOWNLOAD_SERVICE) as android.app.DownloadManager).enqueue(request)
            Toast.makeText(this, "APK download started. Find it in Downloads.", Toast.LENGTH_LONG).show()
        } catch (error: Exception) { info("Download could not start", friendlyError(error)) }
    }

    private fun showWebsiteBuilder() {
        val user = FirebaseBackend.auth?.currentUser
        if (user == null) { base(); heading("Creator Website", "Build a public website for your channel"); action("Sign in required", "Sign in to create and manage your creator website.") { showAuth(false) }; addBottom(); return }
        val db = FirebaseBackend.db ?: run { info("Website builder unavailable", "Firebase Firestore is not configured."); return }
        selected = "Website Builder"; base(); heading("Website Builder", "Create and preview a personal creator website")
        val loading = ProgressBar(this).apply { isIndeterminate = true }
        content.addView(loading, LinearLayout.LayoutParams(dp(36), dp(36)).apply { gravity = Gravity.CENTER })
        db.collection("profiles").document(user.uid).get()
            .addOnSuccessListener { profile ->
                if (!profile.exists()) { base(); heading("Creator profile required", "Complete your Hira Bhai creator profile before creating a public website."); action("Open profile", "Create your username and creator identity.") { showAccount() }; addBottom(); return@addOnSuccessListener }
                websiteOwnerProfile = profile.data ?: emptyMap()
                val username = profile.getString("username") ?: run { info("Username required", "Set a unique username on your creator profile first."); return@addOnSuccessListener }
                websiteUsername = username; websiteCreatorId = profile.getString("creatorId")
                db.collection("creatorWebsites").document(username).get()
                    .addOnSuccessListener { site -> buildWebsiteEditor(websiteOwnerProfile, site.data ?: emptyMap()) }
                    .addOnFailureListener { error ->
                        Log.e("HiraBhaiWebsite", "Could not load creatorWebsites/$username for owner uid=${user.uid}", error)
                        base(); heading("Website settings unavailable", "Firestore denied the website read or could not connect: ${friendlyError(error)}"); addBottom()
                    }
            }
            .addOnFailureListener { error -> base(); heading("Creator website unavailable", friendlyError(error)); addBottom() }
        addBottom()
    }

    private fun buildWebsiteEditor(profile: Map<String, Any>, saved: Map<String, Any>) {
        if (websiteUsername == null || websiteCreatorId == null) { base(); heading("Creator profile required", "Your profile is missing its public creator ID or username."); addBottom(); return }
        base(); heading("Website Builder", "Choose a theme, arrange sections, preview, and publish")
        websiteTemplate = saved["template"] as? String ?: "portfolio"
        websitePalette = saved["palette"] as? String ?: "ocean"
        websiteFont = saved["font"] as? String ?: "system"
        websiteLogoData = saved["logoData"] as? String
        websitePhotoData = saved["profilePhotoData"] as? String
        websitePublished = saved["published"] as? Boolean ?: false
        websitePublishedAt = saved["publishedAt"]
        websiteHtmlEditor = null; websiteCssEditor = null; websiteJsEditor = null
        websiteProjectId = websiteProjectId ?: getSharedPreferences("hira_website_projects", MODE_PRIVATE)
            .getString("active_${FirebaseBackend.auth?.currentUser?.uid}", null) ?: java.util.UUID.randomUUID().toString()
        val savedSections: List<*> = saved["sections"] as? List<*> ?: emptyList<Any>()
        websiteSections = savedSections.mapNotNull { value ->
            val source = value as? Map<*, *> ?: return@mapNotNull null
            val section = mutableMapOf<String, Any>()
            source.forEach { (key, item) -> if (key is String && item != null) section[key] = item }
            section
        }.toMutableList()
        if (websiteSections.isEmpty() && saved.isEmpty()) {
            websiteSections.add(mutableMapOf("type" to "text", "title" to "Welcome", "text" to "Thanks for visiting my creator website.", "order" to 0))
            websiteSections.add(mutableMapOf("type" to "videos", "title" to "My videos", "order" to 1))
        }
        content.addView(label("Website name", 14, primaryText, true))
        websiteBuilderName = EditText(this).apply { hint = "Your channel or brand name"; textSize = 15f; setTextColor(primaryText); setHintTextColor(secondaryText); background = round(Color.WHITE, 14); setPadding(dp(13), dp(11), dp(13), dp(11)); setText(saved["websiteName"] as? String ?: (profile["fullName"] as? String ?: "My Creator Website")) }
        content.addView(websiteBuilderName, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(5); bottomMargin = dp(10) })
        content.addView(label("Description", 14, primaryText, true))
        websiteBuilderDescription = EditText(this).apply { hint = "Tell visitors what you make"; textSize = 14f; setTextColor(primaryText); setHintTextColor(secondaryText); minLines = 2; maxLines = 4; gravity = Gravity.TOP; background = round(Color.WHITE, 14); setPadding(dp(13), dp(11), dp(13), dp(11)); setText(saved["description"] as? String ?: (profile["bio"] as? String ?: "")) }
        content.addView(websiteBuilderDescription, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5); bottomMargin = dp(10) })
        val templates = listOf("portfolio" to "Creator portfolio", "video" to "Video channel", "minimal" to "Minimal profile", "business" to "Business", "blog" to "Blog", "landing" to "Landing page")
        val templateSpinner = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, templates.map { it.second }); setSelection(templates.indexOfFirst { it.first == websiteTemplate }.coerceAtLeast(0)); onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener { override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}; override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { websiteTemplate = templates[position].first } } }
        content.addView(label("Template", 14, primaryText, true)); content.addView(templateSpinner, LinearLayout.LayoutParams(-1, dp(48)))
        val palettes = listOf("ocean" to "Ocean blue", "forest" to "Forest green", "sunset" to "Sunset coral", "violet" to "Violet night")
        val paletteSpinner = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, palettes.map { it.second }); setSelection(palettes.indexOfFirst { it.first == websitePalette }.coerceAtLeast(0)); onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener { override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}; override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { websitePalette = palettes[position].first } } }
        content.addView(label("Color theme", 14, primaryText, true)); content.addView(paletteSpinner, LinearLayout.LayoutParams(-1, dp(48)))
        val fonts = listOf("system" to "System sans", "serif" to "Serif", "rounded" to "Rounded", "mono" to "Monospace")
        val fontSpinner = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, fonts.map { it.second }); setSelection(fonts.indexOfFirst { it.first == websiteFont }.coerceAtLeast(0)); onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener { override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}; override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { websiteFont = fonts[position].first } } }
        content.addView(label("Website font", 14, primaryText, true)); content.addView(fontSpinner, LinearLayout.LayoutParams(-1, dp(48)))
        content.addView(label("AI website instructions", 14, primaryText, true).apply { setPadding(0, dp(10), 0, dp(3)) })
        websiteAiPrompt = EditText(this).apply {
            hint = "Describe the website or changes you want…"; textSize = 14f; setTextColor(primaryText); setHintTextColor(secondaryText)
            minLines = 2; maxLines = 5; gravity = Gravity.TOP; background = round(Color.WHITE, 14); setPadding(dp(13), dp(11), dp(13), dp(11))
        }
        content.addView(websiteAiPrompt, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        content.addView(buttonView("Generate / edit with Hira Bhai AI") { generateWebsiteWithAi() })
        content.addView(buttonView("My website projects · load, duplicate, rename, delete") { showWebsiteProjects() })
        content.addView(label("Generated source · HTML, CSS and JavaScript", 14, primaryText, true).apply { setPadding(0, dp(12), 0, dp(4)) })
        websiteHtmlEditor = websiteCodeEditor("HTML body", saved["generatedHtml"] as? String ?: "", 5)
        websiteCssEditor = websiteCodeEditor("CSS styles", saved["generatedCss"] as? String ?: "", 4)
        websiteJsEditor = websiteCodeEditor("JavaScript interactions", saved["generatedJs"] as? String ?: "", 3)
        content.addView(websiteHtmlEditor, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })
        content.addView(websiteCssEditor, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })
        content.addView(websiteJsEditor, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        content.addView(buttonView("Export website source (.zip)") { exportWebsiteSource() })
        content.addView(buttonView("Choose website logo image") { websiteImagePurpose = "logo"; chooseWebsiteImage() })
        content.addView(buttonView("Choose website profile picture") { websiteImagePurpose = "profile"; chooseWebsiteImage() })
        content.addView(label("Sections · drag order with the arrows", 16, primaryText, true).apply { setPadding(0, dp(12), 0, dp(4)) })
        websiteSectionsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(websiteSectionsBox)
        val addRow = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        addRow.addView(buttonView("Add text section") { addWebsiteTextSection() })
        addRow.addView(buttonView("Add image section") { websiteImagePurpose = "section"; websitePendingImageTitle = "Creator image"; chooseWebsiteImage() })
        addRow.addView(buttonView("Add social or contact link") { addWebsiteLinkSection() })
        addRow.addView(buttonView("Add a public channel video") { chooseWebsiteVideoSection() })
        content.addView(addRow)
        websitePublishSwitch = Switch(this).apply { text = "Published website"; setTextColor(primaryText); isChecked = websitePublished; setOnCheckedChangeListener { _, checked -> websitePublished = checked } }
        content.addView(websitePublishSwitch, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(10) })
        websiteBuilderStatus = label(if (websitePublished) "Published in Firestore · Firebase Hosting must also be deployed for the public web URL." else "Draft is private to your account.", 12, secondaryText, false).apply { setPadding(0, dp(4), 0, dp(8)) }
        content.addView(websiteBuilderStatus)
        button("Save website") { saveCreatorWebsite() }
        content.addView(buttonView("Live preview") { showWebsitePreview() })
        content.addView(buttonView("Open public URL in Hira Bhai Browser") {
            if (!websitePublished) info("Website is not public", "Turn on Published website and save first.")
            else websiteShareUrl()?.let { startActivity(Intent(this, InAppBrowserActivity::class.java).putExtra(InAppBrowserActivity.EXTRA_URL, it)) }
        })
        content.addView(buttonView("Share published website URL") { shareCreatorWebsite() })
        renderWebsiteSectionEditor()
        addBottom()
    }

    private fun chooseWebsiteImage() {
        try { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION), 56) }
        catch (error: Exception) { info("Image picker", friendlyError(error)) }
    }

    private fun websiteCodeEditor(hintText: String, value: String, lines: Int) = EditText(this).apply {
        hint = hintText; textSize = 12f; setTextColor(primaryText); setHintTextColor(secondaryText)
        setText(value); minLines = lines; maxLines = 14; gravity = Gravity.TOP or Gravity.START
        inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        background = round(Color.WHITE, 12); setPadding(dp(11), dp(9), dp(11), dp(9))
    }

    private fun generateWebsiteWithAi() {
        val prompt = websiteAiPrompt?.text?.toString()?.trim().orEmpty()
        if (prompt.length !in 5..1800) { websiteAiPrompt?.error = "Describe the site or change in 5–1,800 characters"; return }
        val user = FirebaseBackend.auth?.currentUser ?: run { info("Sign in required", "Sign in to generate a website with Hira Bhai AI."); return }
        val project = try { com.google.firebase.FirebaseApp.getInstance().options.projectId } catch (_: Exception) { null }
        if (project.isNullOrBlank()) { info("AI website builder unavailable", "Firebase is not connected to a project."); return }
        val current = JSONObject()
            .put("html", websiteHtmlEditor?.text?.toString().orEmpty())
            .put("css", websiteCssEditor?.text?.toString().orEmpty())
            .put("js", websiteJsEditor?.text?.toString().orEmpty())
        websiteBuilderStatus?.text = "Hira Bhai AI is generating website source…"
        websiteBuilderStatus?.setTextColor(secondaryText)
        aiScope.launch {
            try {
                val token = user.getIdToken(false).await().token ?: throw IllegalStateException("Could not verify your sign-in")
                val response = withContext(Dispatchers.IO) {
                    postWebsiteGeneration(project, token, prompt, websiteTemplate, websitePalette, current)
                }
                runOnUiThread {
                    websiteHtmlEditor?.setText(response.optString("html"))
                    websiteCssEditor?.setText(response.optString("css"))
                    websiteJsEditor?.setText(response.optString("js"))
                    websiteBuilderStatus?.text = "AI source generated. Review and edit HTML/CSS/JavaScript, preview, then save."
                    websiteBuilderStatus?.setTextColor(mint)
                }
            } catch (error: Exception) {
                runOnUiThread {
                    websiteBuilderStatus?.text = "AI generation failed: ${error.message ?: friendlyError(error)}. Check GEMINI_API_KEY, function deployment, quota and billing."
                    websiteBuilderStatus?.setTextColor(0xffa33a36.toInt())
                }
            }
        }
    }

    private fun postWebsiteGeneration(projectId: String, token: String, prompt: String, template: String, palette: String, current: JSONObject): JSONObject {
        val connection = (URL("https://us-central1-$projectId.cloudfunctions.net/generateWebsite").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 15000; readTimeout = 50000; doOutput = true
            setRequestProperty("Content-Type", "application/json"); setRequestProperty("Authorization", "Bearer $token")
        }
        try {
            val body = JSONObject().put("prompt", prompt).put("template", template).put("palette", palette).put("current", current)
            connection.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = connection.responseCode
            val text = (if (code in 200..299) connection.inputStream else connection.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
            val response = try { JSONObject(text) } catch (_: Exception) { throw IllegalStateException("Website AI service returned an unreadable response (HTTP $code).") }
            if (code !in 200..299) throw IllegalStateException(response.optString("error", "Website generation failed (HTTP $code)."))
            return response
        } finally { connection.disconnect() }
    }

    private fun addWebsiteTextSection() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(4), dp(2), dp(4), dp(2)) }
        val title = EditText(this).apply { hint = "Section title"; setText("About me") }
        val text = EditText(this).apply { hint = "Write a public message for website visitors"; minLines = 3; gravity = Gravity.TOP }
        box.addView(title); box.addView(text)
        AlertDialog.Builder(this).setTitle("Add text section").setView(box).setNegativeButton("Cancel", null).setPositiveButton("Add") { _, _ ->
            if (websiteSections.size >= 8) { info("Section limit", "A website can contain up to eight sections."); return@setPositiveButton }
            val heading = title.text.toString().trim().ifBlank { "Section" }; val body = text.text.toString().trim()
            if (body.isBlank()) { info("Add some text", "The section body cannot be empty."); return@setPositiveButton }
            websiteSections.add(mutableMapOf("type" to "text", "title" to heading.take(80), "text" to body.take(2500), "order" to websiteSections.size)); renderWebsiteSectionEditor()
        }.show()
    }

    private fun addWebsiteLinkSection() {
        val title = EditText(this).apply { hint = "Link label · e.g. Instagram" }
        val url = EditText(this).apply { hint = "https://…"; inputType = android.text.InputType.TYPE_TEXT_VARIATION_URI or android.text.InputType.TYPE_CLASS_TEXT }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(4), dp(2), dp(4), dp(2)); addView(title); addView(url) }
        AlertDialog.Builder(this).setTitle("Add a public link").setView(box).setNegativeButton("Cancel", null).setPositiveButton("Add") { _, _ ->
            if (websiteSections.size >= 8) { info("Section limit", "A website can contain up to eight sections."); return@setPositiveButton }
            val link = url.text.toString().trim(); val parsed = Uri.parse(link)
            if (parsed.scheme !in listOf("http", "https") || parsed.host.isNullOrBlank()) { url.error = "Enter a complete public https:// link"; return@setPositiveButton }
            websiteSections.add(mutableMapOf("type" to "link", "title" to title.text.toString().trim().ifBlank { "Social link" }.take(80), "url" to link.take(500), "order" to websiteSections.size)); renderWebsiteSectionEditor()
        }.show()
    }

    private fun chooseWebsiteVideoSection() {
        val db = FirebaseBackend.db ?: return
        val creatorId = websiteCreatorId ?: return
        db.collection("videos").whereEqualTo("creatorId", creatorId).whereEqualTo("visibility", "public").limit(50).get()
            .addOnSuccessListener { snapshot ->
                val videos = snapshot.documents
                if (videos.isEmpty()) { info("No public videos", "Upload a public video to your channel before adding a video section."); return@addOnSuccessListener }
                val labels = videos.map { "${it.getString("title") ?: "Untitled video"} · ${formatDuration(it.getLong("durationMs") ?: 0L)}" }.toTypedArray()
                AlertDialog.Builder(this).setTitle("Choose a public channel video").setItems(labels) { _, index ->
                    if (websiteSections.size >= 8) { info("Section limit", "A website can contain up to eight sections."); return@setItems }
                    val doc = videos[index]
                    websiteSections.add(mutableMapOf("type" to "video", "title" to (doc.getString("title") ?: "Video"), "videoId" to doc.id, "order" to websiteSections.size)); renderWebsiteSectionEditor()
                }.setNegativeButton("Cancel", null).show()
            }
            .addOnFailureListener { error -> info("Videos unavailable", friendlyError(error)) }
    }

    private fun renderWebsiteSectionEditor() {
        val list = websiteSectionsBox ?: return
        list.removeAllViews()
        websiteSections.forEachIndexed { index, section ->
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = round(Color.WHITE, 13); setPadding(dp(12), dp(9), dp(12), dp(9)) }
            val title = section["title"] as? String ?: when (section["type"]) { "image" -> "Image"; "video" -> "Channel video"; "videos" -> "My videos"; else -> "Section" }
            card.addView(label("${index + 1}. $title · ${(section["type"] as? String).orEmpty()}", 14, primaryText, true))
            val body = section["text"] as? String
            if (!body.isNullOrBlank()) card.addView(label(body.take(100), 12, secondaryText, false).apply { setPadding(0, dp(3), 0, 0) })
            val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            controls.addView(buttonView("↑") { if (index > 0) { val item = websiteSections.removeAt(index); websiteSections.add(index - 1, item); renderWebsiteSectionEditor() } }, LinearLayout.LayoutParams(0, dp(38), 1f).apply { rightMargin = dp(4) })
            controls.addView(buttonView("↓") { if (index < websiteSections.lastIndex) { val item = websiteSections.removeAt(index); websiteSections.add(index + 1, item); renderWebsiteSectionEditor() } }, LinearLayout.LayoutParams(0, dp(38), 1f).apply { rightMargin = dp(4) })
            controls.addView(buttonView("Remove") { websiteSections.removeAt(index); renderWebsiteSectionEditor() }, LinearLayout.LayoutParams(0, dp(38), 1f))
            card.addView(controls); list.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
        }
    }

    private fun compressWebsiteImage(uri: Uri): String {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            ?: throw IllegalArgumentException("Could not read the chosen image")
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 1280) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        val source = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
            ?: throw IllegalArgumentException("Could not decode the chosen image")
        val scale = minOf(1f, 640f / maxOf(source.width, source.height))
        val bitmap = if (scale < 1f) Bitmap.createScaledBitmap(source, (source.width * scale).toInt().coerceAtLeast(1), (source.height * scale).toInt().coerceAtLeast(1), true).also { if (it !== source) source.recycle() } else source
        var bytes: ByteArray
        var quality = 76
        do { val out = ByteArrayOutputStream(); bitmap.compress(Bitmap.CompressFormat.JPEG, quality, out); bytes = out.toByteArray(); quality -= 8 } while (bytes.size > 65_000 && quality >= 36)
        bitmap.recycle()
        if (bytes.size > 70_000) throw IllegalArgumentException("Choose a smaller image; website images must compress below 70 KB.")
        return Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    private fun onWebsiteImageSelected(uri: Uri) {
        aiScope.launch {
            try {
                val data = withContext(Dispatchers.IO) { compressWebsiteImage(uri) }
                when (websiteImagePurpose) {
                    "logo" -> websiteLogoData = data
                    "profile" -> websitePhotoData = data
                    else -> {
                        if (websiteSections.size >= 8) { info("Section limit", "A website can contain up to eight sections."); return@launch }
                        if (websiteSections.count { it["type"] == "image" } >= 3) { info("Image limit", "To stay within Firestore's document limit, a website can have up to three uploaded images plus its logo and profile image."); return@launch }
                        websiteSections.add(mutableMapOf("type" to "image", "title" to websitePendingImageTitle.take(80), "imageData" to data, "order" to websiteSections.size))
                        renderWebsiteSectionEditor()
                    }
                }
                websiteBuilderStatus?.text = "Image ready in the editor. Save the website to store it securely."
            } catch (error: Exception) { info("Image not added", friendlyError(error)) }
        }
    }

    private fun saveCreatorWebsite() {
        val user = FirebaseBackend.auth?.currentUser ?: run { showAuth(false); return }
        val db = FirebaseBackend.db ?: run { info("Website not saved", "Firestore is not configured."); return }
        val username = websiteUsername ?: run { info("Creator profile required", "Create a public username first."); return }
        val creatorId = websiteCreatorId ?: return
        val siteName = websiteBuilderName?.text?.toString()?.trim().orEmpty()
        val description = websiteBuilderDescription?.text?.toString()?.trim().orEmpty()
        if (siteName.length !in 2..80) { websiteBuilderName?.error = "Use 2–80 characters"; return }
        if (description.length > 1800) { websiteBuilderDescription?.error = "Keep the description under 1,800 characters"; return }
        val generatedHtml = websiteHtmlEditor?.text?.toString().orEmpty()
        val generatedCss = websiteCssEditor?.text?.toString().orEmpty()
        val generatedJs = websiteJsEditor?.text?.toString().orEmpty()
        if (generatedHtml.length > 50000 || generatedCss.length > 24000 || generatedJs.length > 10000) { info("Website source too large", "Keep HTML under 50,000, CSS under 24,000 and JavaScript under 10,000 characters."); return }
        websitePublished = websitePublishSwitch?.isChecked == true
        val data = hashMapOf<String, Any>(
            "creatorId" to creatorId, "username" to username, "websiteName" to siteName,
            "description" to description, "template" to websiteTemplate, "palette" to websitePalette, "font" to websiteFont,
            "sections" to websiteSections.mapIndexed { index, section -> section.toMutableMap().apply { put("order", index) } },
            "published" to websitePublished, "updatedAt" to com.google.firebase.firestore.FieldValue.serverTimestamp()
        )
        if (generatedHtml.isNotBlank()) data["generatedHtml"] = generatedHtml
        if (generatedCss.isNotBlank()) data["generatedCss"] = generatedCss
        if (generatedJs.isNotBlank()) data["generatedJs"] = generatedJs
        websiteLogoData?.let { data["logoData"] = it }
        websitePhotoData?.let { data["profilePhotoData"] = it }
        if (websitePublished) data["publishedAt"] = com.google.firebase.firestore.FieldValue.serverTimestamp() else websitePublishedAt?.let { data["publishedAt"] = it }
        websiteBuilderStatus?.text = "Saving securely to Firestore…"; websiteBuilderStatus?.setTextColor(secondaryText)
        val projectId = websiteProjectId ?: java.util.UUID.randomUUID().toString().also { websiteProjectId = it }
        val snapshot = data.toMutableMap().apply { remove("updatedAt"); remove("publishedAt"); put("published", false) }
        val projectDoc = hashMapOf<String, Any>("name" to siteName, "websiteData" to snapshot, "updatedAt" to com.google.firebase.firestore.FieldValue.serverTimestamp())
        val publicRef = db.collection("creatorWebsites").document(username)
        val projectRef = db.collection("creatorWebsiteProjects").document(user.uid).collection("projects").document(projectId)
        db.batch().set(publicRef, data).set(projectRef, projectDoc, SetOptions.merge()).commit()
            .addOnSuccessListener {
                websitePublishedAt = data["publishedAt"]
                getSharedPreferences("hira_website_projects", MODE_PRIVATE).edit().putString("active_${user.uid}", projectId).apply()
                val suffix = if (websitePublished) "Website content is public in Firestore. The public URL still needs configured Firebase Hosting and deployment." else "Saved as a private draft; only your signed-in account can read it."
                websiteBuilderStatus?.text = suffix; websiteBuilderStatus?.setTextColor(mint)
                if (websitePublished) websiteShareUrl()?.let { url -> content.findViewWithTag<TextView>("website_url")?.text = url }
                Toast.makeText(this, if (websitePublished) "Website content made public" else "Website saved", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener { error ->
                Log.e("HiraBhaiWebsite", "Could not save creatorWebsites/$username for uid=${user.uid}", error)
                websiteBuilderStatus?.text = "Save failed: ${friendlyError(error)}. Publish the matching secure creatorWebsites Firestore rules."
                websiteBuilderStatus?.setTextColor(0xffa33a36.toInt())
            }
    }

    private fun websiteShareUrl(): String? {
        val project = try { com.google.firebase.FirebaseApp.getInstance().options.projectId } catch (_: Exception) { null } ?: return null
        val username = websiteUsername ?: return null
        return "https://$project.web.app/creator/$username"
    }

    private fun shareCreatorWebsite() {
        if (!websitePublished) { info("Website is not published", "Turn on Published website and save it first."); return }
        val url = websiteShareUrl() ?: return
        val profileRoute = "hirabhai://site/${websiteUsername}"
        AlertDialog.Builder(this).setTitle("Creator website link")
            .setMessage("$url\n\nThis public URL works after Firebase Hosting is deployed. In-app preview route: $profileRoute")
            .setPositiveButton("Share URL") { _, _ -> startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, "${websiteBuilderName?.text ?: "Creator website"}: $url"), "Share website")) }
            .setNegativeButton("Copy URL") { _, _ -> (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Creator website", url)); Toast.makeText(this, "Website URL copied", Toast.LENGTH_SHORT).show() }
            .setNeutralButton("Close", null).show()
    }

    private fun websitePaletteColors(palette: String): Pair<Int, Int> = when (palette) {
        "forest" -> 0xff164b3d.toInt() to 0xff45b59a.toInt()
        "sunset" -> 0xff763c3b.toInt() to 0xfff2a56b.toInt()
        "violet" -> 0xff36295c.toInt() to 0xffa890ff.toInt()
        else -> 0xff123e5a.toInt() to 0xff49bcd0.toInt()
    }

    private fun showWebsitePreview() {
        val title = websiteBuilderName?.text?.toString()?.trim().orEmpty().ifBlank { "My Creator Website" }
        val description = websiteBuilderDescription?.text?.toString()?.trim().orEmpty()
        val html = websiteHtmlEditor?.text?.toString().orEmpty()
        if (html.isNotBlank()) { showGeneratedWebsitePreview(html, websiteCssEditor?.text?.toString().orEmpty(), websiteJsEditor?.text?.toString().orEmpty()); return }
        val dialogScroll = ScrollView(this)
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)); background = round(0xfff1f6f8.toInt(), 18) }
        dialogScroll.addView(page)
        renderWebsiteContent(page, title, description, websiteOwnerProfile, websiteSections, websitePalette, websiteLogoData, websitePhotoData, false, websiteTemplate)
        AlertDialog.Builder(this).setTitle("Live preview · ${websiteTemplate}").setView(dialogScroll).setPositiveButton("Done", null).show()
    }

    private fun showGeneratedWebsitePreview(html: String, css: String, js: String) {
        val web = createSandboxedWebsiteWebView(html, css, js, -1)
        AlertDialog.Builder(this).setTitle("AI website preview").setView(web).setPositiveButton("Done", null).show()
    }

    private fun createSandboxedWebsiteWebView(html: String, css: String, js: String, height: Int): WebView {
        val fontFamily = when (websiteFont) { "serif" -> "Georgia,serif"; "rounded" -> "Arial Rounded MT Bold,system-ui,sans-serif"; "mono" -> "monospace"; else -> "system-ui,sans-serif" }
        val safeDoc = "<!doctype html><html><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><meta http-equiv=\"Content-Security-Policy\" content=\"default-src 'none'; img-src data:; style-src 'unsafe-inline'; script-src 'unsafe-inline'; connect-src 'none'; form-action 'none'; base-uri 'none'; frame-src 'none'\"><style>body{font-family:$fontFamily}$css</style></head><body>$html<script>$js</script></body></html>"
        val encoded = Base64.encodeToString(safeDoc.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        val outer = "<!doctype html><html><head><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><style>html,body{margin:0;min-height:100%;background:#eff4f7}iframe{width:100%;height:100%;min-height:100vh;border:0;background:white}</style></head><body><iframe sandbox=\"allow-scripts\" id=\"preview\"></iframe><script>document.getElementById('preview').srcdoc=decodeURIComponent(escape(atob('$encoded')));</script></body></html>"
        return WebView(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, height)
            settings.javaScriptEnabled = true; settings.domStorageEnabled = false
            settings.allowFileAccess = false; settings.allowContentAccess = false
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            setDownloadListener { _, _, _, _, _ -> Toast.makeText(this@MainActivity, "Downloads are disabled in the isolated code preview.", Toast.LENGTH_SHORT).show() }
            loadDataWithBaseURL(null, outer, "text/html", "UTF-8", null)
        }
    }

    private fun exportWebsiteSource() {
        val html = websiteHtmlEditor?.text?.toString().orEmpty()
        if (html.isBlank()) { info("No generated source", "Generate or add HTML before exporting the website."); return }
        try {
            val folder = File(cacheDir, "website_exports").apply { mkdirs() }
            val file = File(folder, "hira-website-${System.currentTimeMillis()}.zip")
            java.util.zip.ZipOutputStream(file.outputStream().buffered()).use { zip ->
                fun put(name: String, text: String) { zip.putNextEntry(java.util.zip.ZipEntry(name)); zip.write(text.toByteArray(Charsets.UTF_8)); zip.closeEntry() }
                put("index.html", "<!doctype html><html><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><link rel=\"stylesheet\" href=\"style.css\"></head><body>$html<script src=\"script.js\"></script></body></html>")
                val font = when (websiteFont) { "serif" -> "Georgia,serif"; "rounded" -> "Arial Rounded MT Bold,system-ui,sans-serif"; "mono" -> "monospace"; else -> "system-ui,sans-serif" }
                put("style.css", "body{font-family:$font}\n" + websiteCssEditor?.text?.toString().orEmpty()); put("script.js", websiteJsEditor?.text?.toString().orEmpty())
                put("README.txt", "Hira Bhai Website Builder export. Upload these files to a hosting provider. Review generated code before publishing.")
            }
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("application/zip").putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Export website source"))
        } catch (error: Exception) { info("Export failed", friendlyError(error)) }
    }

    private fun showWebsiteProjects() {
        val user = FirebaseBackend.auth?.currentUser ?: return
        val db = FirebaseBackend.db ?: return
        db.collection("creatorWebsiteProjects").document(user.uid).collection("projects").orderBy("updatedAt", com.google.firebase.firestore.Query.Direction.DESCENDING).limit(50).get()
            .addOnSuccessListener { snapshot ->
                val docs = snapshot.documents
                if (docs.isEmpty()) { info("My website projects", "Save a website to create your first private project."); return@addOnSuccessListener }
                val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(4), dp(10), dp(4)) }
                val scroll = ScrollView(this).apply { addView(list) }
                docs.forEach { doc ->
                    val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = glass(0x2affffff, 14); setPadding(dp(10), dp(8), dp(10), dp(8)) }
                    row.addView(label(doc.getString("name") ?: "Untitled website", 16, primaryText, true))
                    val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                    actions.addView(buttonView("Load") { val map = doc.get("websiteData") as? Map<String, Any> ?: emptyMap(); websiteProjectId = doc.id; getSharedPreferences("hira_website_projects", MODE_PRIVATE).edit().putString("active_${user.uid}", doc.id).apply(); buildWebsiteEditor(websiteOwnerProfile, map) }, LinearLayout.LayoutParams(0, -2, 1f))
                    actions.addView(buttonView("Rename") { renameWebsiteProject(doc.id, doc.getString("name") ?: "Website", doc.get("websiteData") as? Map<String, Any> ?: emptyMap()) }, LinearLayout.LayoutParams(0, -2, 1f))
                    actions.addView(buttonView("Duplicate") { duplicateWebsiteProject(doc.id, doc.getString("name") ?: "Website", doc.get("websiteData") as? Map<String, Any> ?: emptyMap()) }, LinearLayout.LayoutParams(0, -2, 1f))
                    actions.addView(buttonView("Delete") { AlertDialog.Builder(this).setMessage("Delete ${doc.getString("name") ?: "this project"}?").setNegativeButton("Cancel", null).setPositiveButton("Delete") { _, _ -> doc.reference.delete().addOnSuccessListener { showWebsiteProjects() }.addOnFailureListener { info("Delete failed", friendlyError(it)) } }.show() }, LinearLayout.LayoutParams(0, -2, 1f))
                    row.addView(actions); list.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
                }
                AlertDialog.Builder(this).setTitle("My website projects").setView(scroll).setPositiveButton("Done", null).show()
            }.addOnFailureListener { info("Projects unavailable", "Could not load private projects: ${friendlyError(it)}. Check the deployed creatorWebsiteProjects rules.") }
    }

    private fun renameWebsiteProject(id: String, oldName: String, source: Map<String, Any>) {
        val input = EditText(this).apply { setText(oldName); setSelection(text.length) }
        AlertDialog.Builder(this).setTitle("Rename website").setView(input).setNegativeButton("Cancel", null).setPositiveButton("Save") { _, _ ->
            val name = input.text.toString().trim().take(80); if (name.length < 2) { info("Name too short", "Use at least two characters."); return@setPositiveButton }
            FirebaseBackend.db?.collection("creatorWebsiteProjects")?.document(FirebaseBackend.auth?.currentUser?.uid ?: return@setPositiveButton)?.collection("projects")?.document(id)?.update("name", name, "websiteData.websiteName", name, "updatedAt", FieldValue.serverTimestamp())?.addOnSuccessListener { showWebsiteProjects() }?.addOnFailureListener { info("Rename failed", friendlyError(it)) }
        }.show()
    }

    private fun duplicateWebsiteProject(sourceId: String, oldName: String, source: Map<String, Any>) {
        val user = FirebaseBackend.auth?.currentUser ?: return
        val id = java.util.UUID.randomUUID().toString(); val copied = source.toMutableMap().apply { put("published", false) }
        FirebaseBackend.db?.collection("creatorWebsiteProjects")?.document(user.uid)?.collection("projects")?.document(id)?.set(mapOf("name" to "Copy of $oldName".take(80), "websiteData" to copied, "createdAt" to FieldValue.serverTimestamp(), "updatedAt" to FieldValue.serverTimestamp()))
            ?.addOnSuccessListener { info("Website duplicated", "Private draft created. Load it from My website projects.") }?.addOnFailureListener { info("Duplicate failed", friendlyError(it)) }
    }

    private fun loadCreatorWebsite(username: String) {
        if (!Regex("^[a-z0-9_]{3,24}$").matches(username)) { base(); heading("Website not found", "Invalid creator website address."); addBottom(); return }
        val db = FirebaseBackend.db ?: run { base(); heading("Website unavailable", "Firebase is not configured."); addBottom(); return }
        selected = "Website"; base(); heading("Creator website", "Loading @${username}…"); addBottom()
        db.collection("creatorWebsites").document(username).get()
            .addOnSuccessListener { website ->
                if (!website.exists() || website.getBoolean("published") != true) { base(); heading("Website not published", "@${username} has not published a creator website."); action("Open creator channel", "View their public Hira Bhai profile.") { loadPublicCreator(username, null) }; addBottom(); return@addOnSuccessListener }
                db.collection("publicProfiles").document(username).get()
                    .addOnSuccessListener { profile ->
                        if (!profile.exists()) { base(); heading("Creator profile unavailable", "This website has no public creator profile."); addBottom(); return@addOnSuccessListener }
                        showPublicWebsite(username, website.data ?: emptyMap(), profile.data ?: emptyMap())
                    }
                    .addOnFailureListener { error -> base(); heading("Website unavailable", friendlyError(error)); addBottom() }
            }
            .addOnFailureListener { error ->
                Log.e("HiraBhaiWebsite", "Public website read failed path=creatorWebsites/$username", error)
                base(); heading("Could not load website", "${friendlyError(error)}. The published creatorWebsites read rule may not be deployed."); addBottom()
            }
    }

    private fun showPublicWebsite(username: String, website: Map<String, Any>, profile: Map<String, Any>) {
        base(); val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(page)
        websiteFont = website["font"] as? String ?: "system"
        renderWebsiteContent(page, website["websiteName"] as? String ?: (profile["fullName"] as? String ?: "Creator"), website["description"] as? String ?: (profile["bio"] as? String ?: ""), profile, (website["sections"] as? List<*>)?.mapNotNull { (it as? Map<*, *>)?.entries?.associate { e -> e.key.toString() to e.value as Any } } ?: emptyList(), website["palette"] as? String ?: "ocean", website["logoData"] as? String, website["profilePhotoData"] as? String, true, website["template"] as? String ?: "portfolio")
        val generatedHtml = website["generatedHtml"] as? String
        if (!generatedHtml.isNullOrBlank()) {
            page.addView(label("Custom website", 18, primaryText, true).apply { setPadding(dp(2), dp(8), dp(2), dp(6)) })
            page.addView(createSandboxedWebsiteWebView(generatedHtml, website["generatedCss"] as? String ?: "", website["generatedJs"] as? String ?: "", dp(720)))
        }
        addBottom()
    }

    private fun renderWebsiteContent(parent: LinearLayout, title: String, description: String, profile: Map<String, Any>, sections: List<Map<String, Any>>, palette: String, logoData: String?, profilePhotoData: String?, publicPage: Boolean, template: String) {
        val (primary, accent) = websitePaletteColors(palette)
        val handle = profile["username"] as? String ?: websiteUsername.orEmpty()
        val creatorName = profile["fullName"] as? String ?: title
        val minimal = template == "minimal"
        val leftAligned = template == "video"
        val titleColor = if (minimal) primary else Color.WHITE
        val supportingColor = if (minimal) secondaryText else 0xffeaf5fb.toInt()
        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = if (leftAligned) Gravity.START else Gravity.CENTER_HORIZONTAL; background = round(if (minimal) Color.WHITE else primary, 24); setPadding(dp(18), dp(22), dp(18), dp(22)) }
        val photo = profilePhotoData ?: (profile["photoData"] as? String)
        listOfNotNull(logoData?.takeIf { it.isNotBlank() }, photo?.takeIf { it.isNotBlank() }).distinct().forEachIndexed { index, imageData ->
            val image = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; background = round(Color.WHITE, 100); clipToOutline = true; layoutParams = LinearLayout.LayoutParams(dp(if (index == 0) 82 else 70), dp(if (index == 0) 82 else 70)).apply { bottomMargin = dp(8) } }
            header.addView(image)
            try { val bytes = Base64.decode(imageData, Base64.DEFAULT); image.setImageBitmap(BitmapFactory.decodeByteArray(bytes, 0, bytes.size)) } catch (_: Exception) { if (imageData == photo) showProfilePhoto(imageData, image) }
        }
        header.addView(label(title, 27, titleColor, true).apply { gravity = if (leftAligned) Gravity.START else Gravity.CENTER })
        header.addView(label("$creatorName · @$handle", 14, supportingColor, false).apply { gravity = if (leftAligned) Gravity.START else Gravity.CENTER; setPadding(0, dp(5), 0, 0) })
        if (description.isNotBlank()) header.addView(label(description, 15, if (minimal) secondaryText else Color.WHITE, false).apply { gravity = if (leftAligned) Gravity.START else Gravity.CENTER; setPadding(0, dp(10), 0, 0) })
        parent.addView(header, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        val bio = profile["bio"] as? String
        if (!bio.isNullOrBlank()) websiteInfoCard(parent, "About", bio, accent)
        val social = profile["websiteUrl"] as? String
        if (!social.isNullOrBlank()) {
            val contact = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = round(Color.WHITE, 15); setPadding(dp(14), dp(13), dp(14), dp(13)); isClickable = true; setOnClickListener { try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(social))) } catch (_: Exception) {} } }
            contact.addView(label("Contact & social", 16, primaryText, true)); contact.addView(label(social, 14, accent, false).apply { setPadding(0, dp(4), 0, 0) })
            parent.addView(contact, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) })
        }
        sections.forEach { section ->
            val type = section["type"] as? String ?: return@forEach
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = round(Color.WHITE, 15); setPadding(dp(14), dp(13), dp(14), dp(13)) }
            val sectionTitle = section["title"] as? String ?: if (type == "videos") "My videos" else "Section"
            card.addView(label(sectionTitle, 17, primaryText, true))
            when (type) {
                "text" -> card.addView(label(section["text"] as? String ?: "", 14, secondaryText, false).apply { setPadding(0, dp(6), 0, 0) })
                "image" -> {
                    val encoded = section["imageData"] as? String
                    if (!encoded.isNullOrBlank()) try { val bytes = Base64.decode(encoded, Base64.DEFAULT); val image = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; adjustViewBounds = true; layoutParams = LinearLayout.LayoutParams(-1, dp(220)).apply { topMargin = dp(8) } }; image.setImageBitmap(BitmapFactory.decodeByteArray(bytes, 0, bytes.size)); card.addView(image) } catch (_: Exception) { card.addView(label("Image could not be decoded.", 12, secondaryText, false)) }
                }
                "link" -> {
                    val url = section["url"] as? String
                    if (!url.isNullOrBlank()) card.addView(label(url, 14, accent, false).apply { setPadding(0, dp(6), 0, 0); isClickable = true; setOnClickListener { try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) {} } })
                }
                "video", "videos" -> {
                    val videoId = section["videoId"] as? String
                    val db = FirebaseBackend.db
                    if (videoId != null && db != null) db.collection("videos").document(videoId).get().addOnSuccessListener { doc ->
                        if (doc.exists() && doc.getString("visibility") == "public") {
                            val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = round(0xffedf3f6.toInt(), 12); setPadding(dp(11), dp(9), dp(11), dp(9)); isClickable = true; setOnClickListener { openVideoById(videoId, doc.data ?: emptyMap()) } }
                            row.addView(label(doc.getString("title") ?: sectionTitle, 14, primaryText, true)); row.addView(label("▶  Watch on Hira Bhai · ${formatDuration(doc.getLong("durationMs") ?: 0L)}", 12, accent, false).apply { setPadding(0, dp(4), 0, 0) }); card.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(7) })
                        }
                    }
                    if (type == "videos") {
                        val creatorId = profile["creatorId"] as? String
                        if (creatorId != null) loadWebsiteVideoList(card, creatorId, accent)
                    }
                }
            }
            parent.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) })
        }
        if (publicPage) parent.addView(label("Hira Bhai creator website · @$handle", 12, secondaryText, false).apply { gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(14)) })
    }

    private fun websiteInfoCard(parent: LinearLayout, title: String, body: String, accent: Int) {
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = round(Color.WHITE, 15); setPadding(dp(14), dp(13), dp(14), dp(13)) }
        card.addView(label(title, 17, primaryText, true)); card.addView(label(body, 14, secondaryText, false).apply { setPadding(0, dp(6), 0, 0) })
        parent.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) })
    }

    private fun loadWebsiteVideoList(parent: LinearLayout, creatorId: String, accent: Int) {
        val db = FirebaseBackend.db ?: return
        db.collection("videos").whereEqualTo("creatorId", creatorId).whereEqualTo("visibility", "public").limit(30).get()
            .addOnSuccessListener { snapshot ->
                if (snapshot.isEmpty) { parent.addView(label("No public videos yet.", 13, secondaryText, false).apply { setPadding(0, dp(6), 0, 0) }); return@addOnSuccessListener }
                snapshot.documents.sortedByDescending { it.getTimestamp("createdAt")?.toDate()?.time ?: 0L }.forEach { doc ->
                    val item = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = round(0xffedf3f6.toInt(), 11); setPadding(dp(10), dp(9), dp(10), dp(9)); isClickable = true; setOnClickListener { openVideoById(doc.id, doc.data ?: emptyMap()) } }
                    item.addView(label(doc.getString("title") ?: "Creator video", 14, primaryText, true)); item.addView(label("▶  Watch · ${formatDuration(doc.getLong("durationMs") ?: 0L)}", 12, accent, false).apply { setPadding(0, dp(4), 0, 0) }); parent.addView(item, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(7) })
                }
            }
            .addOnFailureListener { error -> parent.addView(label("Creator videos could not load: ${friendlyError(error)}", 12, secondaryText, false)) }
    }
    private fun visibilityDialog() { AlertDialog.Builder(this).setTitle("Content visibility").setSingleChoiceItems(arrayOf("Public","Unlisted","Private"),0) { d,w -> d.dismiss(); info("${arrayOf("Public","Unlisted","Private")[w]} selected","Visibility is shown for the prototype. Publishing is not connected.") }.setNegativeButton("Cancel",null).show() }
    private fun showUploadOptions(openLive: Boolean = false) {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            val needs = mutableListOf(Manifest.permission.CAMERA)
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) needs.add(Manifest.permission.RECORD_AUDIO)
            requestPermissions(needs.toTypedArray(), 70)
            return
        }
        uploadWantRecord = false
        uploadRecording = false
        keepLiveRecording = false
        val screen = FrameLayout(this)
        val preview = TextureView(this).apply { uploadCameraTexture = this }
        screen.addView(preview, FrameLayout.LayoutParams(-1, -1))
        screen.addView(TextView(this).apply {
            text = "×"; textSize = 26f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = frostGlass(100, 0xB8F7FBFF.toInt())
            layoutParams = FrameLayout.LayoutParams(dp(44), dp(44), Gravity.TOP or Gravity.END).apply { topMargin = dp(18); rightMargin = dp(16) }
            setOnClickListener { uploadCameraDialog?.dismiss() }
        })
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = frostGlass(32, 0x8CF4FBFF.toInt())
            setPadding(dp(14), dp(14), dp(14), dp(14))
        }
        val options = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val live = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        listOf(
            "Upload Video" to { uploadCameraDialog?.dismiss(); chooseVideoUpload() },
            "Upload Short · vertical 9:16" to { uploadCameraDialog?.dismiss(); chooseShortUpload() },
            "Upload Audio" to { uploadCameraDialog?.dismiss(); chooseAudioUpload() },
            "Upload Image" to { uploadCameraDialog?.dismiss(); chooseImageForUpload() },
            "Upload Your Document" to { uploadCameraDialog?.dismiss(); chooseDocumentForUpload() },
            "Upload Your Any File" to { uploadCameraDialog?.dismiss(); chooseAnyFileForUpload() },
            "Upload Your Live" to { showLiveChoices(options, live) }
        ).forEach { (title, click) ->
            options.addView(TextView(this).apply {
                text = title; textSize = 16f; gravity = Gravity.CENTER_VERTICAL
                setTextColor(if (title == "Upload Your Live") 0xffb4232c.toInt() else 0xff10283a.toInt())
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                background = frostGlass(18, if (title == "Upload Your Live") 0x99FFE4E6.toInt() else 0x72FFFFFF)
                setPadding(dp(16), dp(14), dp(16), dp(14))
                isClickable = true; isFocusable = true
                setOnClickListener { click() }
            }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
        live.addView(label("Upload Your Live", 18, 0xff10283a.toInt(), true))
        live.addView(label("Record a clip to upload, or start a real live broadcast.", 13, 0xff3d5568.toInt(), false).apply { setPadding(0, dp(4), 0, dp(12)) })
        live.addView(TextView(this).apply {
            text = "Start live broadcast"; textSize = 15f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = round(0xff199c8a.toInt(), 18); setPadding(dp(16), dp(13), dp(16), dp(13))
            setOnClickListener { uploadCameraDialog?.dismiss(); openLiveScreen() }
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        liveActionButton = TextView(this).apply {
            text = "Go Live"; textSize = 16f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = round(0xffe23b45.toInt(), 18); setPadding(dp(16), dp(14), dp(16), dp(14))
            isClickable = true; isFocusable = true
            setOnClickListener {
                if (uploadRecording) finishLiveRecording(upload = true) else beginLiveCapture()
            }
        }
        live.addView(liveActionButton, LinearLayout.LayoutParams(-1, -2))
        live.addView(TextView(this).apply {
            text = "Back"; textSize = 14f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            setPadding(0, dp(12), 0, dp(2)); isClickable = true
            setOnClickListener {
                if (uploadRecording) finishLiveRecording(upload = false)
                live.visibility = View.GONE
                options.visibility = View.VISIBLE
            }
        })
        panel.addView(options)
        panel.addView(live)
        screen.addView(panel, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER).apply { setMargins(dp(12), dp(12), dp(12), dp(12)) })
        val dialog = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        uploadCameraDialog = dialog
        dialog.setContentView(screen)
        dialog.window?.apply {
            setBackgroundDrawableResource(android.R.color.transparent)
            setLayout(-1, -1)
            statusBarColor = Color.TRANSPARENT
            navigationBarColor = 0x66000000
        }
        dialog.setOnDismissListener {
            val file = uploadRecordFile
            stopUploadCameraPreview()
            if (!keepLiveRecording) file?.delete()
            uploadCameraDialog = null
            liveActionButton = null
        }
        dialog.show()
        dialog.window?.setLayout(-1, -1)
        if (openLive) { dialog.dismiss(); openLiveScreen() }
        val listener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(surface: android.graphics.SurfaceTexture, width: Int, height: Int) { openUploadCamera(preview) }
            override fun onSurfaceTextureSizeChanged(surface: android.graphics.SurfaceTexture, width: Int, height: Int) {
                uploadPreviewSize?.let { fitCameraPreview(preview, it) }
            }
            override fun onSurfaceTextureDestroyed(surface: android.graphics.SurfaceTexture): Boolean = true
            override fun onSurfaceTextureUpdated(surface: android.graphics.SurfaceTexture) {}
        }
        if (preview.isAvailable) openUploadCamera(preview) else preview.surfaceTextureListener = listener
        preview.surfaceTextureListener = listener
    }

    private fun showLiveChoices(options: LinearLayout, live: LinearLayout) {
        options.visibility = View.GONE
        live.visibility = View.VISIBLE
    }

    private fun frostGlass(radius: Int, fill: Int) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radius).toFloat()
        setStroke(dp(1), 0xEEFFFFFF.toInt())
    }

    private fun beginLiveCapture() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 71)
            return
        }
        if (uploadCameraDevice == null) {
            uploadWantRecord = true
            Toast.makeText(this, "Opening the camera…", Toast.LENGTH_SHORT).show()
            return
        }
        uploadWantRecord = true
        startCameraSession(record = true)
    }

    private fun finishLiveRecording(upload: Boolean) {
        val file = uploadRecordFile
        uploadWantRecord = false
        releaseUploadRecorder()
        if (upload && file != null && file.length() > 0L) {
            keepLiveRecording = true
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            uploadCameraDialog?.dismiss()
            selectedVideoUri = uri
            selectedVideoThumbnailUri = null
            val extracted = extractVideoThumbnail(uri)
            videoThumbnail = extracted.first
            selectedVideoDurationMs = extracted.second
            pendingVideoTitle = "Live"
            pendingVideoDescription = ""
            pendingVideoVisibility = "public"
            showVideoUploadForm(uri)
        } else {
            file?.delete()
            uploadRecordFile = null
            liveActionButton?.text = "Go Live"
            if (uploadCameraDialog?.isShowing == true) startCameraSession(record = false)
            if (upload) Toast.makeText(this, "The recording was too short. Try again.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openUploadCamera(texture: TextureView) {
        if (!texture.isAvailable || uploadCameraDevice != null || checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return
        try {
            val manager = getSystemService(CameraManager::class.java) ?: return
            val cameraId = manager.cameraIdList.firstOrNull { id -> manager.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK }
                ?: manager.cameraIdList.firstOrNull() ?: return
            val characteristics = manager.getCameraCharacteristics(cameraId)
            val map = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            uploadSensorOrientation = characteristics.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
            val recorderSizes = map?.getOutputSizes(MediaRecorder::class.java).orEmpty()
            uploadRecordSize = recorderSizes.firstOrNull { it.width == 1280 && it.height == 720 }
                ?: recorderSizes.filter { it.width <= 1920 && it.height <= 1080 }.maxByOrNull { it.width.toLong() * it.height }
                ?: android.util.Size(1280, 720)
            val recordSize = uploadRecordSize ?: android.util.Size(1280, 720)
            val previewSizes = map?.getOutputSizes(SurfaceTexture::class.java).orEmpty()
            uploadPreviewSize = previewSizes.filter { kotlin.math.abs(it.width.toFloat() / it.height - recordSize.width.toFloat() / recordSize.height) < 0.2f }
                .minByOrNull { kotlin.math.abs(it.width.toLong() * it.height - 1280L * 720L) }
                ?: previewSizes.firstOrNull()
                ?: recordSize
            uploadCameraId = cameraId
            manager.openCamera(cameraId, object : CameraDevice.StateCallback() {
                override fun onOpened(camera: CameraDevice) {
                    if (uploadCameraDialog?.isShowing != true) { camera.close(); return }
                    uploadCameraDevice = camera
                    startCameraSession(record = uploadWantRecord)
                }
                override fun onDisconnected(camera: CameraDevice) { camera.close(); if (uploadCameraDevice === camera) uploadCameraDevice = null }
                override fun onError(camera: CameraDevice, error: Int) { camera.close(); uploadCameraDevice = null; Log.e("HiraBhaiCamera", "Camera error $error") }
            }, null)
        } catch (error: Exception) {
            Log.e("HiraBhaiCamera", "Unable to open camera preview", error)
            Toast.makeText(this, "Camera preview unavailable", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startCameraSession(record: Boolean) {
        val camera = uploadCameraDevice ?: return
        val texture = uploadCameraTexture ?: return
        val surfaceTexture = texture.surfaceTexture ?: return
        val previewSize = uploadPreviewSize ?: return
        if (record && uploadRecording) return
        try { uploadCameraSession?.stopRepeating() } catch (_: Exception) {}
        try { uploadCameraSession?.close() } catch (_: Exception) {}
        uploadCameraSession = null
        releaseUploadRecorder()
        surfaceTexture.setDefaultBufferSize(previewSize.width, previewSize.height)
        fitCameraPreview(texture, previewSize)
        val previewSurface = Surface(surfaceTexture)
        val surfaces = mutableListOf(previewSurface)
        if (record) {
            try {
                val folder = File(cacheDir, "shared_video").apply { mkdirs() }
                val file = File(folder, "live-${System.currentTimeMillis()}.mp4")
                uploadRecordFile = file
                val recorder = newLiveRecorder(file, uploadRecordSize ?: previewSize, uploadSensorOrientation)
                uploadRecorder = recorder
                surfaces.add(recorder.surface)
            } catch (error: Exception) {
                Log.e("HiraBhaiCamera", "Could not prepare the live recording", error)
                Toast.makeText(this, "Live recording could not start", Toast.LENGTH_SHORT).show()
                uploadWantRecord = false
            }
        }
        val recording = uploadRecorder != null
        camera.createCaptureSession(surfaces, object : CameraCaptureSession.StateCallback() {
            override fun onConfigured(session: CameraCaptureSession) {
                if (uploadCameraDevice == null) { session.close(); return }
                uploadCameraSession = session
                val request = camera.createCaptureRequest(if (recording) CameraDevice.TEMPLATE_RECORD else CameraDevice.TEMPLATE_PREVIEW).apply {
                    addTarget(previewSurface)
                    uploadRecorder?.surface?.let { addTarget(it) }
                    set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO)
                }
                try {
                    session.setRepeatingRequest(request.build(), null, null)
                    if (recording) {
                        uploadRecorder?.start()
                        uploadRecording = true
                        runOnUiThread { liveActionButton?.text = "Stop and upload" }
                    }
                } catch (error: Exception) {
                    Log.e("HiraBhaiCamera", "Preview request failed", error)
                }
            }
            override fun onConfigureFailed(session: CameraCaptureSession) { Log.e("HiraBhaiCamera", "Could not configure the camera") }
        }, null)
    }

    @Suppress("DEPRECATION")
    private fun newLiveRecorder(file: File, size: android.util.Size, orientation: Int): MediaRecorder {
        val recorder = if (android.os.Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
        recorder.setAudioSource(MediaRecorder.AudioSource.MIC)
        recorder.setVideoSource(MediaRecorder.VideoSource.SURFACE)
        recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
        recorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
        recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
        recorder.setVideoSize(size.width, size.height)
        recorder.setVideoFrameRate(30)
        recorder.setVideoEncodingBitRate(5_000_000)
        recorder.setAudioEncodingBitRate(128_000)
        recorder.setAudioSamplingRate(44100)
        recorder.setOrientationHint(orientation)
        recorder.setOutputFile(file.absolutePath)
        recorder.prepare()
        return recorder
    }

    private fun fitCameraPreview(texture: TextureView, preview: android.util.Size) {
        val viewW = texture.width
        val viewH = texture.height
        if (viewW == 0 || viewH == 0) return
        @Suppress("DEPRECATION")
        val rotation = windowManager.defaultDisplay.rotation
        val matrix = Matrix()
        val viewRect = RectF(0f, 0f, viewW.toFloat(), viewH.toFloat())
        val bufferRect = RectF(0f, 0f, preview.height.toFloat(), preview.width.toFloat())
        val centerX = viewRect.centerX()
        val centerY = viewRect.centerY()
        bufferRect.offset(centerX - bufferRect.centerX(), centerY - bufferRect.centerY())
        matrix.setRectToRect(viewRect, bufferRect, Matrix.ScaleToFit.FILL)
        val scale = maxOf(viewH.toFloat() / preview.height, viewW.toFloat() / preview.width)
        matrix.postScale(scale, scale, centerX, centerY)
        val degrees = when (rotation) {
            Surface.ROTATION_90 -> 90
            Surface.ROTATION_180 -> 180
            Surface.ROTATION_270 -> 270
            else -> 0
        }
        matrix.postRotate(((uploadSensorOrientation - degrees + 360) % 360).toFloat(), centerX, centerY)
        texture.setTransform(matrix)
    }

    private fun releaseUploadRecorder() {
        val recorder = uploadRecorder
        val wasRecording = uploadRecording
        uploadRecording = false
        uploadRecorder = null
        if (wasRecording) { try { recorder?.stop() } catch (_: Exception) {} }
        try { recorder?.reset() } catch (_: Exception) {}
        try { recorder?.release() } catch (_: Exception) {}
    }

    private fun stopUploadCameraPreview() {
        uploadWantRecord = false
        releaseUploadRecorder()
        try { uploadCameraSession?.stopRepeating() } catch (_: Exception) {}
        try { uploadCameraSession?.close() } catch (_: Exception) {}
        uploadCameraSession = null
        try { uploadCameraDevice?.close() } catch (_: Exception) {}
        uploadCameraDevice = null
        uploadCameraTexture = null
        uploadCameraId = null
    }

    private fun chooseImageForUpload() = launchUploadPicker("image/*", 61)
    private fun chooseDocumentForUpload() = launchUploadPicker("application/*", 62, arrayOf("application/pdf", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/vnd.ms-excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "text/plain"))
    private fun chooseAnyFileForUpload() = launchUploadPicker("*/*", 63)
    private fun launchUploadPicker(type: String, requestCode: Int, mimeTypes: Array<String>? = null) {
        if (FirebaseBackend.auth?.currentUser == null) { showAuth(false); return }
        try { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).setType(type).apply { if (mimeTypes != null) putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes) }.addCategory(Intent.CATEGORY_OPENABLE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION), requestCode) }
        catch (error: Exception) { info("File picker unavailable", friendlyError(error)) }
    }

    private fun uploadCreatorFile(uri: Uri) {
        val user = FirebaseBackend.auth?.currentUser ?: run { showAuth(false); return }
        val db = FirebaseBackend.db ?: run { info("Upload unavailable", "Cloud Firestore is not configured."); return }
        val storage = FirebaseBackend.storage ?: run { info("Upload unavailable", FirebaseBackend.storageSetupError ?: "Firebase Storage is not configured."); return }
        db.collection("profiles").document(user.uid).get().addOnSuccessListener { profile ->
            val creatorId = profile.getString("creatorId") ?: run { info("Creator profile required", "Create a creator profile before uploading files."); return@addOnSuccessListener }
            val mime = contentResolver.getType(uri) ?: "application/octet-stream"
            val fileName = uri.lastPathSegment?.substringAfterLast('/')?.substringAfterLast(':')?.takeLast(80)?.replace(Regex("[^A-Za-z0-9._-]"), "_")?.ifBlank { "upload.bin" } ?: "upload.bin"
            val path = "creatorMedia/$creatorId/${UUID.randomUUID()}/$fileName"
            val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
            val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(12), dp(20), 0); addView(label("Uploading privately to your creator files…", 14, primaryText, false)); addView(bar, LinearLayout.LayoutParams(-1, dp(12)).apply { topMargin = dp(12) }) }
            val progressDialog = AlertDialog.Builder(this).setTitle("Uploading file").setView(body).setNegativeButton("Hide", null).create(); progressDialog.show()
            val metadata = com.google.firebase.storage.StorageMetadata.Builder().setContentType(mime).build()
            storage.reference.child(path).putFile(uri, metadata).addOnProgressListener { task -> if (task.totalByteCount > 0) bar.progress = (100 * task.bytesTransferred / task.totalByteCount).toInt() }
                .addOnSuccessListener { progressDialog.dismiss(); info("Upload complete", "$fileName is stored in your private creator files.") }
                .addOnFailureListener { error -> progressDialog.dismiss(); Log.e("HiraBhaiMediaUpload", "Storage upload failed at $path", error); info("Upload failed", friendlyError(error)) }
        }.addOnFailureListener { error -> info("Upload unavailable", friendlyError(error)) }
    }

    private fun pickMedia() = chooseAnyFileForUpload()

    private fun startPhoneVideoCamera() {
        try {
            val camera = Intent(MediaStore.ACTION_VIDEO_CAPTURE).apply { putExtra(MediaStore.EXTRA_VIDEO_QUALITY, 1) }
            startActivityForResult(camera, 64)
        } catch (error: Exception) {
            info("Camera unavailable", "No video camera app could be opened: ${friendlyError(error)}")
        }
    }

    private fun openLiveScreen(streamId: String? = null) {
        if (FirebaseBackend.auth?.currentUser == null) { showAuth(false); return }
        startActivity(Intent(this, LiveStreamingActivity::class.java).apply { streamId?.let { putExtra(LiveStreamingActivity.EXTRA_STREAM_ID, it) } })
    }

    private fun showLiveStudio() = openLiveScreen()
    private fun info(title:String,message:String) { AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("Got it",null).show() }
    private fun columnText(title:String,sub:String)=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; addView(label(title,16,primaryText,true)); addView(label(sub,12,secondaryText,false).apply { setPadding(0,dp(4),0,0) }) }
    private fun label(s:String,size:Int,color:Int,bold:Boolean)=TextView(this).apply { text=s; textSize=size.toFloat(); setTextColor(color); if(bold) typeface=Typeface.create("sans-serif-medium",Typeface.NORMAL) }
    private fun round(color:Int,radius:Int)=GradientDrawable().apply {
        val alpha = Color.alpha(color)
        val red = Color.red(color); val green = Color.green(color); val blue = Color.blue(color)
        val brightSurface = red > 225 && green > 225 && blue > 225
        val glassColor = when {
            color == Color.TRANSPARENT -> Color.TRANSPARENT
            brightSurface -> 0x30ffffff
            color == mint -> 0x9923a48f.toInt()
            alpha < 255 -> color
            radius == 0 -> color
            else -> Color.argb(0xb0, red, green, blue)
        }
        setColor(glassColor); cornerRadius=dp(radius).toFloat()
        if (radius > 0 && glassColor != Color.TRANSPARENT) setStroke(dp(1), 0x70ffffff)
    }
    private fun dp(value:Int)= (value*resources.displayMetrics.density).toInt()
}

private data class AiChatMessage(var id: String, val role: String, var text: String, val at: Date?)

/** Lightweight code-drawn landscape wallpaper; it keeps the UI self-contained and offline. */
private class NatureBackdropDrawable : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private fun ridge(points: FloatArray): Path = Path().apply {
        moveTo(points[0], points[1])
        var i = 2
        while (i < points.size) { lineTo(points[i], points[i + 1]); i += 2 }
        lineTo(1000f, 1800f); lineTo(0f, 1800f); close()
    }
    override fun draw(canvas: Canvas) {
        val b = bounds
        if (b.width() <= 0 || b.height() <= 0) return
        paint.shader = null
        paint.color = Color.rgb(0, 45, 41)
        canvas.drawColor(paint.color)
    }
    override fun setAlpha(alpha: Int) { paint.alpha = alpha }
    override fun setColorFilter(colorFilter: android.graphics.ColorFilter?) { paint.colorFilter = colorFilter }
    @Deprecated("Deprecated in Java") override fun getOpacity(): Int = PixelFormat.OPAQUE
}

/** Scenery behind the featured upload card, matching the same blue mountain palette. */
private class MountainArtView(context: android.content.Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private fun shape(vararg xy: Float): Path = Path().apply {
        moveTo(xy[0], xy[1]); var i = 2
        while (i < xy.size) { lineTo(xy[i], xy[i + 1]); i += 2 }
        close()
    }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val save = canvas.save(); canvas.scale(width / 1000f, height / 600f)
        paint.shader = LinearGradient(0f, 0f, 0f, 600f, intArrayOf(0xff72d4ff.toInt(), 0xff087bb8.toInt(), 0xff084d69.toInt()), null, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, 1000f, 600f, paint); paint.shader = null
        paint.color = 0xff1b7691.toInt(); canvas.drawPath(shape(0f,460f, 120f,260f, 250f,430f, 390f,160f, 540f,430f, 700f,205f, 860f,430f, 1000f,255f, 1000f,600f, 0f,600f), paint)
        paint.color = 0xff0c566e.toInt(); canvas.drawPath(shape(0f,500f, 145f,345f, 300f,495f, 470f,240f, 625f,485f, 800f,290f, 1000f,490f, 1000f,600f, 0f,600f), paint)
        paint.color = Color.WHITE
        canvas.drawPath(shape(260f,430f,390f,160f,475f,320f,420f,290f,390f,330f,350f,286f), paint)
        canvas.drawPath(shape(545f,435f,700f,205f,790f,345f,745f,320f,705f,350f,675f,310f), paint)
        paint.shader = LinearGradient(0f, 445f, 0f, 600f, intArrayOf(0xff16bbbd.toInt(), 0xff07607d.toInt()), null, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 445f, 1000f, 600f, paint); paint.shader = null
        paint.color = 0x66ffffff; paint.strokeWidth = 3f
        for (x in 25..975 step 55) canvas.drawLine(x.toFloat(), 500f + (x % 4) * 7f, x + 30f, 498f + (x % 4) * 7f, paint)
        paint.color = 0xff063d37.toInt()
        for (x in 0..1000 step 42) {
            val h = 75f + (x % 5) * 15f
            canvas.drawRect(x.toFloat(), 445f - h * .25f, x + 8f, 480f, paint)
            canvas.drawPath(shape(x - 13f, 460f - h * .6f, x + 4f, 430f - h, x + 21f, 460f - h * .6f), paint)
        }
        canvas.restoreToCount(save)
    }
}
