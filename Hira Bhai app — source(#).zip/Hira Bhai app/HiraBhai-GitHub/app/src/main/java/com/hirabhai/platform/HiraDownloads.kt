package com.hirabhai.platform

import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.WebView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

object HiraDownloads {
    private const val PREFS = "hira_downloads"
    private const val KEY_ITEMS = "items"
    const val WRITE_PERMISSION_REQUEST = 9417

    data class Entry(val id: Long, val title: String, val url: String, val mime: String)

    fun enableLongPressDownloads(activity: Activity, webView: WebView) {
        webView.setOnLongClickListener {
            val hit = webView.hitTestResult ?: return@setOnLongClickListener false
            val target = hit.extra.orEmpty()
            when (hit.type) {
                WebView.HitTestResult.IMAGE_TYPE, WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE -> {
                    if (target.isBlank()) return@setOnLongClickListener false
                    AlertDialog.Builder(activity).setItems(arrayOf("Download image")) { _, _ ->
                        enqueue(activity, target, webView.settings.userAgentString, null, null, webView.url)
                    }.show()
                    true
                }
                WebView.HitTestResult.SRC_ANCHOR_TYPE -> {
                    if (target.isBlank()) return@setOnLongClickListener false
                    AlertDialog.Builder(activity).setItems(arrayOf("Download linked file")) { _, _ ->
                        enqueue(activity, target, webView.settings.userAgentString, null, null, webView.url)
                    }.show()
                    true
                }
                else -> false
            }
        }
    }

    fun enqueue(activity: Activity, url: String, userAgent: String?, disposition: String?, mimeType: String?, referer: String? = null): Boolean {
        val uri = Uri.parse(url)
        if (uri.scheme !in setOf("http", "https") || uri.host.isNullOrBlank()) {
            Toast.makeText(activity, "This download link is not supported.", Toast.LENGTH_SHORT).show()
            return false
        }
        val guessedName = URLUtil.guessFileName(url, disposition, mimeType)
        val providedMime = mimeType?.substringBefore(';')?.trim()
        val mime = if (providedMime.isNullOrBlank() || providedMime == "application/octet-stream") guessMime(guessedName) else providedMime
        if (Build.VERSION.SDK_INT <= 28 && activity.checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("pending", JSONObject()
                .put("url", url).put("userAgent", userAgent ?: "").put("disposition", disposition ?: "").put("mime", mime)
                .put("referer", referer ?: "").toString()).apply()
            activity.requestPermissions(arrayOf(android.Manifest.permission.WRITE_EXTERNAL_STORAGE), WRITE_PERMISSION_REQUEST)
            return false
        }
        return enqueueNow(activity, url, userAgent, disposition, mime, referer)
    }

    fun downloadCurrentDirectVideo(activity: Activity, webView: WebView) {
        val script = "(function(){var v=document.querySelector('video');if(!v)return '{}';var s=v.querySelector('source');return JSON.stringify({url:v.currentSrc||s&&s.src||'',type:s&&s.type||''});})()"
        webView.evaluateJavascript(script) { encoded ->
            try {
                val jsonText = JSONArray("[$encoded]").optString(0)
                val media = JSONObject(jsonText)
                val url = media.optString("url")
                val uri = Uri.parse(url)
                val extension = uri.lastPathSegment.orEmpty().substringAfterLast('.', "").lowercase()
                val mime = media.optString("type").substringBefore(';').ifBlank { guessMime(URLUtil.guessFileName(url, null, null)) }
                val supported = mime in setOf("video/mp4", "video/webm", "video/quicktime", "video/3gpp", "video/x-matroska", "video/x-msvideo") ||
                    extension in setOf("mp4", "m4v", "mov", "webm", "3gp", "mkv", "avi")
                if (uri.scheme !in setOf("http", "https") || uri.host.isNullOrBlank() || !supported || extension in setOf("m3u8", "mpd", "ts", "m4s")) {
                    Toast.makeText(activity, "This player does not expose a direct downloadable video file. Protected streaming videos cannot be saved to Gallery.", Toast.LENGTH_LONG).show()
                    return@evaluateJavascript
                }
                enqueue(activity, url, webView.settings.userAgentString, null, mime, webView.url)
            } catch (_: Exception) {
                Toast.makeText(activity, "This page has no direct downloadable video file.", Toast.LENGTH_LONG).show()
            }
        }
    }

    fun handlePermissionResult(activity: Activity, requestCode: Int, grantResults: IntArray) {
        if (requestCode != WRITE_PERMISSION_REQUEST) return
        val prefs = activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val pending = prefs.getString("pending", null)
        prefs.edit().remove("pending").apply()
        if (grantResults.firstOrNull() != android.content.pm.PackageManager.PERMISSION_GRANTED || pending == null) {
            Toast.makeText(activity, "Storage permission is needed to save downloads to Gallery.", Toast.LENGTH_LONG).show()
            return
        }
        try {
            val item = JSONObject(pending)
            enqueueNow(activity, item.getString("url"), item.optString("userAgent"), item.optString("disposition"), item.optString("mime"), item.optString("referer"))
        } catch (_: Exception) {
            Toast.makeText(activity, "Could not start this download.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun enqueueNow(activity: Activity, url: String, userAgent: String?, disposition: String?, mime: String, referer: String? = null): Boolean {
        return try {
            val manager = activity.getSystemService(DownloadManager::class.java) ?: throw IllegalStateException()
            val filename = URLUtil.guessFileName(url, disposition, mime).replace(Regex("[^A-Za-z0-9._() -]"), "_").take(120).ifBlank { "download" }
            val isVideo = mime.startsWith("video/") || filename.substringAfterLast('.', "").lowercase() in setOf("mp4", "m4v", "mov", "webm", "3gp", "mkv", "avi")
            val folder = if (isVideo) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_DOWNLOADS
            val destinationName = "Hira Bhai - $filename"
            val request = DownloadManager.Request(Uri.parse(url)).apply {
                setTitle(filename)
                setDescription(if (isVideo) "Saving video to Gallery · Hira Bhai" else "Downloading with Hira Bhai")
                setMimeType(mime)
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                setAllowedOverMetered(true); setAllowedOverRoaming(false)
                userAgent?.takeIf(String::isNotBlank)?.let { addRequestHeader("User-Agent", it) }
                referer?.takeIf { it.startsWith("https://") || it.startsWith("http://") }?.let { addRequestHeader("Referer", it) }
                CookieManager.getInstance().getCookie(url)?.takeIf(String::isNotBlank)?.let { addRequestHeader("Cookie", it) }
                setDestinationInExternalPublicDir(folder, destinationName)
            }
            val id = manager.enqueue(request)
            val prefs = activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val old = try { JSONArray(prefs.getString(KEY_ITEMS, "[]")) } catch (_: Exception) { JSONArray() }
            val updated = JSONArray().put(JSONObject().put("id", id).put("title", filename).put("url", url).put("mime", mime))
            for (i in 0 until minOf(old.length(), 39)) old.optJSONObject(i)?.let(updated::put)
            prefs.edit().putString(KEY_ITEMS, updated.toString()).apply()
            Toast.makeText(activity, if (isVideo) "Video downloading to Gallery" else "Download started", Toast.LENGTH_SHORT).show()
            true
        } catch (_: Exception) {
            Toast.makeText(activity, "Could not start this download. The website may block it.", Toast.LENGTH_LONG).show()
            false
        }
    }

    fun entries(context: Context): List<Entry> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_ITEMS, "[]")
        val json = try { JSONArray(raw) } catch (_: Exception) { JSONArray() }
        return (0 until json.length()).mapNotNull { i ->
            json.optJSONObject(i)?.let { Entry(it.optLong("id"), it.optString("title"), it.optString("url"), it.optString("mime")) }
        }
    }

    fun status(context: Context, id: Long): String {
        val manager = context.getSystemService(DownloadManager::class.java) ?: return "Unavailable"
        return try {
            manager.query(DownloadManager.Query().setFilterById(id)).use { cursor ->
                if (!cursor.moveToFirst()) return "Download record unavailable"
                when (cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))) {
                    DownloadManager.STATUS_SUCCESSFUL -> "Downloaded"
                    DownloadManager.STATUS_FAILED -> "Failed"
                    DownloadManager.STATUS_PAUSED -> "Paused"
                    else -> "Downloading"
                }
            }
        } catch (_: Exception) { "Unavailable" }
    }

    fun open(context: Context, id: Long, mime: String) {
        val manager = context.getSystemService(DownloadManager::class.java) ?: return
        val status = status(context, id)
        if (status != "Downloaded") {
            Toast.makeText(context, if (status == "Failed") "Download failed. The source may block direct downloads." else "Download is still in progress.", Toast.LENGTH_SHORT).show()
            return
        }
        val uri = manager.getUriForDownloadedFile(id) ?: return
        try {
            context.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime.ifBlank { "*/*" })
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) { Toast.makeText(context, "No app can open this download.", Toast.LENGTH_SHORT).show() }
    }

    private fun guessMime(filename: String): String = when (filename.substringAfterLast('.', "").lowercase()) {
        "mp4", "m4v" -> "video/mp4"
        "mov" -> "video/quicktime"
        "webm" -> "video/webm"
        "3gp" -> "video/3gpp"
        "mkv" -> "video/x-matroska"
        "avi" -> "video/x-msvideo"
        "jpg", "jpeg" -> "image/jpeg"
        "png" -> "image/png"
        "pdf" -> "application/pdf"
        else -> "application/octet-stream"
    }
}
