package com.hirabhai.platform

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import org.json.JSONArray
import org.json.JSONObject

/** Inexact device reminders; specs are retained locally so Android can restore them after reboot. */
object AssistantReminders {
    private const val PREFS = "assistant_reminders"
    private const val KEY = "scheduled"
    private const val CHANNEL = "assistant_tasks"

    fun schedule(context: Context, id: String, title: String, dueAt: Long, daily: Boolean) {
        val app = context.applicationContext
        var nextDue = dueAt
        if (daily) {
            val calendar = java.util.Calendar.getInstance().apply { timeInMillis = nextDue }
            while (nextDue <= System.currentTimeMillis()) { calendar.add(java.util.Calendar.DAY_OF_YEAR, 1); nextDue = calendar.timeInMillis }
        }
        val spec = JSONObject().put("id", id).put("title", title).put("dueAt", nextDue).put("daily", daily)
        val all = read(app)
        all.put(id, spec)
        write(app, all)
        arm(app, spec)
    }

    fun cancel(context: Context, id: String) {
        val app = context.applicationContext
        val all = read(app); all.remove(id); write(app, all)
        val intent = Intent(app, AssistantReminderReceiver::class.java).setAction("com.hirabhai.platform.REMINDER_$id")
        val pending = PendingIntent.getBroadcast(app, id.hashCode(), intent, PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)
        pending?.let { app.getSystemService(AlarmManager::class.java)?.cancel(it); it.cancel() }
    }

    internal fun restore(context: Context) {
        val app = context.applicationContext
        val all = read(app)
        for (i in 0 until all.length()) all.optJSONObject(all.names()?.optString(i).orEmpty())?.let { arm(app, it) }
    }

    internal fun fired(context: Context, id: String) {
        val app = context.applicationContext
        val all = read(app); val spec = all.optJSONObject(id) ?: return
        if (spec.optBoolean("daily")) {
            val calendar = java.util.Calendar.getInstance().apply { timeInMillis = spec.optLong("dueAt") }
            var next = spec.optLong("dueAt")
            do { calendar.add(java.util.Calendar.DAY_OF_YEAR, 1); next = calendar.timeInMillis } while (next <= System.currentTimeMillis())
            spec.put("dueAt", next); all.put(id, spec); write(app, all); arm(app, spec)
        } else { all.remove(id); write(app, all) }
    }

    private fun arm(context: Context, spec: JSONObject) {
        val id = spec.optString("id"); val dueAt = spec.optLong("dueAt")
        if (id.isBlank() || dueAt <= 0L) return
        val intent = Intent(context, AssistantReminderReceiver::class.java)
            .setAction("com.hirabhai.platform.REMINDER_$id")
            .putExtra("id", id).putExtra("title", spec.optString("title", "Hira Bhai reminder"))
        val pending = PendingIntent.getBroadcast(context, id.hashCode(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        context.getSystemService(AlarmManager::class.java)?.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, dueAt, pending)
    }

    private fun read(context: Context): JSONObject = runCatching {
        JSONObject(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "{}") ?: "{}")
    }.getOrDefault(JSONObject())
    private fun write(context: Context, value: JSONObject) { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, value.toString()).apply() }

    internal fun show(context: Context, id: String, title: String) {
        val manager = context.getSystemService(NotificationManager::class.java) ?: return
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(NotificationChannel(CHANNEL, "Assistant reminders", NotificationManager.IMPORTANCE_DEFAULT))
        val open = PendingIntent.getActivity(context, id.hashCode(), Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText("Your Hira Bhai reminder is due")
            .setContentIntent(open).setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_DEFAULT).build()
        try { manager.notify(id.hashCode(), notification) } catch (_: SecurityException) { }
    }
}

class AssistantReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getStringExtra("id") ?: return
        AssistantReminders.show(context, id, intent.getStringExtra("title") ?: "Hira Bhai reminder")
        AssistantReminders.fired(context, id)
    }
}

class AssistantReminderBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED || intent.action == Intent.ACTION_MY_PACKAGE_REPLACED) AssistantReminders.restore(context)
    }
}
