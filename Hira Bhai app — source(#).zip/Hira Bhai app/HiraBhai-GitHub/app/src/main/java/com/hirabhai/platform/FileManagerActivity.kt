package com.hirabhai.platform

import android.app.AlertDialog
import android.content.ClipData
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.DocumentsContract
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.Query
import com.google.firebase.storage.StorageException
import java.io.File
import java.text.DateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/** Authenticated, UID-scoped cloud files; Storage authorization is enforced by storage.rules. */
class FileManagerActivity : ComponentActivity() {
    private val ink = Color.WHITE
    private val muted = Color.rgb(196, 216, 213)
    private val teal = Color.rgb(35, 164, 143)
    private val pale = Color.rgb(0, 45, 41)
    private lateinit var items: LinearLayout
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var usage: TextView
    private lateinit var searchBox: EditText
    private lateinit var sortBox: Spinner
    private var tab = "Mine"
    private var folderFilter: String? = null
    private var uploadFolder = ""
    private var pendingSaveFile: File? = null
    private var pendingSaveName = ""
    private var searchText = ""
    private var sortMode = "Newest"
    private val localFiles = mutableListOf<LocalFile>()
    private var pendingLocalOperation: String? = null
    private var pendingLocalFile: LocalFile? = null
    private var activePickerRequest = 0
    private val pickerLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        handlePickerResult(activePickerRequest, result)
    }

    private data class LocalFile(val uri: Uri, val name: String, val mime: String, val size: Long)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
        if (FirebaseBackend.auth?.currentUser == null) status.text = "Device files work without sign-in. Sign in to use private cloud storage."
        if (intent?.data?.pathSegments?.let { it.size == 2 && it[0] == "f" } == true) {
            openSharedFile(intent.data!!.lastPathSegment ?: "")
        }
        loadFiles()
    }

    private fun render() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(pale) }
        window.statusBarColor = pale; window.navigationBarColor = pale; window.decorView.systemUiVisibility = 0
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(10)); background = rounded(0x30ffffff, 20) }
        val back = text("‹", 30, teal, true).apply { gravity = Gravity.CENTER; setOnClickListener { finish() } }
        header.addView(back, LinearLayout.LayoutParams(dp(42), dp(42)))
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), 0, 0, 0) }
        titles.addView(text("File Manager", 21, ink, true))
        titles.addView(text("Your secure Hira Bhai cloud files", 12, muted, false))
        header.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(header)
        val scroll = ScrollView(this).apply { clipToPadding = false }
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(22)) }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        usage = text("Storage used by your files: …", 13, muted, false)
        body.addView(usage)
        val storageNotice = text(
            "Cloud uploads use the Hira Bhai Firebase bucket and its security rules. Firebase Cloud Storage currently requires the project owner to enable Blaze billing; usage may incur charges. For a no-cloud option, browse files on this device or use Download to save through Android's picker (including Drive when installed).",
            12, muted, false
        ).apply {
            background = rounded(0x30ffffff, 16)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        body.addView(storageNotice, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE }
        body.addView(progress, LinearLayout.LayoutParams(-1, dp(7)).apply { topMargin = dp(8) })
        status = text("Choose where to browse, or upload a file.", 13, muted, false).apply { setPadding(0, dp(8), 0, dp(7)) }
        body.addView(status)
        val deviceActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        deviceActions.addView(actionButton("Browse device") { browseDevice() }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(6) })
        deviceActions.addView(actionButton("＋  Upload a file") { if (requireUser()) startPicker() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        body.addView(deviceActions)
        searchBox = EditText(this).apply {
            hint = "Search files by name or type"; isSingleLine = true; textSize = 14f
            setPadding(dp(12), dp(4), dp(12), dp(4))
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { searchText = s?.toString().orEmpty(); loadFiles() }
                override fun afterTextChanged(s: android.text.Editable?) {}
            })
        }
        body.addView(searchBox, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8) })
        sortBox = Spinner(this).apply {
            adapter = ArrayAdapter(this@FileManagerActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Newest", "Name A–Z", "Largest first", "Type"))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {}
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) { sortMode = listOf("Newest", "Name A–Z", "Largest first", "Type")[position]; loadFiles() }
            }
        }
        body.addView(sortBox, LinearLayout.LayoutParams(-1, dp(44)))
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(4), 0, dp(4)) }
        listOf("Mine", "Shared with me", "Public").forEach { name ->
            val button = actionButton(name) { tab = name; folderFilter = null; loadFiles() }
            tabs.addView(button, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(4) })
        }
        body.addView(tabs)
        val folderRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        folderRow.addView(actionButton("All folders") { folderFilter = null; loadFiles() }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(5) })
        folderRow.addView(actionButton("＋ Folder") { promptFolder() }, LinearLayout.LayoutParams(0, dp(42), 1f))
        body.addView(folderRow)
        items = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(6), 0, 0) }
        body.addView(items)
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val safe = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars() or androidx.core.view.WindowInsetsCompat.Type.displayCutout())
            view.setPadding(safe.left, safe.top, safe.right, safe.bottom)
            insets
        }
        setContentView(root)
    }

    private fun loadFiles() {
        if (!::items.isInitialized) return
        val user = FirebaseBackend.auth?.currentUser ?: return
        val db = FirebaseBackend.db ?: run { status.text = "Firestore is unavailable. Check Firebase setup."; return }
        items.removeAllViews()
        status.text = "Loading $tab files…"
        val query: Query = when (tab) {
            "Shared with me" -> db.collection("userFiles").whereArrayContains("sharedWith", user.uid)
            "Public" -> db.collection("userFiles").whereEqualTo("visibility", "public")
            else -> db.collection("userFiles").whereEqualTo("ownerUid", user.uid)
        }
        query.get().addOnSuccessListener { snapshot ->
            val needle = searchText.trim().lowercase(Locale.ROOT)
            val docs = snapshot.documents.filter { document ->
                (folderFilter == null || document.getString("folder").orEmpty() == folderFilter) &&
                    (needle.isBlank() || document.getString("name").orEmpty().lowercase(Locale.ROOT).contains(needle) || document.getString("mimeType").orEmpty().lowercase(Locale.ROOT).contains(needle))
            }.let { filtered -> when (sortMode) {
                "Name A–Z" -> filtered.sortedBy { it.getString("name").orEmpty().lowercase(Locale.ROOT) }
                "Largest first" -> filtered.sortedByDescending { it.getLong("sizeBytes") ?: 0L }
                "Type" -> filtered.sortedBy { it.getString("mimeType").orEmpty() }
                else -> filtered.sortedByDescending { it.getTimestamp("createdAt")?.toDate()?.time ?: 0L }
            } }
            if (tab == "Mine") {
                val total = snapshot.documents.filter { it.getString("ownerUid") == user.uid }.sumOf { it.getLong("sizeBytes") ?: 0L }
                usage.text = "Storage used by your files: ${formatSize(total)}"
                renderFolderFilters(snapshot.documents.map { it.getString("folder").orEmpty() }.filter { it.isNotBlank() }.distinct().sorted())
            } else usage.text = "${docs.size} file${if (docs.size == 1) "" else "s"}"
            if (docs.isEmpty()) items.addView(text(if (folderFilter != null) "No files in this folder." else when (tab) { "Mine" -> "No files uploaded yet. Upload a PDF, document, image, audio file, or other supported format."; "Shared with me" -> "No Hira Bhai users have shared files with you yet."; else -> "No public files are available yet." }, 14, muted, false).apply { setPadding(0, dp(18), 0, dp(10)) })
            if (localFiles.isNotEmpty() && tab == "Mine") {
                items.addView(text("Device files · selected with Android picker", 16, ink, true).apply { setPadding(0, dp(14), 0, dp(4)) })
                localFiles.filter { needle.isBlank() || it.name.lowercase(Locale.ROOT).contains(needle) || it.mime.lowercase(Locale.ROOT).contains(needle) }
                    .let { local -> when (sortMode) { "Name A–Z" -> local.sortedBy { it.name.lowercase(Locale.ROOT) }; "Largest first" -> local.sortedByDescending { it.size }; "Type" -> local.sortedBy { it.mime }; else -> local } }
                    .forEach { renderLocalFile(it) }
            }
            docs.forEach { document -> renderFile(document.id, document.data ?: emptyMap()) }
            status.text = "${docs.size} file${if (docs.size == 1) "" else "s"} · ${if (tab == "Mine") "owned by you" else tab.lowercase(Locale.ROOT)}"
        }.addOnFailureListener { error ->
            status.text = "Could not load files: ${error.localizedMessage ?: "check Firestore rules"}"
            items.addView(text(status.text.toString(), 14, 0xffa33a36.toInt(), false))
        }
    }

    private fun browseDevice() {
        try {
            launchPicker(812, Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE)
                .putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION))
        } catch (error: Exception) { status.text = "Android file picker could not open: ${error.localizedMessage}" }
    }

    private fun renderLocalFile(file: LocalFile) {
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rounded(Color.WHITE, 16); setPadding(dp(12), dp(10), dp(12), dp(8)) }
        card.addView(text(file.name, 15, ink, true))
        card.addView(text("${file.mime.substringAfterLast('/').uppercase(Locale.ROOT)} · ${formatSize(file.size)} · On this device", 12, muted, false))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(actionButton("Preview") { previewLocal(file) }, LinearLayout.LayoutParams(0, dp(38), 1f))
        row.addView(actionButton("Share") { shareLocal(file) }, LinearLayout.LayoutParams(0, dp(38), 1f))
        row.addView(actionButton("Upload") { if (requireUser()) upload(file.uri) }, LinearLayout.LayoutParams(0, dp(38), 1f))
        row.addView(actionButton("⋮") { localFileMenu(file) }, LinearLayout.LayoutParams(0, dp(38), .65f))
        card.addView(row); items.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
    }

    private fun previewLocal(file: LocalFile) {
        try { startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(file.uri, file.mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) }
        catch (_: Exception) { status.text = "No preview app is installed for ${file.mime.substringAfterLast('/')} ." }
    }

    private fun shareLocal(file: LocalFile) {
        try {
            val send = Intent(Intent.ACTION_SEND).setType(file.mime).putExtra(Intent.EXTRA_STREAM, file.uri)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION).apply { clipData = ClipData.newUri(contentResolver, file.name, file.uri) }
            startActivity(Intent.createChooser(send, "Share ${file.name}"))
        } catch (error: Exception) { status.text = "Could not share this file: ${error.localizedMessage}" }
    }

    private fun localFileMenu(file: LocalFile) {
        AlertDialog.Builder(this).setTitle(file.name).setItems(arrayOf("Rename", "Copy to folder", "Move to folder", "Delete")) { _, which ->
            when (which) {
                0 -> renameLocal(file)
                1 -> { pendingLocalFile = file; pendingLocalOperation = "copy"; chooseLocalDestination() }
                2 -> { pendingLocalFile = file; pendingLocalOperation = "move"; chooseLocalDestination() }
                3 -> AlertDialog.Builder(this).setMessage("Delete ${file.name} from this device?").setNegativeButton("Cancel", null).setPositiveButton("Delete") { _, _ ->
                    val deleted = runCatching { DocumentsContract.deleteDocument(contentResolver, file.uri) }.getOrDefault(false)
                    if (deleted) { localFiles.removeAll { it.uri == file.uri }; status.text = "Deleted ${file.name}."; loadFiles() } else status.text = "This Android provider does not allow deleting this file."
                }.show()
            }
        }.show()
    }

    private fun renameLocal(file: LocalFile) {
        val input = EditText(this).apply { setText(file.name); setSingleLine() }
        AlertDialog.Builder(this).setTitle("Rename file").setView(input).setNegativeButton("Cancel", null).setPositiveButton("Rename") { _, _ ->
            val newName = input.text.toString().trim().take(240)
            val renamed = if (newName.isBlank()) null else runCatching { DocumentsContract.renameDocument(contentResolver, file.uri, newName) }.getOrNull()
            if (renamed != null) { val updated = localFile(renamed); localFiles.replaceAll { if (it.uri == file.uri) updated else it }; status.text = "Renamed to ${updated.name}."; loadFiles() }
            else status.text = "This Android provider does not support renaming this file."
        }.show()
    }

    private fun chooseLocalDestination() {
        try { launchPicker(813, Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)) }
        catch (error: Exception) { status.text = "Choose-folder picker unavailable: ${error.localizedMessage}" }
    }

    private fun copyOrMoveLocal(file: LocalFile, tree: Uri, move: Boolean) {
        Thread {
            val result = runCatching {
                val parentId = DocumentsContract.getTreeDocumentId(tree)
                val parent = DocumentsContract.buildDocumentUriUsingTree(tree, parentId)
                val created = DocumentsContract.createDocument(contentResolver, parent, file.mime, file.name) ?: error("The selected provider could not create a file")
                contentResolver.openInputStream(file.uri)?.use { input -> contentResolver.openOutputStream(created, "w")?.use { output -> input.copyTo(output) } ?: error("Could not write destination") } ?: error("Could not read source")
                if (move && !DocumentsContract.deleteDocument(contentResolver, file.uri)) error("Copied successfully, but source deletion was denied")
                created
            }
            runOnUiThread {
                if (result.isSuccess) {
                    status.text = if (move) "Moved ${file.name}." else "Copied ${file.name}."
                    if (move) localFiles.removeAll { it.uri == file.uri } else localFiles.add(localFile(result.getOrThrow()))
                    loadFiles()
                } else status.text = "${if (move) "Move" else "Copy"} failed: ${result.exceptionOrNull()?.localizedMessage}"
                pendingLocalOperation = null
            }
        }.start()
    }

    private fun localFile(uri: Uri): LocalFile {
        var name = uri.lastPathSegment?.substringAfterLast('/') ?: "file"
        var size = 0L
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
            if (c.moveToFirst()) { c.getColumnIndex(OpenableColumns.DISPLAY_NAME).takeIf { it >= 0 }?.let { name = c.getString(it) ?: name }; c.getColumnIndex(OpenableColumns.SIZE).takeIf { it >= 0 }?.let { size = c.getLong(it) } }
        }
        return LocalFile(uri, name, contentResolver.getType(uri) ?: "application/octet-stream", size.coerceAtLeast(0L))
    }

    private fun renderFolderFilters(folders: List<String>) {
        if (folders.isEmpty()) return
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        folders.forEach { folder -> row.addView(actionButton(folder) { folderFilter = folder; loadFiles() }, LinearLayout.LayoutParams(-2, dp(38)).apply { marginEnd = dp(5) }) }
        items.addView(row)
    }

    private fun renderFile(id: String, data: Map<String, Any>) {
        val name = data["name"] as? String ?: "Unnamed file"
        val mime = data["mimeType"] as? String ?: "application/octet-stream"
        val size = (data["sizeBytes"] as? Number)?.toLong() ?: 0L
        val date = (data["createdAt"] as? Timestamp)?.toDate()?.let { DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(it) } ?: "Upload date unavailable"
        val owned = data["ownerUid"] == FirebaseBackend.auth?.currentUser?.uid
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rounded(Color.WHITE, 19); setPadding(dp(14), dp(12), dp(14), dp(10)); isClickable = true; isFocusable = true }
        card.addView(text(name, 16, ink, true).apply { setOnClickListener { openFile(data) } })
        card.addView(text("${mime.substringAfterLast('/').uppercase(Locale.ROOT)} · ${formatSize(size)} · $date", 12, muted, false).apply { setPadding(0, dp(4), 0, dp(2)) })
        val details = listOfNotNull((data["folder"] as? String)?.takeIf { it.isNotBlank() }?.let { "Folder: $it" }, "${if (data["visibility"] == "public") "Public to signed-in users" else "Private"}${if (!owned) " · shared with you" else ""}")
        card.addView(text(details.joinToString(" · "), 11, muted, false))
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        controls.addView(actionButton("Preview") { openFile(data) }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(3) })
        controls.addView(actionButton("Download") { downloadFile(data) }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(3) })
        if (owned) {
            controls.addView(actionButton("Share") { manageShare(id, name) }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(3) })
            controls.addView(actionButton("⋮") { fileMenu(id, data) }, LinearLayout.LayoutParams(0, dp(40), .7f))
        }
        card.addView(controls, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5) })
        items.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
    }

    private fun fileMenu(id: String, data: Map<String, Any>) {
        val names = listOf("Rename", "Copy to My files", "Change visibility", "Move to folder", "Manage sharing", "Delete file")
        AlertDialog.Builder(this).setTitle(data["name"] as? String ?: "File actions").setItems(names.toTypedArray()) { _, which ->
            when (which) {
                0 -> renameCloudFile(id, data["name"] as? String ?: "file")
                1 -> copyCloudFile(data)
                2 -> changeVisibility(id, data["visibility"] as? String ?: "private")
                3 -> promptMoveFolder(id, data["folder"] as? String ?: "")
                4 -> manageShare(id, data["name"] as? String ?: "file")
                5 -> confirmDelete(id, data)
            }
        }.show()
    }

    private fun renameCloudFile(id: String, oldName: String) {
        val field = EditText(this).apply { setText(oldName); setSingleLine() }
        AlertDialog.Builder(this).setTitle("Rename cloud file").setMessage("This changes the name shown in Hira Bhai; the protected cloud object stays in place.").setView(field)
            .setNegativeButton("Cancel", null).setPositiveButton("Save") { _, _ ->
                val newName = field.text.toString().trim().take(240)
                if (newName.isBlank()) { status.text = "File name cannot be empty."; return@setPositiveButton }
                FirebaseBackend.db?.collection("userFiles")?.document(id)
                    ?.update("name", newName, "updatedAt", FieldValue.serverTimestamp())
                    ?.addOnSuccessListener { status.text = "File renamed to $newName."; loadFiles() }
                    ?.addOnFailureListener { status.text = "Rename failed: ${it.localizedMessage}" }
            }.show()
    }

    private fun copyCloudFile(source: Map<String, Any>) {
        val user = FirebaseBackend.auth?.currentUser ?: return
        val db = FirebaseBackend.db ?: run { status.text = "Firestore is unavailable."; return }
        val storage = FirebaseBackend.storage ?: run { status.text = FirebaseBackend.storageSetupError ?: "Cloud Storage is unavailable."; return }
        val sourcePath = source["storagePath"] as? String ?: return
        val sourceName = source["name"] as? String ?: "file"
        val mime = source["mimeType"] as? String ?: "application/octet-stream"
        val fileId = UUID.randomUUID().toString()
        val name = "Copy of $sourceName".take(240)
        val path = "userFiles/${user.uid}/$fileId/${safeStorageName(name)}"
        val temporary = File(cacheDir, "file_manager_copy_$fileId")
        status.text = "Copying $sourceName…"; progress.visibility = View.VISIBLE; progress.isIndeterminate = true
        storage.reference.child(sourcePath).getFile(temporary).addOnSuccessListener {
            val now = Timestamp(Date())
            val metadata = hashMapOf<String, Any>(
                "ownerUid" to user.uid, "name" to name, "mimeType" to mime,
                "sizeBytes" to ((source["sizeBytes"] as? Number)?.toLong() ?: 0L).coerceAtLeast(0L),
                "storagePath" to path, "visibility" to "private", "sharedWith" to emptyList<String>(),
                "folder" to (source["folder"] as? String ?: ""), "createdAt" to now, "updatedAt" to now
            )
            val doc = db.collection("userFiles").document(fileId)
            doc.set(metadata).addOnSuccessListener {
                storage.reference.child(path).putFile(Uri.fromFile(temporary), com.google.firebase.storage.StorageMetadata.Builder().setContentType(mime).build())
                    .addOnProgressListener { task ->
                        val total = task.totalByteCount.coerceAtLeast(1L)
                        progress.isIndeterminate = false; progress.progress = (100L * task.bytesTransferred / total).toInt().coerceIn(0, 100)
                    }
                    .addOnSuccessListener { temporary.delete(); progress.visibility = View.GONE; status.text = "Created a private copy of $sourceName."; loadFiles() }
                    .addOnFailureListener { error ->
                        temporary.delete(); progress.visibility = View.GONE; doc.delete()
                        storage.reference.child(path).delete()
                        status.text = "Copy upload failed: ${error.localizedMessage ?: "check Storage rules and billing"}"
                    }
            }.addOnFailureListener { error -> temporary.delete(); progress.visibility = View.GONE; status.text = "Could not save copy details: ${error.localizedMessage}" }
        }.addOnFailureListener { error -> temporary.delete(); progress.visibility = View.GONE; status.text = "Could not read source file: ${error.localizedMessage}" }
    }

    private fun startPicker() {
        try {
            launchPicker(810, Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION))
        } catch (error: Exception) { status.text = "File picker could not open: ${error.localizedMessage ?: "unknown error"}" }
    }

    private fun launchPicker(requestCode: Int, intent: Intent) {
        activePickerRequest = requestCode
        pickerLauncher.launch(intent)
    }

    private fun handlePickerResult(requestCode: Int, result: ActivityResult) {
        val data = result.data
        if (result.resultCode != RESULT_OK || data == null) return
        if (requestCode == 812) {
            val selected = buildList {
                data.data?.let(::add)
                data.clipData?.let { clip -> for (index in 0 until clip.itemCount) add(clip.getItemAt(index).uri) }
            }.distinct()
            selected.forEach { uri ->
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                val file = runCatching { localFile(uri) }.getOrNull()
                if (file != null) { localFiles.removeAll { it.uri == uri }; localFiles.add(file) }
            }
            status.text = "Selected ${selected.size} device file${if (selected.size == 1) "" else "s"}. Android granted access only to the files you chose."
            loadFiles()
            return
        }
        if (requestCode == 813) {
            val target = data.data ?: return
            try { contentResolver.takePersistableUriPermission(target, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } catch (_: Exception) {}
            val selected = pendingLocalFile
            if (selected == null) { status.text = "Select a device file first."; return }
            copyOrMoveLocal(selected, target, pendingLocalOperation == "move")
            return
        }
        if (data.data == null) return
        if (requestCode == 810) {
            val uri = data.data!!
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            upload(uri)
        } else if (requestCode == 811) {
            val target = data.data!!
            val source = pendingSaveFile ?: return
            val name = pendingSaveName
            status.text = "Saving $name to your device…"
            Thread {
                val result = runCatching { contentResolver.openOutputStream(target)?.use { out -> source.inputStream().use { it.copyTo(out) } } ?: error("Could not open the selected save location") }
                runOnUiThread { status.text = if (result.isSuccess) "$name saved to your selected location." else "Download save failed: ${result.exceptionOrNull()?.localizedMessage}" }
                pendingSaveFile = null
            }.start()
        }
    }

    private fun upload(source: Uri) {
        val user = FirebaseBackend.auth?.currentUser ?: return
        val db = FirebaseBackend.db ?: run { status.text = "Firestore is not configured."; return }
        val storage = FirebaseBackend.storage ?: run { status.text = FirebaseBackend.storageSetupError ?: "Firebase Storage is not configured."; return }
        val fileId = UUID.randomUUID().toString()
        val name = displayName(source).take(240).ifBlank { "upload-$fileId" }
        val mime = contentResolver.getType(source)?.take(160) ?: "application/octet-stream"
        val temporary = File(cacheDir, "file_manager_upload_$fileId")
        status.text = "Preparing $name…"
        progress.visibility = View.VISIBLE; progress.isIndeterminate = true
        Thread {
            val copy = runCatching {
                contentResolver.openInputStream(source)?.use { input ->
                    temporary.outputStream().use { output ->
                        val buffer = ByteArray(64 * 1024); var total = 0L
                        while (true) {
                            val count = input.read(buffer); if (count < 0) break
                            total += count
                            if (total > MAX_BYTES) throw IllegalArgumentException("Files must be 100 MB or smaller.")
                            output.write(buffer, 0, count)
                        }
                        total
                    }
                } ?: throw IllegalStateException("Android could not read this file.")
            }
            runOnUiThread {
                if (copy.isFailure) { progress.visibility = View.GONE; status.text = "Upload preparation failed: ${copy.exceptionOrNull()?.localizedMessage}"; temporary.delete(); return@runOnUiThread }
                val bytes = copy.getOrThrow()
                val path = "userFiles/${user.uid}/$fileId/${safeStorageName(name)}"
                val doc = db.collection("userFiles").document(fileId)
                val now = Timestamp(Date())
                val metadata = hashMapOf<String, Any>(
                    "ownerUid" to user.uid, "name" to name, "mimeType" to mime,
                    "sizeBytes" to bytes, "storagePath" to path, "visibility" to "private",
                    "sharedWith" to emptyList<String>(), "folder" to uploadFolder,
                    "createdAt" to now, "updatedAt" to now
                )
                status.text = "Preparing secure upload…"
                doc.set(metadata).addOnSuccessListener {
                    val ref = storage.reference.child(path)
                    val storageMetadata = com.google.firebase.storage.StorageMetadata.Builder().setContentType(mime).build()
                    ref.putFile(Uri.fromFile(temporary), storageMetadata)
                        .addOnProgressListener { task ->
                            val total = task.totalByteCount.coerceAtLeast(1L)
                            val percent = ((100L * task.bytesTransferred) / total).toInt().coerceIn(0, 100)
                            progress.isIndeterminate = false; progress.progress = percent
                            status.text = "Uploading $name · $percent%"
                        }
                        .addOnSuccessListener {
                            temporary.delete(); progress.visibility = View.GONE
                            status.text = "Uploaded $name to your private cloud files."
                            loadFiles()
                        }
                        .addOnFailureListener { error ->
                            temporary.delete(); progress.visibility = View.GONE
                            doc.delete(); status.text = "Upload failed: ${error.localizedMessage ?: "check Storage rules and billing"}"
                        }
                }.addOnFailureListener { error ->
                    temporary.delete(); progress.visibility = View.GONE
                    status.text = "Could not save file details: ${error.localizedMessage ?: "check Firestore rules"}"
                }
            }
        }.start()
    }

    private fun openFile(data: Map<String, Any>) {
        val name = data["name"] as? String ?: "file"
        val path = data["storagePath"] as? String ?: run { status.text = "File path is missing."; return }
        val mime = data["mimeType"] as? String ?: "application/octet-stream"
        fetchToCache(path, name) { file ->
            if (mime.startsWith("image/")) {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(file.absolutePath, bounds)
                val sample = BitmapFactory.Options().apply {
                    var size = 1
                    while (bounds.outWidth / size > 1800 || bounds.outHeight / size > 1800) size *= 2
                    inSampleSize = size
                }
                val bitmap = BitmapFactory.decodeFile(file.absolutePath, sample)
                if (bitmap == null) { status.text = "Image preview is not available for this file."; return@fetchToCache }
                val image = ImageView(this).apply { setImageBitmap(bitmap); adjustViewBounds = true; maxHeight = resources.displayMetrics.heightPixels * 2 / 3; scaleType = ImageView.ScaleType.FIT_CENTER }
                AlertDialog.Builder(this).setTitle(name).setView(ScrollView(this).apply { addView(image) }).setPositiveButton("Done", null).show()
            } else if (mime == "text/plain" || name.endsWith(".txt", true)) {
                val content = runCatching { file.readText(Charsets.UTF_8).take(120_000) }.getOrElse { "Text preview could not be opened." }
                val preview = TextView(this).apply { text = content; textSize = 14f; setTextColor(ink); setPadding(dp(16), dp(12), dp(16), dp(12)) }
                AlertDialog.Builder(this).setTitle(name).setView(ScrollView(this).apply { addView(preview) }).setPositiveButton("Done", null).show()
            } else {
                try {
                    val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
                    startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                } catch (_: Exception) { status.text = "No preview app is installed for ${mime.substringAfterLast('/').uppercase(Locale.ROOT)}. Use Download to save it." }
            }
        }
    }

    private fun downloadFile(data: Map<String, Any>) {
        val name = data["name"] as? String ?: "download"
        val path = data["storagePath"] as? String ?: run { status.text = "File path is missing."; return }
        fetchToCache(path, name) { file ->
            pendingSaveFile = file; pendingSaveName = name
            try { launchPicker(811, Intent(Intent.ACTION_CREATE_DOCUMENT).setType(data["mimeType"] as? String ?: "application/octet-stream").addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_TITLE, name)) }
            catch (error: Exception) { status.text = "Save location picker unavailable: ${error.localizedMessage}" }
        }
    }

    private fun fetchToCache(path: String, name: String, done: (File) -> Unit) {
        val storage = FirebaseBackend.storage ?: run { status.text = FirebaseBackend.storageSetupError ?: "Cloud Storage is unavailable."; return }
        val target = File(File(cacheDir, "file_manager").apply { mkdirs() }, "${UUID.randomUUID()}-${safeStorageName(name)}")
        status.text = "Downloading securely…"; progress.visibility = View.VISIBLE; progress.isIndeterminate = true
        storage.reference.child(path).getFile(target)
            .addOnProgressListener { task ->
                if (task.totalByteCount > 0) { progress.isIndeterminate = false; progress.progress = (100L * task.bytesTransferred / task.totalByteCount).toInt().coerceIn(0, 100) }
            }
            .addOnSuccessListener { progress.visibility = View.GONE; status.text = "Ready: $name"; done(target) }
            .addOnFailureListener { error -> progress.visibility = View.GONE; target.delete(); status.text = "Secure download failed: ${error.localizedMessage ?: "permission or network error"}" }
    }

    private fun changeVisibility(id: String, existing: String) {
        val options = arrayOf("Private · owner and approved users", "Public · signed-in Hira Bhai users")
        AlertDialog.Builder(this).setTitle("File visibility").setSingleChoiceItems(options, if (existing == "public") 1 else 0) { dialog, which ->
            val visibility = if (which == 1) "public" else "private"
            FirebaseBackend.db?.collection("userFiles")?.document(id)?.update("visibility", visibility, "updatedAt", FieldValue.serverTimestamp())
                ?.addOnSuccessListener { dialog.dismiss(); status.text = "Visibility set to $visibility."; loadFiles() }
                ?.addOnFailureListener { status.text = "Visibility update failed: ${it.localizedMessage}" }
        }.setNegativeButton("Cancel", null).show()
    }

    private fun manageShare(fileId: String, fileName: String) {
        val handle = EditText(this).apply { hint = "Hira Bhai username"; setSingleLine(); setPadding(dp(14), dp(10), dp(14), dp(10)) }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(6), dp(18), 0)
            addView(text("Grant or remove private access by username. The link itself never contains a Storage URL.", 13, muted, false))
            addView(handle, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(8) })
            addView(actionButton("Remove this user's access") { updateRecipient(fileId, handle.text.toString(), false) }, LinearLayout.LayoutParams(-1, dp(42)).apply { topMargin = dp(4) })
        }
        AlertDialog.Builder(this).setTitle("Share $fileName").setView(box)
            .setPositiveButton("Grant access", null).setNeutralButton("Send share link…", null).setNegativeButton("Done", null).create().also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        updateRecipient(fileId, handle.text.toString(), true) { recipientName ->
                            dialog.dismiss(); shareLink(fileId, fileName, recipientName)
                        }
                    }
                    dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener { shareLink(fileId, fileName, null) }
                }
            }.show()
    }

    private fun updateRecipient(fileId: String, rawHandle: String, grant: Boolean, done: (String) -> Unit = {}) {
        val handle = rawHandle.trim().removePrefix("@").lowercase(Locale.ROOT)
        if (!Regex("^[a-z0-9_]{3,24}$").matches(handle)) { status.text = "Enter a valid Hira Bhai username."; return }
        val user = FirebaseBackend.auth?.currentUser ?: return
        val db = FirebaseBackend.db ?: return
        db.collection("userDirectory").document(handle).get().addOnSuccessListener { directory ->
            val recipientUid = directory.getString("uid")
            if (!directory.exists() || recipientUid.isNullOrBlank()) { status.text = "No Hira Bhai account found for @$handle."; return@addOnSuccessListener }
            if (recipientUid == user.uid) { status.text = "You already own this file."; return@addOnSuccessListener }
            val value: Any = if (grant) FieldValue.arrayUnion(recipientUid) else FieldValue.arrayRemove(recipientUid)
            db.collection("userFiles").document(fileId).update("sharedWith", value, "updatedAt", FieldValue.serverTimestamp())
                .addOnSuccessListener { status.text = if (grant) "Private access granted to @$handle." else "Private access removed from @$handle."; done(handle) }
                .addOnFailureListener { status.text = "Could not change sharing access: ${it.localizedMessage}" }
        }.addOnFailureListener { status.text = "Could not look up @$handle: ${it.localizedMessage}" }
    }

    private fun shareLink(fileId: String, fileName: String, recipient: String?) {
        val link = "hirabhai:/f/$fileId"
        val text = buildString {
            append("Hira Bhai file: ").append(fileName).append("\n").append(link)
            if (recipient != null) append("\nAccess granted to @").append(recipient).append(". Sign in to Hira Bhai to open it.")
            else append("\nPrivate files require the owner to grant your Hira Bhai account access. Public files require sign-in.")
        }
        try { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), "Share Hira Bhai file")) }
        catch (_: Exception) { status.text = "Share link: $link" }
    }

    private fun openSharedFile(fileId: String) {
        if (fileId.isBlank()) return
        val db = FirebaseBackend.db ?: return
        db.collection("userFiles").document(fileId).get().addOnSuccessListener { doc ->
            if (doc.exists()) openFile(doc.data ?: emptyMap())
            else status.text = "This file is private, unavailable, or you are not signed in with an authorized Hira Bhai account."
        }.addOnFailureListener { status.text = "This file is private or could not be opened: ${it.localizedMessage}" }
    }

    private fun confirmDelete(id: String, data: Map<String, Any>) {
        val name = data["name"] as? String ?: "this file"
        AlertDialog.Builder(this).setTitle("Delete file?").setMessage("This permanently removes $name from cloud storage and from your file list.")
            .setNegativeButton("Cancel", null).setPositiveButton("Delete") { _, _ ->
                val path = data["storagePath"] as? String ?: return@setPositiveButton
                val ref = FirebaseBackend.storage?.reference?.child(path) ?: run { status.text = "Cloud Storage is unavailable."; return@setPositiveButton }
                status.text = "Deleting $name…"
                ref.delete().addOnSuccessListener { removeFileMetadata(id, name) }.addOnFailureListener { error ->
                    if (error is StorageException && error.errorCode == StorageException.ERROR_OBJECT_NOT_FOUND) removeFileMetadata(id, name)
                    else status.text = "File deletion failed: ${error.localizedMessage}"
                }
            }.show()
    }

    private fun removeFileMetadata(id: String, name: String) {
        FirebaseBackend.db?.collection("userFiles")?.document(id)?.delete()
            ?.addOnSuccessListener { status.text = "$name deleted."; loadFiles() }
            ?.addOnFailureListener { status.text = "Storage object removed, but metadata cleanup failed: ${it.localizedMessage}" }
    }

    private fun promptFolder() {
        val field = EditText(this).apply { hint = "Folder name"; setSingleLine() }
        AlertDialog.Builder(this).setTitle("Create or select folder").setView(field).setNegativeButton("Cancel", null).setPositiveButton("Use folder") { _, _ ->
            val folder = field.text.toString().trim().take(80)
            if (folder.isBlank()) { uploadFolder = ""; status.text = "Uploads will go to All files." }
            else { uploadFolder = folder; folderFilter = folder; status.text = "New uploads will go to $folder."; loadFiles() }
        }.show()
    }

    private fun promptMoveFolder(id: String, existing: String) {
        val field = EditText(this).apply { hint = "Folder name · leave blank for All files"; setSingleLine(); setText(existing) }
        AlertDialog.Builder(this).setTitle("Move file to folder").setView(field).setNegativeButton("Cancel", null).setPositiveButton("Save") { _, _ ->
            val folder = field.text.toString().trim().take(80)
            FirebaseBackend.db?.collection("userFiles")?.document(id)?.update("folder", folder, "updatedAt", FieldValue.serverTimestamp())
                ?.addOnSuccessListener { status.text = "File moved."; loadFiles() }
                ?.addOnFailureListener { status.text = "Folder update failed: ${it.localizedMessage}" }
        }.show()
    }

    private fun displayName(uri: Uri): String {
        var result: String? = null
        if (uri.scheme == "content") contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) result = cursor.getString(cursor.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME))
        }
        return result ?: uri.lastPathSegment?.substringAfterLast('/')?.substringAfterLast(':') ?: "upload"
    }

    private fun safeStorageName(value: String): String = value.replace(Regex("[^A-Za-z0-9._-]"), "_").take(180).ifBlank { "file" }
    private fun requireUser(): Boolean { if (FirebaseBackend.auth?.currentUser != null) return true; status.text = "Sign in before uploading."; startActivity(Intent(this, MainActivity::class.java)); return false }
    private fun formatSize(bytes: Long): String = when { bytes < 1024 -> "$bytes B"; bytes < 1024 * 1024 -> String.format(Locale.ROOT, "%.1f KB", bytes / 1024.0); bytes < 1024L * 1024L * 1024L -> String.format(Locale.ROOT, "%.1f MB", bytes / (1024.0 * 1024.0)); else -> String.format(Locale.ROOT, "%.2f GB", bytes / (1024.0 * 1024.0 * 1024.0)) }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun text(value: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply { text = value; textSize = size.toFloat(); setTextColor(color); if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL) }
    private fun rounded(color: Int, radius: Int) = android.graphics.drawable.GradientDrawable().apply { setColor(if (color == Color.WHITE) 0x30ffffff else color); cornerRadius = dp(radius).toFloat(); setStroke(dp(1), 0x70ffffff) }
    private fun actionButton(value: String, action: () -> Unit) = TextView(this).apply { text = value; textSize = 13f; gravity = Gravity.CENTER; setTextColor(teal); typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL); background = rounded(0x7723a48f, 13); setPadding(dp(8), dp(5), dp(8), dp(5)); isClickable = true; isFocusable = true; setOnClickListener { action() } }

    companion object { private const val MAX_BYTES = 100L * 1024L * 1024L }
}
