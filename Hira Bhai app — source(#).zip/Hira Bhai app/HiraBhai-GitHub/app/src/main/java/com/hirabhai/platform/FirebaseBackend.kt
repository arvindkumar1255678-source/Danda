package com.hirabhai.platform

import android.app.Application
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage

object FirebaseBackend {
    var auth: FirebaseAuth? = null
    var db: FirebaseFirestore? = null
    var storage: FirebaseStorage? = null
    var storageSetupError: String? = null
    var isConfigured = false

    fun initialize(app: Application) {
        val existing = FirebaseApp.getApps(app).firstOrNull { it.name == FirebaseApp.DEFAULT_APP_NAME }
        // The Google Services plugin generates these resources from
        // app/google-services.json. Keep the manual values as a fallback for
        // editable builds that do not yet contain that file.
        fun configuredString(generatedName: String, fallbackId: Int): String {
            val generatedId = app.resources.getIdentifier(generatedName, "string", app.packageName)
            return (if (generatedId != 0) app.getString(generatedId) else app.getString(fallbackId)).trim()
        }
        val apiKey = configuredString("google_api_key", R.string.firebase_api_key)
        val appId = configuredString("google_app_id", R.string.firebase_application_id)
        val projectId = configuredString("project_id", R.string.firebase_project_id)
        val storageBucket = configuredString("google_storage_bucket", R.string.firebase_storage_bucket)
        val hasManualConfig = apiKey.isNotBlank() && appId.isNotBlank() && projectId.isNotBlank() &&
                !apiKey.startsWith("YOUR_") && !appId.startsWith("YOUR_") && !projectId.startsWith("YOUR_")
        isConfigured = existing != null || hasManualConfig
        if (!isConfigured) return
        try {
            val firebase = existing ?: FirebaseApp.initializeApp(
                app,
                FirebaseOptions.Builder().setApiKey(apiKey).setApplicationId(appId).setProjectId(projectId).setStorageBucket(storageBucket.takeIf { it.isNotBlank() }).build()
            ) ?: FirebaseApp.getInstance()
            auth = FirebaseAuth.getInstance(firebase)
            db = FirebaseFirestore.getInstance(firebase)
            storage = try {
                FirebaseStorage.getInstance(firebase).also { storageSetupError = null }
            } catch (error: Exception) {
                storageSetupError = error.localizedMessage ?: "Firebase Storage bucket is unavailable"
                null
            }
        } catch (_: Exception) {
            isConfigured = false
            auth = null; db = null; storage = null; storageSetupError = "Firebase initialization failed"
        }
    }
}
