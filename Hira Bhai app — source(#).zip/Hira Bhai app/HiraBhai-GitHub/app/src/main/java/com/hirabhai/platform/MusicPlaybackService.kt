package com.hirabhai.platform

import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/** Playback session owned by Android, so active audio can continue off-screen. */
class MusicPlaybackService : MediaSessionService() {
    private var player: ExoPlayer? = null
    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        val mediaSourceFactory = DefaultMediaSourceFactory(this)
            .setDataSourceFactory(FirebaseStorageAudioDataSource.Factory())
        player = ExoPlayer.Builder(this).setMediaSourceFactory(mediaSourceFactory).build()
        session = MediaSession.Builder(this, player!!).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onDestroy() {
        session?.run { player.release(); release() }
        session = null
        player = null
        super.onDestroy()
    }
}
