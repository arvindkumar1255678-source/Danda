package com.hirabhai.platform

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.PopupMenu
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** A Hira Bhai branded search page and in-app browser; web pages never open another app. */
class InAppBrowserActivity : Activity() {
    private lateinit var rootView: LinearLayout
    private lateinit var webView: WebView
    private lateinit var address: EditText
    private lateinit var searchPanel: ScrollView
    private lateinit var searchContent: LinearLayout
    private lateinit var searchStatus: TextView
    private lateinit var searchProgress: ProgressBar
    private lateinit var pageError: TextView
    private lateinit var bookmarkAction: TextView
    private var desktopMode = false
    private var lastQuery = ""
    private var lastType = "web"
    private var fullscreenView: View? = null
    private var fullscreenContainer: ViewGroup? = null
    private var fullscreenCallback: WebChromeClient.CustomViewCallback? = null
    private var previousOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.rgb(0, 57, 52), Color.rgb(0, 45, 41))
            )
        }
        rootView = root
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val safe = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            if (fullscreenView != null) view.setPadding(0, 0, 0, 0)
            else view.setPadding(safe.left, safe.top, safe.right, safe.bottom)
            insets
        }

        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = glass(0xa633617e.toInt(), 20)
            setPadding(dp(12), dp(8), dp(12), dp(10))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply {
                leftMargin = dp(10); rightMargin = dp(10); topMargin = dp(8); bottomMargin = dp(5)
            }
        }
        val brandRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.hira_bhai_logo); contentDescription = "Hira Bhai logo"
        }
        brandRow.addView(logo, LinearLayout.LayoutParams(dp(25), dp(25)))
        brandRow.addView(TextView(this).apply {
            text = "Hira Bhai Browser"; textSize = 15f; setTextColor(Color.WHITE)
            setPadding(dp(7), 0, 0, 0); typeface = android.graphics.Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, -2, 1f))
        fun toolbarAction(symbol: String, description: String, action: () -> Unit) = TextView(this).apply {
            text = symbol; textSize = 18f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            contentDescription = description; isClickable = true; isFocusable = true
            setOnClickListener { action() }
        }
        bookmarkAction = toolbarAction("☆", "Bookmark current page") { toggleCurrentBookmark() }
        brandRow.addView(bookmarkAction, LinearLayout.LayoutParams(dp(30), dp(32)))
        brandRow.addView(toolbarAction("+", "Add current page to Home") { saveCurrentPageToHome() }, LinearLayout.LayoutParams(dp(30), dp(32)))
        brandRow.addView(toolbarAction("↓", "Downloads") { showDownloads() }, LinearLayout.LayoutParams(dp(30), dp(32)))
        brandRow.addView(toolbarAction("◷", "History") { showBrowserHistory() }, LinearLayout.LayoutParams(dp(30), dp(32)))
        val menu = TextView(this).apply {
            text = "⋮"; textSize = 24f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            contentDescription = "Browser actions"; setOnClickListener { showBrowserMenu(this) }
        }
        brandRow.addView(menu, LinearLayout.LayoutParams(dp(38), dp(32)))
        toolbar.addView(brandRow, LinearLayout.LayoutParams(-1, dp(29)))

        val addressRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(-1, dp(43)).apply { topMargin = dp(5) }
        }
        val back = TextView(this).apply {
            text = "‹"; textSize = 30f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            contentDescription = "Back"; setOnClickListener { goBackOrClose() }
        }
        addressRow.addView(back, LinearLayout.LayoutParams(dp(32), -1))
        addressRow.addView(toolbarAction("›", "Forward") { if (webView.canGoForward()) webView.goForward() }, LinearLayout.LayoutParams(dp(25), -1))
        addressRow.addView(toolbarAction("↻", "Reload") { if (webView.url != null) webView.reload() else submitAddress(address.text.toString()) }, LinearLayout.LayoutParams(dp(28), -1))
        addressRow.addView(toolbarAction("⌂", "Browser home") { showBrowserHome() }, LinearLayout.LayoutParams(dp(27), -1))
        address = EditText(this).apply {
            hint = "Search Hira Bhai or enter a website"; textSize = 14f
            setTextColor(Color.WHITE); setHintTextColor(0xffd7eaf3.toInt())
            setSingleLine(true); imeOptions = EditorInfo.IME_ACTION_GO
            setPadding(dp(11), 0, dp(10), 0)
            background = glass(0x38ffffff, 24)
            setOnEditorActionListener { _, action, _ ->
                if (action == EditorInfo.IME_ACTION_GO || action == EditorInfo.IME_ACTION_SEARCH) {
                    submitAddress(text.toString()); true
                } else false
            }
        }
        addressRow.addView(address, LinearLayout.LayoutParams(0, -1, 1f).apply { leftMargin = dp(3) })
        val go = TextView(this).apply {
            text = "Go"; textSize = 14f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            setPadding(dp(10), 0, dp(2), 0); contentDescription = "Search or open website"
            setOnClickListener { submitAddress(address.text.toString()) }
        }
        addressRow.addView(go, LinearLayout.LayoutParams(-2, -1))
        toolbar.addView(addressRow)
        root.addView(toolbar)

        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; progress = 0 }
        root.addView(progress, LinearLayout.LayoutParams(-1, dp(2)))
        val body = FrameLayout(this)
        root.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        pageError = TextView(this).apply {
            textSize = 14f; setTextColor(Color.WHITE); background = glass(0xb833617e.toInt(), 14)
            setPadding(dp(14), dp(12), dp(14), dp(12)); visibility = View.GONE
            isClickable = true; setOnClickListener { webView.reload() }
        }

        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.allowFileAccessFromFileURLs = false
            settings.allowUniversalAccessFromFileURLs = false
            settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
            settings.javaScriptCanOpenWindowsAutomatically = true
            settings.setSupportMultipleWindows(true)
            if (android.os.Build.VERSION.SDK_INT >= 26) settings.safeBrowsingEnabled = true
            setBackgroundColor(Color.WHITE)
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = !isWebUrl(request.url)
                @Suppress("DEPRECATION")
                override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean = !isWebUrl(Uri.parse(url))
                override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                    address.setText(url); pageError.visibility = View.GONE
                    bookmarkAction.text = if (InterestHistory.isBookmarked(this@InAppBrowserActivity, url)) "★" else "☆"
                }
                override fun onReceivedError(view: WebView, request: WebResourceRequest, error: android.webkit.WebResourceError) {
                    if (request.isForMainFrame) {
                        pageError.text = "This page could not be loaded (${error.description}). Tap to retry."
                        pageError.visibility = View.VISIBLE
                    }
                }
                override fun onReceivedSslError(view: WebView, handler: android.webkit.SslErrorHandler, error: android.net.http.SslError) {
                    handler.cancel()
                    pageError.text = "Secure connection failed. Hira Bhai blocked this page because its certificate could not be verified."
                    pageError.visibility = View.VISIBLE
                }
            }
            setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
                HiraDownloads.enqueue(this@InAppBrowserActivity, url, userAgent, contentDisposition, mimeType, this.url)
            }
            HiraDownloads.enableLongPressDownloads(this@InAppBrowserActivity, this)
            webChromeClient = object : WebChromeClient() {
                override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                    if (fullscreenView != null) { callback.onCustomViewHidden(); return }
                    fullscreenView = view
                    fullscreenCallback = callback
                    previousOrientation = requestedOrientation
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    searchPanel.visibility = View.GONE
                    webView.visibility = View.GONE
                    val full = FrameLayout(this@InAppBrowserActivity).apply {
                        setBackgroundColor(Color.BLACK)
                        addView(view, FrameLayout.LayoutParams(-1, -1))
                    }
                    (window.decorView as ViewGroup).addView(full, ViewGroup.LayoutParams(-1, -1))
                    fullscreenContainer = full
                    WindowInsetsControllerCompat(window, window.decorView).hide(
                        WindowInsetsCompat.Type.statusBars() or WindowInsetsCompat.Type.navigationBars()
                    )
                    rootView.requestApplyInsets()
                }

                override fun onHideCustomView() { exitWebFullscreen() }

                override fun onProgressChanged(view: WebView, newProgress: Int) {
                    progress.progress = newProgress
                    progress.visibility = if (newProgress >= 100) View.GONE else View.VISIBLE
                }
                override fun onReceivedTitle(view: WebView, title: String?) {
                    this@InAppBrowserActivity.title = title?.take(80) ?: "Hira Bhai Browser"
                    InterestHistory.recordPage(this@InAppBrowserActivity, title.orEmpty(), view.url.orEmpty())
                }
                override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message): Boolean {
                    val popup = WebView(this@InAppBrowserActivity).apply {
                        settings.javaScriptEnabled = true
                        webViewClient = object : WebViewClient() {
                            private fun forward(url: String): Boolean {
                                if (isWebUrl(Uri.parse(url))) webView.loadUrl(url)
                                return true
                            }
                            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest) = forward(request.url.toString())
                            @Suppress("DEPRECATION")
                            override fun shouldOverrideUrlLoading(view: WebView, url: String) = forward(url)
                        }
                    }
                    val transport = resultMsg.obj as? WebView.WebViewTransport ?: run { popup.destroy(); return false }
                    transport.webView = popup; resultMsg.sendToTarget(); return true
                }
            }
        }
        body.addView(webView, FrameLayout.LayoutParams(-1, -1))
        body.addView(pageError, FrameLayout.LayoutParams(-1, -2, Gravity.TOP).apply { setMargins(dp(12), dp(10), dp(12), 0) })

        searchPanel = ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(Color.TRANSPARENT)
        }
        searchContent = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(20))
        }
        searchStatus = TextView(this).apply { textSize = 14f; setTextColor(0xffe5f3fa.toInt()) }
        searchProgress = ProgressBar(this).apply { isIndeterminate = true; visibility = View.GONE }
        searchContent.addView(TextView(this).apply {
            text = "Search the web, from Hira Bhai"; textSize = 21f
            setTextColor(Color.WHITE); typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        searchContent.addView(TextView(this).apply {
            text = "Results open here inside Hira Bhai. Enter a website address above to visit it."
            textSize = 13f; setTextColor(0xffe5f3fa.toInt()); setPadding(0, dp(5), 0, dp(12))
        })
        searchContent.addView(searchStatus)
        searchContent.addView(searchProgress, LinearLayout.LayoutParams(dp(25), dp(25)).apply { topMargin = dp(8) })
        searchPanel.addView(searchContent)
        body.addView(searchPanel, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        val query = intent.getStringExtra(EXTRA_QUERY).orEmpty()
        val initialUrl = intent.getStringExtra(EXTRA_URL).orEmpty()
        if (query.isNotBlank()) {
            address.setText(query)
            search(query, intent.getStringExtra(EXTRA_TYPE) ?: "web")
        } else if (initialUrl.isNotBlank()) {
            searchPanel.visibility = View.GONE
            loadWebsite(initialUrl)
        } else {
            searchStatus.text = "Enter a topic or website address above to get started."
        }
    }

    private fun submitAddress(value: String) {
        val text = value.trim()
        if (text.isEmpty()) return
        val uri = Uri.parse(if (text.startsWith("http://", true) || text.startsWith("https://", true)) text else "https://$text")
        if (isWebUrl(uri) && (text.contains('.') || text.startsWith("http", true))) {
            searchPanel.visibility = View.GONE
            loadWebsite(uri.toString())
        } else {
            search(text, "web")
        }
    }

    private fun search(query: String, type: String) {
        lastQuery = query.trim()
        lastType = type.takeIf { it in setOf("web", "apps", "images") } ?: "web"
        webView.visibility = View.GONE
        searchPanel.visibility = View.VISIBLE
        searchProgress.visibility = View.VISIBLE
        searchStatus.text = "Searching with Hira Bhai…"
        searchContent.removeViews(4, (searchContent.childCount - 4).coerceAtLeast(0))

        val user = FirebaseAuth.getInstance().currentUser
        if (user == null) {
            showSearchError("Sign in to Hira Bhai to search the web. You can still enter a website address above.")
            return
        }
        val projectId = try { FirebaseApp.getInstance().options.projectId } catch (_: Exception) { null }
        if (projectId.isNullOrBlank()) {
            showSearchError("Internet search is not connected yet. Enter a website address above to browse within Hira Bhai.")
            return
        }
        user.getIdToken(false).addOnSuccessListener { result ->
            val token = result.token
            if (token.isNullOrBlank()) { showSearchError("Could not verify your Hira Bhai sign-in. Please try again."); return@addOnSuccessListener }
            Thread {
                try {
                    val payload = requestResults(projectId, token, lastQuery, lastType)
                    runOnUiThread { showResults(payload, lastType) }
                } catch (error: Exception) {
                    runOnUiThread { showSearchError(error.message ?: "Search is temporarily unavailable.") }
                }
            }.start()
        }.addOnFailureListener {
            showSearchError("Could not verify your Hira Bhai sign-in. Please try again.")
        }
    }

    private fun requestResults(projectId: String, token: String, query: String, type: String): JSONObject {
        val connection = (URL("https://us-central1-$projectId.cloudfunctions.net/universalSearch").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 12000; readTimeout = 18000; doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Authorization", "Bearer $token")
        }
        return try {
            connection.outputStream.use { it.write(JSONObject().put("query", query).put("type", type).toString().toByteArray()) }
            val code = connection.responseCode
            val bodyText = (if (code in 200..299) connection.inputStream else connection.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
            val payload = try { JSONObject(bodyText) } catch (_: Exception) {
                throw IllegalStateException("Hira Bhai Search returned an invalid response. Please try again later.")
            }
            if (code !in 200..299) {
                val message = payload.optString("error", "Search is temporarily unavailable.")
                if (code == 503 || message.contains("BRAVE_SEARCH_API_KEY")) throw IllegalStateException("Hira Bhai Search is unavailable right now. You can still enter a website address above.")
                throw IllegalStateException(message)
            }
            payload
        } finally { connection.disconnect() }
    }

    private fun showResults(payload: JSONObject, type: String) {
        searchProgress.visibility = View.GONE
        val items = payload.optJSONArray("items")
        if (items == null || items.length() == 0) {
            searchStatus.text = "No results found. Try another search."
            return
        }
        searchStatus.text = "${items.length()} results · Hira Bhai Search"
        for (index in 0 until items.length()) {
            val item = items.optJSONObject(index) ?: continue
            val url = item.optString("url")
            if (!isWebUrl(Uri.parse(url))) continue
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = glass(0x3affffff, 16)
                setPadding(dp(12), dp(11), dp(12), dp(11))
                isClickable = true; isFocusable = true
                setOnClickListener { searchPanel.visibility = View.GONE; loadWebsite(url) }
            }
            card.addView(TextView(this).apply {
                text = item.optString("title", "Search result"); textSize = 16f
                setTextColor(Color.WHITE); typeface = android.graphics.Typeface.DEFAULT_BOLD
                maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END
            })
            if (type == "images") {
                val imageUrl = item.optString("thumbnailUrl")
                if (imageUrl.startsWith("https://")) {
                    val image = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; contentDescription = "Search image" }
                    card.addView(image, LinearLayout.LayoutParams(-1, dp(150)).apply { topMargin = dp(7) })
                    Thread {
                        try {
                            val bitmap = URL(imageUrl).openConnection().apply { connectTimeout = 6000; readTimeout = 6000 }.getInputStream().use { BitmapFactory.decodeStream(it) }
                            if (bitmap != null) runOnUiThread { if (image.isAttachedToWindow) image.setImageBitmap(bitmap) }
                        } catch (_: Exception) { }
                    }.start()
                }
            }
            val description = item.optString("description")
            if (description.isNotBlank()) card.addView(TextView(this).apply {
                text = description; textSize = 13f; setTextColor(0xffe5f3fa.toInt())
                setPadding(0, dp(5), 0, dp(5)); maxLines = 3; ellipsize = android.text.TextUtils.TruncateAt.END
            })
            card.addView(TextView(this).apply {
                text = Uri.parse(url).host.orEmpty(); textSize = 11f; setTextColor(0xffa9d8ef.toInt())
            })
            searchContent.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(9) })
        }
    }

    private fun showSearchError(message: String) {
        searchProgress.visibility = View.GONE
        searchStatus.text = message
        val retry = TextView(this).apply {
            text = "Try search again"; textSize = 14f; gravity = Gravity.CENTER
            setTextColor(Color.WHITE); background = glass(0x5539bda5, 15)
            setPadding(dp(12), dp(11), dp(12), dp(11)); isClickable = true; isFocusable = true
            setOnClickListener { search(lastQuery, lastType) }
        }
        searchContent.addView(retry, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(9) })
    }

    private fun loadWebsite(url: String) {
        val uri = Uri.parse(url)
        if (!isWebUrl(uri) || uri.host.isNullOrBlank()) {
            searchStatus.text = "Enter a valid website address using http or https."
            searchPanel.visibility = View.VISIBLE
            return
        }
        address.setText(uri.toString())
        pageError.visibility = View.GONE
        searchPanel.visibility = View.GONE
        webView.visibility = View.VISIBLE
        webView.loadUrl(uri.toString())
    }

    private fun showBrowserMenu(anchor: View) {
        PopupMenu(this, anchor).apply {
            menu.add("Add page to Home feed")
            menu.add("Bookmarks")
            menu.add("Copy current URL")
            menu.add("Share current URL")
            menu.add(if (desktopMode) "Use mobile website" else "Use desktop website")
            menu.add(if (webView.settings.javaScriptEnabled) "Turn JavaScript off" else "Turn JavaScript on")
            menu.add("Download current video")
            menu.add("History")
            menu.add("Downloads")
            setOnMenuItemClickListener { item ->
                when (item.title.toString()) {
                    "Add page to Home feed" -> saveCurrentPageToHome()
                    "Bookmarks" -> showBookmarks()
                    "Copy current URL" -> copyCurrentUrl()
                    "Share current URL" -> shareCurrentUrl()
                    "Use desktop website" -> setDesktopMode(true)
                    "Use mobile website" -> setDesktopMode(false)
                    "Turn JavaScript off" -> { webView.settings.javaScriptEnabled = false; webView.reload() }
                    "Turn JavaScript on" -> { webView.settings.javaScriptEnabled = true; webView.reload() }
                    "Download current video" -> downloadCurrentVideo()
                    "History" -> showBrowserHistory()
                    "Downloads" -> showDownloads()
                }
                true
            }
            show()
        }
    }

    private fun toggleCurrentBookmark() {
        val url = webView.url ?: return
        if (!isWebUrl(Uri.parse(url))) return
        val saved = InterestHistory.toggleBookmark(this, webView.title.orEmpty(), url)
        bookmarkAction.text = if (saved) "★" else "☆"
        android.widget.Toast.makeText(this, if (saved) "Bookmark saved" else "Bookmark removed", android.widget.Toast.LENGTH_SHORT).show()
    }

    private fun showBookmarks() {
        val pages = InterestHistory.bookmarks(this)
        if (pages.isEmpty()) {
            AlertDialog.Builder(this).setTitle("Bookmarks").setMessage("No bookmarks saved yet. Tap ☆ on an open page to bookmark it.").setPositiveButton("OK", null).show()
            return
        }
        AlertDialog.Builder(this).setTitle("Hira Bhai Bookmarks")
            .setItems(pages.map { "${it.title}\n${Uri.parse(it.url).host.orEmpty()}" }.toTypedArray()) { _, which -> loadWebsite(pages[which].url) }
            .setNegativeButton("Close", null).show()
    }

    private fun copyCurrentUrl() {
        val url = webView.url?.takeIf { isWebUrl(Uri.parse(it)) } ?: return
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Website URL", url))
        android.widget.Toast.makeText(this, "URL copied", android.widget.Toast.LENGTH_SHORT).show()
    }

    private fun shareCurrentUrl() {
        val url = webView.url?.takeIf { isWebUrl(Uri.parse(it)) } ?: return
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, url), "Share website"))
    }

    private fun setDesktopMode(enabled: Boolean) {
        desktopMode = enabled
        val settings = webView.settings
        settings.userAgentString = if (enabled) {
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
        } else android.webkit.WebSettings.getDefaultUserAgent(this)
        settings.useWideViewPort = enabled
        settings.loadWithOverviewMode = enabled
        webView.reload()
    }

    private fun showBrowserHome() {
        webView.stopLoading()
        webView.visibility = View.GONE
        pageError.visibility = View.GONE
        searchPanel.visibility = View.VISIBLE
        address.setText("")
        searchStatus.text = "Hira Bhai Browser home · enter a website or search above."
        searchProgress.visibility = View.GONE
    }

    private fun saveCurrentPageToHome() {
        val current = webView.url
        if (current != null && isWebUrl(Uri.parse(current))) {
            val preview = InterestHistory.capturePreview(this, webView, current)
            InterestHistory.saveToHome(this, webView.title.orEmpty(), current, preview)
            android.widget.Toast.makeText(this, "Page added to Hira Bhai Home", android.widget.Toast.LENGTH_SHORT).show()
        } else android.widget.Toast.makeText(this, "Open a webpage first.", android.widget.Toast.LENGTH_SHORT).show()
    }

    private fun downloadCurrentVideo() {
        HiraDownloads.downloadCurrentDirectVideo(this, webView)
    }

    private fun showBrowserHistory() {
        val pages = InterestHistory.recentPages(this)
        if (pages.isEmpty()) {
            AlertDialog.Builder(this).setTitle("Hira Bhai History").setMessage("No pages in browser history yet.").setPositiveButton("OK", null).show()
            return
        }
        AlertDialog.Builder(this).setTitle("Hira Bhai History")
            .setItems(pages.map { "${it.title}\n${Uri.parse(it.url).host.orEmpty()}" }.toTypedArray()) { _, which -> loadWebsite(pages[which].url) }
            .setNeutralButton("Clear history") { _, _ -> InterestHistory.clear(this); showBrowserHistory() }
            .setNegativeButton("Close", null).show()
    }

    private fun showDownloads() {
        val entries = HiraDownloads.entries(this)
        if (entries.isEmpty()) {
            AlertDialog.Builder(this).setTitle("Downloads").setMessage("No downloads yet. Downloadable files from websites appear here.").setPositiveButton("OK", null).show()
            return
        }
        AlertDialog.Builder(this).setTitle("Hira Bhai Downloads")
            .setItems(entries.map { "${it.title}\n${HiraDownloads.status(this, it.id)}" }.toTypedArray()) { _, which ->
                HiraDownloads.open(this, entries[which].id, entries[which].mime)
            }
            .setNegativeButton("Close", null).show()
    }

    private fun isWebUrl(uri: Uri): Boolean = uri.scheme.equals("https", true) || uri.scheme.equals("http", true)

    private fun goBackOrClose() {
        if (fullscreenView != null) { exitWebFullscreen(); return }
        if (webView.visibility == View.VISIBLE) {
            if (webView.canGoBack()) webView.goBack()
            else showBrowserHome()
        } else finish()
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() { goBackOrClose() }

    @Deprecated("Runtime permission result callback")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        HiraDownloads.handlePermissionResult(this, requestCode, grantResults)
    }

    private fun exitWebFullscreen() {
        val view = fullscreenView ?: return
        val container = fullscreenContainer
        container?.let { (it.parent as? ViewGroup)?.removeView(it) }
        fullscreenView = null
        fullscreenContainer = null
        fullscreenCallback?.onCustomViewHidden()
        fullscreenCallback = null
        requestedOrientation = previousOrientation
        WindowInsetsControllerCompat(window, window.decorView).show(
            WindowInsetsCompat.Type.statusBars() or WindowInsetsCompat.Type.navigationBars()
        )
        webView.visibility = View.VISIBLE
        rootView.requestApplyInsets()
    }

    override fun onDestroy() {
        if (fullscreenView != null) exitWebFullscreen()
        if (::webView.isInitialized) {
            (webView.parent as? ViewGroup)?.removeView(webView)
            webView.stopLoading(); webView.destroy()
        }
        super.onDestroy()
    }

    private fun glass(color: Int, radius: Int) = android.graphics.drawable.GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat(); setStroke(dp(1), 0x88ffffff.toInt())
    }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        const val EXTRA_URL = "com.hirabhai.platform.extra.BROWSER_URL"
        const val EXTRA_QUERY = "com.hirabhai.platform.extra.BROWSER_QUERY"
        const val EXTRA_TYPE = "com.hirabhai.platform.extra.BROWSER_TYPE"
    }
}
