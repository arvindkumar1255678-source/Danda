package com.hirabhai.platform

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import io.livekit.android.LiveKit
import io.livekit.android.room.Room
import io.livekit.android.events.RoomEvent
import io.livekit.android.events.collect
import io.livekit.android.room.track.VideoTrack
import io.livekit.android.renderer.SurfaceViewRenderer
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.tasks.await
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

class LiveStreamingActivity : ComponentActivity() {
    companion object { const val EXTRA_STREAM_ID = "live_stream_id"; private const val ENDPOINT = "/liveToken" }
    private val db: FirebaseFirestore? get() = FirebaseBackend.db
    private lateinit var root: LinearLayout
    private lateinit var room: Room
    private var streamId: String? = null
    private var publishing = false
    private var streamListener: ListenerRegistration? = null
    private var chatListener: ListenerRegistration? = null
    private var streamDocs: ListenerRegistration? = null
    private var video: SurfaceViewRenderer? = null
    private var status: TextView? = null
    private var count: TextView? = null
    private var chatList: LinearLayout? = null
    private var titleField: EditText? = null
    private var descriptionField: EditText? = null
    private val permissions = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        if (grants[Manifest.permission.CAMERA] == true && grants[Manifest.permission.RECORD_AUDIO] == true) createBroadcast()
        else showMessage("Camera and microphone access are required to start a live broadcast.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(0,45,41); window.navigationBarColor = Color.rgb(0,45,41)
        window.decorView.systemUiVisibility = 0
        room = LiveKit.create(applicationContext)
        streamId = intent.getStringExtra(EXTRA_STREAM_ID)
        render()
        streamId?.let { watchStream(it) } ?: loadLiveList()
    }

    private fun render() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(0,45,41)); setPadding(dp(18),dp(20),dp(18),dp(16)) }
        applySafeInsets(root, 18, 20, 16)
        val scroll = ScrollView(this).apply { addView(root) }; setContentView(scroll)
        root.addView(TextView(this).apply { text = "‹   Hira Bhai Live"; textSize=21f; setTextColor(Color.WHITE); setPadding(0,0,0,dp(12)); setOnClickListener { finish() } })
        status = text("Live broadcasts from Hira Bhai creators", 14, 0xffc4d8d5.toInt())
        root.addView(status)
        if (streamId == null) {
            val card = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(16),dp(15),dp(16),dp(15)); background=bg(0xffffffff.toInt(),20) }
            card.addView(text("Start a live broadcast",18,Color.WHITE,true))
            titleField = field("Stream title (required)").also { card.addView(it) }
            descriptionField = field("Description (optional)").also { card.addView(it) }
            card.addView(button("●  Start Live") { requestPublish() })
            root.addView(card)
            root.addView(text("Active now",18,Color.WHITE,true).apply { setPadding(0,dp(20),0,dp(8)) })
            root.addView(LinearLayout(this).apply { tag="live_list"; orientation=LinearLayout.VERTICAL })
        } else {
            video = SurfaceViewRenderer(this).apply { setBackgroundColor(Color.BLACK); layoutParams=LinearLayout.LayoutParams(-1,dp(250)); root.addView(this) }
            count = text("Connecting to live video…",14,0xffc4d8d5.toInt()); root.addView(count)
            val controls = LinearLayout(this).apply { gravity=Gravity.CENTER_VERTICAL; addView(text("LIVE",13,0xffdc3444.toInt(),true),LinearLayout.LayoutParams(0,-2,1f)); addView(button("End broadcast") { endBroadcast() }) }; root.addView(controls)
            root.addView(text("Live chat",18,Color.WHITE,true).apply { setPadding(0,dp(14),0,dp(7)) })
            chatList = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; background=bg(0xffffffff.toInt(),16); setPadding(dp(10),dp(8),dp(10),dp(8)); root.addView(this) }
            val entry = field("Say something…"); val send = button("Send") { sendChat(entry) }
            root.addView(entry); root.addView(send)
            connectViewer()
        }
    }

    private fun requestPublish() {
        if (FirebaseBackend.auth?.currentUser == null) { showMessage("Sign in to start a live stream."); return }
        if (titleField?.text.isNullOrBlank()) { titleField?.error="Enter a title"; return }
        val needed = listOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO).filter { ContextCompat.checkSelfPermission(this,it)!=PackageManager.PERMISSION_GRANTED }
        if (needed.isEmpty()) createBroadcast() else permissions.launch(needed.toTypedArray())
    }

    private fun createBroadcast() {
        lifecycleScope.launch {
            setStatus("Creating secure live room…")
            try {
                val response = backend("liveToken", JSONObject().put("mode","publish").put("title",titleField?.text?.toString().orEmpty()).put("description",descriptionField?.text?.toString().orEmpty()))
                streamId = response.getString("streamId"); publishing = true
                val liveRoot = LinearLayout(this@LiveStreamingActivity).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(0,45,41)); setPadding(dp(18),dp(18),dp(18),dp(18)); addView(text("‹  Hira Bhai Live",21,Color.WHITE).apply { setOnClickListener { finish() } }); addView(SurfaceViewRenderer(this@LiveStreamingActivity).also { video=it; it.setBackgroundColor(Color.BLACK) },LinearLayout.LayoutParams(-1,dp(260))); addView(text("Starting broadcast…",15,Color.WHITE).also { status=it }); addView(button("End broadcast") { endBroadcast() }) }
                applySafeInsets(liveRoot, 18, 18, 18)
                setContentView(liveRoot)
                val target = video!!; room.initVideoRenderer(target)
                room.connect(response.getString("url"), response.getString("token"))
                launch { room.events.collect { event -> if(event is RoomEvent.ParticipantConnected || event is RoomEvent.ParticipantDisconnected) updateCount() } }
                room.localParticipant.setMicrophoneEnabled(true); room.localParticipant.setCameraEnabled(true)
                room.localParticipant.videoTrackPublications.firstOrNull()?.second.let { (it as? VideoTrack)?.addRenderer(target) }
                setStatus("You are live. Keep this screen open while broadcasting.")
                watchStream(streamId!!)
            } catch (error: Exception) { setStatus("Could not start broadcast: ${error.message ?: "Check LiveKit and Firebase Functions setup."}") }
        }
    }

    private fun connectViewer() {
        val id = streamId ?: return
        lifecycleScope.launch {
            try {
                val response=backend("liveToken",JSONObject().put("mode","viewer").put("streamId",id))
                video?.let { room.initVideoRenderer(it) }
                launch { room.events.collect { event -> when(event) {
                    is RoomEvent.TrackSubscribed -> { val track = event.track; if (track is VideoTrack) track.addRenderer(video!!) }
                    is RoomEvent.ParticipantConnected, is RoomEvent.ParticipantDisconnected -> updateCount()
                    else -> Unit
                } } }
                room.connect(response.getString("url"),response.getString("token"))
                updateCount(); setStatus("Connected to live broadcast")
            } catch (error: Exception) { setStatus("Could not join live stream: ${error.message ?: "Check your connection."}") }
        }
    }

    private fun watchStream(id:String) {
        val ref=db?.collection("liveStreams")?.document(id) ?: return
        streamListener?.remove(); streamListener=ref.addSnapshotListener { snap,error ->
            if(error!=null) setStatus("Live stream unavailable: ${error.message}")
            else if(snap==null||!snap.exists()||snap.getString("status")!="live") { setStatus("This broadcast has ended."); if(!publishing) lifecycleScope.launch { room.disconnect() } }
            else { val owner=snap.getString("ownerUid"); findViewById<TextView?>(android.R.id.content); if(publishing && owner!=FirebaseBackend.auth?.currentUser?.uid) setStatus("Stream ownership mismatch; ending session.") }
        }
        chatListener?.remove(); chatListener=ref.collection("chat").orderBy("createdAt").limitToLast(60).addSnapshotListener { snap,error ->
            if(error!=null) { showMessage("Live chat unavailable: ${error.message}"); return@addSnapshotListener }
            chatList?.removeAllViews(); snap?.documents?.forEach { doc -> chatList?.addView(text("${doc.getString("username") ?: "Viewer"}: ${doc.getString("text") ?: ""}",14,Color.WHITE)) }
        }
    }

    private fun loadLiveList() {
        val list=root.findViewWithTag<LinearLayout>("live_list") ?: return
        val database=db ?: run { list.addView(text("Connect Firebase to see live broadcasts.",14,0xffc4d8d5.toInt())); return }
        streamDocs=database.collection("liveStreams").whereEqualTo("status","live").limit(30).addSnapshotListener { snapshot,error ->
            if(error!=null) { list.removeAllViews(); list.addView(text("Could not load live streams: ${error.message}",14,0xffc4d8d5.toInt())); return@addSnapshotListener }
            list.removeAllViews()
            if(snapshot?.isEmpty!=false) { list.addView(text("No one is live right now.",14,0xffc4d8d5.toInt())); return@addSnapshotListener }
            snapshot.documents.forEach { doc -> list.addView(button("●  ${doc.getString("title") ?: "Live stream"} · ${doc.getString("creatorName") ?: "Creator"}") { startActivity(Intent(this,LiveStreamingActivity::class.java).putExtra(EXTRA_STREAM_ID,doc.id)) }) }
        }
    }

    private fun sendChat(entry:EditText) {
        val user=FirebaseBackend.auth?.currentUser ?: return showMessage("Sign in to use live chat.")
        val message=entry.text.toString().trim(); if(message.isEmpty())return
        if(message.length>500) { entry.error="Keep messages under 500 characters"; return }
        lifecycleScope.launch {
            try {
                val profile=db?.collection("profiles")?.document(user.uid)?.get()?.await() ?: throw IllegalStateException("Firestore is unavailable")
                db!!.collection("liveStreams").document(streamId!!).collection("chat").add(mapOf("uid" to user.uid,"creatorId" to profile.getString("creatorId"),"username" to (profile.getString("username") ?: "viewer"),"text" to message,"createdAt" to FieldValue.serverTimestamp())).await()
                entry.setText("")
            } catch(error:Exception) { showMessage("Message was not sent: ${error.message}") }
        }
    }

    private fun endBroadcast() {
        if(!publishing) { finish(); return }
        lifecycleScope.launch {
            try { backend("endLiveBroadcast",JSONObject().put("streamId",streamId)); room.disconnect(); publishing=false; setStatus("Broadcast ended and saved to your live history."); finish() }
            catch(error:Exception) { showMessage("Could not end broadcast securely: ${error.message}") }
        }
    }

    private fun updateCount() { count?.text="${room.remoteParticipants.size + 1} connected" }
    private suspend fun backend(name:String, body:JSONObject):JSONObject {
        val user=FirebaseBackend.auth?.currentUser ?: throw IllegalStateException("Sign in again to continue")
        val projectId=com.google.firebase.FirebaseApp.getInstance().options.projectId ?: throw IllegalStateException("Firebase project ID is missing")
        val bearer="Bearer ${user.getIdToken(false).await().token}"
        return withContext(Dispatchers.IO) {
            val connection=(URL("https://us-central1-$projectId.cloudfunctions.net/$name").openConnection() as HttpURLConnection).apply { requestMethod="POST"; connectTimeout=15000; readTimeout=25000; doOutput=true; setRequestProperty("Authorization",bearer); setRequestProperty("Content-Type","application/json") }
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code=connection.responseCode
            val stream=if(code in 200..299) connection.inputStream else connection.errorStream
            val parsed=JSONObject(stream.bufferedReader().use { it.readText() })
            if(code !in 200..299) throw IllegalStateException(parsed.optString("error","Live service request failed ($code)"))
            connection.disconnect(); parsed
        }
    }

    private fun field(hint:String)=EditText(this).apply { this.hint=hint; textSize=15f; setTextColor(Color.WHITE); setHintTextColor(0xffc4d8d5.toInt()); background=bg(0x30ffffff,16); setPadding(dp(12),dp(10),dp(12),dp(10)); layoutParams=LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(8) } }
    private fun button(label:String,onClick:()->Unit)=TextView(this).apply { text=label; textSize=14f; gravity=Gravity.CENTER; minHeight=dp(48); setTextColor(Color.WHITE); background=bg(0x7723a48f,16); setPadding(dp(12),dp(12),dp(12),dp(12)); isClickable=true; isFocusable=true; setOnClickListener { onClick() }; layoutParams=LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(8) } }
    private fun text(value:String,size:Int,color:Int,bold:Boolean=false)=TextView(this).apply { text=value; textSize=size.toFloat(); setTextColor(color); if(bold) setTypeface(null,1); setPadding(0,dp(3),0,dp(3)) }
    private fun bg(color:Int,radius:Int)=android.graphics.drawable.GradientDrawable().apply { setColor(if(color==Color.WHITE) 0x30ffffff else color); cornerRadius=dp(radius).toFloat(); setStroke(dp(1),0x70ffffff) }
    private fun applySafeInsets(view: View, horizontal: Int, top: Int, bottom: Int) {
        ViewCompat.setOnApplyWindowInsetsListener(view) { target, insets ->
            val safe = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            target.setPadding(dp(horizontal) + safe.left, dp(top) + safe.top, dp(horizontal) + safe.right, dp(bottom) + safe.bottom)
            insets
        }
    }
    private fun dp(n:Int)=(n*resources.displayMetrics.density).toInt()
    private fun setStatus(value:String) { runOnUiThread { status?.text=value } }
    private fun showMessage(value:String) { runOnUiThread { android.app.AlertDialog.Builder(this).setMessage(value).setPositiveButton("OK",null).show() } }
    @Deprecated("Use the in-screen End broadcast control to securely finish a live broadcast")
    override fun onBackPressed() { if(publishing) endBroadcast() else super.onBackPressed() }
    override fun onDestroy() { streamListener?.remove(); chatListener?.remove(); streamDocs?.remove(); lifecycleScope.launch { room.disconnect() }; super.onDestroy() }
}
