package com.hirabhai.platform

import android.app.Application
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.PixelCopy
import android.os.Handler
import android.os.Looper
import android.graphics.Bitmap
import java.io.ByteArrayOutputStream
import com.google.firebase.FirebaseApp
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.appcheck.debug.DebugAppCheckProviderFactory
import com.google.firebase.appcheck.playintegrity.PlayIntegrityAppCheckProviderFactory

class HiraApp : Application() {
    override fun onCreate() {
        super.onCreate()
        FirebaseBackend.initialize(this)
        if (FirebaseBackend.isConfigured) {
            try {
                val appCheck = FirebaseAppCheck.getInstance(FirebaseApp.getInstance())
                appCheck.installAppCheckProviderFactory(
                    if (applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE != 0) DebugAppCheckProviderFactory.getInstance()
                    else PlayIntegrityAppCheckProviderFactory.getInstance()
                )
            } catch (error: Exception) {
                Log.e("HiraBhaiAppCheck", "App Check initialization failed", error)
            }
        }
        val previousHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            try {
                val sender = android.app.PendingIntent.getBroadcast(this, 0, Intent("dev.appmama.action.REPORT_CRASH").setPackage(packageName), android.app.PendingIntent.FLAG_IMMUTABLE)
                startActivity(Intent("dev.appmama.action.REPORT_CRASH").setPackage("dev.appmama").putExtra("dev.appmama.extra.PACKAGE", packageName).putExtra("dev.appmama.extra.SENDER", sender).putExtra("dev.appmama.extra.TRACE", Log.getStackTraceString(error).take(20000)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Throwable) {}
            if (previousHandler != null) previousHandler.uncaughtException(thread, error) else { android.os.Process.killProcess(android.os.Process.myPid()); kotlin.system.exitProcess(10) }
        }
        val app: Application = this
        val installed = try { packageManager.getPackageInfo("dev.appmama", 0); true } catch (_: Exception) { false }
        if (installed) registerActivityLifecycleCallbacks(object : ActivityLifecycleCallbacks {
            private val sensors = getSystemService(android.hardware.SensorManager::class.java)
            private var listener: android.hardware.SensorEventListener? = null
            override fun onActivityResumed(activity: Activity) {
                val accelerometer = sensors?.getDefaultSensor(android.hardware.Sensor.TYPE_ACCELEROMETER) ?: return
                var jolts = 0; var first = 0L; var last = 0L
                listener = object : android.hardware.SensorEventListener {
                    override fun onSensorChanged(event: android.hardware.SensorEvent) {
                        val (x,y,z) = event.values
                        if (x*x+y*y+z*z < 26f*26f) return
                        val now = android.os.SystemClock.elapsedRealtime(); if (now-last < 200) return
                        if (now-first > 1500) { jolts=0; first=now }; last=now
                        if (++jolts == 3) sendScreenshot(activity)
                    }
                    override fun onAccuracyChanged(sensor: android.hardware.Sensor?, accuracy: Int) {}
                }
                sensors.registerListener(listener, accelerometer, android.hardware.SensorManager.SENSOR_DELAY_UI)
            }
            override fun onActivityPaused(activity: Activity) { listener?.let { sensors?.unregisterListener(it) }; listener=null }
            private fun sendScreenshot(activity: Activity) {
                val view=activity.window.decorView; if(view.width==0||view.height==0)return
                val shot=Bitmap.createBitmap(view.width,view.height,Bitmap.Config.ARGB_8888)
                PixelCopy.request(activity.window,shot,{ result ->
                    if(result!=PixelCopy.SUCCESS)return@request
                    val scale=minOf(1f,1080f/maxOf(shot.width,shot.height)); val small=Bitmap.createScaledBitmap(shot,(shot.width*scale).toInt().coerceAtLeast(1),(shot.height*scale).toInt().coerceAtLeast(1),true)
                    val jpeg=ByteArrayOutputStream().also { small.compress(Bitmap.CompressFormat.JPEG,75,it) }.toByteArray()
                    try { val sender=android.app.PendingIntent.getBroadcast(app,1,Intent("dev.appmama.action.SEND_FEEDBACK").setPackage(app.packageName),android.app.PendingIntent.FLAG_IMMUTABLE); activity.startActivity(Intent("dev.appmama.action.SEND_FEEDBACK").setPackage("dev.appmama").putExtra("dev.appmama.extra.PACKAGE",app.packageName).putExtra("dev.appmama.extra.SENDER",sender).putExtra("dev.appmama.extra.SCREENSHOT",jpeg)) } catch (_:Throwable) {}
                },Handler(Looper.getMainLooper()))
            }
            override fun onActivityCreated(a:Activity,b:Bundle?){}; override fun onActivityStarted(a:Activity){}; override fun onActivityStopped(a:Activity){}; override fun onActivitySaveInstanceState(a:Activity,b:Bundle){}; override fun onActivityDestroyed(a:Activity){}
        })
    }
}
