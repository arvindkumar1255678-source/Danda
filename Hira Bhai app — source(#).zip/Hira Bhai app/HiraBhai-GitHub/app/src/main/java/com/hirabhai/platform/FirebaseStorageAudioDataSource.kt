package com.hirabhai.platform

import android.net.Uri
import androidx.media3.common.C
import androidx.media3.datasource.BaseDataSource
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DataSource
import com.google.firebase.storage.StreamDownloadTask
import java.io.EOFException
import java.io.IOException
import java.io.PipedInputStream
import java.io.PipedOutputStream

/** Progressively reads an audio object through Firebase Storage's authenticated SDK. */
class FirebaseStorageAudioDataSource : BaseDataSource(true) {
    class Factory : DataSource.Factory {
        override fun createDataSource(): DataSource = FirebaseStorageAudioDataSource()
    }

    private var sourceUri: Uri? = null
    private var input: PipedInputStream? = null
    private var output: PipedOutputStream? = null
    private var task: StreamDownloadTask? = null
    @Volatile private var streamError: Exception? = null
    private var remaining = C.LENGTH_UNSET.toLong()
    private var opened = false

    @Throws(IOException::class)
    override fun open(dataSpec: DataSpec): Long {
        transferInitializing(dataSpec)
        sourceUri = dataSpec.uri
        val path = dataSpec.uri.getQueryParameter("path")
            ?: throw IOException("Audio storage path is missing")
        val storage = FirebaseBackend.storage ?: throw IOException("Firebase Storage is unavailable")
        try {
            val pipeIn = PipedInputStream(128 * 1024)
            val pipeOut = PipedOutputStream(pipeIn)
            input = pipeIn; output = pipeOut
            remaining = dataSpec.length
            task = storage.reference.child(path).getStream(object : StreamDownloadTask.StreamProcessor {
                override fun doInBackground(snapshot: StreamDownloadTask.TaskSnapshot, stream: java.io.InputStream) {
                    try {
                        stream.use { source ->
                            val skipBuffer = ByteArray(16 * 1024)
                            var skipped = 0L
                            while (skipped < dataSpec.position) {
                                val count = source.read(skipBuffer, 0, minOf(skipBuffer.size.toLong(), dataSpec.position - skipped).toInt())
                                if (count < 0) throw EOFException("Audio ended before the requested seek position")
                                skipped += count
                            }
                            pipeOut.use { sink ->
                                val buffer = ByteArray(32 * 1024)
                                var sent = 0L
                                while (dataSpec.length == C.LENGTH_UNSET.toLong() || sent < dataSpec.length) {
                                    val requested = if (dataSpec.length == C.LENGTH_UNSET.toLong()) buffer.size else minOf(buffer.size.toLong(), dataSpec.length - sent).toInt()
                                    val count = source.read(buffer, 0, requested)
                                    if (count < 0) break
                                    sink.write(buffer, 0, count)
                                    sent += count
                                }
                            }
                        }
                    } catch (error: Exception) {
                        streamError = error
                        try { pipeOut.close() } catch (_: Exception) {}
                        throw error
                    }
                }
            })
            task?.addOnFailureListener { error ->
                streamError = error
                try { pipeOut.close() } catch (_: Exception) {}
            }
            opened = true
            transferStarted(dataSpec)
            return remaining
        } catch (error: Exception) {
            close()
            if (error is IOException) throw error
            throw IOException("Could not open protected audio stream", error)
        }
    }

    @Throws(IOException::class)
    override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
        if (length == 0) return 0
        val stream = input ?: throw IOException("Audio stream is closed")
        try {
            val count = stream.read(buffer, offset, length)
            if (count == -1) {
                streamError?.let { throw IOException("Firebase audio stream failed", it) }
                return C.RESULT_END_OF_INPUT
            }
            if (remaining != C.LENGTH_UNSET.toLong()) remaining -= count
            bytesTransferred(count)
            return count
        } catch (error: IOException) {
            streamError?.let { throw IOException("Firebase audio stream failed", it) }
            throw error
        }
    }

    override fun getUri(): Uri? = sourceUri

    override fun close() {
        sourceUri = null
        try { task?.cancel() } catch (_: Exception) {}
        task = null
        try { input?.close() } catch (_: Exception) {}
        try { output?.close() } catch (_: Exception) {}
        input = null; output = null; streamError = null
        if (opened) { opened = false; transferEnded() }
    }
}
