package com.hirabhai.platform

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.view.View
import java.io.File
import java.security.MessageDigest
import org.json.JSONArray
import org.json.JSONObject

/** Small, private on-device record of pages the user opened inside Hira Bhai. */
object InterestHistory {
    private const val PREFS = "hira_local_interest_history"
    private const val KEY_PAGES = "pages"
    private const val KEY_HOME_PAGES = "home_pages"
    private const val KEY_BOOKMARKS = "bookmarks"

    data class SavedPage(val title: String, val url: String, val previewPath: String? = null)

    fun recordPage(context: Context, title: String, url: String) {
        val safeUrl = url.takeIf { it.startsWith("https://") || it.startsWith("http://") } ?: return
        val cleanTitle = title.trim().take(180)
        if (cleanTitle.isBlank()) return
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (!prefs.getBoolean("enabled", true)) return
        val old = try { JSONArray(prefs.getString(KEY_PAGES, "[]")) } catch (_: Exception) { JSONArray() }
        val updated = JSONArray().put(JSONObject().put("title", cleanTitle).put("url", safeUrl).put("time", System.currentTimeMillis()))
        for (i in 0 until minOf(old.length(), 29)) {
            val item = old.optJSONObject(i) ?: continue
            if (item.optString("url") != safeUrl) updated.put(item)
        }
        prefs.edit().putString(KEY_PAGES, updated.toString()).apply()
    }

    fun recentPageTitles(context: Context): List<String> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val pages = try { JSONArray(prefs.getString(KEY_PAGES, "[]")) } catch (_: Exception) { JSONArray() }
        return (0 until pages.length()).mapNotNull { pages.optJSONObject(it)?.optString("title")?.takeIf(String::isNotBlank) }
    }

    fun recentPages(context: Context): List<SavedPage> {
        val pages = try { JSONArray(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_PAGES, "[]")) } catch (_: Exception) { JSONArray() }
        return (0 until pages.length()).mapNotNull { index ->
            pages.optJSONObject(index)?.let { SavedPage(it.optString("title"), it.optString("url"), it.optString("preview").takeIf(String::isNotBlank)) }
                ?.takeIf { it.title.isNotBlank() && it.url.startsWith("http") }
        }
    }

    fun capturePreview(context: Context, view: View, url: String): String? {
        val width = view.width.takeIf { it > 0 } ?: return null
        val height = view.height.takeIf { it > 0 } ?: return null
        return try {
            val scale = minOf(1f, 640f / width, 1000f / height)
            val bitmap = Bitmap.createBitmap((width * scale).toInt().coerceAtLeast(1), (height * scale).toInt().coerceAtLeast(1), Bitmap.Config.RGB_565)
            Canvas(bitmap).apply { drawColor(Color.WHITE); scale(scale, scale); view.draw(this) }
            val directory = File(context.filesDir, "saved_page_previews").apply { mkdirs() }
            val digest = MessageDigest.getInstance("SHA-256").digest(url.toByteArray()).take(12).joinToString("") { "%02x".format(it) }
            val file = File(directory, "$digest.jpg")
            file.outputStream().use { bitmap.compress(Bitmap.CompressFormat.JPEG, 76, it) }
            bitmap.recycle()
            file.absolutePath
        } catch (_: Exception) { null }
    }

    fun saveToHome(context: Context, title: String, url: String, previewPath: String? = null) {
        if (!url.startsWith("https://") && !url.startsWith("http://")) return
        val cleanTitle = title.trim().take(180).ifBlank { url }
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val old = try { JSONArray(prefs.getString(KEY_HOME_PAGES, "[]")) } catch (_: Exception) { JSONArray() }
        val updated = JSONArray().put(JSONObject().put("title", cleanTitle).put("url", url).put("time", System.currentTimeMillis()).put("preview", previewPath ?: ""))
        for (i in 0 until minOf(old.length(), 29)) {
            val item = old.optJSONObject(i) ?: continue
            if (item.optString("url") != url) updated.put(item)
            else if (previewPath.isNullOrBlank() && item.optString("preview").isNotBlank()) updated.put(JSONObject().put("title", cleanTitle).put("url", url).put("time", System.currentTimeMillis()).put("preview", item.optString("preview")))
        }
        prefs.edit().putString(KEY_HOME_PAGES, updated.toString()).apply()
    }

    fun savedHomePages(context: Context): List<SavedPage> {
        val pages = try { JSONArray(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_HOME_PAGES, "[]")) } catch (_: Exception) { JSONArray() }
        return (0 until pages.length()).mapNotNull { index ->
            pages.optJSONObject(index)?.let { SavedPage(it.optString("title"), it.optString("url"), it.optString("preview").takeIf(String::isNotBlank)) }
                ?.takeIf { it.title.isNotBlank() && it.url.startsWith("http") }
        }
    }

    fun bookmarks(context: Context): List<SavedPage> {
        val pages = try { JSONArray(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_BOOKMARKS, "[]")) } catch (_: Exception) { JSONArray() }
        return (0 until pages.length()).mapNotNull { index ->
            pages.optJSONObject(index)?.let { SavedPage(it.optString("title"), it.optString("url")) }
                ?.takeIf { it.title.isNotBlank() && (it.url.startsWith("https://") || it.url.startsWith("http://")) }
        }
    }

    fun isBookmarked(context: Context, url: String): Boolean = bookmarks(context).any { it.url == url }

    /** Returns true when the page is now bookmarked, false when it was removed. */
    fun toggleBookmark(context: Context, title: String, url: String): Boolean {
        if (!url.startsWith("https://") && !url.startsWith("http://")) return false
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val old = try { JSONArray(prefs.getString(KEY_BOOKMARKS, "[]")) } catch (_: Exception) { JSONArray() }
        val updated = JSONArray()
        val wasSaved = (0 until old.length()).any { old.optJSONObject(it)?.optString("url") == url }
        val retained = (0 until old.length()).mapNotNull { old.optJSONObject(it) }
            .filter { it.optString("url") != url }.take(49)
        if (!wasSaved) updated.put(JSONObject().put("title", title.trim().take(180).ifBlank { url }).put("url", url).put("time", System.currentTimeMillis()))
        retained.forEach(updated::put)
        prefs.edit().putString(KEY_BOOKMARKS, updated.toString()).apply()
        return !wasSaved
    }

    fun removeHomePage(context: Context, url: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val old = try { JSONArray(prefs.getString(KEY_HOME_PAGES, "[]")) } catch (_: Exception) { JSONArray() }
        val updated = JSONArray()
        for (i in 0 until old.length()) {
            val page = old.optJSONObject(i) ?: continue
            if (page.optString("url") == url) page.optString("preview").takeIf(String::isNotBlank)?.let { File(it).delete() }
            else updated.put(page)
        }
        prefs.edit().putString(KEY_HOME_PAGES, updated.toString()).apply()
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY_PAGES).apply()
    }
}
