package com.hirabhai.os

import android.app.Activity
import android.app.Application
import android.app.PendingIntent
import android.content.Intent
import android.graphics.Bitmap
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.PixelCopy
import java.io.ByteArrayOutputStream
import kotlin.system.exitProcess

class HiraBhaiLauncherApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val previousHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            try {
                val sender = PendingIntent.getBroadcast(
                    this, 0,
                    Intent("dev.appmama.action.REPORT_CRASH").setPackage(packageName),
                    PendingIntent.FLAG_IMMUTABLE,
                )
                startActivity(
                    Intent("dev.appmama.action.REPORT_CRASH")
                        .setPackage("dev.appmama")
                        .putExtra("dev.appmama.extra.PACKAGE", packageName)
                        .putExtra("dev.appmama.extra.SENDER", sender)
                        .putExtra("dev.appmama.extra.TRACE", Log.getStackTraceString(error).take(20_000))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (_: Throwable) { }
            if (previousHandler != null) previousHandler.uncaughtException(thread, error)
            else {
                android.os.Process.killProcess(android.os.Process.myPid())
                exitProcess(10)
            }
        }

        val app: Application = this
        val appMamaInstalled = try {
            packageManager.getPackageInfo("dev.appmama", 0)
            true
        } catch (_: Exception) { false }
        if (appMamaInstalled) registerActivityLifecycleCallbacks(object : ActivityLifecycleCallbacks {
            private val sensors = app.getSystemService(SensorManager::class.java)
            private var listener: SensorEventListener? = null

            override fun onActivityResumed(activity: Activity) {
                val accelerometer = sensors?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) ?: return
                var jolts = 0
                var firstJolt = 0L
                var lastJolt = 0L
                listener = object : SensorEventListener {
                    override fun onSensorChanged(event: SensorEvent) {
                        val (x, y, z) = event.values
                        if (x * x + y * y + z * z < 26f * 26f) return
                        val now = SystemClock.elapsedRealtime()
                        if (now - lastJolt < 200) return
                        if (now - firstJolt > 1500) { jolts = 0; firstJolt = now }
                        lastJolt = now
                        if (++jolts == 3) sendScreenshot(activity)
                    }
                    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
                }
                sensors.registerListener(listener, accelerometer, SensorManager.SENSOR_DELAY_UI)
            }

            override fun onActivityPaused(activity: Activity) {
                listener?.let { sensors?.unregisterListener(it) }
                listener = null
            }

            private fun sendScreenshot(activity: Activity) {
                val view = activity.window.decorView
                if (view.width == 0 || view.height == 0) return
                val shot = Bitmap.createBitmap(view.width, view.height, Bitmap.Config.ARGB_8888)
                PixelCopy.request(activity.window, shot, { result ->
                    if (result != PixelCopy.SUCCESS) return@request
                    val scale = minOf(1f, 1080f / maxOf(shot.width, shot.height))
                    val small = Bitmap.createScaledBitmap(shot, (shot.width * scale).toInt().coerceAtLeast(1), (shot.height * scale).toInt().coerceAtLeast(1), true)
                    val jpeg = ByteArrayOutputStream().also { small.compress(Bitmap.CompressFormat.JPEG, 75, it) }.toByteArray()
                    try {
                        val sender = PendingIntent.getBroadcast(app, 1, Intent("dev.appmama.action.SEND_FEEDBACK").setPackage(app.packageName), PendingIntent.FLAG_IMMUTABLE)
                        activity.startActivity(
                            Intent("dev.appmama.action.SEND_FEEDBACK")
                                .setPackage("dev.appmama")
                                .putExtra("dev.appmama.extra.PACKAGE", app.packageName)
                                .putExtra("dev.appmama.extra.SENDER", sender)
                                .putExtra("dev.appmama.extra.SCREENSHOT", jpeg)
                        )
                    } catch (_: Throwable) { }
                }, Handler(Looper.getMainLooper()))
            }

            override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) = Unit
            override fun onActivityStarted(activity: Activity) = Unit
            override fun onActivityStopped(activity: Activity) = Unit
            override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) = Unit
            override fun onActivityDestroyed(activity: Activity) = Unit
        })
    }
}
