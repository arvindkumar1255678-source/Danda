package com.hirabhai.os

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

internal object LauncherUi {
    const val BG = 0xFF002D29.toInt()
    const val GLASS = 0xCC365D59.toInt()
    const val STROKE = 0x887FA6A0.toInt()
    const val WHITE = Color.WHITE
    const val MUTED = 0xFFD2E3E0.toInt()
    const val TEAL = 0xFF27B89E.toInt()

    fun dp(context: Context, value: Int): Int = (value * context.resources.displayMetrics.density).toInt()

    fun glass(radius: Int = 26): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = radius.toFloat()
        setColor(GLASS)
        setStroke(2, STROKE)
    }

    fun label(context: Context, value: String, size: Float, color: Int = WHITE, bold: Boolean = false): TextView =
        TextView(context).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    fun button(context: Context, value: String, onClick: () -> Unit): Button = Button(context).apply {
        text = value
        textSize = 15f
        isAllCaps = false
        setTextColor(WHITE)
        background = glass(24)
        setPadding(dp(context, 18), dp(context, 10), dp(context, 18), dp(context, 10))
        setOnClickListener { onClick() }
    }

    fun column(context: Context): LinearLayout = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setBackgroundColor(BG)
    }

    fun addGap(parent: LinearLayout, context: Context, height: Int) {
        parent.addView(View(context), LinearLayout.LayoutParams(1, dp(context, height)))
    }
}
