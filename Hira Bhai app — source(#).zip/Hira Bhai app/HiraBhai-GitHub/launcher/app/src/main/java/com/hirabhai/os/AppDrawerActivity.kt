package com.hirabhai.os

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class AppDrawerActivity : Activity() {
    private lateinit var grid: GridLayout
    private lateinit var empty: TextView
    private var apps: List<android.content.pm.ResolveInfo> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = LauncherUi.BG
        window.navigationBarColor = LauncherUi.BG
        val root = LauncherUi.column(this).apply { gravity = Gravity.TOP; setPadding(LauncherUi.dp(this@AppDrawerActivity, 18), LauncherUi.dp(this@AppDrawerActivity, 12), LauncherUi.dp(this@AppDrawerActivity, 18), LauncherUi.dp(this@AppDrawerActivity, 16)) }
        val header = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(LauncherUi.button(this@AppDrawerActivity, "‹") { finish() }, LinearLayout.LayoutParams(LauncherUi.dp(this@AppDrawerActivity, 58), LauncherUi.dp(this@AppDrawerActivity, 52)))
            addView(LauncherUi.label(this@AppDrawerActivity, "  All apps", 24f, bold = true), LinearLayout.LayoutParams(-1, -2))
        }
        root.addView(header)
        val search = EditText(this).apply {
            hint = "Search apps"
            setSingleLine()
            textSize = 16f
            setTextColor(LauncherUi.WHITE)
            setHintTextColor(LauncherUi.MUTED)
            background = LauncherUi.glass(24)
            setPadding(LauncherUi.dp(this@AppDrawerActivity, 18), 0, LauncherUi.dp(this@AppDrawerActivity, 18), 0)
        }
        root.addView(search, LinearLayout.LayoutParams(-1, LauncherUi.dp(this, 54)).apply { topMargin = LauncherUi.dp(this@AppDrawerActivity, 14) })
        grid = GridLayout(this).apply { columnCount = if (resources.configuration.screenWidthDp >= 600) 5 else 4; useDefaultMargins = false }
        empty = LauncherUi.label(this, "No matching apps", 15f, LauncherUi.MUTED).apply { gravity = Gravity.CENTER; visibility = View.GONE }
        val scroll = ScrollView(this).apply { isFillViewport = true; addView(grid) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = LauncherUi.dp(this@AppDrawerActivity, 14) })
        root.addView(empty, LinearLayout.LayoutParams(-1, LauncherUi.dp(this, 60)))
        setContentView(root)
        @Suppress("DEPRECATION")
        apps = packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), PackageManager.MATCH_ALL)
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }
        renderApps("")
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = renderApps(s?.toString().orEmpty())
            override fun afterTextChanged(s: android.text.Editable?) = Unit
        })
    }

    private fun renderApps(filter: String) {
        grid.removeAllViews()
        val matches = apps.filter { it.loadLabel(packageManager).toString().contains(filter.trim(), ignoreCase = true) }
        empty.visibility = if (matches.isEmpty()) View.VISIBLE else View.GONE
        val columns = grid.columnCount
        val tileWidth = (resources.displayMetrics.widthPixels - LauncherUi.dp(this, 36)) / columns
        matches.forEach { info ->
            val tile = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(LauncherUi.dp(this@AppDrawerActivity, 4), LauncherUi.dp(this@AppDrawerActivity, 10), LauncherUi.dp(this@AppDrawerActivity, 4), LauncherUi.dp(this@AppDrawerActivity, 10))
                background = LauncherUi.glass(22)
                isClickable = true
                isFocusable = true
                setOnClickListener { launchApp(info) }
            }
            val icon = ImageView(this).apply { setImageDrawable(info.loadIcon(packageManager)); contentDescription = info.loadLabel(packageManager).toString() }
            tile.addView(icon, LinearLayout.LayoutParams(LauncherUi.dp(this, 48), LauncherUi.dp(this, 48)))
            tile.addView(LauncherUi.label(this, info.loadLabel(packageManager).toString(), 12f).apply { gravity = Gravity.CENTER; maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END }, LinearLayout.LayoutParams(-1, LauncherUi.dp(this, 34)).apply { topMargin = LauncherUi.dp(this@AppDrawerActivity, 5) })
            grid.addView(tile, GridLayout.LayoutParams().apply {
                width = tileWidth
                height = LauncherUi.dp(this@AppDrawerActivity, 104)
                setMargins(LauncherUi.dp(this@AppDrawerActivity, 3), LauncherUi.dp(this@AppDrawerActivity, 3), LauncherUi.dp(this@AppDrawerActivity, 3), LauncherUi.dp(this@AppDrawerActivity, 3))
            })
        }
    }

    private fun launchApp(info: android.content.pm.ResolveInfo) {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setClassName(info.activityInfo.packageName, info.activityInfo.name)
        try { startActivity(intent) } catch (_: Exception) { Toast.makeText(this, "This app could not be opened.", Toast.LENGTH_SHORT).show() }
    }
}
