package com.hirabhai.os

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast

class LauncherSettingsActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = LauncherUi.BG
        window.navigationBarColor = LauncherUi.BG
        val content = LauncherUi.column(this).apply {
            gravity = Gravity.TOP
            setPadding(LauncherUi.dp(this@LauncherSettingsActivity, 20), LauncherUi.dp(this@LauncherSettingsActivity, 16), LauncherUi.dp(this@LauncherSettingsActivity, 20), LauncherUi.dp(this@LauncherSettingsActivity, 20))
        }
        content.addView(LauncherUi.button(this, "‹   Back") { finish() }, LinearLayout.LayoutParams(-2, LauncherUi.dp(this, 52)))
        content.addView(LauncherUi.label(this, "Launcher settings", 28f, bold = true), LinearLayout.LayoutParams(-1, -2).apply { topMargin = LauncherUi.dp(this@LauncherSettingsActivity, 24) })
        content.addView(LauncherUi.label(this, "Choose HiraBhai OS as your Home app in Android settings. Android controls the default launcher choice.", 15f, LauncherUi.MUTED), LinearLayout.LayoutParams(-1, -2).apply { topMargin = LauncherUi.dp(this@LauncherSettingsActivity, 8) })
        content.addView(LauncherUi.button(this, "Choose default Home app") { openHomeSettings() }, LinearLayout.LayoutParams(-1, LauncherUi.dp(this, 58)).apply { topMargin = LauncherUi.dp(this@LauncherSettingsActivity, 16) })

        val immersive = CheckBox(this).apply {
            text = "Hide status and navigation bars"
            textSize = 15f
            setTextColor(LauncherUi.WHITE)
            buttonTintList = android.content.res.ColorStateList.valueOf(LauncherUi.TEAL)
            isChecked = getSharedPreferences("launcher", MODE_PRIVATE).getBoolean("fullscreen", false)
            setOnCheckedChangeListener { _, checked ->
                getSharedPreferences("launcher", MODE_PRIVATE).edit().putBoolean("fullscreen", checked).apply()
                Toast.makeText(this@LauncherSettingsActivity, "Fullscreen preference saved", Toast.LENGTH_SHORT).show()
            }
        }
        val glassRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = LauncherUi.glass(24)
            setPadding(LauncherUi.dp(this@LauncherSettingsActivity, 12), LauncherUi.dp(this@LauncherSettingsActivity, 6), LauncherUi.dp(this@LauncherSettingsActivity, 12), LauncherUi.dp(this@LauncherSettingsActivity, 6))
            addView(immersive, LinearLayout.LayoutParams(-1, -2))
        }
        content.addView(glassRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = LauncherUi.dp(this@LauncherSettingsActivity, 12) })
        content.addView(LauncherUi.label(this, "Fullscreen mode can be exited temporarily by swiping from the screen edge. No special device-owner or system permissions are used.", 14f, LauncherUi.MUTED), LinearLayout.LayoutParams(-1, -2).apply { topMargin = LauncherUi.dp(this@LauncherSettingsActivity, 8) })
        val scroll = ScrollView(this).apply { addView(content) }
        setContentView(scroll)
    }

    private fun openHomeSettings() {
        try {
            startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
        } catch (_: Exception) {
            try { startActivity(Intent(Settings.ACTION_SETTINGS)) }
            catch (_: Exception) { Toast.makeText(this, "Open Android Settings and search for Default apps → Home app.", Toast.LENGTH_LONG).show() }
        }
    }
}
