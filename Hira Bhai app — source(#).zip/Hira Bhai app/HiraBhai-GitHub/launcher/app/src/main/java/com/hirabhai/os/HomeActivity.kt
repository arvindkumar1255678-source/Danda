package com.hirabhai.os

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HomeActivity : android.app.Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private var clock: TextView? = null
    private var date: TextView? = null
    private var downY = 0f
    private val tick = object : Runnable {
        override fun run() {
            val now = Date()
            clock?.text = SimpleDateFormat("h:mm", Locale.getDefault()).format(now)
            date?.text = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(now)
            handler.postDelayed(this, 30_000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        window.statusBarColor = LauncherUi.BG
        window.navigationBarColor = LauncherUi.BG
        setContentView(makeHome())
        applyFullscreenPreference()
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(tick)
        tick.run()
        applyFullscreenPreference()
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        super.onPause()
    }

    private fun makeHome(): LinearLayout {
        val root = LauncherUi.column(this).apply {
            setPadding(LauncherUi.dp(this@HomeActivity, 24), LauncherUi.dp(this@HomeActivity, 14), LauncherUi.dp(this@HomeActivity, 24), LauncherUi.dp(this@HomeActivity, 14))
        }
        val top = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(LauncherUi.label(this@HomeActivity, "HiraBhai OS", 20f, bold = true), LinearLayout.LayoutParams(0, -2, 1f))
            addView(LauncherUi.button(this@HomeActivity, "⚙") { openSettings() }, LinearLayout.LayoutParams(LauncherUi.dp(this@HomeActivity, 58), LauncherUi.dp(this@HomeActivity, 54)))
        }
        root.addView(top, LinearLayout.LayoutParams(-1, -2))

        val center = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        clock = LauncherUi.label(this, "", 56f, bold = true).apply { gravity = Gravity.CENTER }
        date = LauncherUi.label(this, "", 17f, LauncherUi.MUTED).apply { gravity = Gravity.CENTER }
        center.addView(clock)
        center.addView(date, LinearLayout.LayoutParams(-1, -2).apply { topMargin = LauncherUi.dp(this@HomeActivity, 2) })
        LauncherUi.addGap(center, this, 34)
        val mark = ImageView(this).apply {
            setImageResource(R.drawable.ic_hirabhai_mark)
            contentDescription = "Hira Bhai circular logo · open YouTube channel"
            scaleType = ImageView.ScaleType.FIT_CENTER
            setOnClickListener { openHiraBhaiChannel() }
            isClickable = true
            isFocusable = true
        }
        center.addView(mark, LinearLayout.LayoutParams(LauncherUi.dp(this, 196), LauncherUi.dp(this, 196)))
        center.addView(LauncherUi.label(this, "Hira Bhai", 24f, bold = true).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = LauncherUi.dp(this@HomeActivity, 15) })
        center.addView(LauncherUi.label(this, "Tap the logo to visit our channel", 14f, LauncherUi.MUTED).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = LauncherUi.dp(this@HomeActivity, 4) })
        root.addView(center, LinearLayout.LayoutParams(-1, 0, 1f))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = LauncherUi.glass(32)
            setPadding(LauncherUi.dp(this@HomeActivity, 10), LauncherUi.dp(this@HomeActivity, 10), LauncherUi.dp(this@HomeActivity, 10), LauncherUi.dp(this@HomeActivity, 10))
            addView(LauncherUi.button(this@HomeActivity, "▦   Apps") { openDrawer() }, LinearLayout.LayoutParams(0, LauncherUi.dp(this@HomeActivity, 56), 1f).apply { marginEnd = LauncherUi.dp(this@HomeActivity, 6) })
            addView(LauncherUi.button(this@HomeActivity, "⚙   Settings") { openSettings() }, LinearLayout.LayoutParams(0, LauncherUi.dp(this@HomeActivity, 56), 1f).apply { marginStart = LauncherUi.dp(this@HomeActivity, 6) })
        }
        root.addView(bottom, LinearLayout.LayoutParams(-1, -2))
        root.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { downY = event.y; true }
                MotionEvent.ACTION_UP -> { if (downY - event.y > LauncherUi.dp(this, 72)) openDrawer(); true }
                else -> false
            }
        }
        return root
    }

    private fun openHiraBhaiChannel() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://youtube.com/@thehirabhai")))
        } catch (_: Exception) {
            Toast.makeText(this, "No app can open the Hira Bhai channel link.", Toast.LENGTH_LONG).show()
        }
    }

    private fun openDrawer() = startActivity(Intent(this, AppDrawerActivity::class.java))
    private fun openSettings() = startActivity(Intent(this, LauncherSettingsActivity::class.java))

    private fun applyFullscreenPreference() {
        val immersive = getSharedPreferences("launcher", MODE_PRIVATE).getBoolean("fullscreen", false)
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        if (immersive) {
            controller.hide(WindowInsetsCompat.Type.systemBars())
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        } else controller.show(WindowInsetsCompat.Type.systemBars())
    }
}
