# HiraBhai OS native launcher

- Application ID: `com.hirabhai.os`
- Version: `1.0` (version code `1`)
- Language: Kotlin
- Minimum Android version: Android 8.0 (API 26)
- Compile and target SDK: Android 16 (API 36)

This is a native Android HOME application, not a WebView. `HomeActivity` handles Android's `MAIN` + `HOME` + `DEFAULT` intent and also has a regular launcher icon entry. Android asks the user to select the default Home app through the system Home settings; the app cannot make itself default silently.

The home screen has a live clock/date, the original Hira Bhai circular multicolor logo, glass-style controls, an app drawer populated from installed launcher activities, and an optional immersive fullscreen preference. Tap the logo to open `https://youtube.com/@thehirabhai`. The app uses package visibility declarations for launchable apps and AppMama; it does not request `QUERY_ALL_PACKAGES`, accessibility, overlay, device-admin, or Device Owner access.

## Build

From this directory, with JDK 21 and Android SDK 36 installed:

```sh
gradle assembleDebug
```

GitHub Actions runs the same build and uploads the debug APK as the `hirabhai-os-debug-apk` artifact. Debug signing is for development and testing.
