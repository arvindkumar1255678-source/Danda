# HiraBhai OS

**Version:** 1.0  
**Repository:** HiraBhai

HiraBhai is an existing native Android application with Firebase-backed services and a separately hosted creator website. This export preserves the available Android source, web source, backend functions, Firebase rules, assets, and the original circular Hira Bhai logo.

The Android app is a regular Android application; the website module is a Firebase Hosting site. This project does not register itself as the device's default Home/launcher app.

## Project layout

- `app/` — the existing Hira Bhai Android app source, resources, manifest, and logo assets.
- `launcher/` — a separate native Kotlin Android HOME launcher (`com.hirabhai.os`, version 1.0). It does not replace the existing app.
- `functions/` — Firebase Cloud Functions source and tests.
- `website/` — hosted creator website HTML, JavaScript, and configuration placeholder.
- `firestore.rules`, `firestore.indexes.json`, `storage.rules`, `firebase.json` — Firebase deployment source.
- `docs/` — feature-specific setup notes.

## Build the Android app

Open this directory as a Gradle Android project or run `gradle assembleDebug` in an Android build environment with Android SDK 36 and Java 21. The existing app module uses application version 1.0. To build the separate launcher project, run `cd launcher && gradle assembleDebug`.

The launcher declares `MAIN` + `HOME` + `DEFAULT` and lets Android select it from Default apps → Home app. It queries launchable applications through the launcher intent category, includes a native app drawer and settings page, and uses the original Hira Bhai circular icon. It does not request Device Owner access or special permissions. A GitHub Actions workflow builds the launcher APK.

## Configure Firebase before use

This GitHub export intentionally contains no project-specific `google-services.json`, live Firebase web API key, service-account key, or provider secrets. Before building/deploying a connected instance:

1. Add your own Android Firebase configuration as `app/google-services.json`.
2. Replace placeholder values in `app/src/main/res/values/firebase_config.xml` and `website/public/firebase-config.js` with the configuration for your Firebase project. The web API key is a public project identifier, but restrict it to required APIs.
3. Configure backend provider credentials with Firebase Functions Secrets (for example, AI/search/live-stream providers). Never put server secrets in Android or website source.
4. Review and deploy Firestore and Storage rules for your project. Some cloud functions require Firebase billing and additional Google Cloud/provider configuration; see `functions/README.md` and the guides in `docs/`.

Without those project-specific settings, Firebase-dependent features cannot connect to your backend. The source export does not claim those services are configured.

## Included logo and assets

The original circular Hira Bhai logo is preserved in `app/src/main/res/drawable-nodpi/hira_bhai_logo.png`; the adaptive launcher icon assets are in the Android resources. Website images and source assets are included under `website/`.

## Security and export contents

Build outputs, Gradle caches, temporary files, local environment files, and live Firebase configuration files were excluded. No generated or placeholder Android code was added; the export uses the existing application source.
