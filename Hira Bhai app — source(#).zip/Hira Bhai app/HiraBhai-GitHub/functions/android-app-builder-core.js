'use strict';

const zlib = require('node:zlib');

function safePackageName(value) {
  return typeof value === 'string' && value.length <= 64 && /^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*){1,5}$/.test(value)
    && !value.startsWith('android.') && !value.startsWith('java.');
}

function tarGzip(files) {
  const chunks = [];
  const octal = (buffer, offset, length, value) => {
    const text = Math.max(0, value).toString(8).padStart(length - 1, '0') + '\0';
    buffer.write(text.slice(-length), offset, length, 'ascii');
  };
  for (const [name, contentValue] of Object.entries(files)) {
    const content = Buffer.from(contentValue, 'utf8');
    if (Buffer.byteLength(name) > 100 || name.startsWith('/') || name.split('/').includes('..')) throw new Error('Generated project path is invalid.');
    const header = Buffer.alloc(512);
    header.write(name, 0, 100, 'utf8');
    octal(header, 100, 8, 0o644); octal(header, 108, 8, 0); octal(header, 116, 8, 0);
    octal(header, 124, 12, content.length); octal(header, 136, 12, Math.floor(Date.now() / 1000));
    header.fill(0x20, 148, 156); header[156] = 0x30; header.write('ustar\0', 257, 6, 'ascii'); header.write('00', 263, 2, 'ascii');
    let checksum = 0; for (const byte of header) checksum += byte;
    header.write(checksum.toString(8).padStart(6, '0') + '\0 ', 148, 8, 'ascii');
    chunks.push(header, content);
    const padding = (512 - (content.length % 512)) % 512;
    if (padding) chunks.push(Buffer.alloc(padding));
  }
  chunks.push(Buffer.alloc(1024));
  return zlib.gzipSync(Buffer.concat(chunks), { level: 6 });
}

function generatedAndroidFiles(name, packageName, javaSource) {
  if (!safePackageName(packageName)) throw new Error('Android package name is invalid.');
  const safeName = String(name || 'My AI App').replace(/[^A-Za-z0-9_-]/g, '_').slice(0, 40) || 'MyAiApp';
  const label = String(name || 'My AI App').slice(0, 60).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&apos;' })[c]);
  const source = javaSource.replace(/^\s*package\s+[A-Za-z0-9_.]+\s*;/m, `package ${packageName};`);
  const java = /^\s*package\s+[A-Za-z0-9_.]+\s*;/m.test(source) ? source : `package ${packageName};\n\n${source}`;
  const packagePath = packageName.replace(/\./g, '/');
  return {
    'settings.gradle': `pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }\ndependencyResolutionManagement { repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS); repositories { google(); mavenCentral() } }\nrootProject.name = '${safeName}'\ninclude ':app'\n`,
    'build.gradle': "plugins { id 'com.android.application' version '9.4.1' apply false }\n",
    'gradle.properties': 'org.gradle.jvmargs=-Xmx3g -Dfile.encoding=UTF-8\norg.gradle.daemon=false\nandroid.useAndroidX=true\n',
    'app/build.gradle': `plugins { id 'com.android.application' }\nandroid { namespace '${packageName}'; compileSdk 36; defaultConfig { applicationId '${packageName}'; minSdk 26; targetSdk 36; versionCode 1; versionName '1.0' } }\ntasks.withType(JavaCompile).configureEach { options.compilerArgs += ['-proc:none'] }\n`,
    'app/src/main/AndroidManifest.xml': `<manifest xmlns:android="http://schemas.android.com/apk/res/android"><application android:theme="@android:style/Theme.Material.Light.NoActionBar" android:label="${label}" android:allowBackup="false"><activity android:name=".MainActivity" android:exported="true"><intent-filter><action android:name="android.intent.action.MAIN"/><category android:name="android.intent.category.LAUNCHER"/></intent-filter></activity></application></manifest>\n`,
    [`app/src/main/java/${packagePath}/MainActivity.java`]: java,
    'README.md': `# ${label}\n\nGenerated native Android project for ${safeName}. Build a debug APK with Gradle 9.7.1 and JDK 17 or newer by running: gradle assembleDebug.\n\nReview generated Java source before installing. The build contains no API keys, Firebase credentials, extra permissions, annotation processors, or third-party app dependencies. APKs from this builder are debug-signed and intended for review/testing, not Play Store release.\n`,
  };
}

function sourceSafetyError(source) {
  const blocked = [
    /\bRuntime\s*\.\s*getRuntime\s*\(/,
    /\bProcessBuilder\b/,
    /\bClassLoader\b|\bDexClassLoader\b|\bPathClassLoader\b/,
    /\bClass\s*\.\s*forName\s*\(/,
    /\bjava\s*\.\s*lang\s*\.\s*reflect\b/,
    /\bSystem\s*\.\s*load(?:Library)?\s*\(/,
    /\bjava\s*\.\s*net\s*\./,
    /\bandroid\s*\.\s*webkit\s*\.\s*WebView\b/,
  ];
  return blocked.some(pattern => pattern.test(source))
    ? 'This build contains a restricted dynamic-code, process, network, or WebView API. Remove it before building.'
    : '';
}

module.exports = { safePackageName, tarGzip, generatedAndroidFiles, sourceSafetyError };
