// Run only from a trusted operator workstation with Google Application Default
// Credentials. The UID must be repeated in HB_CONFIRM_ADMIN_UID to prevent a
// mistaken one-argument invocation from granting an admin claim.
const { initializeApp, applicationDefault } = require('firebase-admin/app');
const { getAuth } = require('firebase-admin/auth');

async function main() {
  const uid = process.argv[2];
  if (!uid || process.env.HB_CONFIRM_ADMIN_UID !== uid) {
    throw new Error('Usage: HB_CONFIRM_ADMIN_UID=<uid> GOOGLE_CLOUD_PROJECT=<project> node grant-platform-admin.js <uid>');
  }
  initializeApp({ credential: applicationDefault(), projectId: process.env.GOOGLE_CLOUD_PROJECT });
  const auth = getAuth();
  const user = await auth.getUser(uid);
  const claims = { ...(user.customClaims || {}), platformAdmin: true };
  await auth.setCustomUserClaims(uid, claims);
  await auth.revokeRefreshTokens(uid);
  console.log(`Granted platformAdmin claim to ${uid}. The admin must sign in again to refresh the token.`);
}

main().catch(error => { console.error(error.message); process.exitCode = 1; });
