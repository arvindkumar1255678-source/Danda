const { onRequest } = require('firebase-functions/v2/https');
const { defineSecret, defineString } = require('firebase-functions/params');
const { initializeApp } = require('firebase-admin/app');
const { getAuth } = require('firebase-admin/auth');
const { getFirestore, FieldValue } = require('firebase-admin/firestore');
const { getStorage } = require('firebase-admin/storage');
const { AccessToken, RoomServiceClient, WebhookReceiver } = require('livekit-server-sdk');
const crypto = require('node:crypto');
const { GoogleAuth } = require('google-auth-library');
const { safePackageName, tarGzip, generatedAndroidFiles, sourceSafetyError } = require('./android-app-builder-core');

initializeApp();
const geminiApiKey = defineSecret('GEMINI_API_KEY');
const livekitApiKey = defineSecret('LIVEKIT_API_KEY');
const livekitApiSecret = defineSecret('LIVEKIT_API_SECRET');
const livekitUrl = defineSecret('LIVEKIT_URL');
const razorpayKeyId = defineSecret('RAZORPAY_KEY_ID');
const razorpayKeySecret = defineSecret('RAZORPAY_KEY_SECRET');
const razorpayWebhookSecret = defineSecret('RAZORPAY_WEBHOOK_SECRET');
const youtubeDataApiKey = defineSecret('YOUTUBE_DATA_API_KEY');
const braveSearchApiKey = defineSecret('BRAVE_SEARCH_API_KEY');
const aiAppBuildBucket = defineString('AI_APP_BUILD_BUCKET', { default: '' });
const aiAppBuildServiceAccount = defineString('AI_APP_BUILD_SERVICE_ACCOUNT', { default: '' });

function livekitClients() {
  const url = livekitUrl.value().replace(/^wss:/, 'https:').replace(/^ws:/, 'http:').replace(/\/$/, '');
  return { url: livekitUrl.value(), rooms: new RoomServiceClient(url, livekitApiKey.value(), livekitApiSecret.value()) };
}

async function authenticatedUser(req) {
  const match = /^Bearer (.+)$/.exec(req.get('Authorization') || '');
  if (!match) throw Object.assign(new Error('Sign-in required'), { status: 401 });
  const user = await getAuth().verifyIdToken(match[1], true);
  await assertAccountActive(user.uid);
  return user;
}

async function requirePlatformAdmin(req) {
  const user = await authenticatedUser(req);
  if (user.platformAdmin !== true) throw Object.assign(new Error('Verified platform administrator access is required.'), { status: 403 });
  const moderation = await getFirestore().collection('userModeration').doc(user.uid).get();
  if (moderation.exists && moderation.get('status') === 'suspended') throw Object.assign(new Error('This account is suspended.'), { status: 403 });
  return user;
}

async function assertAccountActive(uid) {
  const moderation = await getFirestore().collection('userModeration').doc(uid).get();
  if (moderation.exists && moderation.get('status') === 'suspended') throw Object.assign(new Error('This account is suspended.'), { status: 403 });
}

async function creatorOwner(creatorId) {
  const profiles = await getFirestore().collection('profiles').where('creatorId', '==', creatorId).limit(1).get();
  if (profiles.empty) throw Object.assign(new Error('Creator account not found.'), { status: 404 });
  return profiles.docs[0];
}

// Authenticated, rate-limited playback events feed the real public trending list.
exports.recordAudioPlay = onRequest({ region: 'us-central1', maxInstances: 20 }, async (req, res) => {
  res.set('Cache-Control', 'no-store');
  if (req.method !== 'POST') return res.status(405).json({ error: 'POST required' });
  try {
    const user = await authenticatedUser(req);
    const audioId = req.body?.audioId;
    if (typeof audioId !== 'string' || audioId.length < 1 || audioId.length > 160)
      return res.status(400).json({ error: 'Choose a valid audio track.' });
    const db = getFirestore();
    const audioRef = db.collection('audios').doc(audioId);
    const eventRef = db.collection('userActivity').doc(user.uid).collection('audioPlayEvents').doc(audioId);
    const statsRef = db.collection('audioStats').doc(audioId);
    const now = Date.now();
    const result = await db.runTransaction(async tx => {
      const audio = await tx.get(audioRef);
      if (!audio.exists) throw Object.assign(new Error('Audio is unavailable.'), { status: 404 });
      if (!['public', 'unlisted'].includes(audio.get('visibility'))) {
        const profile = await tx.get(db.collection('profiles').doc(user.uid));
        if (!profile.exists || profile.get('creatorId') !== audio.get('creatorId'))
          throw Object.assign(new Error('Audio is private.'), { status: 403 });
      }
      const event = await tx.get(eventRef);
      const last = event.get('lastPlayedAt')?.toMillis?.() || 0;
      if (now - last < 30000) return { counted: false };
      const stats = await tx.get(statsRef);
      const count = Math.max(0, stats.get('playCount') || 0) + 1;
      tx.set(eventRef, { audioId, lastPlayedAt: new Date(now) });
      tx.set(statsRef, { audioId, creatorId: audio.get('creatorId'), playCount: count, updatedAt: new Date(now) });
      return { counted: true, playCount: count };
    });
    return res.status(200).json(result);
  } catch (error) {
    console.error('Audio play event rejected', error);
    return res.status(error.status || 500).json({ error: error.status ? error.message : 'Could not record audio playback.' });
  }
});

exports.trendingAudio = onRequest({ region: 'us-central1', maxInstances: 10 }, async (req, res) => {
  res.set('Cache-Control', 'public, max-age=60');
  if (req.method !== 'GET') return res.status(405).json({ error: 'GET required' });
  try {
    const limit = Math.max(1, Math.min(30, Number.parseInt(req.query.limit, 10) || 20));
    const db = getFirestore();
    const stats = await db.collection('audioStats').orderBy('playCount', 'desc').limit(limit * 4).get();
    const items = await Promise.all(stats.docs.map(async stat => {
      const audio = await db.collection('audios').doc(stat.id).get();
      if (!audio.exists || audio.get('visibility') !== 'public') return null;
      const data = audio.data();
      return { ...data, audioId: audio.id, playCount: stat.get('playCount') || 0 };
    }));
    return res.status(200).json({ audios: items.filter(Boolean).slice(0, limit) });
  } catch (error) {
    console.error('Trending audio could not load', error);
    return res.status(500).json({ error: 'Trending audio is temporarily unavailable.' });
  }
});

exports.submitContentReport = onRequest({ region: 'us-central1', maxInstances: 20 }, async (req, res) => {
  res.set('Cache-Control', 'no-store');
  if (req.method !== 'POST') return res.status(405).json({ error: 'POST required' });
  try {
    const user = await authenticatedUser(req); await assertAccountActive(user.uid);
    const { type, targetId, videoId, commentId, reason, details } = req.body || {};
    if (!['video', 'user', 'comment'].includes(type) || typeof targetId !== 'string' || targetId.length < 1 || targetId.length > 160)
      return res.status(400).json({ error: 'Choose valid content to report.' });
    if (typeof reason !== 'string' || !['harassment', 'hate', 'sexual', 'violence', 'spam', 'copyright', 'other'].includes(reason))
      return res.status(400).json({ error: 'Choose a valid report reason.' });
    if (typeof details !== 'string' || details.length > 500) return res.status(400).json({ error: 'Report details must be at most 500 characters.' });
    const db = getFirestore(); let targetUid = ''; let targetCreatorId = ''; let targetUsername = ''; let contentSummary = '';
    let resolvedVideoId = ''; let resolvedCommentId = '';
    if (type === 'video') {
      const video = await db.collection('videos').doc(targetId).get();
      if (!video.exists || !['public', 'unlisted'].includes(video.get('visibility'))) return res.status(404).json({ error: 'Public video not found.' });
      targetCreatorId = video.get('creatorId') || ''; targetUsername = video.get('creatorUsername') || '';
      targetUid = (await creatorOwner(targetCreatorId)).id; contentSummary = String(video.get('title') || 'Video').slice(0, 160);
      resolvedVideoId = video.id;
    } else if (type === 'user') {
      targetCreatorId = targetId;
      const profile = await creatorOwner(targetCreatorId); targetUid = profile.id;
      targetUsername = profile.get('username') || '';
      contentSummary = String(profile.get('fullName') || targetUsername || 'Creator').slice(0, 160);
    } else {
      if (typeof videoId !== 'string' || typeof commentId !== 'string') return res.status(400).json({ error: 'Video and comment references are required.' });
      const [video, comment] = await Promise.all([
        db.collection('videos').doc(videoId).get(), db.collection('videos').doc(videoId).collection('comments').doc(commentId).get(),
      ]);
      if (!video.exists || !comment.exists || !['public', 'unlisted'].includes(video.get('visibility'))) return res.status(404).json({ error: 'Reported comment not found.' });
      targetCreatorId = comment.get('authorCreatorId') || ''; targetUsername = comment.get('authorUsername') || '';
      targetUid = (await creatorOwner(targetCreatorId)).id; contentSummary = String(comment.get('text') || 'Comment').slice(0, 240);
      resolvedVideoId = videoId; resolvedCommentId = commentId;
    }
    if (targetUid === user.uid) return res.status(400).json({ error: 'You cannot report your own content.' });
    const key = type === 'comment' ? `${resolvedVideoId}:${resolvedCommentId}` : targetId;
    const reportId = crypto.createHash('sha256').update(`${user.uid}:${type}:${key}`).digest('hex');
    const ref = db.collection('reports').doc(reportId);
    let duplicate = false;
    await db.runTransaction(async tx => {
      const prior = await tx.get(ref);
      if (prior.exists) { duplicate = true; return; }
      tx.create(ref, {
        reportId, type, targetId, targetUid, targetCreatorId, targetUsername,
        videoId: resolvedVideoId, commentId: resolvedCommentId, contentSummary,
        reporterUid: user.uid, reason, details: details.trim(), status: 'open',
        createdAt: FieldValue.serverTimestamp(), resolvedAt: null, resolution: '',
      });
    });
    return res.status(200).json({ submitted: true, duplicate, message: duplicate ? 'You have already reported this content.' : 'Report sent for moderator review.' });
  } catch (error) {
    console.error('Content report submission failed', error);
    return res.status(error.status || 500).json({ error: error.status ? error.message : 'Could not submit this report.' });
  }
});

exports.adminModeration = onRequest({ region: 'us-central1', timeoutSeconds: 120, maxInstances: 5 }, async (req, res) => {
  res.set('Cache-Control', 'no-store');
  if (req.method !== 'POST') return res.status(405).json({ error: 'POST required' });
  try {
    const admin = await requirePlatformAdmin(req); const db = getFirestore();
    const { mode, reportId, action, targetUid, notes } = req.body || {};
    if (mode === 'dashboard') {
      const [users, creators, videos, openReports, totalReports, audit] = await Promise.all([
        (async () => { let count = 0; let pageToken; do { const page = await getAuth().listUsers(1000, pageToken); count += page.users.length; pageToken = page.pageToken; } while (pageToken); return count; })(),
        db.collection('profiles').count().get(), db.collection('videos').count().get(),
        db.collection('reports').where('status', '==', 'open').count().get(), db.collection('reports').count().get(),
        db.collection('moderationAudit').orderBy('createdAt', 'desc').limit(20).get(),
      ]);
      return res.status(200).json({ users, creators: creators.data().count, videos: videos.data().count, openReports: openReports.data().count, totalReports: totalReports.data().count, activity: audit.docs.map(d => ({ id: d.id, action: d.get('action'), targetType: d.get('targetType'), createdAt: d.get('createdAt')?.toDate()?.toISOString() || '' })) });
    }
    if (mode === 'reports') {
      const snap = await db.collection('reports').where('status', '==', 'open').orderBy('createdAt', 'desc').limit(100).get();
      return res.status(200).json({ reports: snap.docs.map(d => ({ id: d.id, ...d.data(), createdAt: d.get('createdAt')?.toDate()?.toISOString() || '' })) });
    }
    if (mode === 'audit') {
      const snap = await db.collection('moderationAudit').orderBy('createdAt', 'desc').limit(100).get();
      return res.status(200).json({ entries: snap.docs.map(d => ({ id: d.id, ...d.data(), createdAt: d.get('createdAt')?.toDate()?.toISOString() || '' })) });
    }
    if (mode === 'suspended') {
      const snap = await db.collection('userModeration').where('status', '==', 'suspended').orderBy('updatedAt', 'desc').limit(100).get();
      return res.status(200).json({ accounts: snap.docs.map(d => ({ uid: d.id, reason: d.get('reason') || '', updatedAt: d.get('updatedAt')?.toDate()?.toISOString() || '' })) });
    }
    if (mode !== 'resolve' || !['dismiss', 'remove_video', 'remove_comment', 'suspend_user', 'restore_user'].includes(action)) return res.status(400).json({ error: 'Unsupported moderation operation.' });
    const reportRef = typeof reportId === 'string' ? db.collection('reports').doc(reportId) : null;
    const reportSnap = reportRef ? await reportRef.get() : null;
    let report = reportSnap?.exists ? reportSnap.data() : null;
    if (reportId && !report) return res.status(404).json({ error: 'Report not found.' });
    if (report && report.status !== 'open' && action !== 'restore_user') return res.status(409).json({ error: 'This report was already reviewed.' });
    const note = typeof notes === 'string' ? notes.trim().slice(0, 500) : '';
    let target = targetUid || report?.targetUid || '';
    let targetType = report?.type || 'user'; let targetId = report?.targetId || target;
    if (action === 'remove_video') {
      if (!report || report.type !== 'video') return res.status(400).json({ error: 'Select a reported video before removing it.' });
      const ref = db.collection('videos').doc(report.targetId); const video = await ref.get();
      if (video.exists) {
        const bucket = getStorage().bucket();
        for (const field of ['storagePath', 'thumbnailStoragePath']) {
          const path = video.get(field);
          if (typeof path === 'string' && path.startsWith('videos/')) await bucket.file(path).delete({ ignoreNotFound: true });
        }
        await db.recursiveDelete(ref); await db.collection('videoStats').doc(report.targetId).delete().catch(() => {});
      }
      targetType = 'video'; targetId = report.targetId;
    } else if (action === 'remove_comment') {
      if (!report || report.type !== 'comment') return res.status(400).json({ error: 'Select a reported comment before removing it.' });
      await db.collection('videos').doc(report.videoId).collection('comments').doc(report.commentId).delete().catch(error => { if (error.code !== 5) throw error; });
      targetType = 'comment'; targetId = `${report.videoId}/${report.commentId}`;
    } else if (action === 'suspend_user' || action === 'restore_user') {
      if (!target || (report && report.type !== 'user' && target !== report.targetUid)) return res.status(400).json({ error: 'Select a reported account or a suspended account.' });
      if (target === admin.uid) return res.status(400).json({ error: 'Administrators cannot suspend their own account.' });
      const auth = getAuth();
      if (action === 'suspend_user') {
        await auth.updateUser(target, { disabled: true }); await auth.revokeRefreshTokens(target);
        await db.collection('userModeration').doc(target).set({ status: 'suspended', reason: note || 'Policy violation', adminUid: admin.uid, updatedAt: FieldValue.serverTimestamp() }, { merge: true });
      } else {
        await auth.updateUser(target, { disabled: false });
        await db.collection('userModeration').doc(target).set({ status: 'active', reason: '', adminUid: admin.uid, updatedAt: FieldValue.serverTimestamp() }, { merge: true });
      }
      targetType = 'user'; targetId = target;
    }
    if (reportRef && report) await reportRef.update({ status: 'reviewed', resolution: action, moderatorUid: admin.uid, moderatorNotes: note, resolvedAt: FieldValue.serverTimestamp() });
    const auditRef = db.collection('moderationAudit').doc();
    await auditRef.create({ action, targetType, targetId: targetId || '', reportId: reportId || '', adminUid: admin.uid, notes: note, createdAt: FieldValue.serverTimestamp() });
    return res.status(200).json({ completed: true, auditId: auditRef.id });
  } catch (error) {
    console.error('Admin moderation request failed', error);
    return res.status(error.status || 500).json({ error: error.status ? error.message : 'Moderation request failed.' });
  }
});

exports.liveToken = onRequest({ region: 'us-central1', secrets: [livekitApiKey, livekitApiSecret, livekitUrl], maxInstances: 10 }, async (req, res) => {
  res.set('Cache-Control', 'no-store');
  if (req.method !== 'POST') return res.status(405).json({ error: 'POST required' });
  try {
    const user = await authenticatedUser(req);
    const { mode, streamId, title, description } = req.body || {};
    const db = getFirestore();
    const profileSnap = await db.collection('profiles').doc(user.uid).get();
    const profile = profileSnap.exists ? profileSnap.data() : {};
    if (mode === 'publish' && (!profileSnap.exists || typeof profile.creatorId !== 'string')) return res.status(403).json({ error: 'Create a Hira Bhai creator profile before broadcasting.' });
    const creatorId = typeof profile.creatorId === 'string' ? profile.creatorId : '';
    const { url, rooms } = livekitClients();
    if (mode === 'publish') {
      if (typeof title !== 'string' || !title.trim() || title.trim().length > 120) return res.status(400).json({ error: 'A title between 1 and 120 characters is required.' });
      if (typeof description !== 'string' || description.length > 1000) return res.status(400).json({ error: 'Description must be at most 1,000 characters.' });
      const doc = db.collection('liveStreams').doc();
      const roomName = `hb_${doc.id}`;
      await rooms.createRoom({ name: roomName, emptyTimeout: 60, maxParticipants: 500 });
      await doc.set({ streamId: doc.id, roomName, ownerUid: user.uid, creatorId, creatorUsername: profile.username || '', creatorName: profile.fullName || 'Creator', title: title.trim(), description: description.trim(), status: 'live', startedAt: FieldValue.serverTimestamp(), endedAt: null });
      const token = new AccessToken(livekitApiKey.value(), livekitApiSecret.value(), { identity: user.uid, ttl: '2h', metadata: JSON.stringify({ uid: user.uid, creatorId }) });
      token.addGrant({ roomJoin: true, room: roomName, canPublish: true, canSubscribe: true, canPublishData: false, roomAdmin: false, roomRecord: false });
      return res.status(200).json({ url, token: await token.toJwt(), streamId: doc.id, role: 'publisher' });
    }
    if (mode === 'viewer') {
      if (typeof streamId !== 'string' || !/^[A-Za-z0-9_-]{10,40}$/.test(streamId)) return res.status(400).json({ error: 'Invalid live stream.' });
      const doc = await db.collection('liveStreams').doc(streamId).get();
      if (!doc.exists || doc.get('status') !== 'live') return res.status(404).json({ error: 'This broadcast has ended.' });
      const token = new AccessToken(livekitApiKey.value(), livekitApiSecret.value(), { identity: user.uid, ttl: '2h', metadata: JSON.stringify({ uid: user.uid, creatorId }) });
      token.addGrant({ roomJoin: true, room: doc.get('roomName'), canPublish: false, canSubscribe: true, canPublishData: false, roomAdmin: false, roomRecord: false });
      return res.status(200).json({ url, token: await token.toJwt(), streamId, role: 'viewer' });
    }
    return res.status(400).json({ error: 'Unsupported live token mode.' });
  } catch (error) {
    console.error('Live token request failed', error);
    return res.status(error.status || 500).json({ error: error.status ? error.message : 'Live streaming service is not configured or is temporarily unavailable.' });
  }
});

exports.endLiveBroadcast = onRequest({ region: 'us-central1', secrets: [livekitApiKey, livekitApiSecret, livekitUrl], maxInstances: 10 }, async (req, res) => {
  res.set('Cache-Control', 'no-store');
  if (req.method !== 'POST') return res.status(405).json({ error: 'POST required' });
  try {
    const user = await authenticatedUser(req);
    const { streamId } = req.body || {};
    if (typeof streamId !== 'string') return res.status(400).json({ error: 'Invalid stream.' });
    const db = getFirestore();
    const ref = db.collection('liveStreams').doc(streamId);
    await db.runTransaction(async tx => {
      const snap = await tx.get(ref);
      if (!snap.exists || snap.get('ownerUid') !== user.uid) throw Object.assign(new Error('Only the broadcaster can end this stream.'), { status: 403 });
      if (snap.get('status') === 'live') tx.update(ref, { status: 'ended', endedAt: FieldValue.serverTimestamp() });
    });
    const { rooms } = livekitClients();
    try { await rooms.deleteRoom(`hb_${streamId}`); } catch (error) { if (!String(error.message || '').toLowerCase().includes('not found')) throw error; }
    return res.status(200).json({ ended: true });
  } catch (error) {
    console.error('End live broadcast failed', error);
    return res.status(error.status || 500).json({ error: error.status ? error.message : 'Could not end the live broadcast.' });
  }
});

// Configure this URL in LiveKit Cloud → Settings → Webhooks and select room_finished.
// The SDK validates the signed webhook against the raw request body.
exports.livekitWebhook = onRequest({ region: 'us-central1', secrets: [livekitApiKey, livekitApiSecret], maxInstances: 10 }, async (req, res) => {
  if (req.method !== 'POST') return res.status(405).send('POST required');
  try {
    const body = req.rawBody?.toString('utf8');
    if (!body) return res.status(400).send('Raw event body required');
    const receiver = new WebhookReceiver(livekitApiKey.value(), livekitApiSecret.value());
    const event = await receiver.receive(body, req.get('Authorization'));
    if (event.event === 'room_finished' && event.room?.name?.startsWith('hb_')) {
      const streamId = event.room.name.substring(3);
      const ref = getFirestore().collection('liveStreams').doc(streamId);
      await getFirestore().runTransaction(async tx => {
        const snap = await tx.get(ref);
        if (snap.exists && snap.get('status') === 'live') tx.update(ref, { status: 'ended', endedAt: FieldValue.serverTimestamp() });
      });
    }
    return res.status(200).send('ok');
  } catch (error) {
    console.error('LiveKit webhook verification failed', error);
    return res.status(401).send('Invalid webhook');
  }
});

// Destructive operation: requires a recently reauthenticated Firebase session.
exports.deleteAccount = onRequest({ region: 'us-central1', maxInstances: 2, timeoutSeconds: 540, secrets: [livekitApiKey, livekitApiSecret, livekitUrl] }, async (req, res) => {
  res.set('Cache-Control', 'no-store');
  if (req.method !== 'POST') return res.status(405).json({ error: 'POST required' });
  try {
    const user = await authenticatedUser(req);
    if (!user.auth_time || Math.floor(Date.now() / 1000) - user.auth_time > 300)
      return res.status(401).json({ error: 'For your security, re-enter your password and try again.' });
    const db = getFirestore();
    const uid = user.uid;
    const profileRef = db.collection('profiles').doc(uid);
    const profileSnap = await profileRef.get();
    const profile = profileSnap.data() || {};
    const creatorId = profile.creatorId;
    const username = profile.username;
    const bucket = getStorage().bucket();

    // End owner's active LiveKit rooms before removing their stream catalog.
    const live = await db.collection('liveStreams').where('ownerUid', '==', uid).get();
    if (live.size) {
      const { rooms } = livekitClients();
      for (const stream of live.docs) {
        if (stream.get('status') === 'live') {
          try { await rooms.deleteRoom(stream.get('roomName')); }
          catch (e) { if (!String(e.message || '').toLowerCase().includes('not found')) throw e; }
        }
      }
    }

    const userFiles = await db.collection('userFiles').where('ownerUid', '==', uid).get();
    for (const fileDoc of userFiles.docs) {
      const path = fileDoc.get('storagePath');
      if (path) await bucket.file(path).delete({ ignoreNotFound: true });
      await db.recursiveDelete(fileDoc.ref);
    }
    if (creatorId) {
      const videos = await db.collection('videos').where('creatorId', '==', creatorId).get();
      for (const video of videos.docs) await db.recursiveDelete(video.ref);
      const audios = await db.collection('audios').where('creatorId', '==', creatorId).get();
      for (const audio of audios.docs) await db.recursiveDelete(audio.ref);
      for (const prefix of [`creatorMedia/${creatorId}/`, `videos/public/${creatorId}/`, `videos/unlisted/${creatorId}/`, `videos/private/${creatorId}/`, `audio/public/${creatorId}/`, `audio/unlisted/${creatorId}/`, `audio/private/${creatorId}/`]) {
        await bucket.deleteFiles({ prefix, force: true });
      }
      const authoredComments = await db.collectionGroup('comments').where('authorCreatorId', '==', creatorId).get();
      for (const doc of authoredComments.docs) await doc.ref.delete();
      const senderNotices = await db.collectionGroup('items').where('senderCreatorId', '==', creatorId).get();
      for (const doc of senderNotices.docs) await doc.ref.delete();
      await db.recursiveDelete(db.collection('notifications').doc(creatorId));
      await db.collection('creatorStats').doc(creatorId).delete().catch(() => {});
      await db.collection('subscriptionTestStats').doc(creatorId).delete().catch(() => {});
      await db.collection('subscriptionTests').doc(uid).get().then(s => s.exists ? db.recursiveDelete(s.ref) : undefined);
      const incomingSubscriptions = await db.collectionGroup('creators').where('creatorId', '==', creatorId).get();
      for (const sub of incomingSubscriptions.docs) await db.recursiveDelete(sub.ref);
      await db.collection('liveStreams').where('ownerUid', '==', uid).get().then(async s => { for (const d of s.docs) await db.recursiveDelete(d.ref); });
    }
    const ownLikes = await db.collectionGroup('likes').where('uid', '==', uid).get();
    for (const like of ownLikes.docs) {
      const videoRef = like.ref.parent.parent;
      if (videoRef) {
        const statRef = db.collection('videoStats').doc(videoRef.id);
        await db.runTransaction(async tx => {
          const stat = await tx.get(statRef);
          if (stat.exists) tx.update(statRef, { likeCount: Math.max(0, (stat.get('likeCount') || 0) - 1) });
          tx.delete(like.ref);
        });
      } else await like.ref.delete();
    }
    const outgoingSubscriptions = await db.collection('subscriptions').doc(uid).collection('creators').get();
    for (const sub of outgoingSubscriptions.docs) {
      const statsRef = db.collection('creatorStats').doc(sub.id);
      await db.runTransaction(async tx => {
        const stats = await tx.get(statsRef);
        if (stats.exists) tx.update(statsRef, { subscriberCount: Math.max(0, (stats.get('subscriberCount') || 0) - 1) });
        tx.delete(sub.ref);
      });
    }
    await db.recursiveDelete(db.collection('subscriptions').doc(uid));
    await db.recursiveDelete(db.collection('aiConversations').doc(uid));
    await db.recursiveDelete(db.collection('userActivity').doc(uid));
    await db.recursiveDelete(db.collection('userPlaylists').doc(uid));
    if (creatorId) {
      const publicPlaylists = await db.collection('publicPlaylists').where('creatorId', '==', creatorId).get();
      for (const playlist of publicPlaylists.docs) await db.recursiveDelete(playlist.ref);
    }
    await db.recursiveDelete(db.collection('userSettings').doc(uid));
    if (username) {
      await db.collection('publicProfiles').doc(username).delete().catch(() => {});
      await db.collection('usernames').doc(username).delete().catch(() => {});
      await db.collection('userDirectory').doc(username).delete().catch(() => {});
    }
    await profileRef.delete().catch(() => {});
    await bucket.deleteFiles({ prefix: `userFiles/${uid}/`, force: true });
    await getAuth().deleteUser(uid);
    return res.status(200).json({ deleted: true });
  } catch (error) {
    console.error('Secure account deletion failed', error);
    const code = error.status || (String(error.code || '').startsWith('auth/') ? 401 : 500);
    return res.status(code).json({ error: code === 401 ? 'Your sign-in session expired. Sign in and reauthenticate before deleting your account.' : 'The account could not be fully deleted. Contact support before creating another account.' });
  }
});

function razorpayAuth() {
  return `Basic ${Buffer.from(`${razorpayKeyId.value()}:${razorpayKeySecret.value()}`).toString('base64')}`;
}

async function razorpayRequest(path, options = {}) {
  const response = await fetch(`https://api.razorpay.com/v1${path}`, {
    ...options,
    headers: { Authorization: razorpayAuth(), 'Content-Type': 'application/json', ...(options.headers || {}) },
    signal: AbortSignal.timeout(15000),
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw Object.assign(new Error(body.error?.description || 'Razorpay request failed'), { status: 502 });
  return body;
}

exports.createDonationOrder = onRequest({ region: 'us-central1', secrets: [razorpayKeyId, razorpayKeySecret], maxInstances: 10 }, async (req, res) => {
  res.set('Cache-Control', 'no-store');
  if (req.method !== 'POST') return res.status(405).json({ error: 'POST required' });
  try {
    const user = await authenticatedUser(req);
    if (user.email_verified !== true) return res.status(403).json({ error: 'Verify your Firebase email before making a donation.' });
    const { creatorId, amountPaise } = req.body || {};
    if (typeof creatorId !== 'string' || !/^[A-Za-z0-9_-]{6,80}$/.test(creatorId) || ![5000, 10000, 50000].includes(amountPaise)) return res.status(400).json({ error: 'Choose a listed donation amount and a valid creator.' });
    const db = getFirestore();
    const [donor, payout] = await Promise.all([db.collection('profiles').doc(user.uid).get(), db.collection('creatorPayouts').doc(creatorId).get()]);
    if (!donor.exists) return res.status(403).json({ error: 'Create a Hira Bhai profile before donating.' });
    if (donor.get('creatorId') === creatorId) return res.status(400).json({ error: 'You cannot donate to your own creator account.' });
    if (!payout.exists || payout.get('status') !== 'active' || !/^acc_[A-Za-z0-9]+$/.test(payout.get('accountId') || '')) return res.status(503).json({ error: 'Donations are not enabled for this creator yet. Their verified payout account is not connected.' });
    const enabledAmounts = payout.get('donationAmounts') || [5000, 10000, 50000];
    if (!enabledAmounts.includes(amountPaise)) return res.status(400).json({ error: 'This donation amount is not currently offered by the creator.' });
    const profile = await db.collection('profiles').where('creatorId', '==', creatorId).limit(1).get();
    if (profile.empty) return res.status(404).json({ error: 'Creator profile not found.' });
    const receipt = `hb_${crypto.randomUUID().replaceAll('-', '').slice(0, 32)}`;
    const order = await razorpayRequest('/orders', { method: 'POST', body: JSON.stringify({
      amount: amountPaise, currency: 'INR', receipt,
      notes: { donorUid: user.uid, creatorId, purpose: 'creator_donation' },
      transfers: [{ account: payout.get('accountId'), amount: amountPaise, currency: 'INR', notes: { creatorId } }],
    }) });
    await db.collection('paymentOrders').doc(order.id).create({ orderId: order.id, donorUid: user.uid, creatorId, amountPaise, currency: 'INR', status: 'created', createdAt: FieldValue.serverTimestamp() });
    return res.status(200).json({ keyId: razorpayKeyId.value(), orderId: order.id, amount: order.amount, currency: order.currency });
  } catch (error) {
    console.error('Donation order creation failed', error);
    return res.status(error.status || 500).json({ error: error.status ? error.message : 'Secure payment service is not configured or unavailable.' });
  }
});

exports.updateDonationOptions = onRequest({ region: 'us-central1', secrets: [razorpayKeyId, razorpayKeySecret], maxInstances: 10 }, async (req, res) => {
  res.set('Cache-Control', 'no-store');
  if (req.method !== 'POST') return res.status(405).json({ error: 'POST required' });
  try {
    const user = await authenticatedUser(req); const { creatorId, amounts } = req.body || {};
    if (typeof creatorId !== 'string' || !Array.isArray(amounts) || !amounts.length || amounts.length > 3 || amounts.some(value => ![5000, 10000, 50000].includes(value))) return res.status(400).json({ error: 'Choose one to three supported donation amounts.' });
    const profile = await getFirestore().collection('profiles').doc(user.uid).get();
    if (!profile.exists || profile.get('creatorId') !== creatorId) return res.status(403).json({ error: 'Only the signed-in creator can change their donation options.' });
    const payout = await getFirestore().collection('creatorPayouts').doc(creatorId).get();
    if (!payout.exists || payout.get('status') !== 'active') return res.status(503).json({ error: 'Connect and verify a Razorpay Route payout account before enabling donations.' });
    const unique = [...new Set(amounts)];
    await payout.ref.update({ donationAmounts: unique, updatedAt: FieldValue.serverTimestamp() });
    return res.status(200).json({ saved: true, amounts: unique });
  } catch (error) { console.error('Donation options update failed', error); return res.status(error.status || 500).json({ error: error.status ? error.message : 'Could not save donation options.' }); }
});

exports.getDonationOptions = onRequest({ region: 'us-central1', maxInstances: 10 }, async (req, res) => {
  res.set('Cache-Control', 'no-store');
  if (req.method !== 'POST') return res.status(405).json({ error: 'POST required' });
  try {
    await authenticatedUser(req); const { creatorId } = req.body || {};
    if (typeof creatorId !== 'string') return res.status(400).json({ error: 'Creator is required.' });
    const payout = await getFirestore().collection('creatorPayouts').doc(creatorId).get();
    if (!payout.exists || payout.get('status') !== 'active') return res.status(503).json({ error: 'Donations are not enabled for this creator yet.' });
    const amounts = payout.get('donationAmounts') || [5000, 10000, 50000];
    return res.status(200).json({ amounts: amounts.filter(value => [5000, 10000, 50000].includes(value)) });
  } catch (error) { return res.status(error.status || 500).json({ error: error.status ? error.message : 'Donation options are unavailable.' }); }
});

exports.verifyDonationPayment = onRequest({ region: 'us-central1', secrets: [razorpayKeyId, razorpayKeySecret], maxInstances: 10 }, async (req, res) => {
  res.set('Cache-Control', 'no-store');
  if (req.method !== 'POST') return res.status(405).json({ error: 'POST required' });
  try {
    const user = await authenticatedUser(req);
    const { orderId, paymentId, signature } = req.body || {};
    if (typeof orderId !== 'string' || typeof paymentId !== 'string' || typeof signature !== 'string') return res.status(400).json({ error: 'Incomplete payment response.' });
    const expected = crypto.createHmac('sha256', razorpayKeySecret.value()).update(`${orderId}|${paymentId}`).digest('hex');
    const supplied = Buffer.from(signature, 'hex'); const calculated = Buffer.from(expected, 'hex');
    if (supplied.length !== calculated.length || !crypto.timingSafeEqual(supplied, calculated)) return res.status(400).json({ error: 'Payment signature did not verify.' });
    const db = getFirestore(); const orderRef = db.collection('paymentOrders').doc(orderId); const orderSnap = await orderRef.get();
    if (!orderSnap.exists || orderSnap.get('donorUid') !== user.uid) return res.status(403).json({ error: 'This payment order does not belong to this account.' });
    const payment = await razorpayRequest(`/payments/${encodeURIComponent(paymentId)}`);
    if (payment.order_id !== orderId || payment.amount !== orderSnap.get('amountPaise') || payment.currency !== 'INR' || payment.status !== 'captured') return res.status(409).json({ error: 'Gateway has not confirmed a captured payment. No earnings were recorded.' });
    const creatorId = orderSnap.get('creatorId'); const ledgerRef = db.collection('creatorEarnings').doc(creatorId).collection('transactions').doc(paymentId);
    const created = await db.runTransaction(async tx => {
      const [freshOrder, old] = await Promise.all([tx.get(orderRef), tx.get(ledgerRef)]);
      if (freshOrder.get('donorUid') !== user.uid) throw Object.assign(new Error('Order ownership changed.'), { status: 403 });
      if (freshOrder.get('paymentId') && freshOrder.get('paymentId') !== paymentId) throw Object.assign(new Error('This order already has a different verified payment.'), { status: 409 });
      if (!old.exists) tx.create(ledgerRef, { paymentId, orderId, creatorId, amountPaise: payment.amount, currency: 'INR', status: 'captured', createdAt: FieldValue.serverTimestamp() });
      if (freshOrder.get('status') !== 'verified') tx.update(orderRef, { status: 'verified', paymentId, verifiedAt: FieldValue.serverTimestamp() });
      return !old.exists;
    });
    return res.status(200).json({ verified: true, duplicate: !created, message: created ? 'Razorpay confirmed the captured payment. Settlement is still pending.' : 'This payment was already verified.' });
  } catch (error) {
    console.error('Donation verification failed', error);
    return res.status(error.status || 500).json({ error: error.status ? error.message : 'Payment verification service failed.' });
  }
});

exports.razorpayWebhook = onRequest({ region: 'us-central1', secrets: [razorpayWebhookSecret, razorpayKeyId, razorpayKeySecret], maxInstances: 10 }, async (req, res) => {
  if (req.method !== 'POST') return res.status(405).send('POST required');
  try {
    const signature = req.get('X-Razorpay-Signature') || '';
    const expected = crypto.createHmac('sha256', razorpayWebhookSecret.value()).update(req.rawBody).digest('hex');
    const a = Buffer.from(signature, 'hex'); const b = Buffer.from(expected, 'hex');
    if (!a.length || a.length !== b.length || !crypto.timingSafeEqual(a, b)) return res.status(401).send('Invalid signature');
    const event = JSON.parse(req.rawBody.toString('utf8')); const db = getFirestore();
    const transfer = event.payload?.transfer?.entity;
    let transfers = [];
    if (transfer && ['transfer.processed', 'transfer.failed', 'transfer.reversed'].includes(event.event)) transfers.push(transfer);
    if (event.event === 'settlement.processed') {
      const settlementId = event.payload?.settlement?.entity?.id;
      if (settlementId) {
        const found = await razorpayRequest(`/transfers?recipient_settlement_id=${encodeURIComponent(settlementId)}`);
        transfers = transfers.concat(found.items || []);
      }
    }
    for (const item of transfers) {
      const docs = await db.collectionGroup('transactions').where('paymentId', '==', item.source).limit(1).get();
      if (docs.empty) continue;
      const ledger = docs.docs[0]; const creatorId = ledger.ref.parent.parent?.id;
      if (!creatorId) continue;
      const status = item.status === 'failed' ? 'transfer_failed' : item.status === 'reversed' ? 'reversed' : item.settlement_status === 'settled' ? 'settled' : null;
      const patch = { transferId: item.id, transferStatus: item.status || 'pending', settlementStatus: item.settlement_status || 'pending', transferUpdatedAt: FieldValue.serverTimestamp() };
      if (status) patch.status = status;
      if (status === 'settled') patch.settledAmountPaise = Math.max(0, (item.amount || 0) - (item.fees || 0) - (item.tax || 0));
      await ledger.ref.set(patch, { merge: true });
      await db.collection('creatorEarnings').doc(creatorId).collection('payouts').doc(item.id).set({ transferId: item.id, paymentId: item.source, amountPaise: item.amount, settledAmountPaise: status === 'settled' ? Math.max(0, (item.amount || 0) - (item.fees || 0) - (item.tax || 0)) : null, currency: item.currency || 'INR', status: status || item.settlement_status || item.status || 'pending', createdAt: FieldValue.serverTimestamp() }, { merge: true });
    }
    return res.status(200).send('ok');
  } catch (error) { console.error('Razorpay webhook failed', error); return res.status(500).send('Webhook processing failed'); }
});

exports.generateVideo = onRequest(
  { region: 'us-central1', timeoutSeconds: 540, memory: '1GiB', secrets: [geminiApiKey], maxInstances: 2 },
  async (req, res) => {
    res.set('Cache-Control', 'no-store');
    if (req.method !== 'POST') return res.status(405).json({ error: 'POST required' });
    try {
      const match = /^Bearer (.+)$/.exec(req.get('Authorization') || '');
      if (!match) return res.status(401).json({ error: 'Sign-in required' });
      await getAuth().verifyIdToken(match[1], true);

      const { prompt, imageBase64, imageMimeType, aspectRatio, resolution } = req.body || {};
      if (typeof prompt !== 'string' || !prompt.trim() || prompt.length > 2000)
        return res.status(400).json({ error: 'Prompt must be between 1 and 2,000 characters' });
      if (!['16:9', '9:16'].includes(aspectRatio))
        return res.status(400).json({ error: 'Unsupported aspect ratio' });
      if (!['360p', '720p'].includes(resolution))
        return res.status(400).json({ error: 'Unsupported resolution' });

      const input = imageBase64
        ? [
            { type: 'image', data: imageBase64, mime_type: imageMimeType || 'image/jpeg' },
            { type: 'text', text: prompt.trim() },
          ]
        : prompt.trim();
      const payload = {
        model: 'gemini-omni-1.1-flash',
        input,
        response_format: { type: 'video', aspect_ratio: aspectRatio, resolution },
        background: false,
        store: false,
        stream: false,
      };
      if (imageBase64) payload.generation_config = { video_config: { task: 'image_to_video' } };

      const apiResponse = await fetch('https://generativelanguage.googleapis.com/v1beta/interactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-goog-api-key': geminiApiKey.value() },
        body: JSON.stringify(payload),
        signal: AbortSignal.timeout(510_000),
      });
      const responseText = await apiResponse.text();
      let interaction;
      try { interaction = JSON.parse(responseText); } catch (_) { interaction = null; }
      if (!apiResponse.ok) {
        console.error('Gemini video request failed', apiResponse.status, responseText.slice(0, 2000));
        return res.status(502).json({ error: interaction?.error?.message || 'Gemini video generation failed' });
      }
      const video = (interaction?.steps || [])
        .filter(step => step.type === 'model_output')
        .flatMap(step => step.content || [])
        .find(part => part.type === 'video' && part.data);
      if (interaction?.status !== 'completed' || !video?.data) {
        console.error('Gemini returned no inline completed video', interaction?.status, interaction?.id);
        return res.status(502).json({ error: 'The video API did not return a completed downloadable video. Please try again.' });
      }
      return res.status(200).json({ status: 'completed', interactionId: interaction.id, mimeType: video.mime_type || 'video/mp4', videoBase64: video.data });
    } catch (error) {
      console.error('Authenticated video generation failed', error);
      const code = error?.code === 'auth/id-token-revoked' || error?.code === 'auth/argument-error' ? 401 : 500;
      return res.status(code).json({ error: code === 401 ? 'Your sign-in session is no longer valid' : 'Video generation service failed. Check backend setup, quota, and billing.' });
    }
  }
);

// Public discovery only. The API key stays in Secret Manager and video playback
// always opens through the official YouTube app/site; no media is proxied.
exports.youtubeMoviesSearch = onRequest(
  { region: 'us-central1', timeoutSeconds: 30, secrets: [youtubeDataApiKey], maxInstances: 10 },
  async (req, res) => {
    res.set('Cache-Control', 'no-store');
    if (req.method !== 'POST') return res.status(405).json({ error: 'POST required' });
    try {
      const rawQuery = req.body?.query;
      if (typeof rawQuery !== 'string' || !rawQuery.trim() || rawQuery.length > 120)
        return res.status(400).json({ error: 'Enter a search term up to 120 characters.' });
      const searchUrl = new URL('https://www.googleapis.com/youtube/v3/search');
      searchUrl.search = new URLSearchParams({
        part: 'snippet', type: 'video', q: rawQuery.trim(), maxResults: '15',
        regionCode: 'IN', safeSearch: 'strict', videoEmbeddable: 'true', key: youtubeDataApiKey.value(),
      }).toString();
      const searchResponse = await fetch(searchUrl, { signal: AbortSignal.timeout(12000) });
      const searchPayload = await searchResponse.json();
      if (!searchResponse.ok) {
        console.error('YouTube search API failed', searchResponse.status, searchPayload?.error?.message);
        return res.status(502).json({ error: 'YouTube search is unavailable. Check API enablement, key restrictions, and quota.' });
      }
      const ids = (searchPayload.items || []).map(item => item.id?.videoId).filter(Boolean);
      if (!ids.length) return res.status(200).json({ items: [] });
      const detailUrl = new URL('https://www.googleapis.com/youtube/v3/videos');
      detailUrl.search = new URLSearchParams({
        part: 'snippet,status,contentDetails', id: ids.join(','), key: youtubeDataApiKey.value(),
      }).toString();
      const detailResponse = await fetch(detailUrl, { signal: AbortSignal.timeout(12000) });
      const detailPayload = await detailResponse.json();
      if (!detailResponse.ok) {
        console.error('YouTube video details API failed', detailResponse.status, detailPayload?.error?.message);
        return res.status(502).json({ error: 'YouTube video availability could not be checked.' });
      }
      const regionAllowed = restriction => {
        const regions = restriction?.regionRestriction;
        if (!regions) return true;
        if (Array.isArray(regions.allowed) && !regions.allowed.includes('IN')) return false;
        if (Array.isArray(regions.blocked) && regions.blocked.includes('IN')) return false;
        return true;
      };
      const items = (detailPayload.items || [])
        .filter(item => item.status?.privacyStatus === 'public' && item.status?.embeddable === true && regionAllowed(item.contentDetails))
        .map(item => ({
          videoId: item.id,
          title: String(item.snippet?.title || 'YouTube video').slice(0, 180),
          channelName: String(item.snippet?.channelTitle || 'YouTube channel').slice(0, 120),
          thumbnailUrl: item.snippet?.thumbnails?.high?.url || item.snippet?.thumbnails?.medium?.url || item.snippet?.thumbnails?.default?.url || '',
        }));
      return res.status(200).json({ items });
    } catch (error) {
      console.error('YouTube movie discovery failed', error);
      return res.status(500).json({ error: 'YouTube discovery failed. Try again later.' });
    }
  }
);

// All third-party search credentials stay server-side. Search is authenticated
// and rate-limited so the public Android client cannot spend the API balance
// without a signed-in Hira Bhai account.
exports.universalSearch = onRequest(
  { region: 'us-central1', timeoutSeconds: 20, secrets: [braveSearchApiKey], maxInstances: 10 },
  async (req, res) => {
    res.set('Cache-Control', 'no-store');
    if (req.method !== 'POST') return res.status(405).json({ error: 'POST required' });
    try {
      const user = await authenticatedUser(req);
      const query = typeof req.body?.query === 'string' ? req.body.query.trim() : '';
      const type = req.body?.type;
      const page = Number.isInteger(req.body?.page) ? req.body.page : 0;
      if (!query || query.length > 120 || !['web', 'apps', 'images', 'videos', 'news'].includes(type) || page < 0 || page > 9)
        return res.status(400).json({ error: 'Enter a search up to 120 characters, choose a supported search type, and use a page from 0 to 9.' });

      const db = getFirestore();
      const limitRef = db.collection('universalSearchLimits').doc(user.uid);
      const now = Date.now();
      const permitted = await db.runTransaction(async tx => {
        const snapshot = await tx.get(limitRef);
        const windowStart = snapshot.get('windowStart') || 0;
        const count = now - windowStart >= 60000 ? 0 : (snapshot.get('count') || 0);
        if (count >= 30) return false;
        tx.set(limitRef, { windowStart: count === 0 ? now : windowStart, count: count + 1, expiresAt: new Date(now + 86400000) });
        return true;
      });
      if (!permitted) return res.status(429).json({ error: 'Search limit reached. Wait a minute and try again.' });

      let apiKey;
      try { apiKey = braveSearchApiKey.value(); }
      catch (_) { return res.status(503).json({ error: 'Internet search is not configured. Add BRAVE_SEARCH_API_KEY to Firebase Functions secrets and deploy universalSearch.' }); }
      if (!apiKey) return res.status(503).json({ error: 'Internet search is not configured. Add BRAVE_SEARCH_API_KEY to Firebase Functions secrets and deploy universalSearch.' });

      const imageSearch = type === 'images';
      const endpoint = type === 'apps' || type === 'web' ? 'web' : type;
      const searchLanguage = /[\u0a80-\u0aff]/u.test(query) ? 'gu' : /[\u0900-\u097f]/u.test(query) ? 'hi' : 'en';
      const searchParams = {
        q: type === 'apps' ? `site:play.google.com/store/apps ${query}` : query,
        count: imageSearch ? '200' : '10', country: endpoint === 'web' ? 'IN' : 'ALL', safesearch: 'strict',
        search_lang: searchLanguage, ui_lang: `${searchLanguage}-IN`,
      };
      if (!imageSearch) searchParams.offset = String(page);
      const searchUrl = new URL(`https://api.search.brave.com/res/v1/${endpoint}/search`);
      searchUrl.search = new URLSearchParams(searchParams).toString();
      const response = await fetch(searchUrl, {
        headers: { Accept: 'application/json', 'X-Subscription-Token': apiKey },
        signal: AbortSignal.timeout(12000),
      });
      const payload = await response.json();
      if (!response.ok) {
        console.error('Brave Search API failed', response.status, payload?.error?.message);
        return res.status(502).json({ error: 'Internet search provider failed. Check the Brave API account and quota.' });
      }
      const rawItems = endpoint === 'web' ? (payload.web?.results || []) : (payload.results || []);
      const items = rawItems.map(item => {
        const url = imageSearch ? (item.url || item.properties?.url || '') : (item.url || '');
        let parsed;
        try { parsed = new URL(url); } catch (_) { return null; }
        if (parsed.protocol !== 'https:') return null;
        if (type === 'apps' && !(parsed.hostname === 'play.google.com' && parsed.pathname.startsWith('/store/apps'))) return null;
        const thumbnail = item.thumbnail || {};
        const video = item.video || {};
        return {
          type: type === 'apps' ? 'app' : type === 'images' ? 'image' : type === 'videos' ? 'video' : type === 'news' ? 'news' : 'web',
          title: String(item.title || 'Search result').slice(0, 180),
          description: String([item.description || item.alt || '', video.creator || item.source || ''].filter(Boolean).join(' · ')).slice(0, 500),
          url,
          thumbnailUrl: String(thumbnail.src || thumbnail.original || item.properties?.url || ''),
          source: String(item.meta_url?.hostname || item.source || parsed.hostname).slice(0, 100),
          published: String(item.age || item.page_age || '').slice(0, 80),
        };
      }).filter(Boolean);
      const hasMore = !imageSearch && payload.query?.more_results_available === true && page < 9;
      return res.status(200).json({ items, page, hasMore });
    } catch (error) {
      console.error('Universal internet search failed', error);
      return res.status(error.status || 500).json({ error: error.status ? error.message : 'Internet search failed. Try again later.' });
    }
  }
);

// AI answers use live Brave web snippets as bounded context. Both provider
// credentials stay in Secret Manager and are never sent to the Android client.
exports.aiSearch = onRequest(
  { region: 'us-central1', timeoutSeconds: 45, secrets: [geminiApiKey, braveSearchApiKey], maxInstances: 10 },
  async (req, res) => {
    res.set('Cache-Control', 'no-store');
    if (req.method !== 'POST') return res.status(405).json({ error: 'POST required' });
    try {
      const user = await authenticatedUser(req);
      const question = typeof req.body?.question === 'string' ? req.body.question.trim() : '';
      const rawHistory = Array.isArray(req.body?.history) ? req.body.history : [];
      if (!question || question.length > 1000 || rawHistory.length > 12)
        return res.status(400).json({ error: 'Enter a question up to 1,000 characters. Conversation context is limited to 12 messages.' });

      const db = getFirestore();
      const limitRef = db.collection('aiSearchLimits').doc(user.uid);
      const now = Date.now();
      const permitted = await db.runTransaction(async tx => {
        const snapshot = await tx.get(limitRef);
        const windowStart = snapshot.get('windowStart') || 0;
        const count = now - windowStart >= 60000 ? 0 : (snapshot.get('count') || 0);
        if (count >= 10) return false;
        tx.set(limitRef, { windowStart: count === 0 ? now : windowStart, count: count + 1, expiresAt: new Date(now + 86400000) });
        return true;
      });
      if (!permitted) return res.status(429).json({ error: 'AI search limit reached. Wait a minute and try again.' });

      const key = geminiApiKey.value();
      const braveKey = braveSearchApiKey.value();
      const language = /[\u0a80-\u0aff]/u.test(question) ? 'Gujarati' : /[\u0900-\u097f]/u.test(question) ? 'Hindi' : 'the same language as the question';
      const searchUrl = new URL('https://api.search.brave.com/res/v1/web/search');
      searchUrl.search = new URLSearchParams({ q: question, count: '8', country: 'IN', safesearch: 'moderate', search_lang: language === 'Gujarati' ? 'gu' : language === 'Hindi' ? 'hi' : 'en', ui_lang: language === 'Gujarati' ? 'gu-IN' : language === 'Hindi' ? 'hi-IN' : 'en-IN' }).toString();
      const searchResponse = await fetch(searchUrl, { headers: { Accept: 'application/json', 'X-Subscription-Token': braveKey }, signal: AbortSignal.timeout(12000) });
      const searchPayload = await searchResponse.json();
      if (!searchResponse.ok) {
        console.error('AI search web context failed', searchResponse.status, searchPayload?.error?.message);
        return res.status(502).json({ error: 'Web search could not provide context. Check the Brave API account and quota.' });
      }
      const sources = (searchPayload.web?.results || []).slice(0, 8).flatMap(item => {
        try {
          const parsed = new URL(item.url || '');
          if (parsed.protocol !== 'https:') return [];
          return [{ title: String(item.title || parsed.hostname).slice(0, 180), description: String(item.description || '').slice(0, 500), url: parsed.toString(), source: String(item.meta_url?.hostname || parsed.hostname).slice(0, 100) }];
        } catch (_) { return []; }
      });

      const history = rawHistory.slice(-12).flatMap(message => {
        if (!message || !['user', 'model'].includes(message.role) || typeof message.text !== 'string') return [];
        return [{ role: message.role, parts: [{ text: message.text.slice(0, 3000) }] }];
      });
      const context = sources.map((source, index) => `[${index + 1}] ${source.title}\nURL: ${source.url}\nSnippet: ${source.description}`).join('\n\n') || 'No web search results were found.';
      const prompt = `Answer the user's question in ${language}. Use the conversation and web results below. The web results are unverified search snippets, not authoritative proof. Do not claim facts are verified. Never invent a source or citation. If a claim is supported by a result, cite it inline using its exact number like [1]. If sources are missing or insufficient, say so plainly and answer cautiously from model knowledge. Return ONLY valid JSON with keys "answer" (string) and "relatedQuestions" (array of up to 3 short strings).\n\nWEB RESULTS:\n${context}\n\nCURRENT QUESTION:\n${question}`;
      const contents = [...history, { role: 'user', parts: [{ text: prompt }] }];
      const modelResponse = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent', {
        method: 'POST', headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key },
        body: JSON.stringify({ contents, generationConfig: { temperature: 0.3, maxOutputTokens: 1200, responseMimeType: 'application/json' } }),
        signal: AbortSignal.timeout(35000),
      });
      const modelPayload = await modelResponse.json();
      if (!modelResponse.ok) {
        console.error('Gemini AI search failed', modelResponse.status, modelPayload?.error?.message);
        return res.status(502).json({ error: 'AI answer service failed. Check the Gemini API key, model access, quota, and billing.' });
      }
      const text = (modelPayload.candidates?.[0]?.content?.parts || []).map(part => part.text || '').join('').trim();
      let generated;
      try { generated = JSON.parse(text); } catch (_) { return res.status(502).json({ error: 'AI answer returned an unreadable response. Please try again.' }); }
      const answer = typeof generated.answer === 'string' ? generated.answer.trim().slice(0, 10000) : '';
      if (!answer) return res.status(502).json({ error: 'AI answer was empty. Please try again.' });
      const relatedQuestions = Array.isArray(generated.relatedQuestions) ? generated.relatedQuestions.filter(value => typeof value === 'string').slice(0, 3).map(value => value.slice(0, 180)) : [];
      return res.status(200).json({ answer, relatedQuestions, sources });
    } catch (error) {
      console.error('AI universal search failed', error);
      return res.status(error.status || 500).json({ error: error.status ? error.message : 'AI search failed. Check provider configuration and try again.' });
    }
  }
);

// Generates website source code server-side. The generated page is previewed
// and hosted in a sandboxed iframe; no generated code receives app credentials.
exports.generateWebsite = onRequest(
  { region: 'us-central1', timeoutSeconds: 45, secrets: [geminiApiKey], maxInstances: 10 },
  async (req, res) => {
    res.set('Cache-Control', 'no-store');
    if (req.method !== 'POST') return res.status(405).json({ error: 'POST required' });
    try {
      const user = await authenticatedUser(req);
      const prompt = typeof req.body?.prompt === 'string' ? req.body.prompt.trim() : '';
      const template = ['portfolio', 'video', 'minimal', 'business', 'blog', 'landing'].includes(req.body?.template) ? req.body.template : 'portfolio';
      const palette = ['ocean', 'forest', 'sunset', 'violet'].includes(req.body?.palette) ? req.body.palette : 'ocean';
      const current = req.body?.current && typeof req.body.current === 'object' ? req.body.current : {};
      if (prompt.length < 5 || prompt.length > 1800) return res.status(400).json({ error: 'Describe the website change in 5–1,800 characters.' });
      if (['html', 'css', 'js'].some(key => typeof current[key] === 'string' && current[key].length > 70000)) return res.status(400).json({ error: 'Current website source is too large to regenerate.' });

      const db = getFirestore();
      const limitRef = db.collection('websiteGenerationLimits').doc(user.uid);
      const now = Date.now();
      const permitted = await db.runTransaction(async tx => {
        const snapshot = await tx.get(limitRef);
        const windowStart = snapshot.get('windowStart') || 0;
        const count = now - windowStart >= 60000 ? 0 : (snapshot.get('count') || 0);
        if (count >= 5) return false;
        tx.set(limitRef, { windowStart: count === 0 ? now : windowStart, count: count + 1, expiresAt: new Date(now + 86400000) });
        return true;
      });
      if (!permitted) return res.status(429).json({ error: 'AI website generation limit reached. Wait a minute and try again.' });

      const apiKey = geminiApiKey.value();
      const colors = { ocean: 'ocean blue and cyan', forest: 'forest green and mint', sunset: 'warm coral and amber', violet: 'deep violet and lavender' };
      const input = `Create or revise a mobile-responsive creator/business website using the user's instructions. Return source code, not an explanation. Output JSON only with keys html, css, js. html must be a BODY fragment, never a full document; css must be inline CSS for this fragment; js must be small progressive enhancement code. Use semantic accessible HTML, responsive layouts, clear navigation and well-written original content. Theme: ${colors[palette]}; layout: ${template}. Do not use external scripts, libraries, fonts, iframes, forms that submit data, network requests, storage, or any API keys. Do not use remote image URLs; use attractive CSS-only decorations and textual content. Preserve existing content and sections unless the request asks to change them. Keep html under 45,000 characters, css under 22,000, and js under 8,000.\n\nUSER REQUEST:\n${prompt}\n\nEXISTING HTML:\n${String(current.html || '').slice(0, 45000)}\n\nEXISTING CSS:\n${String(current.css || '').slice(0, 22000)}\n\nEXISTING JS:\n${String(current.js || '').slice(0, 8000)}`;
      const response = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent', {
        method: 'POST', headers: { 'Content-Type': 'application/json', 'x-goog-api-key': apiKey },
        body: JSON.stringify({ contents: [{ role: 'user', parts: [{ text: input }] }], generationConfig: { temperature: 0.65, maxOutputTokens: 12000, responseMimeType: 'application/json' } }),
        signal: AbortSignal.timeout(38000),
      });
      const payload = await response.json();
      if (!response.ok) {
        console.error('Website generation Gemini API failed', response.status, payload?.error?.message);
        return res.status(502).json({ error: 'Website generation failed. Check the Gemini API key, model access, quota, and billing.' });
      }
      const text = (payload.candidates?.[0]?.content?.parts || []).map(part => part.text || '').join('').trim();
      let source;
      try { source = JSON.parse(text); } catch (_) { return res.status(502).json({ error: 'AI returned invalid website source. Try regenerating with a shorter request.' }); }
      const html = typeof source.html === 'string' ? source.html : '';
      const css = typeof source.css === 'string' ? source.css : '';
      const js = typeof source.js === 'string' ? source.js : '';
      if (!html || html.length > 50000 || css.length > 24000 || js.length > 10000)
        return res.status(502).json({ error: 'Generated source was empty or exceeded safe size limits.' });
      return res.status(200).json({ html, css, js, model: 'gemini-2.5-flash' });
    } catch (error) {
      console.error('Website generation request failed', error);
      return res.status(error.status || 500).json({ error: error.status ? error.message : 'Website generation failed. Check backend configuration and try again.' });
    }
  }
);

// AI generated apps are compiled in short-lived Cloud Build workers. User Java
// source is the only user-controlled build input; Gradle files, dependencies,
// permissions, and build commands are generated and fixed by this service.
function reserveAiAppQuota(uid, kind, maxCount, windowMs) {
  const db = getFirestore();
  const ref = db.collection('aiAppLimits').doc(uid).collection('windows').doc(kind);
  const now = Date.now();
  return db.runTransaction(async tx => {
    const prior = await tx.get(ref);
    const start = prior.get('startedAt') || 0;
    const count = now - start >= windowMs ? 0 : (prior.get('count') || 0);
    if (count >= maxCount) return false;
    tx.set(ref, { startedAt: count === 0 ? now : start, count: count + 1, expiresAt: new Date(now + windowMs * 2) });
    return true;
  });
}

exports.generateAndroidApp = onRequest(
  { region: 'us-central1', timeoutSeconds: 60, secrets: [geminiApiKey], maxInstances: 10 },
  async (req, res) => {
    res.set('Cache-Control', 'no-store');
    if (req.method !== 'POST') return res.status(405).json({ error: 'POST required' });
    try {
      const user = await authenticatedUser(req);
      const prompt = typeof req.body?.prompt === 'string' ? req.body.prompt.trim() : '';
      const appName = typeof req.body?.appName === 'string' ? req.body.appName.trim().slice(0, 60) : 'My AI App';
      const packageName = req.body?.packageName;
      const template = ['counter', 'notes', 'checklist', 'contact', 'blank'].includes(req.body?.template) ? req.body.template : 'blank';
      const theme = ['teal', 'blue', 'orange', 'purple'].includes(req.body?.theme) ? req.body.theme : 'teal';
      const currentSource = typeof req.body?.currentSource === 'string' ? req.body.currentSource.slice(0, 40000) : '';
      if (prompt.length < 5 || prompt.length > 1800) return res.status(400).json({ error: 'Describe the app in 5–1,800 characters.' });
      if (!safePackageName(packageName)) return res.status(400).json({ error: 'Choose a valid Android package name.' });
      if (!await reserveAiAppQuota(user.uid, 'generation-minute', 4, 60000)) return res.status(429).json({ error: 'AI app generation is limited to 4 requests per minute.' });
      if (!await reserveAiAppQuota(user.uid, 'generation-day', 20, 86400000)) return res.status(429).json({ error: 'AI app generation is limited to 20 requests per account each day to control Gemini costs.' });
      const themeNames = { teal: 'teal', blue: 'blue', orange: 'orange', purple: 'purple' };
      const instruction = `Generate a complete, compilable native Android Java Activity for an app. Return JSON only with keys mainActivityJava and previewSpec. mainActivityJava must be a single Java source file for Android SDK 36, package @@PACKAGE@@, class MainActivity extends android.app.Activity, with onCreate and all required imports/helpers. Use native Android Views only; implement the described screens, navigation, buttons, forms and useful local in-memory behavior. Use accessible labels, touch-friendly controls and a polished responsive layout. Apply the ${themeNames[theme]} theme and use the ${template} starter idea. Preserve and revise the supplied source when present. Do not request permissions or access network, files, WebView, reflection, dynamic code loading, shell/process APIs, credentials, Firebase, or external libraries. Do not generate Gradle/build files. Keep source under 60,000 characters. previewSpec must be JSON with title, subtitle, fields (string array), items (string array), and primaryAction.\n\nAPP NAME: ${appName}\nUSER REQUEST: ${prompt}\nCURRENT JAVA SOURCE TO EDIT: ${currentSource}`;
      const response = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent', {
        method: 'POST', headers: { 'Content-Type': 'application/json', 'x-goog-api-key': geminiApiKey.value() },
        body: JSON.stringify({ contents: [{ role: 'user', parts: [{ text: instruction }] }], generationConfig: { temperature: 0.35, maxOutputTokens: 14000, responseMimeType: 'application/json' } }),
        signal: AbortSignal.timeout(50000),
      });
      const payload = await response.json();
      if (!response.ok) {
        console.error('Android source generation Gemini error', response.status, payload?.error?.message);
        return res.status(502).json({ error: 'Android source generation failed. Check the server Gemini key, model access, quota, and billing.' });
      }
      const text = (payload.candidates?.[0]?.content?.parts || []).map(part => part.text || '').join('').trim();
      let generated;
      try { generated = JSON.parse(text); } catch (_) { return res.status(502).json({ error: 'AI returned invalid Android source. Try a shorter description.' }); }
      let source = typeof generated.mainActivityJava === 'string' ? generated.mainActivityJava.trim() : '';
      if (!source || source.length > 60000 || !/\bclass\s+MainActivity\b/.test(source)) return res.status(502).json({ error: 'Generated Android source was empty, too large, or missing MainActivity.' });
      source = source.replace(/^\s*package\s+[A-Za-z0-9_.]+\s*;/m, `package ${packageName};`);
      if (!/^\s*package\s+[A-Za-z0-9_.]+\s*;/m.test(source)) source = `package ${packageName};\n\n${source}`;
      const preview = generated.previewSpec && typeof generated.previewSpec === 'object' ? generated.previewSpec : {};
      return res.status(200).json({ mainActivityJava: source, previewSpec: JSON.stringify(preview), model: 'gemini-2.5-flash' });
    } catch (error) {
      console.error('Android source generation failed', error);
      return res.status(error.status || 500).json({ error: error.status ? error.message : 'Android source generation failed. Check Firebase Functions and Gemini configuration.' });
    }
  }
);

async function googleCloudBuildRequest(method, url, body) {
  const auth = new GoogleAuth({ scopes: ['https://www.googleapis.com/auth/cloud-platform'] });
  const client = await auth.getClient();
  const response = await client.request({ url, method, data: body, timeout: 30000 });
  return response.data;
}

exports.startAndroidAppBuild = onRequest(
  { region: 'us-central1', timeoutSeconds: 90, maxInstances: 5 },
  async (req, res) => {
    res.set('Cache-Control', 'no-store');
    if (req.method !== 'POST') return res.status(405).json({ error: 'POST required' });
    try {
      const user = await authenticatedUser(req);
      const projectId = req.body?.projectId;
      if (typeof projectId !== 'string' || !/^[A-Za-z0-9_-]{1,120}$/.test(projectId)) return res.status(400).json({ error: 'Choose a saved app project first.' });
      const bucketName = aiAppBuildBucket.value().trim();
      const buildServiceAccount = aiAppBuildServiceAccount.value().trim();
      if (!bucketName || !buildServiceAccount) return res.status(503).json({ error: 'Cloud APK builds are not configured yet. Source export is available; the owner must set AI_APP_BUILD_BUCKET and AI_APP_BUILD_SERVICE_ACCOUNT and grant the documented Cloud Build permissions.' });
      const db = getFirestore();
      const projectRef = db.collection('aiAppProjects').doc(user.uid).collection('projects').doc(projectId);
      const snapshot = await projectRef.get();
      if (!snapshot.exists) return res.status(404).json({ error: 'Saved app project not found. Save it again, then retry.' });
      const app = snapshot.data();
      const packageName = app.packageName;
      const source = typeof app.mainActivityJava === 'string' ? app.mainActivityJava : '';
      if (!safePackageName(packageName) || !source.trim() || source.length > 80000 || !/\bclass\s+MainActivity\b/.test(source)) return res.status(400).json({ error: 'Project source is incomplete or invalid. Generate and save MainActivity source before building.' });
      const unsafe = sourceSafetyError(source);
      if (unsafe) return res.status(400).json({ error: unsafe });
      if (!await reserveAiAppQuota(user.uid, 'apk-build-day', 3, 86400000)) return res.status(429).json({ error: 'APK builds are limited to 3 per account each day to control cloud costs.' });
      const files = generatedAndroidFiles(app.name, packageName, source);
      const bucket = getStorage().bucket(bucketName);
      const buildKey = crypto.randomUUID();
      const sourceObject = `inputs/${user.uid}/${buildKey}.tar.gz`;
      const artifactPrefix = `outputs/${user.uid}/${buildKey}/`;
      const archive = tarGzip(files);
      if (archive.length > 2 * 1024 * 1024) return res.status(400).json({ error: 'Generated project exceeds the 2 MB source archive limit.' });
      await bucket.file(sourceObject).save(archive, { resumable: false, contentType: 'application/gzip', metadata: { cacheControl: 'private, no-store' } });
      const buildConfig = {
        source: { storageSource: { bucket: bucket.name, object: sourceObject } },
        steps: [{
          name: 'ghcr.io/cirruslabs/android-sdk:36@sha256:f9b3ea9ed2b5fc9522adae82c7b4622ab7aa54207ef532c8e615a347dca08f31',
          entrypoint: 'bash',
          args: ['-ceu', 'curl -fsSL https://services.gradle.org/distributions/gradle-9.7.1-bin.zip -o /tmp/gradle.zip && unzip -q /tmp/gradle.zip -d /tmp && /tmp/gradle-9.7.1/bin/gradle --no-daemon --stacktrace assembleDebug'],
          timeout: '1200s',
        }],
        timeout: '1200s',
        serviceAccount: buildServiceAccount,
        options: { logging: 'CLOUD_LOGGING_ONLY', machineType: 'E2_MEDIUM' },
        artifacts: { objects: { location: `gs://${bucket.name}/${artifactPrefix}`, paths: ['app/build/outputs/apk/debug/app-debug.apk'] } },
        tags: ['hira-bhai-ai-app', `uid-${user.uid.slice(0, 20)}`],
      };
      const projectNumber = process.env.GCLOUD_PROJECT || process.env.GCP_PROJECT;
      if (!projectNumber) throw new Error('Cloud Functions project ID is unavailable.');
      let created;
      try {
        created = await googleCloudBuildRequest('POST', `https://cloudbuild.googleapis.com/v1/projects/${projectNumber}/builds`, buildConfig);
      } catch (error) {
        await bucket.file(sourceObject).delete({ ignoreNotFound: true }).catch(() => {});
        const apiMessage = error.response?.data?.error?.message;
        console.error('Cloud Build submission failed', error.response?.status, apiMessage || error.message);
        return res.status(503).json({ error: `Could not start Cloud Build. Enable the Cloud Build API and grant the Functions service account builds.create plus actAs on the dedicated build service account. ${apiMessage || ''}`.trim() });
      }
      const jobRef = db.collection('aiAppBuildJobs').doc(user.uid).collection('jobs').doc(buildKey);
      await jobRef.set({ projectId, cloudBuildId: created.id, status: created.status || 'QUEUED', sourceObject, artifactPrefix, createdAt: FieldValue.serverTimestamp(), expiresAt: new Date(Date.now() + 30 * 86400000) });
      return res.status(200).json({ buildId: buildKey, cloudBuildId: created.id, status: created.status || 'QUEUED' });
    } catch (error) {
      console.error('Android APK build request failed', error);
      return res.status(error.status || 500).json({ error: error.status ? error.message : 'Could not start the APK build. Check Firebase Storage and Cloud Build permissions.' });
    }
  }
);

exports.androidAppBuildStatus = onRequest(
  { region: 'us-central1', timeoutSeconds: 45, maxInstances: 10 },
  async (req, res) => {
    res.set('Cache-Control', 'no-store');
    if (req.method !== 'POST') return res.status(405).json({ error: 'POST required' });
    try {
      const user = await authenticatedUser(req);
      const buildId = req.body?.buildId;
      if (typeof buildId !== 'string' || !/^[0-9a-f-]{36}$/i.test(buildId)) return res.status(400).json({ error: 'Invalid build ID.' });
      const db = getFirestore();
      const jobRef = db.collection('aiAppBuildJobs').doc(user.uid).collection('jobs').doc(buildId);
      const job = await jobRef.get();
      if (!job.exists) return res.status(404).json({ error: 'Build job not found for this account.' });
      const data = job.data();
      const project = process.env.GCLOUD_PROJECT || process.env.GCP_PROJECT;
      const build = await googleCloudBuildRequest('GET', `https://cloudbuild.googleapis.com/v1/projects/${project}/builds/${encodeURIComponent(data.cloudBuildId)}`);
      const status = build.status || 'UNKNOWN';
      let error = '';
      if (['FAILURE', 'INTERNAL_ERROR', 'TIMEOUT', 'CANCELLED', 'EXPIRED'].includes(status)) {
        error = (build.failureInfo?.detail || build.statusDetail || `Cloud Build ended with ${status}.`).toString().slice(0, 800);
      }
      let downloadUrl = '';
      if (status === 'SUCCESS') {
        const bucket = getStorage().bucket(aiAppBuildBucket.value().trim());
        const apk = bucket.file(`${data.artifactPrefix}app/build/outputs/apk/debug/app-debug.apk`);
        const [exists] = await apk.exists();
        if (exists) {
          const [url] = await apk.getSignedUrl({ action: 'read', expires: Date.now() + 15 * 60 * 1000, responseType: 'application/vnd.android.package-archive' });
          downloadUrl = url;
        } else {
          error = 'Cloud Build succeeded but the APK artifact was not found in the private build bucket.';
        }
      }
      await jobRef.update({ status, statusDetail: error, checkedAt: FieldValue.serverTimestamp() });
      if (['SUCCESS', 'FAILURE', 'INTERNAL_ERROR', 'TIMEOUT', 'CANCELLED', 'EXPIRED'].includes(status)) {
        await getStorage().bucket(aiAppBuildBucket.value().trim()).file(data.sourceObject).delete({ ignoreNotFound: true }).catch(() => {});
      }
      const steps = (build.steps || []).map((step, index) => ({ index: index + 1, status: step.status || 'QUEUED', name: (step.name || 'Android build').split('@')[0].split('/').pop() }));
      return res.status(200).json({ status, error, downloadUrl, steps });
    } catch (error) {
      console.error('Android APK build status failed', error);
      return res.status(error.status || 500).json({ error: error.status ? error.message : 'Could not retrieve Cloud Build status. Check Cloud Build and Storage permissions.' });
    }
  }
);
