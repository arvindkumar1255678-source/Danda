'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const zlib = require('node:zlib');
const { safePackageName, tarGzip, generatedAndroidFiles, sourceSafetyError } = require('../android-app-builder-core');

function untarGzip(input) {
  const tar = zlib.gunzipSync(input);
  const files = new Map();
  for (let offset = 0; offset + 512 <= tar.length;) {
    const header = tar.subarray(offset, offset + 512);
    if (header.every(byte => byte === 0)) break;
    const name = header.subarray(0, 100).toString('utf8').replace(/\0.*$/, '');
    const size = Number.parseInt(header.subarray(124, 136).toString('ascii').replace(/\0.*$/, '').trim(), 8);
    const checksumField = header.subarray(148, 156).toString('ascii').replace(/\0.*$/, '').trim();
    const sum = header.reduce((value, byte, i) => value + (i >= 148 && i < 156 ? 0x20 : byte), 0);
    assert.equal(Number.parseInt(checksumField, 8), sum, `tar checksum for ${name}`);
    const start = offset + 512;
    files.set(name, tar.subarray(start, start + size).toString('utf8'));
    offset = start + Math.ceil(size / 512) * 512;
  }
  return files;
}

test('package names accept normal app IDs and reject platform namespaces', () => {
  assert.equal(safePackageName('com.example.notes'), true);
  assert.equal(safePackageName('android.bad.app'), false);
  assert.equal(safePackageName('com..bad'), false);
});

test('fixed project archive contains native Java source and an SDK 36 launcher project', () => {
  const files = generatedAndroidFiles('Notes & Tasks', 'com.example.notes', 'package old.name;\npublic class MainActivity extends android.app.Activity {}');
  assert.equal(files['app/src/main/java/com/example/notes/MainActivity.java'].startsWith('package com.example.notes;'), true);
  assert.match(files['app/build.gradle'], /compileSdk 36/);
  assert.match(files['app/src/main/AndroidManifest.xml'], /android:name="android\.intent\.action\.MAIN"/);
  assert.match(files['app/src/main/AndroidManifest.xml'], /Notes &amp; Tasks/);
  const extracted = untarGzip(tarGzip(files));
  assert.equal(extracted.get('app/src/main/java/com/example/notes/MainActivity.java'), files['app/src/main/java/com/example/notes/MainActivity.java']);
  assert.equal(extracted.size, Object.keys(files).length);
});

test('archive builder rejects path traversal and source policy blocks dynamic execution APIs', () => {
  assert.throws(() => tarGzip({ '../escape': 'bad' }), /path is invalid/);
  assert.match(sourceSafetyError('Runtime.getRuntime().exec("id")'), /restricted/);
  assert.equal(sourceSafetyError('new android.widget.Button(this)'), '');
});
