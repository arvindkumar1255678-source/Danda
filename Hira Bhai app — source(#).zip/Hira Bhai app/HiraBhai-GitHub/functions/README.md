# Hira Bhai AI video backend

## AI App Builder and Cloud APK builds

The authenticated `generateAndroidApp` function uses Gemini 2.5 Flash to return a native Java `MainActivity` and a JSON preview spec. It accepts only the app prompt, selected built-in template/theme and existing Java source. The Gemini key stays in Secret Manager. Server quotas: 4 generation requests per account per minute and 20 per account per day. Generated source is private in `aiAppProjects/{uid}/projects`; deploy the Firestore rules in this repository before using save/load/manage.

`startAndroidAppBuild` reads the saved project for the signed-in UID and constructs a fixed Gradle project. It submits a pinned Android SDK 36 container to Google Cloud Build. User-controlled Java is compiled in an ephemeral Cloud Build worker; user Gradle files, plugins, dependencies, build scripts, annotation processors, credentials and permissions are never accepted. Restricted dynamic-code, process, network and WebView APIs are rejected. This is a safer compilation boundary, not a guarantee that arbitrary generated app source is harmless: users must review source before installing. The output is a debug-signed APK for testing, not a Play Store release. Builds are limited to 3 per account per rolling 24 hours. The returned APK link is private and expires after 15 minutes. Source archives are deleted after a terminal build status is checked; APKs remain in the private bucket until removed by the project owner.

### Required cloud setup

APK builds are not enabled until an owner configures these resources in the same Firebase project as `app/google-services.json`:

1. Use the Firebase Blaze plan, enable the Cloud Build, Cloud Storage, and IAM Credentials APIs, and create a dedicated, private, uniform-access bucket in `us-central1` for AI build input and output. Enforce Public Access Prevention and lifecycle rules that delete `inputs/` objects after 1 day and `outputs/` objects after 30 days. Enable Firestore TTL for `aiAppBuildJobs` documents on `expiresAt`. Do not reuse a bucket containing unrelated user data.
2. Create a dedicated Cloud Build service account. Give it only the permissions needed to read objects under `inputs/`, write objects under `outputs/`, and write build logs. Prefer IAM Conditions restricting its object access to those prefixes. It receives no Firebase, Secret Manager, or user-data permissions. The configured build image is pinned to an immutable digest; Gradle and Maven still need outbound access to download public build dependencies.
3. Give the deployed Functions runtime identity only Cloud Build build-create/build-get permissions, `serviceusage.services.use`, permission to act as the dedicated build service account, and object create/get/delete access to the dedicated bucket. Allow it to sign short-lived URLs for its own service identity (or configure a dedicated signer). Do not grant project-wide Owner or Editor roles to either service account.
4. Set the Functions string parameters `AI_APP_BUILD_BUCKET` to the bucket name and `AI_APP_BUILD_SERVICE_ACCOUNT` to the full service-account resource name. Firebase CLI prompts for missing `defineString` parameters during deployment; alternatively use a project-specific functions `.env` file and keep it out of source control.
5. Set `GEMINI_API_KEY` in Firebase Secret Manager, install backend dependencies, and deploy both Functions and Firestore rules:

   ```sh
   firebase functions:secrets:set GEMINI_API_KEY --project hira-bhai
   cd functions && npm install && cd ..
   firebase deploy --only functions,firestore:rules --project hira-bhai
   ```

Firebase Functions, Cloud Build minutes, Cloud Storage, logging, Gemini generation and dependency downloads can incur charges. Amounts depend on usage, region, selected billing plan and current provider pricing. Configure budget alerts and review Google Cloud and Gemini billing before enabling builds for users. If Cloud Build is not configured, source export remains available and the app reports that APK generation is unavailable; it never claims an APK succeeded without a successful Cloud Build result and an existing APK artifact.

### Source export and local preview

The app can export a complete native Android source ZIP without Cloud Build. The preview screen renders a small UI mock from Gemini's preview specification; the generated Java source is the real app implementation. Forms and basic interactions are supported; this first build pipeline deliberately excludes generated network, filesystem, Firebase, WebView, and permission-based features. Exported projects use Android SDK 36 and the workspace's Android Gradle Plugin version. Build a release APK only after reviewing the source and configuring your own signing key.

## AI Search Assistant

The Home search `AI Answer` tab calls the authenticated `aiSearch` HTTPS function. It fetches live Brave web snippets, sends those snippets plus the recent conversation to Gemini 2.5 Flash, and returns an answer, related questions, and the exact source links. The answer is marked AI-generated; snippets are not represented as verified facts. Both provider keys remain Firebase Secrets and are never placed in the APK.

Configure both secrets and deploy the function:

```sh
firebase functions:secrets:set GEMINI_API_KEY --project PROJECT_ID
firebase functions:secrets:set BRAVE_SEARCH_API_KEY --project PROJECT_ID
firebase deploy --only functions:aiSearch --project PROJECT_ID
```

The Firebase project needs Cloud Functions billing (Blaze). Gemini API usage has model-specific free-tier availability and paid token rates; Brave Search API is billed separately. See [Gemini API pricing](https://ai.google.dev/gemini-api/docs/pricing) and [Brave Search API plans](https://brave.com/search/api/). This function is authenticated and limits AI Search to 10 requests per account per minute. Set budget alerts and inspect provider quotas before enabling broad access.

The Android app sends requests to `generateVideo` with a Firebase Authentication ID token. The function verifies that token, calls Gemini Omni Flash from the server, and returns the completed MP4. The Gemini API key is read only from Firebase Secret Manager; it is never compiled into the APK or returned to the app.

## Setup and deploy

1. Install the Firebase CLI and sign in, then select the same Firebase project used by `app/google-services.json` (`firebase use <project-id>`).
2. Enable billing for the Firebase project. Cloud Functions deployment and Gemini video generation require a billing-enabled project; Gemini Omni Flash has no free API tier.
3. In Google AI Studio, create a Gemini API key with access to Gemini Omni Flash. Store it as a Firebase secret:

   ```sh
   firebase functions:secrets:set GEMINI_API_KEY
   ```

4. Install the backend packages and deploy:

   ```sh
   cd functions
   npm install
   cd ..
   firebase deploy --only functions
   ```

The callable endpoint is in `us-central1`; the Android client derives its URL from the configured Firebase project ID. Requests require a signed-in Firebase account. The function is limited to two concurrent instances and a 9-minute runtime; check usage and set billing alerts before sharing the feature.

## Model limits and charges

The current request uses the stable `gemini-omni-1.1-flash` model. It supports text-to-video and reference-image-to-video, landscape/portrait ratios, and 360p/720p here. Model output is a short 3–10 second clip; the API does not provide a fixed duration selector for this request, so the app does not pretend to offer one. Current published Standard pricing is about **US$0.10 per second of 720p video** and video generation has no free tier. Prices and availability can change; check Gemini API pricing before enabling the function.

The UI shows an indeterminate wait indicator while the synchronous request runs; Gemini does not provide percentage completion in this implementation. If the backend is not deployed, the API key/billing is missing, or the model rejects a prompt, the app shows the service error and creates no placeholder video.

## Security note

The function checks Firebase ID tokens with Firebase Admin before using the secret. Do not make the endpoint anonymous or move `GEMINI_API_KEY` into Android resources. For production rollout, add per-user daily quotas and abuse monitoring appropriate to your audience.
# Hira Bhai live streaming setup

The Android app uses LiveKit WebRTC for live audio/video. Firebase Auth verifies
the caller; these HTTPS functions issue room-scoped JWTs and Admin SDK writes
the `liveStreams` catalog. Firestore stores metadata/chat only; it does not
transport video. The app contains no LiveKit API secret.

1. Create a LiveKit Cloud project and copy its WebSocket URL, API key, and API
   secret from the project settings.
2. Link Firebase to the Blaze plan (Cloud Functions deployment requires a
   billing account), then set backend secrets:

   ```sh
   firebase functions:secrets:set LIVEKIT_API_KEY
   firebase functions:secrets:set LIVEKIT_API_SECRET
   firebase functions:secrets:set LIVEKIT_URL
   ```

3. Install function dependencies and deploy:

   ```sh
   cd functions && npm install && cd ..
   firebase deploy --only functions,firestore:rules
   ```

4. In LiveKit Cloud, add a webhook pointing to
   `https://us-central1-PROJECT_ID.cloudfunctions.net/livekitWebhook`, select
   `room_finished`, and sign it with the same LiveKit API key. This updates a
   stream record if the broadcaster disconnects unexpectedly and the room
   expires.
5. Deploy `deleteAccount` with the other functions. It requires a recently
   reauthenticated Firebase ID token, removes the user profile, preferences,
   subscriptions, creator videos/files, related comments/likes/notifications,
   LiveKit rooms, and finally the Firebase Auth account. Configure the default
   Firebase Storage bucket because account cleanup removes stored media.
6. Rebuild and distribute the Android app with the matching Firebase
   `google-services.json` project. Sign in, create a creator profile, and grant
   camera/microphone access to start broadcasting.

The LiveKit Build plan currently includes 5,000 participant minutes, 50 GB
downstream transfer, 100 concurrent participants, and 60 transcode minutes;
free-plan quotas are hard caps. Media usage is metered by participant time and
data transfer. Firebase Functions requires Blaze; Firebase currently lists
monthly no-cost allowances for 2 million invocations, compute, and 5 GB egress,
then usage is billed. Set budget alerts/spend caps. Live recording/replay is not
enabled by this integration; LiveKit Egress supports MP4/HLS but needs an
additional recording destination and its own usage/configuration.
