// Fill in your own Firebase Web App configuration before deployment.
// Do not commit private service-account credentials or provider secrets.
window.HIRA_FIREBASE_CONFIG = {
  apiKey: "YOUR_FIREBASE_WEB_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.firebasestorage.app",
  appId: "YOUR_FIREBASE_WEB_APP_ID"
};
