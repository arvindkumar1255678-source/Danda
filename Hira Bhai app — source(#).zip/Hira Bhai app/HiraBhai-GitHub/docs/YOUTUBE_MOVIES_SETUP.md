# YouTube Movies Home section

The Home Page discovers real YouTube videos through a Firebase HTTPS Function. It asks YouTube Data API v3 for video search results, then checks `status.embeddable`, public status, and any India region restriction before returning only video IDs, titles, channel names, and thumbnail URLs. The APK contains no YouTube Data API key and never downloads or proxies movie media.

Playback launches the official YouTube app using a YouTube video URI, with the official YouTube watch page as fallback. YouTube controls playback, account/Premium requirements, age gates, and availability. `status.embeddable=true` is not a playback guarantee: YouTube documents that policy or Content ID claims can still block an embedded player. Search results therefore are not a statement that Hira Bhai verified a movie's copyright license or that a full movie is free.

## Configure and deploy

1. In Google Cloud Console, enable **YouTube Data API v3** for the project and create an API key. Restrict the key to YouTube Data API v3.
2. Add the key as a Firebase Functions secret; never put it in Android resources, `BuildConfig`, or Firestore:

   ```sh
   firebase functions:secrets:set YOUTUBE_DATA_API_KEY --project hira-bhai
   ```

3. Deploy the discovery function:

   ```sh
   firebase deploy --only functions:youtubeMoviesSearch --project hira-bhai
   ```

The function searches India-region results with strict SafeSearch and `videoEmbeddable=true`; it confirms public and embeddable status using `videos.list` and filters explicit India region restrictions. The YouTube app/site remains authoritative for the viewer's actual age and geographic access.

YouTube's documented default quota currently includes 100 `search.list` requests per day and a separate 10,000 units/day pool for other Data API methods. Every movie search makes one search request and one batched video-details request; repeated searches consume quota. Check the Google Cloud Console quota page and request a quota audit/extension if needed.
