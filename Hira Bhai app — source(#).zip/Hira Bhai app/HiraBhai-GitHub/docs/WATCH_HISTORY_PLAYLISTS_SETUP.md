# Watch history, Watch Later, and playlists

The app stores watch history and Watch Later under `userActivity/{Firebase UID}`. Only that signed-in UID can read, update, or delete those records. History stores the last playback position and duration; the player saves while playing and when paused or closed, then offers resume when reopened. Clearing history removes those private records; saved Watch Later videos are separate.

Playlists use `userPlaylists/{UID}/playlists/{playlistId}` as the private source of truth. Playlist items use the video ID as their document ID, which prevents duplicates. Private playlists can contain videos the owner can access; public playlists can contain public videos only. Public playlists are mirrored to `publicPlaylists/{playlistId}` without the owner's Firebase UID, and appear on the creator's public profile. Users can reorder items in the playlist screen and play a playlist sequentially. Playlists hold up to 200 videos.

Publish the Firestore rules and public-profile playlist index before using these features in Firebase. The account deletion Cloud Function also removes private activity, private playlist trees, and public playlist projections:

```sh
firebase deploy --only firestore:rules,firestore:indexes,functions:deleteAccount --project hira-bhai
```

The deployment was not run from this workspace. Without publishing these rules and index, Firestore may reject the new reads and writes.
