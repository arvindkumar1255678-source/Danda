# Home search and movie catalog setup

## Internet, image, and app search

The app keeps third-party credentials on Firebase Functions; no Brave key is included in the APK. Home has `All`, `Websites`, `Images`, `Videos`, `News`, and `Apps` filters. Brave results render in the Home search panel, and tapping a result opens it in Hira Bhai Browser. If the provider fails, the error stays on Home instead of redirecting to a different search page. Hindi (Devanagari), Gujarati, and English scripts are sent with matching search-language hints. Apps are real Brave web results restricted to official Google Play listing URLs. Suggestions shown while typing and recent searches are on-device; Brave Autosuggest is a separate paid plan/key and is not currently enabled.

The `universalSearch` function requires a signed-in, active Hira Bhai account and limits each account to 30 provider requests per minute. The Home live-search debounce can use provider calls as the user pauses typing; each settled search uses quota. If the secret or function is missing, the app displays the backend error rather than presenting fake results.

1. Create a Brave Search API account and API key.
2. Enable Firebase Functions billing if required by the Firebase project, then set the secret:

   ```sh
   firebase functions:secrets:set BRAVE_SEARCH_API_KEY --project hira-bhai
   ```

3. Deploy the backend and Firestore changes:

   ```sh
   firebase deploy --only functions:universalSearch,functions:youtubeMoviesSearch,firestore:rules,firestore:indexes --project hira-bhai
   ```

Brave currently lists Search at **$5 per 1,000 requests** and includes **$5 in monthly credits**. It requires an activated API plan and payment-card verification; it is not a standalone free tier. Search plan supports web, image, news, and video search. Apps use a web query filtered to `play.google.com`. The separately licensed Autosuggest plan is needed before turning on Brave-powered autocomplete. Check Brave's dashboard for live spend limits and current terms. [Brave API plans](https://brave.com/search/api/), [API authentication](https://api-dashboard.search.brave.com/documentation/guides/authentication), and [Autosuggest plan details](https://api-dashboard.search.brave.com/documentation/services/suggest).

YouTube results continue through the existing `youtubeMoviesSearch` function and `YOUTUBE_DATA_API_KEY` secret. Enable YouTube Data API v3, set the secret, and deploy the function. The default YouTube Data API quota allows **100 `search.list` requests per day**; every search consumes a request, so Home live search can exhaust that quota. [YouTube quota limits](https://developers.google.com/youtube/v3/determine_quota_cost).

Google Custom Search JSON API is closed to new customers and is scheduled to discontinue on **January 1, 2027**; existing customers should migrate. [Google availability and pricing](https://developers.google.com/custom-search/v1/overview).

## Movie catalog

The app reads up to 100 `published` documents from Firestore `/movies`. The project source had no movie catalog records, so the app starts with an empty catalog rather than invented titles. A user with the Firebase custom claim `platformAdmin: true` can add, edit, and remove entries in the app. The create screen refuses entries above the 100-item limit and requires a source/license URL, HTTPS poster and playback URLs, category, language, genre, and year. Firestore rules restrict catalog writes to platform admins and only expose the explicit movie metadata fields to public readers.

Grant that claim only from the trusted Admin SDK tool described in [ADMIN_MODERATION_SETUP.md](ADMIN_MODERATION_SETUP.md); do not grant it from an app client.

Use `licenseType` as one of `public_domain`, `licensed`, or `official_youtube`; only add records after checking their source and playback rights. Hira Bhai opens the supplied official HTTPS playback URL and does not download or re-upload media. No movie is seeded automatically because this project contains no verified license/source list.

TMDB can provide metadata/posters for non-commercial projects with attribution, but its own terms say commercial projects must contact it for a commercial license. Hira Bhai includes monetization features, so this app does not import TMDB data without that license. [TMDB API FAQ](https://developer.themoviedb.org/docs/faq).

## Firestore video search permissions

The shipped `firestore.rules` already permits list queries only when they constrain `/videos.visibility == 'public'`; document reads allow public/unlisted items and the creator's own items. Private documents remain owner-only. The Home query uses that public filter, and the video metadata schema contains creator display fields and storage paths, not private profile records. The Firebase Emulator Suite verified that the public-only query succeeds, guest/stranger reads of private videos fail, and the owner can read their private video. It also verified that movie writes are admin-only and published metadata is public. The Firebase CLI is available through npm, but this workspace is not logged into Firebase (`projects:list` fails authentication), so the actual Firebase project's currently published rules could not be read or deployed. Run `firebase login` in an authenticated environment, then deploy the reviewed `firestore.rules` using the command above to verify the live project.
