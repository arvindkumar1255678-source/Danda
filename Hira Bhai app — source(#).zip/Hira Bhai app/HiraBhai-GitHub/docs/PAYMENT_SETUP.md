# Creator donations and earnings setup

The app includes Razorpay Checkout, server-created payment orders, callback signature checks, a server-side captured-payment lookup, an idempotent Firestore earnings ledger, and signed Route settlement webhook handling. It stays unavailable until the production backend and merchant accounts are configured.

## Required account and infrastructure setup

1. Activate a Razorpay merchant account for Hira Bhai and complete the business verification/KYC requested by Razorpay. Enable Payment Gateway and Razorpay Route for marketplace transfers. Route linked accounts must be onboarded and verified by Razorpay.
2. Enable Firebase billing for deployed Cloud Functions. The functions create orders and verify payments; they are part of the trusted payment path. Check current Firebase Functions and Firestore usage charges for the project.
3. Set the production API Key ID and API Key Secret as Firebase Functions secrets. Never add the secret to Android resources, source constants, or `google-services.json`.
4. Set a separate Razorpay webhook secret. Configure the Razorpay webhook URL to `https://us-central1-<firebase-project-id>.cloudfunctions.net/razorpayWebhook` and subscribe to `transfer.processed`, `transfer.failed`, `transfer.reversed`, and `settlement.processed`.
5. Deploy the updated Firestore rules and the payment functions. Ensure the Razorpay account has automatic payment capture enabled; the verification endpoint deliberately rejects authorized-but-not-captured payments.
6. After each creator completes Route linked-account onboarding, an authorized operator must add `/creatorPayouts/{creatorId}` using Admin SDK or a trusted admin tool, with the verified `accountId` (`acc_…`) and `status: "active"`. Client writes are denied. Do not accept arbitrary payout account IDs from the app.

Set secrets with Firebase CLI (`firebase functions:secrets:set RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, and `RAZORPAY_WEBHOOK_SECRET`) and deploy the three donation endpoints plus webhook. The key ID is returned to the app only after the backend has validated the creator's active linked account.

The creator can then configure which of the supported ₹50, ₹100, and ₹500 donation suggestions appear. This does not alter gateway keys or payout destinations. A donation order includes one Route transfer to the already verified creator linked account.

## Payment status and records

Firestore payment orders and creator payout configuration are backend-only. The owner can read their own transaction and payout history; app clients cannot create or change earnings. Earnings count as estimated after the gateway confirms capture and as finalized only after the Route settlement record reports a settled transfer. Razorpay webhook signature verification uses the raw request body. Duplicate verification callbacks resolve to the existing payment ledger row.

## Fees and approval

Razorpay merchant activation, Route access, linked-account acceptance, and KYC are account-specific and may require review. Razorpay currently publishes a standard Payment Gateway platform fee of 2% plus 18% GST on that fee; Route transfers have their own charges and applicable GST. Offers and account terms can change, so confirm the rate and settlement schedule in the merchant dashboard before launch. Firebase Functions deployment requires a billing-enabled Firebase project; usage is billed separately by Google Cloud.

See [Razorpay pricing](https://razorpay.com/pricing/), [Razorpay Route](https://razorpay.com/route/), and [Razorpay security checklist](https://razorpay.com/security/checklist/).
