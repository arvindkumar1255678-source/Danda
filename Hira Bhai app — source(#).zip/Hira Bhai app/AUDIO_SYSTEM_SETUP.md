# Hira Bhai audio system setup

Audio bytes are uploaded to Firebase Storage at `audio/{visibility}/{creatorId}/{audioId}/{audio|cover}`. Firestore metadata is stored in `audios/{audioId}`. Public and unlisted objects can be read by their visibility; private objects require the creator's authenticated UID. Playback progressively reads from Firebase Storage through its authenticated SDK and does not request or store public download-token URLs.

Playback uses a Media3 media session service for background audio and system media controls. Play queue order comes from the currently displayed list; shuffle is available in the player. Music playlists are not persisted as a separate playlist type yet; existing video playlists remain unchanged.

The Home Feed Music tab and Music screen show current public uploads. Title and artist search uses normalized prefix matching. Trending counts are recorded by the authenticated `recordAudioPlay` Cloud Function with one count per UID/track per 30 seconds, then the `trendingAudio` function returns currently public tracks only. These counts are playback starts, not verified listening duration or royalties.

Before production use, publish the Firestore and Storage Rules and indexes and deploy the two audio functions plus the existing account deletion function:

```sh
firebase deploy --only firestore:rules,firestore:indexes,storage,functions:recordAudioPlay,functions:trendingAudio,functions:deleteAccount --project hira-bhai
```

Firebase CLI authentication is required. Cloud Storage for Firebase requires the Blaze billing plan; actual storage, download, and function usage may incur charges. Set billing alerts and confirm the project's current regional prices/quotas in Firebase/Google Cloud. Deployment was not performed from this workspace.
